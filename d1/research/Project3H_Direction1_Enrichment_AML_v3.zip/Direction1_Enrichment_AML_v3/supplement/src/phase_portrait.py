"""Reproduce the inherited P4 phase portrait and its two data tables."""

import csv
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import numpy as np
from scipy.integrate import solve_ivp
from scipy.special import expit

ROOT = Path(__file__).resolve().parents[1]
BLUE, TEAL, RED, GOLD, INK = "#225683", "#007c70", "#a23d2e", "#d3993a", "#202c35"
plt.rcParams.update(
    {
        "font.size": 9,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "axes.labelcolor": INK,
        "text.color": INK,
        "pdf.fonttype": 42,
        "font.family": "DejaVu Sans",
        "savefig.facecolor": "white",
    }
)


def write_csv(name, rows):
    with (ROOT / name).open("w", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def save_figure(fig, name):
    for ext in ["pdf", "png"]:
        fig.savefig(
            ROOT / "figures" / f"{name}.{ext}",
            dpi=220,
            bbox_inches="tight",
            pad_inches=0.12,
        )
    plt.close(fig)


def phase_portrait():
    # The positive-quadrant samples reproduce the original P4 example.
    a, c, d = 0.8, 8 / 15, 0.2
    rho = (a / d - 1) / c

    def rhs(t, logstate):
        lx, ly = logstate
        f = expit(-(np.log(c) + ly - lx))
        x = np.exp(lx)
        return np.array([(1 + x / 2) * (1 - x / 8) - (a / c) * (1 - f), a * f - d])

    def direction(x, y):
        p = a * x / (x + c * y)
        return x * (1 + x / 2) * (1 - x / 8) - y * p, y * (p - d)

    seeds = [
        ("C1", 5.8, 30.0),
        ("C2", 4.0, 20.0),
        ("C3", 7.0, 32.0),
        ("E1", 0.005, 0.5),
        ("E2", 0.08, 0.65),
        ("E3", 0.15, 1.0),
    ]
    eqx = 3 + np.sqrt(7)
    eqy = rho * eqx
    fig, axes = plt.subplots(1, 2, figsize=(8.8, 3.85), layout="constrained")
    for ax, xmax, ymax in zip(axes, [8.3, 0.20], [45.0, 1.15]):
        xx, yy = np.meshgrid(
            np.linspace(xmax / 25, xmax * 0.98, 16),
            np.linspace(ymax / 25, ymax * 0.98, 13),
        )
        u, v = direction(xx, yy)
        magnitude = np.hypot(u / xmax, v / ymax)
        ax.quiver(
            xx,
            yy,
            u / magnitude,
            v / magnitude,
            angles="xy",
            scale_units="xy",
            color="#78858f",
            alpha=0.39,
            scale=26,
            width=0.003,
            pivot="mid",
        )
        ax.set(
            xlim=(0, xmax),
            ylim=(0, ymax),
            xlabel="Prey density x",
            ylabel="Predator density y",
        )
    axes[0].set_title("A   Full phase plane", loc="left", weight="bold")
    axes[1].set_title("B   Near the origin", loc="left", weight="bold")
    rows = []
    ends = []
    times = np.linspace(0, 240, 481)
    for label, x0, y0 in seeds:

        def trajectory(rtol, atol, max_step):
            sol = solve_ivp(
                rhs,
                [0, times[-1]],
                np.log([x0, y0]),
                method="DOP853",
                t_eval=times,
                rtol=rtol,
                atol=atol,
                max_step=max_step,
            )
            assert sol.success and len(sol.t) == len(times)
            return np.exp(sol.y)

        uv = trajectory(2e-9, 1e-11, 0.5)
        refined = trajectory(2e-11, 1e-13, 0.25)
        u, v = uv
        distance = max(abs(u[-1] - eqx) / eqx, abs(v[-1] - eqy) / eqy)
        near_positive = distance < 1e-6
        near_origin = u[-1] < 1e-8 and v[-1] < 1e-8
        assert near_positive != near_origin
        color = TEAL if near_positive else RED
        for ax in axes:
            ax.plot(u, v, color=color, lw=1.8)
            ax.plot(x0, y0, "o", mfc="white", mec=color, ms=4)
        rows.extend(dict(seed=label, t=t, x=x, y=y) for t, x, y in zip(times, u, v))
        ends.append(
            dict(
                seed=label,
                x0=x0,
                y0=y0,
                T_end=times[-1],
                x_end=u[-1],
                y_end=v[-1],
                observed_endpoint="coexistence" if near_positive else "near origin",
                relative_distance_to_positive_eq=distance,
                max_cross_solver_scaled_difference=np.max(
                    np.abs(uv - refined) / (1 + np.abs(refined))
                ),
            )
        )
    saddle = 3 - np.sqrt(7)
    axes[0].scatter(eqx, eqy, c=TEAL, edgecolor="white", s=62, zorder=4)
    axes[0].scatter(saddle, rho * saddle, marker="x", color=INK, s=35)
    axes[0].annotate(
        "saddle",
        (saddle, rho * saddle),
        xytext=(11, 0),
        textcoords="offset points",
        fontsize=8,
    )
    for ax in axes:
        ax.plot(0, 0, "s", color=RED, ms=4, clip_on=False)
    axes[0].legend(
        handles=[
            Line2D([], [], c=TEAL, label="Toward coexistence"),
            Line2D([], [], c=RED, label="Toward extinction"),
            Line2D(
                [], [], ls="", marker="o", mfc="white", mec=INK, label="Initial state"
            ),
        ],
        frameon=False,
        loc="upper left",
        fontsize=8,
    )
    write_csv("data/phase_trajectories.csv", rows)
    write_csv("data/phase_endpoints.csv", ends)
    save_figure(fig, "03_phase_portraits")
    return ends


if __name__ == "__main__":
    for name in ("data", "figures"):
        (ROOT / name).mkdir(exist_ok=True)
    phase_portrait()
