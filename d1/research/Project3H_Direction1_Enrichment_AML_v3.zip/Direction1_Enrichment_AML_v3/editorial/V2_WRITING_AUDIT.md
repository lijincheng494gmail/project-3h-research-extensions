# Direction 1 · Anti-defensive writing audit

**Manuscript reviewed** · *A curvature criterion for enrichment under ratio-dependent predation*, version 2, with Supplement S1–S4. This is an editorial review of the five-page letter and its three-page supplement. The attached writing guide supplied the review criteria. Its Direction 3 examples involve a different study.

**Verdict.** The abstract states the equivalence and the Holling II construction directly. The proof reports strictness at zero curvature, all three possible derivative signs when curvature is negative, and the stability of the nearby equilibria. The main editorial issue arises after these findings, where repeated reminders about local scope displace a more informative statement. Three passages in the letter merit attention.

## Recommended changes in order of importance

| Location | Editorial decision | Suggested wording |
|---|---|---|
| Main PDF p. 5, numerical section, final two sentences | Replace the generic possibility of other trajectories with the result actually proved in S4. Specify the growth law so readers can distinguish the basin example from the two-crossing model. | “In a separate P4 model with an affine growth factor, Supplement S4 proves that stable coexistence and extinction each have an open basin of attraction.” |
| Main PDF p. 3, immediately after Corollary 2 | The corollary already fixes the intake and the proof ends with the attracting and repelling foci. Remove the two recap sentences. The outstanding nonlinear question currently appears both here and in S2. State it once for the explicit smooth example, at the end of S2 or in a short further discussion. | “For the smooth example, the first Lyapunov coefficient at each crossing remains to be determined.” |
| Main PDF p. 4, after the formula for the second crossing | Express the stronger conclusion proved by the monotonicity and range of the branch parameterization. | “Both crossings lie on the unique positive equilibrium branch.” |

**One precision edit in the introduction.** The first sentence uses prey per predator, whereas the equations use predators per prey. The two ratios are reciprocals at positive coexistence. Use the manuscript's convention consistently and state how the unique ratio is determined. “At a positive coexistence equilibrium, a strictly decreasing intake fixes the predator-to-prey ratio through the break-even condition $p(y/x)=d/e$.”

**Two optional improvements.** In the abstract, the sentence reporting what the proof identifies could give its sign result directly. “When reciprocal curvature is negative, Holling II intakes can give a negative, zero, or positive trace derivative at the same prey density.” In Supplement S4, “Open basins of coexistence and extinction in a P4 model” would give readers the proved result in the heading.

## What the wording needs to preserve

- The theorem quantifies over every admissible intake and realizable positive-determinant equilibrium at a prescribed density. Each derivative follows a branch in the original time variable with only carrying capacity varying.
- On the zero-curvature boundary the trace derivative remains strictly negative. At a negative-curvature density, the classical instability construction asserts existence of a suitable fixed intake. A claim about all fixed intakes at that density would change the theorem.
- In the explicit example, the trace crosses zero at $3/2$ and $8/(3\sqrt3)$, and the determinant stays positive. Stability at either critical capacity and nonlinear bifurcation type require separate analysis. The first Lyapunov coefficient question above refers to this smooth example.
- In the original five-model application, P1/P2 have increasing trace under the stated assumptions and P4 has decreasing trace for the increasing affine growth factor. P0/P3 admit either sign even in the matched comparison. The logistic control has zero slope. S4 proves extinction and coexistence basins for a separate parameter set and growth factor.
- Figure 1 compares admissible loads across models and base capacities. Figure 2 varies capacity within one fixed model. The corresponding captions appropriately keep those conditions visible.

**Audit sources in this archive.** Line numbers refer to the [v2 manuscript](Manuscript_v2.tex) and [v2 supplement](Supplement_v2.tex). The [numerical checks](../data/stability_checks.json) apply to both versions.

## Sentence-level decisions

Locations below use TeX source line numbers. Displayed derivations and numeric tables are reviewed with their surrounding prose. Reference entries are bibliographic metadata. KEEP includes substantive negative statements and hypotheses needed to interpret the results. The proposed actions apply to a future language revision.

### Main manuscript, title through Theorem 1

| Location | Original sentence | Classification | Issue | Action |
|---|---|---|---|---|
| L9 | A curvature criterion for enrichment under ratio-dependent predation | INTERPRETATION | Names both the criterion and the model class. | KEEP |
| L12 | Increasing prey carrying capacity can change the stability of a predator--prey equilibrium. | INTERPRETATION | Introduces the ecological question. | KEEP |
| L12 | Suppose the prey per-capita growth rate is $g(x)(1-x/K)$, where $g$ is positive and $g'>0$. | ESSENTIAL CONDITION | Specifies the growth law in the abstract. | KEEP |
| L12 | We prove that, at a prescribed prey density, enrichment strictly decreases the Jacobian trace at every positive-determinant coexistence equilibrium realized by an admissible ratio-dependent intake if and only if $(1/g)''\geq0$ at that density. | FINDING | States the pointwise equivalence and the positive-determinant restriction. | KEEP |
| L12 | The proof identifies exactly which consumption loads a predator can impose there. | FINDING | Highlights a proof step without giving its outcome. Consider using this space to state that Holling II intakes realize negative, zero, and positive trace derivatives at a negative-curvature density. | REWRITE |
| L12 | At every point where the inequality fails, a classical ratio-dependent Holling II intake can be chosen so that coexistence loses local stability as $K$ increases. | FINDING | The existential wording is essential. The construction selects an intake for each density. | KEEP |
| L12 | An explicit example exhibits both the loss and the subsequent recovery of stability along a single branch. | FINDING | States both changes along one branch. | KEEP |
| L17 | The enrichment question | INTERPRETATION | Identifies the question motivating the letter. | KEEP |
| L18 | A predator whose feeding rate depends on the prey-to-predator ratio fixes this ratio at coexistence \cite{arditi}. | INTERPRETATION | The paper uses the predator-to-prey ratio $y/x$. Its reciprocal is also fixed, but switching conventions obscures the break-even condition. Suggested wording follows. “At positive coexistence, the predator break-even condition fixes the predator-to-prey ratio for a strictly decreasing ratio-dependent intake.” Retain the citation. | REWRITE |
| L18 | If the prey per-capita growth rate depends only on $x/K$, where $K$ is carrying capacity, the equilibrium value of $x/K$ is also fixed. | INTERPRETATION | Explains the scaling premise behind the comparison. | KEEP |
| L18 | Kuang proved that the equilibrium then retains its local stability as $K$ varies \cite[Theorem~2.1]{kuang}. | FINDING | Attributes the published local stability result. | KEEP |
| L18 | Feng and Li analyzed the same scaling in an interference model with logistic growth \cite{feng}. | INTERPRETATION | Identifies the scope of a related study. | KEEP |
| L18 | When prey growth contains a factor that depends on absolute density, the same scaling argument no longer applies. | INTERPRETATION | Identifies where the earlier scaling argument ceases to apply. | KEEP |
| L20 | For ratio-dependent Holling II intake, Sen et al. studied enrichment with an Allee effect \cite{sen}. | INTERPRETATION | Locates the relevant enrichment study. | KEEP |
| L20 | Gao and Li proved that the equilibrium trace decreases at a zero on the upper coexistence branch for a strong Allee growth law with an affine factor \cite[Proposition~2.3(ii)]{gao}. | FINDING | The restriction to a zero of the trace on the upper branch is material. | KEEP |
| L20 | Flores and Gonz\'alez-Olivares analyzed a nonaffine growth factor with the same rational intake \cite{flores}. | INTERPRETATION | Identifies previous work on nonaffine growth. | KEEP |
| L20 | Wu and Liu obtained a Hopf bifurcation under a mate-finding growth law \cite{wu}. | FINDING | Reports the cited nonlinear bifurcation result. | KEEP |
| L20 | General ratio-dependent equilibrium Jacobians are also available \cite[Sec.~4]{kiss}. | INTERPRETATION | Acknowledges the known Jacobian analysis. | KEEP |
| L20 | Here we ask which local condition on prey growth determines the \emph{direction of change} of the trace for every admissible intake. | INTERPRETATION | States the pointwise and universal research question. | KEEP |
| L20 | We also ask whether failure of that condition can produce actual loss of stability within the classical Holling II family. | INTERPRETATION | Distinguishes the sign of a derivative from a change in stability. The word ‘actual’ can be omitted. | REWRITE |
| L22 | The pointwise criterion | INTERPRETATION | Names the mathematical object. | KEEP |
| L23 | In the original time variable the equations are | ESSENTIAL CONDITION | Introduces system (1), lines 25–26. The time convention determines the trace derivative. | KEEP |
| L28 | Fix $e,d>0$ and $s$ in an open interval $I\subset(0,\infty)$. | ESSENTIAL CONDITION | Sets the parameter and density domains. | KEEP |
| L28 | Assume $g\in C^2(I)$ with $g,g'>0$. | ESSENTIAL CONDITION | Specifies differentiability, positivity, and strict positive growth slope. | KEEP |
| L28 | An admissible intake is a positive strictly decreasing $p\in C^1(0,\infty)$. | ESSENTIAL CONDITION | Defines the class quantified over in the theorem. | KEEP |
| L28 | Write $T$ and $\Delta$ for the equilibrium Jacobian trace and determinant. | ESSENTIAL CONDITION | Defines the two local quantities. | KEEP |
| L28 | Along each branch, $K$ alone varies. | ESSENTIAL CONDITION | Identifies the perturbation and fixes the intake along each branch. | KEEP |
| L28 | The prescribed prey density $s$ specifies the point at which the derivative is evaluated. | ESSENTIAL CONDITION | Distinguishes the base density from the varying equilibrium density. | KEEP |
| L31 | The following statements are equivalent at $s$. | FINDING | Introduces the two directions of the theorem. | KEEP |
| L33 | For every admissible $p$, every $K_0>0$, and every $v>0$ such that $(s,v)$ is an equilibrium of \eqref{sys} at $K_0$ with $\Delta>0$, its local branch satisfies $dT/dK<0$ at $K_0$. | ESSENTIAL CONDITION | Each universal quantifier, positive determinant, and the branch derivative are essential. | KEEP |
| L34 | $(1/g)''(s)\geq0$. | FINDING | The weak inequality includes zero curvature. | KEEP |
| L36 | If $(1/g)''(s)<0$, all three signs of $dT/dK$ are realizable at $s$ with Holling II intakes. | FINDING | The negative, zero, and positive derivatives are all proved. | KEEP |
| L39 | The positive predator equation fixes $\rho=y/x$ by $p(\rho)=d/e$. | FINDING | Identifies the fixed equilibrium ratio. | KEEP |
| L39 | Write $Q=\rho d/e$ for consumption per unit prey density. | ESSENTIAL CONDITION | Defines the load and its scale. | KEEP |
| L39 | Then $q=Q$ and $0<x<K$. | FINDING | Shows how the load bounds the positive prey equilibrium. | KEEP |
| L39 | With $p'_*=p'(\rho)$, differentiation of the Cartesian equations gives | FINDING | Introduces the Cartesian Jacobian, trace, and determinant displayed in lines 41–44. | KEEP |
| L46 | Strict decrease allows a flat tangent, but $\Delta>0$ forces $p'_*<0$ and $q_x<0$. | ESSENTIAL CONDITION | Strict monotonicity permits a horizontal tangent. Positive determinant excludes it at the chosen equilibrium. | KEEP |
| L46 | The implicit function theorem applied to $q=Q$ gives a unique local branch with $x_K=-q_K/q_x>0$. | FINDING | Derives existence, uniqueness, and the direction of the branch. | KEEP |
| L48 | Set $E=xg'/g$ and $D=g-(1+E)Q$. | ESSENTIAL CONDITION | Defines elasticity and the determinant-related quantity. | KEEP |
| L48 | Substitution of $x/K=1-Q/g$ gives $xq_x=-D$. | FINDING | Connects the per-capita slope to the determinant sign. | KEEP |
| L48 | The ratio and the intake slope at that ratio stay fixed on the branch. | ESSENTIAL CONDITION | Identifies which terms are constant when differentiating. | KEEP |
| L48 | Hence | FINDING | Introduces the branch and trace derivatives in line 50. | KEEP |
| L52 | Evaluate $g,E$ and their derivatives at $s$. | ESSENTIAL CONDITION | Fixes the point of evaluation. | KEEP |
| L52 | Since $D>0$, the load lies in $(0,U)$, where $U=g/(1+E)$. | FINDING | Derives the open load interval. | KEEP |
| L52 | Conversely every $Q$ in this interval is realized by | FINDING | Introduces the explicit realization in lines 54–55. The converse is essential to necessity. | KEEP |
| L57 | Indeed, $U<g$, $p(\rho)=d/e$, and $p'(\rho)<0$. | FINDING | Checks finiteness, the break-even value, and the slope. | KEEP |
| L57 | Equation~\eqref{jac} gives $\Delta>0$ at $(s,\rho s)$. | FINDING | Verifies admissibility at the realized state. | KEEP |
| L59 | The sign of $T_K$ is the sign of $L(Q)=QE'-g'$. | FINDING | Reduces the sign problem to one affine function. | KEEP |
| L59 | This affine function has endpoint values | FINDING | Introduces the endpoint computations in lines 61–62. | KEEP |
| L64 | When reciprocal curvature is nonnegative, interpolation gives $L(Q)<0$ throughout the open interval. | FINDING | Proves the sufficient direction on the open interval. | KEEP |
| L64 | Equality of the curvature still gives strict decrease because $Q=U$ has zero determinant. | FINDING | Explains why the branch derivative is strictly negative even at zero curvature. | KEEP |
| L64 | If curvature is negative, $L(U)>0$, $E'>0$, and $Q_c=g'/E'$ lies strictly inside $(0,U)$. | FINDING | Establishes the interior threshold when curvature is negative. | KEEP |
| L64 | Loads below, at, and above $Q_c$ in \eqref{realize} give a negative, zero, and positive derivative, respectively. | FINDING | Proves all three sign possibilities in the stated order. | KEEP |

### Main text, sections 3–5, methods, and declaration

| Location | Original sentence | Classification | Issue | Action |
|---|---|---|---|---|
| L67 heading | Sharpness within the Holling II family | INTERPRETATION | Names the response family in which sharpness is proved. | KEEP |
| L69.1 | At every $s$ with $(1/g)''(s)<0$, there are $a,c,K_0>0$ such that the fixed intake $p(z)=a/(1+cz)$ gives a transverse loss of local stability at a positive equilibrium with prey density $s$ as $K$ passes through $K_0$. | FINDING | Preserves the existential parameter choice at every failed curvature point and fixes the response during enrichment. | KEEP |
| L72.1 | Choose $\max\{Q_c,g/(2+E)\}<Q<U$ at $s$. | ESSENTIAL CONDITION | Specifies the interval used to choose a realizable load. | KEEP |
| L72.2 | Both lower bounds are strictly below $U$. | FINDING | Establishes that the interval is nonempty. | KEEP |
| L72.3 | Then $0<D<Q$ and $T_K>0$ for every regular realization of this load. | FINDING | Derives the two strict inequalities needed for the construction. | KEEP |
| L72.4 | Use $\rho$ and $K_0$ from \eqref{realize}. | ESSENTIAL CONDITION | Links the load to the equilibrium ratio and carrying capacity. | KEEP |
| L72.5 | To set $T=0$, equation~\eqref{jac} requires $p'(\rho)=-(Q-D)/[\rho(\rho+e)]$. | ESSENTIAL CONDITION | Determines the required response slope. | KEEP |
| L72.6 | Define $p(z)=\frac{d/e}{1+k(z-\rho)},\qquad k=\frac{e(Q-D)}{d\rho(\rho+e)}.$ | FINDING | Constructs the intake explicitly. | KEEP |
| L77.1 | This fixes both the intake value and its required slope. | FINDING | Identifies the value and slope matched by the construction. | KEEP |
| L77.2 | Moreover, $0<k\rho=\frac{\rho}{\rho+e}\left(1-\frac{D}{Q}\right)<1.$ | FINDING | Proves the inequality that makes the intake admissible for all nonnegative ratios. | KEEP |
| L81.1 | Thus $a=(d/e)/(1-k\rho)$ and $c=k/(1-k\rho)$ are positive, and the intake is bounded, smooth, and strictly decreasing on $[0,\infty)$. | FINDING | Verifies positivity and regularity over the declared domain. | KEEP |
| L81.2 | At $K_0$, $T=0$ and $\Delta>0$. | FINDING | States the critical trace and determinant. | KEEP |
| L81.3 | In a neighborhood the eigenvalues are complex conjugates with real part $T/2$. | FINDING | Identifies the real part in a neighborhood of the crossing. | KEEP |
| L81.4 | By \eqref{slope} they cross the imaginary axis with positive speed. | FINDING | Establishes transverse crossing. | KEEP |
| L81.5 | The equilibrium is an attracting focus just below $K_0$ and a repelling focus just above it. | FINDING | Gives the proved local stability types on both sides. | KEEP |
| L83.1 | The corollary fixes the intake before $K$ is varied. | REDUNDANT QUALIFICATION | The corollary already specifies a fixed intake and a varying capacity. | DELETE |
| L83.2 | It gives a local stability change. | REDUNDANT QUALIFICATION | The preceding sentence of the proof already identifies the attracting and repelling foci. | DELETE |
| L83.3 | A nondegenerate Hopf classification would also require nonlinear information. | LIMITATION | Consolidate with Supplement S2. For the explicit smooth example, evaluating the first Lyapunov coefficient at each crossing would test Hopf nondegeneracy. | MOVE |
| L85 heading | Consequences for predation mechanisms | INTERPRETATION | Introduces the five-model application. | KEEP |
| L86.1 | For $g=r(1+\alpha x)$, $r,\alpha>0$, reciprocal curvature equals $2\alpha^2/[r(1+\alpha x)^3]>0$. | FINDING | Calculates curvature for the original growth factor. | KEEP |
| L86.2 | Theorem~\ref{th} therefore gives a decreasing trace on every positive-determinant branch for ratio-dependent predation, including Holling II (P4). | FINDING | States the scope of the decreasing-trace result. | KEEP |
| L86.3 | An initial increase of the prey per-capita growth rate itself requires $\alpha K>1$. | ESSENTIAL CONDITION | Distinguishes the initial growth slope from the curvature condition. | KEEP |
| L86.4 | For the logistic control $\alpha=0$, \eqref{slope} gives $T_K=0$ directly. | FINDING | Reports the zero-slope logistic control, outside the strict growth-derivative assumption. | KEEP |
| L88.1 | For prey-dependent consumption $yf(x)$, the predator equation instead fixes a prey density $u$ with $f(u)=d/e$, $f'(u)>0$. | ESSENTIAL CONDITION | Sets the break-even condition and identifies which density is fixed. | KEEP |
| L88.2 | At coexistence $T=uq_x+(1-uf'/f)q$, with all terms evaluated at $u$. | FINDING | Gives the equilibrium trace and its evaluation point. | KEEP |
| L88.3 | At fixed $u$ this gives $T_K=\frac{ug(u)}{K^2}\left[2+\frac{ug'(u)}{g(u)}-\frac{uf'(u)}{f(u)}\right].$ | FINDING | Derives the slope for prey-dependent consumption. | KEEP |
| L92.1 | For increasing concave $f$ with $f(0)=0$, $uf'(u)\le f(u)$, so the sign is positive. | FINDING | States the concavity assumption that determines the slope sign. | KEEP |
| L92.2 | Mass action (P1) and prey-dependent Holling II (P2) satisfy these assumptions. | ESSENTIAL CONDITION | Identifies the prey-dependent models covered. | KEEP |
| L92.3 | The mixed intake $ax/(1+bx+cy)$ with $c>0$ gives the foraging-arena model (P0) when $b=0$ and the Beddington--DeAngelis model (P3) when $b>0$. | ESSENTIAL CONDITION | Defines both mixed-intake families. | KEEP |
| L92.4 | Both share the affine equilibrium relation $cy=(ea/d-b)x-1$. | FINDING | Gives their shared equilibrium condition. | KEEP |
| L92.5 | In both models the trace can increase or decrease even at the same equilibrium with the same growth factor $g=1+x$. | FINDING | Reports both signs under matched conditions. | KEEP |
| L92.6 | The supplement gives examples matched at $x=y=1$ and $K=2$. | INTERPRETATION | Locates the examples and specifies the shared density and capacity. | KEEP |
| L94 heading | A fixed-response stability crossing | INTERPRETATION | The section traces loss and recovery. The plural “Two stability crossings with a fixed Holling II intake” would signal both findings. | REWRITE |
| L95.1 | For $g=1+x^2$, reciprocal curvature is $(6x^2-2)/(1+x^2)^3$. | FINDING | Gives the exact curvature of the example growth law. | KEEP |
| L95.2 | Figure~\ref{fig:region} shows which loads give each trace direction. | INTERPRETATION | Links the calculation to the feasible-load diagram. | KEEP |
| L95.3 | At $s=1/2$ choose $Q=5/6$, $e=d=1$. | ESSENTIAL CONDITION | Sets the density, load and predator parameters. | KEEP |
| L95.4 | Corollary~\ref{cor} gives $D=1/12$, $k=27/55$, and the classical intake $p(z)=\frac{110}{65+54z}.$ | FINDING | Specifies the rational response for the calculation. | KEEP |
| L99–101.1 | The equilibrium at $K_0=3/2$ is $(1/2,5/12)$. | FINDING | Gives the exact critical state. | KEEP |
| L99–101.2 | Its Jacobian is $\left(\begin{smallmatrix}9/22 & -13/22\\15/44&-9/22\end{smallmatrix}\right)$, so $T=0$ and $\Delta=3/88$. | FINDING | Supplies the Cartesian matrix and its critical trace and determinant. | KEEP |
| L99–101.3 | Along the branch $x_K=5/3$ and $T_K=1/9$ at this point. | FINDING | Reports the exact branch and trace derivatives. | KEEP |
| L105.1 | Admissible loads lie below the solid curve $U=(1+x^2)^2/(1+3x^2)$. | FINDING | Gives the feasible upper bound for the loads. | KEEP |
| L105.2 | The dashed curve $Q_c=(1+x^2)^2/2$ separates increasing and decreasing traces on the negative-curvature side. | FINDING | Identifies which boundary separates the signs in the feasible negative-curvature region. | KEEP |
| L105.3 | The dotted line has zero reciprocal curvature. | FINDING | Locates the zero-curvature boundary. | KEEP |
| L105.4 | The circle marks $(1/2,5/6)$. | FINDING | Identifies the base point of the example. | KEEP |
| L105.5 | Each admissible interior point represents a choice of model and base capacity. | ESSENTIAL CONDITION | Clarifies that different admissible points can represent different models. | KEEP |
| L108–112 | For this fixed intake the whole positive branch satisfies $y=5x/6,\quad K(x)=\frac{6x(1+x^2)}{1+6x^2},\quad T(x)=-\frac{(3x^2-1)(4x^2-1)}{12(1+x^2)},\quad \Delta(x)=\frac{3}{88}-\frac{9}{22}T(x).$ | FINDING | Parametrizes the entire positive branch. | KEEP |
| L114.1 | Here $K'(x)=6(1-3x^2+6x^4)/(1+6x^2)^2>0$, $K(x)\to0$ as $x\downarrow0$, and $K(x)\to\infty$. | FINDING | Strict monotonicity and the two endpoint limits give uniqueness for each positive capacity. | KEEP |
| L114.2 | Equations~\eqref{jac} and $K'>0$ give $\Delta>0$ throughout. | FINDING | Checks the determinant on the whole branch. | KEEP |
| L114.3 | As $K$ increases past $3/2$, the trace changes from negative to positive. | FINDING | Reports the first crossing and its direction. | KEEP |
| L114.4 | At $x=1/\sqrt3$, or $K=8/(3\sqrt3)$, it becomes negative again. | FINDING | Reports the second crossing and its direction. | KEEP |
| L114.5 | This second crossing occurs exactly at zero reciprocal curvature, where the exact slope is $-3\sqrt3/32$, in agreement with Theorem~\ref{th}. | FINDING | Connects the second crossing with equality in the curvature theorem. | KEEP |
| L114.6 | Neither crossing requires a switch of equilibrium branch. | FINDING | State the stronger result already proved. “Both crossings lie on the unique positive equilibrium branch.” | REWRITE |
| L118.1 | Fixed Holling II intake with only $K$ varied. | ESSENTIAL CONDITION | Specifies the fixed intake and the sole varying parameter. | KEEP |
| L118.2 | Panel (a) shows the trace multiplied by $10^3$. | ESSENTIAL CONDITION | Preserves the axis multiplier. | KEEP |
| L118.3 | The open circles mark $K=3/2$ and $K=8/(3\sqrt3)$. | FINDING | Identifies both critical capacities. | KEEP |
| L118.4 | Panel (b) gives the positive determinant on the same branch. | ESSENTIAL CONDITION | Directs the reader to the determinant for the same branch. | KEEP |
| L118.5 | The equilibrium is locally unstable strictly between the two crossings and locally stable on the two outer intervals. | FINDING | Classifies the three open intervals without assigning nonlinear stability at either critical point. | KEEP |
| L121.1 | The growth law here differs from the affine-factor P4 application. | ESSENTIAL CONDITION | Clarifies the change in growth law relative to the P4 application. | KEEP |
| L121.2 | In the plotted range $K<\sqrt3$ and $q_x\le K/3-1/K<0$ at every positive density. | ESSENTIAL CONDITION | Quantifies monotonicity of the per-capita prey growth at every positive density over the plotted range. | KEEP |
| L121.3 | Thus the local loss of stability is compatible with a prey per-capita growth rate that decreases with density. | INTERPRETATION | Interprets the result under the stated growth condition. | KEEP |
| L121.4 | Figure~\ref{fig:cross} uses 162 capacities. | FINDING | Supplies the numerical sample count. | KEEP |
| L121.5 | A scalar bracketed solve and an independent solve of the two Cartesian equilibrium equations agreed within $4.3\times10^{-15}$ in either coordinate. | ESSENTIAL CONDITION | Reports the agreement between independent equilibrium solves. | KEEP |
| L121.6 | Direct eigenvalue calculations at $K=1.48$, $1.52$, and $1.56$ gave real parts $-0.001386$, $0.000667$, and $-0.002988$, respectively. | FINDING | Reports independent eigenvalue checks on all three intervals. | KEEP |
| L121.7 | These are local results for coexistence. | REDUNDANT QUALIFICATION | Local stability already appears in the corollary and figure caption. | DELETE |
| L121.8 | Distant trajectories may approach other invariant sets. | DEFENSIVE LANGUAGE | Replace the speculation with the demonstrated result from the separate affine-growth P4 example. “Supplement S4 gives a P4 model with an affine growth factor in which coexistence and extinction each have an open basin of attraction.” | REWRITE |
| L123 heading | Computational methods and data availability | ESSENTIAL CONDITION | Identifies the software and availability statement. | KEEP |
| L124.1 | The supplementary files contain the equilibrium data, executable checks, and plotting scripts. | ESSENTIAL CONDITION | Identifies the reproducibility files. | KEEP |
| L124.2 | Matplotlib 3.10.8 drew the curves from explicit equations and computed equilibria. | ESSENTIAL CONDITION | States the plotting method and software version. | KEEP |
| L124.3 | OpenAI Codex (GPT-6, OpenAI) assisted in writing the Python analysis and plotting programs. | ESSENTIAL CONDITION | Reports assistance with computational implementation. | KEEP |
| L125 heading | Declaration of generative AI use | ESSENTIAL CONDITION | Identifies the disclosure. | KEEP |
| L126.1 | OpenAI Codex assisted with developing and checking the mathematical arguments, comparing published results, and drafting and revising the manuscript. | ESSENTIAL CONDITION | Discloses assistance with the mathematical development, literature comparison, and writing. | KEEP |

### Supplementary material

Adjacent displays and numeric tables appear as evidence rows. The invariant-wedge sentence spans lines 77–82 and is identified on both sides of its display.

| Location | Original sentence or displayed evidence | Classification | Issue or reason to retain | Action |
|---|---|---|---|---|
| Supplement, lines 5–6 | Supplementary mathematics and numerical evidence\\[2pt] \large A curvature criterion for enrichment under ratio-dependent predation | INTERPRETATION | Identifies the supplement and parent study. | KEEP |
| Supplement, line 9 | S1. An independent coordinate calculation | INTERPRETATION | Names the calculation or comparison. | KEEP |
| Supplement, line 10 | Put $z=y/x$ in the positive quadrant without changing time. | ESSENTIAL CONDITION | Preserves the positive-domain chart and the original time scale. | KEEP |
| Supplement, line 10 | Writing $q=g(x)(1-x/K)$ gives | ESSENTIAL CONDITION | Defines the growth term used in the transformation. | KEEP |
| Supplement, lines 11–13 | \[ \dot x=x(q-zp),\qquad \dot z=z[(e+z)p-d-q]. \] | FINDING | Transformed equations used in the derivation. | KEEP |
| Supplement, line 14 | At $p(\rho)=d/e$, $Q=\rho d/e=q$, the Jacobian in $(x,z)$ is | ESSENTIAL CONDITION | Specifies the equilibrium where the next matrix is evaluated. | KEEP |
| Supplement, lines 15–18 | \[ \begin{pmatrix}xq_x&-x[p(\rho)+\rho p'(\rho)]\\ -\rho q_x&\rho[p(\rho)+(e+\rho)p'(\rho)]\end{pmatrix}. \] | FINDING | Ratio-coordinate Jacobian at coexistence. | KEEP |
| Supplement, line 19 | The derivative of the coordinate change has rows $(1,0)$ and $(-\rho/x,1/x)$ at the equilibrium. | FINDING | States the invertible coordinate differential. | KEEP |
| Supplement, line 19 | Conjugation by this invertible matrix recovers the Cartesian trace and determinant in the letter. | FINDING | Gives the independent coordinate check. | KEEP |
| Supplement, line 19 | The substitution is used only in the interior. | REDUNDANT QUALIFICATION | The first sentence of S1 already restricts the transformation to the positive quadrant. | DELETE |
| Supplement, line 19 | With $D=g-(1+E)Q$, $E=xg'/g$, the branch can be parameterized by | ESSENTIAL CONDITION | Defines the variables in the branch formula. | KEEP |
| Supplement, lines 20–22 | \[ K(x)=\frac{xg(x)}{g(x)-Q},\qquad K'(x)=\frac{gD}{(g-Q)^2}. \] | FINDING | Equilibrium branch and its exact capacity derivative. | KEEP |
| Supplement, line 23 | Thus $D>0$ makes $K$ a regular parameter. | FINDING | Shows why capacity is a valid local parameter. | KEEP |
| Supplement, line 23 | In particular, $p$ need only be $C^1$ because its derivative is evaluated at the same $\rho$ along this branch. | ESSENTIAL CONDITION | Explains why one derivative of the intake suffices. | KEEP |
| Supplement, line 23 | On substituting $E'-(1+E)g'/g=-xg(1/g)''$, the slope becomes | FINDING | Identifies the algebraic substitution producing the next identity. | KEEP |
| Supplement, lines 24–26 | \[ T_K=-\frac{x^2}{K^2}\left[g'+\frac{Qxg^2}{D}(1/g)''\right]. \] | FINDING | Exact trace derivative along the fixed branch. | KEEP |
| Supplement, line 27 | At equality the exact slope is $-x^2g'/K^2<0$. | FINDING | The strictly negative slope also holds at zero reciprocal curvature. | KEEP |
| Supplement, line 27 | The positive-determinant assumption excludes a flat intake tangent or a zero of $q_x$. | ESSENTIAL CONDITION | The excluded tangencies give zero determinant. | KEEP |
| Supplement, line 29 | S2. Two ways to check the fixed-response example | INTERPRETATION | Names the calculation or comparison. | KEEP |
| Supplement, line 30 | For $p(z)=110/(65+54z)$ the classical parameters are $a=22/13$, $c=54/65$. | ESSENTIAL CONDITION | Gives the response and its two classical parameters. | KEEP |
| Supplement, line 30 | The load is $Q=\rho=5/6$ throughout. | ESSENTIAL CONDITION | The consumption load stays fixed along the branch. | KEEP |
| Supplement, line 30 | At $(x,y,K)=(1/2,5/12,3/2)$ write $F$ for the Cartesian field. | ESSENTIAL CONDITION | Defines the evaluation point and vector field. | KEEP |
| Supplement, line 30 | Then $F=(0,0)$ and | FINDING | Records the equilibrium residual and introduces its derivatives. | KEEP |
| Supplement, lines 31–35 | \[ F_{(x,y)}=\begin{pmatrix}9/22&-13/22\\ 15/44&-9/22\end{pmatrix},\quad F_K=\begin{pmatrix}5/36\\0\end{pmatrix},\quad -F_{(x,y)}^{-1}F_K=\begin{pmatrix}5/3\\25/18\end{pmatrix}. \] | FINDING | Cartesian derivatives and the branch tangent. | KEEP |
| Supplement, line 36 | This gives $T_K=1/9$ by differentiating the Cartesian trace in all three variables. | FINDING | Reports the trace derivative computed from the Cartesian field. | KEEP |
| Supplement, line 36 | Along the branch the determinant has the equivalent form | FINDING | Introduces an expression for the determinant along the branch. | KEEP |
| Supplement, lines 37–40 | \[ \Delta=\frac{3(6x^4-3x^2+1)}{44(1+x^2)},\qquad 6x^4-3x^2+1=6(x^2-1/4)^2+5/8. \] | FINDING | Positive determinant is verified by completing the square. | KEEP |
| Supplement, line 41 | Both crossings have determinant $3/88$. | FINDING | Both critical determinants are given exactly. | KEEP |
| Supplement, line 41 | The second occurs at $x=1/\sqrt3$ and has $T_K=-3\sqrt3/32$. | FINDING | Reports the second crossing and its transverse derivative. | KEEP |
| Supplement, line 41 | Positive determinant and a nonzero trace slope give the direction of the local stability change. | INTERPRETATION | Explains how these quantities classify the adjacent equilibria. | KEEP |
| Supplement, line 41 | The nonlinear behavior at the critical capacities has not been classified. | LIMITATION | Repeats the nonlinear-classification caveat in the letter. Retain the specific first-Lyapunov-coefficient question once in S2. | MERGE |
| Supplement, line 43 | The numerical follow-up used a scalar bracket and an independent two-equation solve at each capacity. | ESSENTIAL CONDITION | States the two independent equilibrium solves. | KEEP |
| Supplement, line 43 | Complex-step differentiation checked the Cartesian Jacobian. | ESSENTIAL CONDITION | Specifies the numerical differentiation method. | KEEP |
| Supplement, line 43 | In a third calculation the full nonlinear equations started from a relative perturbation of $10^{-6}$ in both coordinates and were integrated for one linear oscillation period. | ESSENTIAL CONDITION | The initial perturbation and time interval define the trajectory check. | KEEP |
| Supplement, line 43 | The table compares the resulting ratio of final to initial displacement norms with $\exp[2\pi\,\mathrm{Re}(\lambda)/\|\mathrm{Im}(\lambda)\|]$. | ESSENTIAL CONDITION | Defines the measured and predicted quantities in the table. | KEEP |
| Supplement, lines 46–50 | \toprule $K$ & $T$ & $\Delta$ & Observed ratio & Linear prediction\\ \midrule 1.48 & $-0.00277203$ & 0.03522492 & 0.95465832 & 0.95465833\\ 1.52 & 0.00133466 & 0.03354491 & 1.02315740 & 1.02315741\\ 1.56 & $-0.00597692$ & 0.03653601 & 0.90642487 & 0.90642486\\ \bottomrule\end{tabular} | FINDING | Includes observed contraction, expansion, and contraction at the three capacities. | KEEP |
| Supplement, line 53 | S3. Mixed interference under identical prey growth | INTERPRETATION | Names the calculation or comparison. | KEEP |
| Supplement, line 54 | For total consumption $axy/(1+bx+cy)$, $c>0$, set $A=ea/d-b$ and $m=d(b-ec)/(ea)$. | ESSENTIAL CONDITION | Defines the mixed-intake family and auxiliary parameters. | KEEP |
| Supplement, line 54 | Elimination gives $cy=Ax-1$ and $q=B(x)=d(A-1/x)/(ec)$. | FINDING | States the two equilibrium relations. | KEEP |
| Supplement, line 54 | The Cartesian equilibrium trace is $T=xq_x+mq$. | FINDING | Gives the Cartesian trace. | KEEP |
| Supplement, line 54 | Hence | INTERPRETATION | Connects the trace formula to its derivative. | KEEP |
| Supplement, lines 55–57 | \[ x_K=\frac{q_K}{B'-q_x},\qquad T_K=(q_x+xq_{xx}+m B')x_K+xq_{xK}. \] | FINDING | Exact branch and trace derivatives for mixed interference. | KEEP |
| Supplement, line 58 | For a comparison with the same $g=1+x$, choose $x=y=e=d=1$, $K=2$ and $a=1+b+c$. | ESSENTIAL CONDITION | Fixes the quantities shared by every row of the comparison. | KEEP |
| Supplement, line 58 | These choices fix the equilibrium and the individual intake at that equilibrium across all rows. | INTERPRETATION | Explains the quantities matched by this choice. | KEEP |
| Supplement, line 58 | Within each row $a,b,c$ stay fixed while $K$ varies. | ESSENTIAL CONDITION | The intake parameters are fixed along each row’s branch. | KEEP |
| Supplement, line 58 | Direct Cartesian differentiation gives | FINDING | Introduces the independently derived determinant and slope. | KEEP |
| Supplement, lines 59–62 | \[ \Delta=\frac{c+2}{2(b+c+1)},\qquad T_K=-\frac{3bc-10b+3c^2+c-6}{4(c+2)(b+c+1)}. \] | FINDING | Exact determinant and slope formulas behind the comparison. | KEEP |
| Supplement, lines 65–70 | \toprule Mechanism & $b$ & $c$ & $a$ & $\Delta$ & $T_K$\\\midrule P0, foraging arena & 0 & 1 & 2 & $3/4$ & $1/12$\\ P0, foraging arena & 0 & 2 & 3 & $2/3$ & $-1/6$\\ P3, Beddington--DeAngelis & 1 & 1 & 3 & $1/2$ & $1/4$\\ P3, Beddington--DeAngelis & 1 & 3 & 5 & $1/2$ & $-23/100$\\ \bottomrule\end{tabular} | FINDING | Four parameter sets realize both derivative signs in each mixed model. | KEEP |
| Supplement, line 72 | In P1 and P2 the predator break-even condition fixes prey density. | FINDING | Prey-only intake fixes equilibrium prey density. | KEEP |
| Supplement, line 72 | In P4 it fixes the density ratio. | FINDING | Ratio-dependent intake fixes the equilibrium ratio. | KEEP |
| Supplement, line 72 | The affine break-even equation of P0 and P3 allows different enrichment directions even after the operating point and the prey growth law are matched. | INTERPRETATION | Relates the mixed-model sign change to its break-even equation. | KEEP |
| Supplement, line 74 | S4. Why a local trace criterion does not determine the basin | INTERPRETATION | The title leads with a scope warning. Name the proved coexistence and extinction basins. | REWRITE |
| Supplement, line 75 | This illustration is retained from the parent study. | INTERPRETATION | The opening gives provenance. If attribution is needed, attach it to the parameter sentence. | MERGE |
| Supplement, line 75 | Take $g=1+x/2$, $K=8$, $e=1$, $d=1/5$, and $p(z)=(4/5)/(1+8z/15)$. | ESSENTIAL CONDITION | Specifies the distinct affine-growth example. | KEEP |
| Supplement, line 75 | The positive equilibrium ray is $y=(45/8)x$ and $Q=9/8$. | FINDING | States the break-even ray and load. | KEEP |
| Supplement, line 75 | The two positive equilibria have prey densities $3\pm\sqrt7$. | FINDING | Gives both positive equilibria. | KEEP |
| Supplement, line 75 | The lower point is a saddle, and the upper one has $\Delta>0$ and $T=-(7+3\sqrt7)/8+21/160<0$. | FINDING | Classifies the lower point and states the upper point’s stability data. | KEEP |
| Supplement, line 75 | The reciprocal curvature is positive, so the upper equilibrium has $T_K<0$. | FINDING | Gives the upper equilibrium’s enrichment response. | KEEP |
| Supplement, line 77 | Set $u=8y/(15x)$. | ESSENTIAL CONDITION | Defines the ratio variable. | KEEP |
| Supplement, line 77 | In $0<x<0.01$, $u>10$, the inequalities | ESSENTIAL CONDITION | Restricts the estimates to the specified wedge. The invariant-wedge conclusion continues after the display. | KEEP |
| Supplement, lines 78–81 | \begin{align*} \dot x/x&=q-1.5u/(1+u)<1.004-15/11<0,\\ \dot u/u&=1.5-0.7/(1+u)-0.2-q>1.5-0.7/11-0.2-1.004>0 \end{align*} | FINDING | Differential inequalities underlying the invariant-wedge proof. | KEEP |
| Supplement, line 82 | make this wedge forward invariant and imply $x\to0$ and $u\to\infty$. | FINDING | Completes the sentence begun on line 77. Both limits follow inside the wedge. | KEEP |
| Supplement, line 82 | It follows that $\dot y/y\to-0.2$ and $y\to0$. | FINDING | Concludes that predator density also tends to zero. | KEEP |
| Supplement, line 82 | Thus coexistence and extinction have open basins in this example. | FINDING | States the proved existence of both open basins. | KEEP |
| Supplement, line 82 | The six trajectories in Fig.~S1 show the two outcomes for one fixed parameter set. | FINDING | Identifies what the six displayed trajectories illustrate. | KEEP |
| Supplement, line 82 | The tabulated endpoints are at $t=240$. | ESSENTIAL CONDITION | Endpoint time defines the numerical comparison. | KEEP |
| Supplement, line 82 | Two integrations per initial state, with tighter tolerances for the repeat, have maximum scaled discrepancy below $1.54\times10^{-9}$. | FINDING | Gives the numerical check and its observed discrepancy. | KEEP |
| Supplement, line 85 (Figure S1) | Positive initial states near coexistence and near the origin in the same P4 model. | INTERPRETATION | Caption describes starting states. It could name their two destinations. | REWRITE |
| Supplement, line 85 (Figure S1) | The right panel enlarges the low-density region. | ESSENTIAL CONDITION | Identifies the zoomed panel. | KEEP |
