# Direction 1 · Publication-readiness report

**Version 3, 19 November 2026.** This author-review draft incorporates the sentence-level writing audit of the letter and supplement. It retains the mathematical result, proofs, five-model application, and numerical evidence established in version 2. The archive contains the manuscript, supplement, source files, data, figures, internal reviews, and reproduction scripts. [Letter](manuscript/AML_MANUSCRIPT.pdf) · [Supplement](supplement/SUPPLEMENT.pdf) · [Editable manuscript bundle](AML_LATEX_SOURCE_v3.zip)

The [sentence-level writing audit](editorial/V2_WRITING_AUDIT.md) includes links to the prior TeX sources for direct comparison.

## Scientific scope of the revision

At a prescribed prey density, nonnegative reciprocal curvature is necessary and sufficient for a strictly decreasing equilibrium trace across all admissible ratio-dependent intakes and all realizable positive-determinant coexistence equilibria. At a density with negative reciprocal curvature, Holling II intakes realize each of the three signs of the trace derivative. The derivative follows one fixed model as carrying capacity changes. Version 3 states the three-sign result in the abstract and uses the predator-to-prey ratio consistently. [Mathematical audit](THEOREM_AUDIT.md)

In the explicit smooth Holling II example the unique positive equilibrium loses local stability at $K=3/2$ and regains it at $K=8/(3\sqrt3)$. The determinant is positive at both crossings. The first Lyapunov coefficients remain to be determined. A separate P4 example with an affine growth factor has open basins of coexistence and extinction. Both the letter and the revised S4 heading identify which example gives that result. [Numerical audit](NUMERICAL_AUDIT.md) · [Supplementary evidence](supplement/SUPPLEMENT.pdf)

The theorem-level comparison is the version 2 review. Gao and Li proved trace decrease at a zero for an affine strong-Allee factor with a rational intake. Flores and González-Olivares studied a nonaffine growth factor in the same product family. The distinction supported by the reviewed sources is the pointwise equivalence over all realizable loads and the Holling II loss-of-stability construction at each failed curvature point. Historical priority remains open. Access to the full dimensional enrichment argument of Sen et al. was limited during that review. [Literature comparison](LITERATURE_NOVELTY.md)

## Verification records

The three enclosed referee simulations examined version 2. Their document hashes and page references identify that version. Version 3 has its own release validation. The research evidence includes 40 general symbolic checks, 12 checks on the branch and mechanism examples, 162 computed equilibria, and three local perturbation integrations. [Version 2 mathematical review](REFEREE_A_MATH.md) · [Version 2 novelty review](REFEREE_B_NOVELTY.md) · [Version 2 applied review](REFEREE_C_APPLIED.md) · [Version 3 validation](VALIDATION.json)

## Author checks before submission

- **Length.** The publisher listing checked for version 2 gives a six-journal-page limit. The version 2 main file occupied five A4 pages in each of two local class layouts. A test with illustrative author details and declarations used six. The version 3 validation records its local PDF page counts. The final author block and production layout determine the journal count. [Official AML description and limit](https://shop.elsevier.com/journals/applied-mathematics-letters/0893-9659)
- **Upload requirements.** In the version 2 check the journal-specific live Guide for Authors returned HTTP 403 and displayed a human-verification page. Before upload, confirm file designations, supplement handling, review model, whether highlights are compulsory, and any author submission-frequency restriction. The package contains editable LaTeX, vector figures, and a highlights file. [AML Guide for Authors](https://www.sciencedirect.com/journal/applied-mathematics-letters/publish/guide-for-authors) · [Editorial Manager](https://www.editorialmanager.com/aml/mainpage.html) · [Elsevier LaTeX instructions](https://www.elsevier.com/researcher/author/policies-and-guidelines/latex-instructions) · [Highlights guidance](https://www.elsevier.com/en-gb/researcher/author/tools-and-resources/highlights)
- **Author information and approval.** Complete the author details, affiliations, corresponding-author address and email, funding, and competing interests. Confirm the manuscript's relationship to other submissions. The authors should verify the arguments and citations, review the AI-use declaration covering the mathematical work, analysis code and writing, and approve the final files before submission. [Author details file](manuscript/author_details.tex) · [Publisher ethics](https://www.elsevier.com/about/policies-and-standards/publishing-ethics) · [Publisher AI policy](https://www.elsevier.com/about/policies-and-standards/generative-ai-policies-for-journals)

## Reproduction

From the extracted project folder, run `python reproduce.py` using Python 3.13, the pinned Python dependencies, and a TeX installation providing `pdflatex` and `elsarticle`. The script regenerates the symbolic checks, numerical outputs, figures, and both PDFs. [Dependencies](requirements.txt) · [Reproduction script](reproduce.py)
