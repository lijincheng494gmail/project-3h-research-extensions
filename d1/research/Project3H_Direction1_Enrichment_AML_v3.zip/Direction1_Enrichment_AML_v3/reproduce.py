"""Rebuild computed data, plots, checks, and both PDFs in the extracted package."""
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

root = Path(__file__).resolve().parent

def run(*args, cwd=root):
    subprocess.run(args, cwd=cwd, check=True)

def typeset(folder, stem):
    with tempfile.TemporaryDirectory() as destination:
        for _ in range(2):
            run("pdflatex", "-interaction=batchmode", "-halt-on-error",
                f"-output-directory={destination}", stem + ".tex", cwd=root / folder)
        log = (Path(destination) / f"{stem}.log").read_text(errors="replace")
        if "undefined references" in log or "Overfull \\hbox" in log:
            raise ValueError(f"Inspect the typesetting log for {stem}")
        shutil.copy2(Path(destination) / (stem + ".pdf"), root / folder)

if __name__ == "__main__":
    for script in ("tests/verify_v2.py", "tests/branch_identities.py", "src/crossing.py",
                   "src/curvature_map.py", "supplement/src/phase_portrait.py"):
        run(sys.executable, script)
    for figure in ("stability_crossing.pdf", "curvature_map.pdf"):
        shutil.copy2(root / "figures" / figure, root / "manuscript" / figure)
    typeset("manuscript", "AML_MANUSCRIPT")
    typeset("supplement", "SUPPLEMENT")
