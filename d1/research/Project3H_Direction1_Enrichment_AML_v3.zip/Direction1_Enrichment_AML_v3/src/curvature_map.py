"""Plot the exact capacity-feasibility and zero-slope curves for g(x)=1+x²."""

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

root = Path(__file__).resolve().parents[1]
boundary = 1 / np.sqrt(3)
x = np.unique(np.r_[np.linspace(0.12, 1.02, 551), boundary, 0.5])
upper = (1 + x**2) ** 2 / (1 + 3 * x**2)
threshold = (1 + x**2) ** 2 / 2
failed = x <= boundary
feasible_color = "#d5e8e5"
positive_color = "#f4d5b5"
plt.rcParams.update(
    {"font.size": 8.5, "pdf.fonttype": 42, "font.family": "DejaVu Sans"}
)
fig, ax = plt.subplots(figsize=(5.2, 2.42), layout="constrained")
ax.fill_between(x, 0.30, upper, color=feasible_color, linewidth=0)
ax.fill_between(
    x[failed], threshold[failed], upper[failed], color=positive_color, linewidth=0
)
ax.plot(x, upper, color="#273d4a", lw=1.4)
ax.plot(x[failed], threshold[failed], "--", color="#a24b11", lw=1.25)
ax.axvline(boundary, color="#4e5960", ls=":", lw=1.15)
ax.plot(
    0.5, 5 / 6, "o", markeredgecolor="#13212c", markerfacecolor="white", markersize=5
)
ax.text(0.25, 0.83, "Trace rises", ha="center")
ax.text(0.71, 0.54, "Trace falls", ha="center")
ax.text(0.225, 0.42, "Trace falls", ha="center")
ax.text(0.79, 1.045, "Outside the nonsaddle range", ha="center", fontsize=8)
ax.annotate(
    r"$Q_c$",
    xy=(0.32, (1 + 0.32**2) ** 2 / 2),
    xytext=(0.34, 0.53),
    arrowprops={"arrowstyle": "-", "lw": 0.65},
    fontsize=9,
)
ax.annotate(
    r"$U$",
    xy=(0.70, (1 + 0.7**2) ** 2 / (1 + 3 * 0.7**2)),
    xytext=(0.73, 0.95),
    arrowprops={"arrowstyle": "-", "lw": 0.65},
    fontsize=9,
)
ax.set(
    xlim=(x.min(), x.max()),
    ylim=(0.30, 1.12),
    xlabel="Prescribed prey density $x$",
    ylabel="Consumption load $Q$",
)
ax.set_xticks(
    [0.2, 0.4, boundary, 0.8, 1], labels=["0.2", "0.4", r"$1/\sqrt{3}$", "0.8", "1.0"]
)
ax.spines[["top", "right"]].set_visible(False)
folder = root / "figures"
folder.mkdir(exist_ok=True)
fig.savefig(folder / "curvature_map.pdf", metadata={"CreationDate": None})
fig.savefig(folder / "curvature_map.png", dpi=190)
plt.close(fig)
