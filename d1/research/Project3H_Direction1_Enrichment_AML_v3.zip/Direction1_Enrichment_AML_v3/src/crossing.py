"""Reproduce Figure 2, its data, and checks from the Cartesian predator-prey field."""

import csv, json, platform
from pathlib import Path
import numpy as np
import scipy
from scipy.optimize import brentq, root
from scipy.integrate import solve_ivp
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator

R = Path(__file__).resolve().parents[1]
for sub in ("figures", "data"):
    (R / sub).mkdir(exist_ok=True)
r = 5 / 6
crossings = (1.5, 8 / (3 * np.sqrt(3)))


def field(v, k):
    x, y = v
    z = y / x
    p = 110 / (65 + 54 * z)
    return np.array([x * (1 + x * x) * (1 - x / k) - y * p, y * (p - 1)])


def jac(v, k):
    x, y = v
    z = y / x
    p = 110 / (65 + 54 * z)
    pp = -5940 / (65 + 54 * z) ** 2
    return np.array(
        [
            [
                (1 + 3 * x * x) * (1 - x / k) - x * (1 + x * x) / k + z * z * pp,
                -p - z * pp,
            ],
            [-z * z * pp, p - 1 + z * pp],
        ]
    )


def jcs(v, k):
    return np.column_stack(
        [field(v + 1j * 1e-25 * d, k).imag / 1e-25 for d in np.eye(2)]
    )


def newrow(k):
    x = brentq(lambda x: (1 + x * x) * (1 - x / k) - r, 0, k, xtol=5e-16)
    y = r * x
    v = np.array([x, y])
    J = jac(v, k)
    T = np.trace(J)
    D = np.linalg.det(J)
    lam = np.linalg.eigvals(J)
    T0 = -(3 * x * x - 1) * (4 * x * x - 1) / (12 * (1 + x * x))
    D0 = 3 / 88 - 9 * T0 / 22
    res = root(lambda w: field(w, k), [0.52, 0.45], tol=1e-12)
    assert np.max(np.abs(res.fun)) < 2e-15 and np.max(np.abs(res.x - v)) < 2e-13
    assert (
        D > 0
        and np.max(np.abs(J - jcs(v, k))) < 2e-15
        and abs(T - T0) < 2e-15
        and abs(D - D0) < 2e-15
    )
    assert max(abs(lam.real - T / 2)) < 2e-15 and abs(lam[0].imag) > 0.17
    if min(abs(k - k0) for k0 in crossings) > 1e-12:
        assert (lam.real.max() > 0) == (crossings[0] < k < crossings[1])
    return dict(
        K=k,
        x=x,
        y=y,
        trace=T,
        determinant=D,
        eigen_real=lam[0].real,
        eigen_abs_imag=abs(lam[0].imag),
        root_resid=max(abs(res.fun)),
        root_vs_scalar=max(abs(res.x - v)),
        jac_cs_error=np.max(np.abs(J - jcs(v, k))),
        trace_error=abs(T - T0),
        det_error=abs(D - D0),
    )


K = np.unique(np.r_[np.linspace(1.48, 1.56, 161), crossings])
rows = [newrow(k) for k in K]
with (R / "data/stability_crossing.csv").open("w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=rows[0])
    w.writeheader()
    w.writerows(rows)
# Integrate the full Cartesian field at three capacities from the same small relative displacement.
# Measure its linearized amplitude at a full oscillation period to avoid eigenvector conditioning effects.
checks = []
for k in [1.48, 1.52, 1.56]:
    a = newrow(k)
    v = np.array([a["x"], a["y"]])
    inc = 1e-6 * v
    period = 2 * np.pi / a["eigen_abs_imag"]
    sol = solve_ivp(
        lambda t, w: field(w, k),
        (0, period),
        v + inc,
        method="DOP853",
        rtol=1e-13,
        atol=2e-15,
        max_step=period / 50,
    )
    assert sol.success
    gain = np.linalg.norm(sol.y[:, -1] - v) / np.linalg.norm(inc)
    linear_gain = np.exp(period * a["eigen_real"])
    assert abs(gain - linear_gain) < 2e-5 and (gain > 1) == (
        crossings[0] < k < crossings[1]
    )
    checks.append(dict(K=k, period=period, full_ODE_gain=gain, linear_gain=linear_gain))
verify = dict(
    grid_points=len(rows),
    max_errors={
        key: max(a[key] for a in rows)
        for key in [
            "root_resid",
            "root_vs_scalar",
            "jac_cs_error",
            "trace_error",
            "det_error",
        ]
    },
    nearby_trajectory_checks=checks,
    environment=dict(
        python=platform.python_version(),
        numpy=np.__version__,
        scipy=scipy.__version__,
        matplotlib=matplotlib.__version__,
    ),
)
print(json.dumps(verify, indent=2))
(R / "data/stability_checks.json").write_text(json.dumps(verify, indent=2) + "\n")
plt.rcParams.update(
    {
        "font.size": 8,
        "axes.labelsize": 8,
        "pdf.fonttype": 42,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "lines.solid_capstyle": "round",
        "font.family": "DejaVu Sans",
    }
)
fig, (ax, bx) = plt.subplots(1, 2, figsize=(5.35, 1.95), layout="constrained")
ts = np.array([a["trace"] for a in rows])
ds = np.array([a["determinant"] for a in rows])
stable = "#185679"
unstable = "#a44517"
for panel in (ax, bx):
    panel.set(
        xlim=(1.478, 1.562),
        xticks=[1.48, 1.50, 1.52, 1.54, 1.56],
        xlabel="Carrying capacity $K$",
    )
    panel.tick_params(labelsize=7, length=3)
    panel.grid(axis="y", lw=0.35, color=".85")
    panel.set_axisbelow(True)
for l, u, c, ls in [
    (1.48, crossings[0], stable, "-"),
    (*crossings, unstable, "--"),
    (crossings[1], 1.56, stable, "-"),
]:
    sel = (K >= l) & (K <= u)
    ax.plot(K[sel], 1000 * ts[sel], color=c, ls=ls, lw=1.7)
ax.axhline(0, color="0.3", lw=0.7, zorder=0)
ax.plot(crossings, [0, 0], "o", mec="0.15", mfc="white", ms=4, mew=0.9)
ax.set_title("(a)  Trace", loc="left", fontsize=9)
ax.set_ylabel(r"$10^3\,\mathrm{tr}\,J$")
ax.set_ylim(-6.6, 2.5)
ax.set_yticks([-6, -4, -2, 0, 2])
from matplotlib.lines import Line2D

ax.legend(
    [
        Line2D([], [], color=stable, lw=1.6),
        Line2D([], [], color=unstable, lw=1.6, ls="--"),
    ],
    ["Stable", "Unstable"],
    loc="lower left",
    frameon=False,
    fontsize=7,
    handlelength=1.6,
    labelspacing=0.25,
)
bx.plot(K, ds, color="#373d47", lw=1.6)
bx.plot(crossings, [3 / 88] * 2, "o", mec="0.15", mfc="white", ms=4, mew=0.9)
bx.set_title("(b)  Determinant", loc="left", fontsize=9)
bx.set_ylabel(r"$\det J$")
bx.set_ylim(0.033, 0.0371)
bx.set_yticks([0.033, 0.035, 0.037])
for ext in ["pdf", "png"]:
    fig.savefig(R / f"figures/stability_crossing.{ext}", dpi=300)
