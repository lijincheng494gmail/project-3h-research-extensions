# Independent mathematical audit: the physical-time enrichment criterion

**Finding.** The pointwise equivalence in the previous proof survives independent rederivation. The response in the transverse-crossing corollary can be chosen from the two-parameter classical ratio-dependent Holling II family at **every** negative-curvature point, with prescribed growth function, prey density, conversion efficiency, and predator mortality. This is an existence result within the family. It does not say that every fixed Holling II model loses stability at that density.

## Setting and quantifiers

Fix an open prey-density interval $I\subset (0,\infty)$, $s\in I$, $g\in C^2(I)$ with $g>0$, $g'>0$, and $e,d>0$. An admissible intake is a positive strictly decreasing $C^1$ function on $(0,\infty)$. At each $K>0$ consider $\dot x=xq-yp(y/x)$, $\dot y=y[ep(y/x)-d]$, $q=g(x)(1-x/K)$. A positive equilibrium here has $x,y>0$; a regular nonsaddle means $\det J>0$, allowing zero trace. For each admissible $p$, each $K_0>0$, and each positive $v$ for which $(s,v)$ meets this condition at $K_0$, take the total trace derivative on its local equilibrium branch. Keep $g,p,e,d$ and the time unit fixed and vary only $K$. Then every such derivative is strictly negative if and only if $(1/g)''(s)\ge0$. The theorem promises no equilibrium for an arbitrary response lacking the level $d/e$.

## Independent proof in ratio coordinates

On the interior set $z=y/x$. This is an invertible coordinate substitution with **no time change**. It gives $\dot x=x(q-zp)$ and $\dot z=z[(e+z)p-d-q]$. At a positive equilibrium $p(\rho)=d/e$; strict monotonicity gives uniqueness of this level when attained. Put $Q=\rho d/e$. Then $y=\rho x$ and $q(x,K)=Q>0$, so $x<K$. Denote $u=p(\rho)$ and $v'=p'(\rho)$. The ratio-coordinate and Cartesian Jacobians at the equilibrium are, respectively,

$$J_{xz}=\begin{pmatrix}xq_x&-x(u+\rho v')\\-\rho q_x&\rho[u+(e+\rho)v']\end{pmatrix},\qquad J_{xy}=\begin{pmatrix}q+xq_x+\rho^2v'&-u-\rho v'\\-e\rho^2v'&e\rho v'\end{pmatrix}.$$

They are similar by the coordinate differential $H=\bigl(\begin{smallmatrix}1&0\\-\rho/x&1/x\end{smallmatrix}\bigr)$. Consequently $T=xq_x+Q+\rho(\rho+e)v'$ and $\Delta=e\rho v' xq_x$. Differentiability and strict decrease give only $v'\le0$. Thus $\Delta>0$ is equivalent to $v'<0$ and $q_x<0$ here. Either horizontal tangent makes the determinant zero. In physical population coordinates the **off-equilibrium** bottom-right entry is $ep(y/x)-d+e(y/x)p'(y/x)$; setting $ep-d=0$ before taking partial derivatives of the vector field would be invalid.

Eliminate $K$ in favor of $x$: $K(x)=xg/(g-Q)$. Write $E=xg'/g$ and $D=g-(1+E)Q$. Differentiation gives $K'(x)=gD/(g-Q)^2$. Also $xq_x=-D$ at equilibrium. Since $D>0$, the inverse function theorem gives a unique local branch with $x_K=(g-Q)^2/(gD)=x^2g/(K^2D)>0$. Along it $Q,\rho,u,v'$ stay fixed, even if $p$ is merely $C^1$. Hence

$$T_K=\frac{x^2g}{K^2D}(QE'-g').$$

At $x=s$ let $G=g(s)$, $A=g'(s)$ and $U=G/(1+E(s))$. Necessarily $0<Q<U<G$. Conversely each such $Q$ gives $\rho=eQ/d$, $K_0=sG/(G-Q)$ and $p(z)=(2d/e)/(1+z/\rho)$. Its slope is negative at $\rho$, and $D>0$ proves positive determinant. These are exactly the realizable loads, already using bounded Holling II intakes. The endpoint $Q=0$ is nonpositive coexistence ($y=0$); $Q=U$ makes $D=0$ and $\Delta=0$.

The sign of $T_K$ is that of the affine function $L(Q)=QE'(s)-A$. We have $L(0)=-A<0$ and

$$L(U)=-\frac{sG^2}{1+E(s)}(1/g)''(s).$$

If reciprocal curvature is nonnegative, affine interpolation implies strict negativity throughout the **open** interval. In fact $T_K=-x^2[g'+Qxg^2(1/g)''/D]/K^2$, so at zero curvature the exact strict slope is $-x^2g'/K^2$. If curvature is negative, $L(U)>0$ implies $E'>0$ and $Q_c=A/E'\in(0,U)$. The realizations on $(0,Q_c)$, at $Q_c$, and on $(Q_c,U)$ have negative, zero, and positive derivatives. Thus one decreasing trace does not force nonnegative curvature. The converse requires the universal quantifier. Zero derivative here has no implication about higher derivatives.

## Classical rational construction

At any prescribed negative-curvature point choose $\max\{Q_c,G/(2+E)\}<Q<U$. Both lower bounds are strictly smaller than $U$, and the choice implies $0<D<Q$ and $L(Q)>0$. Fix the ratio and capacity as above. To set $T=0$ we require $p'(\rho)=-(Q-D)/[\rho(\rho+e)]$. Use

$$p(z)=\frac{d/e}{1+k(z-\rho)},\qquad k=\frac{e(Q-D)}{d\rho(\rho+e)}.$$

The possible pole is excluded globally: $k\rho=[\rho/(\rho+e)](1-D/Q)\in(0,1)$, since $Q=\rho d/e$. Thus the classical parameters $a=(d/e)/(1-k\rho)>0$ and $c=k/(1-k\rho)>0$ give $p(z)=a/(1+cz)$, smooth, bounded, positive and strictly decreasing on $[0,\infty)$. Direct differentiation gives the required slope. Therefore $T=0$, $\Delta>0$, and $T_K>0$. In a neighborhood the discriminant stays negative and both real parts equal $T/2$. Hence positive coexistence is a hyperbolic attracting focus for $K$ just below $K_0$ and a hyperbolic repelling focus just above. Linearization at equality does not decide nonlinear stability there, existence of cycles, or the sign/nonvanishing of a first Lyapunov coefficient. In particular $C^2$ growth alone does not supply the usual third-order Hopf coefficient.

## Original-equation test of the proposed example

With $g=1+x^2$, $p=110/(65+54z)$, $e=d=1$, $s=1/2$, and $K_0=3/2$, both original population derivatives vanish at $(1/2,5/12)$. The parameters are $a=22/13$, $c=54/65$. Exact arithmetic gives $\rho=5/6$, $Q=5/6$, $E=2/5$, $D=1/12$, $k=27/55$, $q_x=-1/6$ and $(1/g)''(s)=-32/125$. Differentiating in Cartesian coordinates before evaluating gives

$$J=\begin{pmatrix}9/22&-13/22\\15/44&-9/22\end{pmatrix},\quad T=0,\quad \Delta=3/88.$$

Solving $J(x_K,y_K)^t=-F_K$ gives $(5/3,25/18)$. Direct differentiation of $\operatorname{tr}(F_{(x,y)})$ in all three arguments along this tangent gives $T_K=1/9$. The eigenvalues at equality are $\pm i\sqrt{3/88}$, and their real-part derivatives equal $1/18$. Solving both Cartesian equations at $K=1.4999$ and $1.5001$ gives real parts $-5.56425\times10^{-6}$ and $+5.54684\times10^{-6}$, respectively; both determinants exceed $0.0340$. A centered difference gives $0.11111090$. Neither finite differences nor plotted continuations enter the proof.

## Five-mechanism audit and limits

- For P4 with $g=r(1+\alpha x)$, $r,\alpha>0$, reciprocal curvature is $2\alpha^2/[r(1+\alpha x)^3]>0$. Every positive-determinant branch has falling trace wherever it remains regular. With $\alpha=0$ enrichment leaves the trace constant; this useful control is outside $g'>0$. Replacing this growth by $1+x^2$ leaves the P4 intake family intact but changes the growth assumption.
- For P1 and P2, the per-predator response $f(x)=ax/(1+bx)$ ($b=0$ for P1) fixes $x$ by $ef=d$; $y=xq/f$ moves with $K$. The resulting derivative is $xg(2+xg'/g-xf'/f)/K^2>0$, since $xf'/f=1/(1+bx)\le1$. Rising trace alone neither ensures a zero nor establishes Hopf nondegeneracy.
- The mixed P0 and P3 intakes $ax/(1+bx+cy)$ retain dependence on both densities. The exact Cartesian checks give positive determinant and both signs: $1/12,-1/5$ (P0) and $1/4,-7/12$ (P3) for the example rows reproduced in the test. Those examples disprove a universal sign for these model families; the ratio criterion does not apply to them.
- At a single point, a falling trace does not imply attraction; the trace itself can be positive. Even a negative trace and positive determinant yield only local attraction in the interior. The argument excludes neither extinction basins nor other attractors elsewhere. At the singular origin no ratio chart is used. A parameter-dependent time rescaling can change the derivative of a nonzero trace; throughout we retain the original clock.

## Executable evidence

Run `python tests/verify_v2.py` from the packet directory with SymPy, NumPy, and SciPy. The script writes `tests/results.json`. Forty exact equalities, additional determinant checks, and three independent numerical root/eigenvalue evaluations passed. Besides the explicit crossing the tests include a smooth strictly decreasing intake with zero derivative at the equilibrium, the zero-determinant load endpoint, a zero-curvature strictly increasing growth law, and all three derivative signs at a single negative-curvature density. The rerun found no failed equality or counterexample to the stated result. This internal mathematical audit is not an external referee report or a priority assessment.
