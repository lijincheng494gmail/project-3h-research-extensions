# Fixed-response stability crossing

Here $g(x)=1+x^2$, $e=d=1$, and $p(z)=110/(65+54z)$. The positive equilibrium has $y=5x/6$. Its capacity is $K(x)=6x(1+x^2)/(1+6x^2)$, which runs from zero to infinity. Its derivative is $6(1-3x^2+6x^4)/(1+6x^2)^2>0$ because $6u^2-3u+1$ has negative discriminant. Thus each positive capacity has exactly one positive equilibrium, and the bracket $0<x<K$ contains it. No switch of branches is possible.

Along this branch the exact trace and determinant are $T=-(3x^2-1)(4x^2-1)/[12(1+x^2)]$ and $\Delta=3/88-9T/22$. In fact $\Delta=(9/22)(1-3x^2+6x^4)/[6(1+x^2)]>0$ for every $x>0$. The first trace crossing is at $x=1/2$, $K=3/2$, $T_K=1/9$, $\Delta=3/88$. There is also a second crossing at $x=1/\sqrt3$, $K=8/(3\sqrt3)\approx1.5396007$, where the equilibrium regains local stability. It is linearly unstable only between these capacities. Both crossings appear in the main figure. These claims concern local linear stability; no periodic orbit or global attraction is inferred.

The 162 capacities in `data/stability_crossing.csv` span $1.48\le K\le1.56$ and include both critical values. At each capacity, we solved the scalar prey equation on $(0,K)$ and, separately, both original Cartesian equations from the same positive starting guess $(0.52,0.45)$. The two solutions differed by at most $4.22\times10^{-15}$ in either coordinate. Complex-step differentiation of the original vector field agreed with the directly differentiated Cartesian Jacobian to $6.11\times10^{-16}$ per entry. Direct eigenvalues form a complex conjugate pair at every sampled point. The largest absolute discrepancies between the Cartesian and closed-form trace and determinant were $6.07\times10^{-16}$ and $2.99\times10^{-16}$, respectively.

| Capacity | Trace | Determinant | Real part of pair | Observed amplitude ratio | Linear prediction |
|---:|---:|---:|---:|---:|---:|
| 1.48 | −0.00277203 | 0.03522492 | −0.00138601 | 0.95465832 | 0.95465833 |
| 1.52 | 0.00133466 | 0.03354491 | 0.00066733 | 1.02315740 | 1.02315741 |
| 1.56 | −0.00597692 | 0.03653601 | −0.00298846 | 0.90642487 | 0.90642486 |

For this last check, both coordinates started $10^{-6}$ above equilibrium in relative terms. We integrated the original nonlinear equations for one linear oscillation period $P=2\pi/|\operatorname{Im}\lambda|$ with DOP853 and measured the final Euclidean displacement divided by the initial displacement. The linear prediction is $\exp(P\operatorname{Re}\lambda)$. This short integration checks the sign and size of the local response at three representative points; it cannot describe a basin of attraction or establish a limit cycle.

Run `python src/crossing.py` with NumPy, SciPy, and Matplotlib from any working directory. It regenerates the figure in PDF and PNG, the CSV table, and `data/stability_checks.json` containing the full-precision error and integration checks. The recorded run used Python 3.13.0, NumPy 2.3.2, SciPy 1.18.1, and Matplotlib 3.10.8. All quantities use the time unit of the original equations.
