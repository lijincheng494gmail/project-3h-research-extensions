"""Independent exact and numerical tests. Run with Python, SymPy, SciPy and NumPy."""

import json, sys
from pathlib import Path
import sympy as S
import numpy as np
import scipy
from scipy.optimize import root

x, y, z, K, e, d, Q, r, G, A, B, D, E, k = S.symbols(
    "x y z K e d Q r G A B D E k", positive=True
)
R = S.Rational
checks = {}


def check(name, calculated, expected):
    residual = calculated - expected
    terms = list(residual) if isinstance(residual, S.MatrixBase) else [residual]
    assert all(S.factor(t) == 0 for t in terms), (name, residual)
    checks[name] = str(expected)


vec = S.Matrix
g = S.Function("g")(x)
h = S.Function("p")
f = S.Function("q")(x, K)
V = vec([x * f - y * h(y / x), y * (e * h(y / x) - d)])
zflow = vec([V[0], (V[1] * x - y * V[0]) / x**2]).subs(y, x * z)
check(
    "ratio vector field (no time change)",
    zflow,
    vec([x * (f - z * h(z)), z * ((e + z) * h(z) - d - f)]),
)
# restore q_x (subs above acts on derivative as well), using x-independent placeholders for equilibrium values
J = (
    zflow.jacobian([x, z])
    .subs(z, r)
    .xreplace({f: r * h(r), f.diff(x): S.Symbol("qx"), d: e * h(r)})
)
qx = S.Symbol("qx")
u = h(r)
v = h(r).diff(r)
check(
    "ratio Jacobian",
    J,
    vec([[x * qx, -x * (u + r * v)], [-r * qx, r * (u + (e + r) * v)]]),
)
check("determinant", J.det(), x * qx * e * r * v)
check("trace", J.trace(), x * qx + r * u + r * (e + r) * v)
H = vec([[1, 0], [-r / x, 1 / x]])
Jxy = (
    V.jacobian([x, y])
    .subs(y, x * r)
    .subs(d, e * u)
    .xreplace({f: r * u, f.diff(x): qx})
    .doit()
)
check("Cartesian and ratio Jacobians similar", H * Jxy * H.inv(), J)
q = g * (1 - x / K)
elog = x * g.diff(x) / g
cap = x * g / (g - Q)
curv = S.diff(1 / g, x, 2)
DD = g - (1 + elog) * Q
upper = g / (1 + elog)
check(
    "physical branch inverse derivative", 1 / S.diff(cap, x), x * x * g / (cap**2 * DD)
)
trace_on = (x * q.diff(x)).subs(K, cap) + Q + r * (r + e) * v
check(
    "slope by differentiating parameterized trace",
    trace_on.diff(x) / cap.diff(x),
    x * x * g / (cap**2 * DD) * (Q * elog.diff(x) - g.diff(x)),
)
check(
    "endpoint curvature",
    (Q * elog.diff(x) - g.diff(x)).subs(Q, upper),
    -x * g * g * curv / (1 + elog),
)
check(
    "decomposition including zero curvature",
    trace_on.diff(x) / cap.diff(x),
    -x * x / cap**2 * (g.diff(x) + Q * x * g * g * curv / DD),
)
# Differentiate the normalized rational function directly, writing the load as r*d/e.
kt = e * (Q - D) / (d * r * (r + e))
pz = (d / e) / (1 + kt * (z - r))
aa = (d / e) / (1 - kt * r)
cc = kt / (1 - kt * r)
check("normalized rational equals classical family", pz, aa / (1 + cc * z))
check(
    "dimensionless slope bound", (kt * r).subs(d, e * Q / r), r / (r + e) * (1 - D / Q)
)
check("tuned trace", (-D + Q + r * (r + e) * pz.diff(z).subs(z, r)), 0)


# Full Cartesian Jacobian at an independently specified equilibrium. Differentiate the original equations before substituting any equilibrium condition.
def audit_cart(F, at):
    J = F.jacobian([x, y])
    jj = J.subs(at)
    branch = -jj.inv() * F.diff(K).subs(at)
    T = J.trace()
    deriv = (S.Matrix([[T.diff(x), T.diff(y)]]).subs(at) * branch)[0] + T.diff(K).subs(
        at
    )
    return F.subs(at), jj, branch, S.factor(deriv)


p = 110 / (65 + 54 * y / x)
q1 = (1 + x * x) * (1 - x / K)
F = vec([x * q1 - y * p, y * (p - 1)])
point = {x: R(1, 2), y: R(5, 12), K: R(3, 2)}
eq, jj, vel, tK = audit_cart(F, point)
check("original vector field residual", eq, vec([0, 0]))
check("original Cartesian J trace", jj.trace(), 0)
check("original Cartesian J determinant", jj.det(), R(3, 88))
check("original equilibrium tangent (x_K,y_K)", vel, vec([R(5, 3), R(25, 18)]))
check("original total trace derivative", tK, R(1, 9))
check(
    "example rational curvature",
    curv.subs(g, 1 + x * x).doit().subs(x, R(1, 2)),
    -R(32, 125),
)
check(
    "example parameter k",
    kt.subs({e: 1, d: 1, r: R(5, 6), Q: R(5, 6), D: R(1, 12)}),
    R(27, 55),
)
# All three enrichment signs at the same negative-curvature density.
for load, expected_sign in [(R(3, 4), -1), (R(25, 32), 0), (R(5, 6), 1)]:
    pr = 2 / (1 + (y / x) / load)
    fr = vec([x * q1 - y * pr, y * (pr - 1)])
    ka = R(1, 2) / (1 - load / R(5, 4))
    zr, jr, br, tr = audit_cart(fr, {x: R(1, 2), y: load / 2, K: ka})
    check("signed example " + str(load) + " residual", zr, vec([0, 0]))
    check("signed example " + str(load) + " slope sign", S.sign(tr), expected_sign)
    assert jr.det() > 0
# Upper endpoint: q_x=0 and det=0 even with strictly negative intake slope.
ue = R(25, 28)
pe = 2 / (1 + (y / x) / ue)
fe = vec([x * q1 - y * pe, y * (pe - 1)])
at_e = {x: R(1, 2), y: ue / 2, K: R(1, 2) / (1 - ue / R(5, 4))}
check("upper endpoint equilibrium", fe.subs(at_e), vec([0, 0]))
check("upper endpoint singular", fe.jacobian([x, y]).subs(at_e).det(), 0)
# Smooth strict decrease with a horizontal tangent: no positive determinant.
flat = S.exp(-((y / x - 1) ** 3))
Fflat = vec([x * (1 + x) * (1 - x / K) - y * flat, y * (flat - 1)])
flatJ = Fflat.jacobian([x, y]).subs({x: 1, y: 1, K: 2})
check("strictly decreasing flat intake: det=0", flatJ.det(), 0)
# Zero-curvature strictly increasing g=1/(2-x), tested inside (0,2).
g0 = 1 / (2 - x)
fixed = {x: 1, y: R(1, 4), K: R(4, 3)}
p0 = 2 / (1 + 4 * y / x)
Feq = vec([x * g0 * (1 - x / K) - y * p0, y * (p0 - 1)])
eq0, j0, b0, t0 = audit_cart(Feq, fixed)
check("zero-curvature equality regular sample", eq0, vec([0, 0]))
check("zero-curvature strict slope", t0, -R(9, 16))
assert j0.det() > 0
# Rebuild affine-growth P4, mass action P1, and Holling II P2 from original fluxes.
alpha, b, a, c, rr = S.symbols("alpha b a c rr", positive=True)
gd = rr * (1 + alpha * x)
qd = gd * (1 - x / K)
sp4 = S.factor((trace_on.diff(x) / cap.diff(x)).subs(g, gd).doit().subs(Q, qd))
check(
    "P4 original weak Allee",
    sp4,
    rr * alpha * x * x * (1 + alpha * K) / (K * K * (alpha * K - 1 - 2 * alpha * x)),
)
ff = a * x / (1 + b * x)
Z = vec([x * qd - y * ff, y * (e * ff - d)])
tprey = Z.jacobian([x, y]).trace().subs({d: e * ff, y: x * qd / ff})
check(
    "P1/P2 fixed prey slope",
    tprey.diff(K),
    x * gd / K**2 * (2 + x * gd.diff(x) / gd - x * ff.diff(x) / ff),
)
for model, bv, av, rate, vy, target in [
    ("P0+", 0, 1, 2, 1, R(1, 12)),
    ("P0-", 0, 2, R(5, 2), R(3, 2), -R(1, 5)),
    ("P3+", 1, 1, 3, 1, R(1, 4)),
    ("P3-", 1, 3, 4, 2, -R(7, 12)),
]:
    flux = rate * x * y / (1 + bv * x + y)
    dz = vec([x * (1 + av * x) * (1 - x / K) - flux, flux - y])
    zero, j, br, ts = audit_cart(dz, {x: 1, y: vy, K: 2})
    check(model + " residual", zero, vec([0, 0]))
    check(model + " signed slope", ts, target)
    assert j.det() > 0
# Fresh roots in both Cartesian coordinates and direct full-J eigenvalues. No branch formula supplied to root.
fun = S.lambdify((x, y, K), F, "numpy")
jfun = S.lambdify((x, y, K), F.jacobian([x, y]), "numpy")
obs = []
for capval in [1.4999, 1.5, 1.5001]:
    res = root(lambda w: fun(*w, capval).ravel(), [0.5, 5 / 12], tol=1e-12)
    assert np.max(abs(res.fun)) < 1e-14 and max(abs(res.x - [0.5, 5 / 12])) < 0.0002
    jv = jfun(*res.x, capval)
    eig = np.linalg.eigvals(jv)
    assert np.linalg.det(jv) > 0 and abs(eig[0].imag) > 0.18
    obs.append(
        dict(
            K=capval,
            x=res.x[0],
            y=res.x[1],
            trace=np.trace(jv),
            det=np.linalg.det(jv),
            real=eig[0].real,
            imag_abs=abs(eig[0].imag),
        )
    )
assert obs[0]["real"] < 0 < obs[-1]["real"]
fd = (obs[-1]["trace"] - obs[0]["trace"]) / (obs[-1]["K"] - obs[0]["K"])
assert abs(fd - 1 / 9) < 2e-6
out = dict(
    status="PASS",
    python=sys.version.split()[0],
    sympy=S.__version__,
    scipy=scipy.__version__,
    numpy=np.__version__,
    n_symbolic_checks=len(checks),
    symbolic_checks=checks,
    direct_example_J=str(jj),
    numerical_crossing=obs,
    finite_difference_slope=fd,
)
Path(__file__).with_name("results.json").write_text(json.dumps(out, indent=2) + "\n")
print("PASS", len(checks), "symbolic checks; finite-difference slope:", fd)
