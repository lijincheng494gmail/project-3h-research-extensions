# Direction 1：五种捕食机制的完整比较

本版执行 `MASTER_SCOPE.md` 中的主任务。研究问题始终是：原模型的哪些动力学性质是共同的，哪些取决于捕食机制？P0 原课程方程完整保留；P1 LV、P2 Holling II、P3 Beddington–DeAngelis、P4 比例依赖全部纳入比较。

先读 `paper/PAPER_EN.pdf`。这是当前英文论文，按七个共同问题展开 Results。完整推导见 `paper/DETAILED_SUPPLEMENT.pdf`；每个模型、每个问题的条件、证据和剩余范围见 `reports/COMPARISON_P0_P4.csv`。

## 文件入口

| 要求 | 位置 |
|---|---|
| 英文论文 | `paper/PAPER_EN.pdf`、可编辑 `paper/PAPER_EN.tex` |
| 全部数学推导及独立核验 | `paper/DETAILED_SUPPLEMENT.pdf`、`reports/ANALYTICAL_RESULTS.md`、`reports/COMPARISON_FOUR_LAW_SUPPLEMENT.md`、`reports/RATIO_ANALYTICAL_SUPPLEMENT.md` |
| 五模型 × 七问题的35格比较 | `reports/COMPARISON_P0_P4.csv`；论文表2为可读摘要 |
| 时间序列、相图、平衡及周期分支 | `figures/`，对应原始数值在 `results/` |
| 参数、单位、范围、文献映射 | `results/five_ecology_parameter_units.csv`、`five_ecology_bounds.csv`、`five_ecology_literature_mapping.csv`、`references/` |
| 五模型相同条件的真实数据比较 | `reports/FIVE_MODEL_ECOLOGY.md`、`results/five_ecology_*.csv` |
| 完成与验证情况 | `reports/MASTER_COMPLETION_MATRIX.csv`、`logs/MASTER_FINAL_STATUS.json` |
| 运行与失败记录 | `logs/MASTER_EXECUTION_HISTORY.json`；旧版本记录继续保留 |
| 表格与生成代码定位 | `results/TABLE_PROVENANCE_V2.csv` |

本次完成33项测试；两套五模型嵌套比较合计280次拟合、8610条预测和310个求解区间核验。P4在原参数范围的平均预测误差最低，P0在扩大范围后最低。数学结果分别说明共同性质、模型差异及机制交互；数据排名不被用作真实捕食机制的确认。

完整边界分类、一般全局吸引/周期唯一性、完整同宿分支，以及 Tanner 原始数值表到全部模型参数的校准仍有明确未解决范围。完成矩阵中保留 `partial`，不把局部证明写成一般定理。

## 复现

需要 Python 3、`requirements.txt` 中的依赖。重建 PDF 还需要本地 `pdflatex`。已生成的 PDF 直接可读。

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
PYTHON=.venv/bin/python bash run.sh all
```

`bash run.sh` 默认执行 `all`。也可使用 `tests`、`verify`、`paper` 或 `package`；`quick`、`full` 保留原基线程序的入口，不代表完成整个五模型研究。`reproduce_all.sh` 等价于 `run.sh all`。

`all` 顺序复现原基线、受控实验、旧四模型生态比较、数学审计、P4、五模型主参数范围与扩大范围比较、严格BD实例、周期延拓、独立检查、测试、论文和打包。两套参数范围始终同时报告，不按测试分数选择发布哪一套。

## 版本与证据

`reports/FINAL_REPORT_EN.pdf` 和同名旧报告是此前四模型主比较阶段的历史材料。当前结论入口为 `paper/PAPER_EN.pdf`，当前状态以带 `MASTER` 名称的报告和记录为准。旧数据、旧失败记录和先前原始来源仍保留，未用本轮结果覆盖其研究状态。

原始课程 PDF、C1–C4 原始观测、校验信息和筛选映射都随包提供。观测数据遵循 Figshare 版本1的 CC BY 4.0，来源和作者见论文参考文献。受限全文只提供文献链接，不假称读过其完整定理或恢复了数值表。所有计算均为本地CPU运行，没有云计算费用或投稿操作。
