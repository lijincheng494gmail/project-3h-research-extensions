# P4: ratio-dependent predation under the original weak-Allee growth law

## 1. Definition and role in the comparison

The fifth model uses the same prey growth as P0–P3:

\[
\dot x=xq(x)-\frac{axy}{x+cy},\qquad
\dot y=\frac{eaxy}{x+cy}-dy,\qquad
q(x)=r(1-x/K)(1+\alpha x).
\]

Assume `r,K,a,c,e,d>0` and `alpha>=0`. Positive alpha is retained in the principal synthetic examples. Alpha zero is an explicit logistic control. Define the response to be zero at `(0,0)`. If the population and time units are X, Y, T, then `a:X/(Y T)`, `c:X/Y`, `e:Y/X`, and `ec` is dimensionless. The same letters a and c in P0–P3 have different units. Parameter matching therefore uses an explicit reference intake rather than equating those numbers across all five models.

Use the following abbreviations only in this supplement:

\[
s=ea/d,\qquad \kappa=ec,\qquad B=a/c,
\quad Q=(a-d/e)/c,\quad h=d(s-1)/s.
\]

For positive coexistence, `s>1`, so Q and h are positive. These direct calculations extend the common comparison. They do not replace the original five-model research question.

## 2. Positivity, boundedness, and the origin

For nonnegative x and y, the response satisfies `0<=P<=a*y` and `P<=(a/c)*x`. Away from the origin,

\[
P_x=\frac{acy^2}{(x+cy)^2},\qquad
P_y=\frac{ax^2}{(x+cy)^2}.
\]

These derivatives are bounded by `a/c` and a on the nonnegative quadrant. The continuous extension is locally Lipschitz there. It is not differentiable at the origin: its restrictions to both axes are zero, but `P(t,t)/t=a/(1+c)` for positive t. Thus a single origin Jacobian cannot describe all approaches to the origin.

For positive states,

\[
q(x)-B\le\dot x/x\le q(x),\qquad
-d\le\dot y/y\le ea-d.
\]

These bounded per-capita rates on bounded x intervals prevent a positive solution from reaching an axis in finite time. Also `x(t)<=max(x(0),K)` by scalar comparison. For `W=e*x+y` and any `delta in (0,d]`,

\[
\dot W+\delta W
=ex[q(x)+\delta]-(d-\delta)y\le M,
\quad M=\max_{x\ge0}ex[q(x)+\delta]<\infty.
\]

Hence solutions are global and ultimately bounded. This cancellation argument is shared by P0–P4 and does not depend on denominator smoothness at the origin.

## 3. Permanence and extinction: verified parameter regions

### Proposition P4.1: a sufficient permanence region

If `r>B=a/c` and `ea>d`, both populations are uniformly persistent for all strictly positive initial states.

**Proof.** Choose `epsilon>0` and `delta>0` such that `q(x)>B+epsilon` for `0<=x<=delta`; this is possible because q(0)=r>B. In that strip, `xdot/x>=epsilon`. Every positive trajectory eventually reaches x=delta, and it cannot subsequently cross that line downward. Thus `liminf x>=delta`, independently of initial states. Since `ea>d`, choose `eta>0` and `gamma>0` such that

\[
\frac{ea\delta}{\delta+c\eta}-d>\gamma.
\]

After prey has reached delta, every state with `y<=eta` satisfies `ydot/y>=gamma`. Predators eventually reach eta and cannot subsequently cross it downward. These two lower bounds, together with boundedness, establish uniform persistence. The constants depend on parameters but not on initial states. QED.

The condition `ea>d` is necessary for permanence. For `ea<d`, predators decay exponentially. At `ea=d`, `ydot=-dc*y^2/(x+cy)<0`. If y approached a positive limit, boundedness of x and y would make this derivative uniformly negative, a contradiction. Therefore y tends to zero also at equality.

### Proposition P4.2: global predator-free convergence in a sufficient region

If `r>B` and `ea<=d`, every strictly positive solution tends to `(K,0)`.

**Proof.** The preceding argument gives `x>=delta>0` eventually and `y->0`. Consequently `a*y/(x+cy)->0`. For every small `epsilon>0`, the eventual prey equation lies between `xdot=x[q(x)-epsilon]` and `xdot=xq(x)`. The upper scalar comparison has limiting value K. On every fixed compact interval below K, q is strictly positive; sufficiently small epsilon makes the lower comparison's attracting positive root arbitrarily close to K. Therefore `liminf x>=K` and `limsup x<=K`. QED.

### Proposition P4.3: an open joint-extinction basin

If `B>r+d`, an open set of strictly positive initial conditions tends to `(0,0)`. This can hold even when `ea>d`.

**Proof.** Let `u=cy/x`. For positive states,

\[
\frac{\dot u}{u}=
\frac{ea}{1+u}-d-q(x)+\frac{Bu}{1+u},\qquad
\frac{\dot x}{x}=q(x)-\frac{Bu}{1+u}.
\]

As `x->0` and `u->infinity`, these right sides tend respectively to `B-d-r>0` and `r-B<0`. Continuity gives delta, U, and positive gamma such that, throughout `0<x<delta,u>U`, `udot/u>=gamma` and `xdot/x<=-gamma`. This open wedge is forward invariant. Thus x tends to zero, u tends to infinity, and `ydot/y=ea/(1+u)-d` eventually tends to `-d`, so y also tends to zero. QED.

This gives a mathematical reason why the P0–P3 invasion-threshold permanence theorem does not transfer to P4. Rare-predator invasion at `(K,0)` is `ea-d`, independent of K, but it does not exclude an origin basin.

The sufficient permanence region is not asserted to be necessary. Cases with `ea>d`, `r<=a/c<=r+d`, their equality boundaries, and other origin sectors require further classification. The theorem above explicitly settles a permanence region and a nonpermanence region.

## 4. All positive equilibria and exact root counts

The nonnegative boundary equilibria are `(0,0)` and `(K,0)`. An interior equilibrium requires `s>1`. The predator nullcline gives

\[
y^*=\rho x^*,\quad \rho=(s-1)/c,
\qquad q(x^*)=Q.
\]

Since Q>0, every positive root lies below K. Therefore all positive equilibria are obtained from a quadratic equation, with no additional roots hidden by numerical initialisation.

If `alpha*K<=1`, q is strictly decreasing on positive x up to K. There is exactly one positive equilibrium when `0<Q<r` and none when `Q>=r`.

If `alpha*K>1`, set

\[
x_v=\frac{\alpha K-1}{2\alpha},\qquad
q_{max}=\frac{r(\alpha K+1)^2}{4\alpha K}.
\]

The root count is:

| Parameter condition | Positive equilibria |
|---|---|
| `0<Q<r` | one, on the falling branch |
| `Q=r` | one positive root `K-1/alpha`; the zero root is excluded |
| `r<Q<q_max` | two, one rising and one falling |
| `Q=q_max` | one double root at x_v |
| `Q>q_max` | none |

When alpha is zero, the unique admissible root is `x*=K(1-Q/r)` if `0<Q<r`. All results are subject to `s>1`; there is no interior equilibrium for `s<=1`.

## 5. Local stability

At `(K,0)` the eigenvalues are `-r(1+alpha*K)` and `ea-d`. Thus it is locally attracting for `ea<d`, a saddle for `ea>d`, and nonhyperbolic at equality. Origin stability must be studied through directional or transformed dynamics rather than an ordinary differentiable Jacobian.

At a positive equilibrium, the Jacobian reduces to

\[
J=\begin{pmatrix}
x^*q'(x^*)+Q/s&-a/s^2\\
eQ(s-1)/s&-h
\end{pmatrix}.
\]

Hence

\[
T=x^*q'(x^*)+h(1/\kappa-1),\qquad
\Delta=-hx^*q'(x^*).
\]

The rising root has negative determinant and is a saddle. The falling root has positive determinant. It is locally attracting for T<0 and unstable for T>0. When `ec>=1`, every simple falling root is locally attracting. When `ec<1`, trace zero can occur on that root. The double root has one zero eigenvalue unless `ec=1`, in which case both eigenvalues vanish.

## 6. A direct sufficient global-coexistence theorem

### Proposition P4.4

If `r>a/c`, `ea>d`, `alpha*K<=1`, and `ec>=1`, the unique positive equilibrium attracts every strictly positive solution.

**Proof.** Proposition P4.1 gives permanence. Also `0<Q<a/c<r`, so Section 4 gives one positive equilibrium, on the falling branch. It is locally attracting by Section 5. For the Dulac multiplier `Dulac(x,y)=1/(xy)`, direct differentiation yields

\[
\nabla\cdot\left(\frac{\dot x}{xy},\frac{\dot y}{xy}\right)
=\frac{q'(x)}y+\frac{a(1-ec)}{(x+cy)^2}<0
\]

throughout the strictly positive quadrant: q'(x)<0 there when `alpha*K<=1`, including equality. The quadrant is simply connected, so there is no nonconstant periodic orbit. Permanence puts each omega-limit set in a compact interior region. The planar limit-set alternatives and uniqueness of the locally attracting equilibrium give convergence to that equilibrium. QED.

This is a sufficient global theorem. Global coexistence outside this parameter region, all basin boundaries, and global periodic-orbit uniqueness are not established here.

## 7. Enrichment: local stability changes in the opposite direction to P1

Hold r, alpha, a, c, e, and d fixed and vary K. On any simple interior branch, implicit differentiation of `q(x*,K)=Q` gives

\[
\frac{dx^*}{dK}
=-\frac{r x^*(1+\alpha x^*)}{K^2q'(x^*)},\qquad
\frac{dy^*}{dK}=\rho\frac{dx^*}{dK}.
\]

Both populations increase with enrichment on the falling branch. The trace derivative is

\[
\frac{dT}{dK}
=(q'+x^*q'')\frac{dx^*}{dK}
+\frac{rx^*(1+2\alpha x^*)}{K^2}
=\frac{r\alpha(x^*)^2(\alpha K+1)}
 {K^2(\alpha K-1-2\alpha x^*)}.
\]

For positive alpha, the denominator is negative on the falling branch and positive on the rising branch. Therefore `dT/dK<0` at every simple nonsaddle equilibrium. Also `dDelta/dK=-h*dT/dK>0`. Increasing K cannot destabilise an existing locally attracting P4 coexistence equilibrium through a local trace crossing. It can instead change an unstable falling equilibrium into a stable one. For the logistic control alpha=0, trace and determinant do not depend on K.

This is a fixed-parameter local-enrichment conclusion. Global cycles and basin changes may still matter. Its contrast with the P1 threshold `K_H=1/alpha+2*d/(ea)`, where enrichment destabilises coexistence, directly answers the original mechanism-comparison question.

When `Q>r`, enrichment can also create a saddle-node. Writing `v=Q/r>1`, the fold carrying capacity is

\[
K_{fold}=\frac{2v-1+2\sqrt{v(v-1)}}{\alpha}.
\]

This follows from `q_max=Q` with `alpha*K>1`. The simple-branch derivatives above do not apply at that fold.

## 8. Exact positive bifurcation examples

All parameters below are synthetic and dimensionless. Root substitution, analytic derivatives, independent Taylor expansion, two independent Hopf coefficient formulas, and parameter derivatives are checked in `src/ratio_analysis.py` and `results/ratio_validation.csv`.

### 8.1 Saddle-node

Set `r=8/25,K=8,alpha=1/2,a=2,c=2,e=d=1`. At `(x,y)=(3,3/2)`, `Q=q_max=1/2`, `q'=0`, `q''=-1/25`, and `dq/dr=25/16`. The other eigenvalue is `T=-1/4`, which is nonzero. The predator nullcline can be eliminated locally because `G_y=-h=-1/2`. On that nullcline the prey equation is `x[q(x)-Q]`; its second x derivative at the double root is nonzero and its r derivative is nonzero. These are the local fold nondegeneracy and unfolding conditions. Increasing r creates a saddle and a stable positive equilibrium near the fold.

### 8.2 Subcritical Hopf and enrichment stabilisation

Set `r=3/2,K=3,alpha=1/2,a=2,c=2/3,e=d=1`. At `(x,y)=(1,3/2)`,

\[
J=\begin{pmatrix}1/2&-1/2\\3/4&-1/2\end{pmatrix},\quad
T=0,\quad\Delta=1/8,\quad\omega=\sqrt{2}/4.
\]

Along the equilibrium branch, `dx/dr=4`, `dT/dr=-19/6`, and `dT/dK=-5/12`. Thus either parameter gives a transverse trace crossing.

Define `X=x-1` and `Y=sqrt(2)[(y-3/2)-(x-1)]`, without rescaling time. Equivalently, the original displacement is `S(X,Y)` with `S=[[1,0],[1,1/sqrt(2)]]`; the linear part becomes `Xdot=-omega*Y,Ydot=omega*X`. In the planar Kuznetsov convention with `q=p=(1,-i)/sqrt(2)`, the cubic derivative sum is `-47/24` and the quadratic bracket is `29*sqrt(2)/48`. Therefore

\[
l_1=\frac{-47/24}{8\omega}
+\frac{29\sqrt2/48}{8\omega^2}
=\frac{11\sqrt2}{96}>0.
\]

An independently coded complex-eigenvector formula in the same rotated coordinates gives the same value. The coefficient's magnitude depends on the state normalization, so only coefficients with their coordinate convention are compared. This is a subcritical Hopf. For K just above 3, the equilibrium is locally stable and a small unstable periodic orbit exists nearby. The analogous stable-equilibrium side under r variation is r just above 3/2. Large cycles and distant basin geometry are not implied by this local theorem.

### 8.3 Generic Bogdanov–Takens point

Set `r=16/25,K=8,alpha=1/2,a=2,c=e=d=1`. At `(x,y)=(3,3)`,

\[
J=\begin{pmatrix}1/2&-1/2\\1/2&-1/2\end{pmatrix},\quad J^2=0,\quad J\ne0.
\]

Choose `q0=(1,1),q1=(0,-2),p0=(1,0),p1=(1/2,-1/2)`. They satisfy `Jq0=0,Jq1=q0,J^T p1=0,J^T p0=p1` and the dual pairings. For the full second-derivative tensor B,

\[
B(q_0,q_0)=(-6/25,0),\qquad B(q_0,q_1)=(0,0).
\]

The quadratic coefficients are

\[
a_{BT}=\tfrac12\langle p_1,B(q_0,q_0)\rangle=-3/50,
\quad b_{BT}=\langle p_0,B(q_0,q_0)\rangle+
\langle p_1,B(q_0,q_1)\rangle=-6/25.
\]

Both are nonzero. For parameters `(r,c)`, define `H=q-Q` and the equilibrium trace `T=xq'+h(1/(ec)-1)`. At the event,

\[
D_{(x,r,c)}(H,H_x,T)
=\begin{pmatrix}
0&25/16&1\\-2/25&0&0\\-6/25&0&-1/2
\end{pmatrix},\qquad \det=-1/16\ne0.
\]

The trace of the full Jacobian restricted to the predator nullcline equals `T+H`; adding this H row does not change the rank. Also `G_y=-1/2` permits the local equilibrium reduction. Thus this is a generic local BT unfolding in `(r,c)`. Numerical continuation of its complete homoclinic branch and all global periodic orbits remains separate work.

## 9. A verified joint-extinction/coexistence example

For `r=1,K=8,alpha=1/2,a=4/5,c=8/15,e=1,d=1/5`, predator invasion is positive: `ea/d=4`. Also `a/c=3/2>r+d=6/5`, so Proposition P4.3 gives an open origin basin. Since Q=9/8 and `q=1+(3/8)x-x^2/16`, the positive prey equilibria are exactly `3-sqrt(7)` and `3+sqrt(7)`. The smaller equilibrium is a saddle, and substitution in the trace formula shows that the larger equilibrium is a hyperbolic attractor. It therefore has an open coexistence basin as well.

Two trajectories illustrate these mathematically established basins. Initial state `(0.005,0.5)` approaches the origin, whereas `(5.8,30)` approaches the larger coexistence equilibrium. Both integrations use log-state DOP853 and are repeated at tighter tolerances and half the maximum step. Tables preserve the initial states, endpoint values, and numerical differences. Finite endpoints are not used as substitutes for the origin-basin proof.

## 10. Evidence and literature relationship

Evidence files are `results/ratio_validation.csv`, `results/ratio_random_root_probes.csv`, `results/ratio_exact_bifurcations.csv`, `results/ratio_enrichment_branches.csv`, `results/ratio_origin_basin_runs.csv`, and `results/ratio_origin_basin_trajectories.csv`. Figures are `figures/ratio_enrichment.png` and `figures/ratio_origin_and_coexistence.png`. The script uses fixed audit seed 20261119; the deterministic dynamics contain no stochastic perturbation.

Hsu, Hwang, and Kuang (2001), *Global analysis of the Michaelis–Menten-type ratio-dependent predator-prey system*, Journal of Mathematical Biology 42:489–506, DOI [10.1007/s002850100079](https://doi.org/10.1007/s002850100079), study logistic prey growth. Their author-hosted [primary paper](https://www.math.nthu.edu.tw/~sbhsu/ratio-dependent.pdf) documents ratio-model mutual extinction, global dynamics, and the logistic enrichment comparison. Those results establish relevant prior context. They are not imported without checking into the present quadratic per-capita weak-Allee growth law. The local normal-form definitions follow Kuznetsov's Hopf convention and the Guckenheimer–Kuznetsov BT convention already cited in the main analytical report. Other published ratio-dependent Allee bifurcation studies must also be considered when judging novelty; the present calculations establish results for the stated equations, not a priority claim.

The strongest results supplied here cover every requested comparison topic: positive bounded solutions; explicit permanence and extinction regions; all equilibrium root counts; local stability; a direct sufficient global theorem; an exact local enrichment result; exact positive fold, Hopf, and BT examples; and their ecological meaning. The remaining origin sectors and global cycle structure are marked as partial rather than described as a full parameter classification.
