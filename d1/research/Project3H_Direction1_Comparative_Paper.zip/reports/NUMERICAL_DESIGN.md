# Controlled numerical design and interpretation

All parameters in `controlled_*.csv` are synthetic and dimensionless. They are not fitted Tanner or chemostat estimates. The main growth law remains `x'=r x(1-x/K)(1+alpha x)-P`, `y'=eP-dy`. No predator competition or stochastic dynamics are added.

## Matched mechanisms and fairness

Two scenarios use `(r,K,e,d,xref)=(0.7,10,0.6,0.3,10)`. Scenario A uses `(alpha,qref)=(0.12,0.9)`; scenario B uses `(0.4,2.4)`. Here `qref=lim[y->0]P(xref,y)/y`. For the four main responses, set `a=qref(1+b*xref)/xref`. This makes low-predator intake at carrying capacity, and hence the predator invasion number, exactly equal within each scenario. Main interference is `c=0.2`, where present; prey saturation is `b=0.15`, where present. The normalized `a`, `m=a/c`, and `beta=1/c` for FA are saved in the parameter table.

This matching fixes one operating point. It does not equate the whole response surface or the equilibrium intake. In enrichment scans, `a` stays fixed at its baseline-K value: changing K therefore changes enrichment rather than refitting predation. In b/c grids, a is renormalized with b to retain the same invasion threshold. In alpha/c grids, the same normalization is used. All four primary comparisons retain the same weak-Allee law.

The ratio extension uses `P=a x y/(x+c y)`, `a=qref`, and `c=2` separately. Its c has units of prey/predator density rather than inverse predator density. Its low-density origin is not differentiable, and it is not included in the smooth-origin invasion or permanence proof. This choice matches reference intake only; it does not make its boundary geometry equivalent to the four smooth responses.

## Algebraic equilibrium enumeration

Write `q(x)=r(1-x/K)(1+alpha*x)` and `A=ea/d-b`. For c>0, every positive smooth-model equilibrium solves

`H(x)=(ce/d)*x*q(x)-A*x+1=0`, `1/A < x < K`, `y=(A*x-1)/c`.

The cubic roots are enumerated and filtered by physical admissibility and the original ODE residual. For c=0 there is the single candidate `x=1/A`, `y=exq(x)/d`, subject to positivity. Thus algebraic completeness replaces the pilot's multistart search, in exact arithmetic. Floating-point roots near a multiple root remain conditioned numerical objects; residuals, event equations, and exact test probes provide crosschecks.

Ratio equilibria solve `q(x)=(a-d/e)/c`, a quadratic, and `y=(ea/d-1)x/c`. They require `ea>d`. All branches, including unstable branches and saddles, appear in the K tables. A branch rank is the sorted root rank at that parameter value, not an assertion that ranks survive a fold without changing.

## Long horizons, cycle descriptions, and solver audit

Each model/scenario has three positive initial states `(7,0.2)`, `(2,3)`, and `(9,1)`. A single deterministic integration to T=1200 supplies summaries at T=600 and T=1200. Samples are every one time unit; every second sample is archived in the trajectory CSV. DOP853 runs in log populations with `(rtol,atol,max_step)=(1e-8,1e-10,2)`. The first initial state of every model/scenario is rerun with `(1e-10,1e-12,0.5)`. The solver audit retains pointwise differences, endpoint differences, late means, and amplitudes. Ratio per-capita rates use stable logistic functions of log ratios; no population floor is inserted into the dynamics. Values below floating-point range can print as zero, with minimum log state retained.

A late prey oscillation is called a *persistent oscillation candidate* only if there are at least four detected peaks in the final quarter and both mean and amplitude changes from the preceding quarter are below 5%. A small span relative to the late means, below 1e-4, is called near equilibrium. These are finite-horizon descriptions. They do not establish cycle uniqueness or global stability. For an attracting cycle, small phase drift can enlarge pointwise trajectory error; tail means and amplitudes provide the complementary comparison.

## H2 growth ablation

For FA and LV, compare the main growth law, logistic growth (`alpha=0`), and an explicit removal of prey self-limitation (`q=r(1+alpha*x)`). The first two run to T=1200. The third runs only to T=40, with an event stopping populations at 1e6. The exact located event time and state are appended even if they fall between requested sample times; `event_t`, `event_population`, `event_x`, and `event_y` retain that terminal evidence. This extension can have unbounded growth, so a finite-time maximum is not a boundedness claim. The growth ablation is not counted as a functional-response comparison.

## H3 recovery and H4 interaction

FA and BD sweep `c=0,0.025,0.05,0.1,0.2,0.4,0.8,1.2` while keeping all other response parameters fixed. This preserves the invasion number exactly within each family/scenario. At every stable interior equilibrium, increase predator density by 10%, simulate to T=600, and report the first sampled time after the last observation more than 2% from either equilibrium population. Unstable equilibria have no assigned recovery time. The spectral relaxation time `-1/max Re(lambda)` is retained as a separate local linear metric.

A 2x2 FA factorial sets alpha to 0 or its scenario value and c to 0 or its scenario value. The predeclared continuous interaction contrast is `joint-alpha_only-interference_only+neither` for equilibrium trace, equilibrium prey, and late x/y amplitude. An interaction is a change in this metric; it is not automatically a newly proved ecological mechanism.

## H5 exact joint-mechanism probe

Use FA with `r=e=d=1`, `K=8`, `alpha=1/2`, `a=9/2`, and `c=8/3`. Its reduced polynomial is

`H(x)=1-(11/6)x+x^2-x^3/6=-(x-1)(x-2)(x-3)/6`.

The interior prey coordinates are exactly 1, 2, and 3. Direct Jacobian checks give a stable equilibrium, saddle, and stable equilibrium. Removing alpha or c, while retaining a, leaves one positive equilibrium. The joint model therefore admits multiple stable coexistence states that these two component ablations do not admit. Multiple initial states to T=1200 illustrate the two attraction basins. This proves existence for this parameter construction, not prevalence across ecology or necessity in all models.

A second exact root probe, FA `(r,K,alpha,e,d,a,c)=(1,10,1,0.6,0.9,2.25,0.625)`, has prey equilibria 2, 3, and 4. It tests the algebraic root enumerator separately from the primary scenarios.

## Local bifurcation checks

K scans retain all positive roots. Trace-sign changes seed the simultaneous equations `H=0, trace(J)=0` (or the c=0 nullcline equation). A Hopf event is labelled numerically nondegenerate only when all parameters and populations are admissible, det(J)>0, the equilibrium residual is small, the derivative of trace along the K branch is nonzero, and the first Lyapunov coefficient is nonzero. Tensor derivatives through order three come from the exact Taylor expansion of the linear rational denominator. The standard complex-eigenvector formula computes l1; independent normal-form sign and tensor/Jacobian tests validate the implementation. l1<0 gives a locally stable small-amplitude cycle on the unstable-equilibrium side of the event; l1>0 gives an unstable cycle on the stable-equilibrium side. These are floating-point local checks, not interval-certified bifurcation proofs.

For c>0, solve `H=H_x=0` for candidate folds and check `H_xx != 0`, `H_K != 0`, and `trace(J) != 0`. Because the predator-nullcline normal derivative is nonzero at a positive equilibrium, these are the scalar reduction's saddle-node nondegeneracy conditions. A failed check remains a candidate. No Bogdanov-Takens classification is inferred from a near-zero determinant or from a plot.

All solver exceptions and terminations are retained in `controlled_failures.csv` or the row-level status. No failed case is silently substituted with a successful trajectory.

## Exact local bifurcation oracles

Three independently derived mathematical constructions are crosschecked in `controlled_local_exact_oracle_audits.csv`. They are separate from the primary matched scenarios.

- Saddle-node: FA `r=e=d=1,K=8,alpha=.5,a=6.25,c=4`, at `(x,y)=(1,21/16)`. The reduced H factors as `-.25(x-1)^2(x-4)`, `H_xx=1.5`, `H_a=-1`, and `trace=-.59`.
- Bogdanov-Takens: FA `r=8/27,K=6,alpha=10/3,a=2,c=1,e=d=1`, at `(1.5,2)`. The Jacobian is nonzero and nilpotent. The stated dual Jordan bases give normal-form coefficients `a_BT=32/243`, `b_BT=-22/81`, and the `(a,c)` unfolding determinant `34/243`. The independent tensor calculation checks these coefficients and nilpotence. A local a/c equilibrium grid documents the nearby branches; no homoclinic curve is claimed from that grid. The proof is recorded in `ANALYTICAL_RESULTS.md`.
- Hopf: FA `r=.36,K=6,alpha=7/3,a=2,c=1,e=d=1`, at `(1,1)`, has trace zero, determinant 1/4, trace derivative along r of `-1/6`, and negative l1. Numerical l1 in unit-eigenvector coordinates can differ in scale from the planar transformed-coordinate coefficient `-579/5000`; its sign must agree. Long integrations at r=.34,.36,.38 compare the two sides and the critical point.

## Verification correction: critical slow decay

The generic finite-window oscillation heuristic can misclassify a slowly decaying weak focus at an exact Hopf point because neighboring window amplitudes are similar. The exact r=.36 oracle is therefore explicitly labelled `critical_Hopf_slow_decay_not_cycle`, using the proved trace-zero and negative-l1 result. The unadjusted label is retained for audit. Neighboring r=.34 and r=.38 finite-horizon results retain their numerical descriptions; no true cycle is inferred from a slowly changing tail.

## Verification correction: the exact saddle initial state

In the H5 probe, initial index 4 is exactly `(x0,y0)=(2,3)`, the saddle equilibrium. Its exact mathematical solution is constant. Floating-point errors can excite the unstable direction and produce a delayed escape to an attracting equilibrium; the displayed escape is a numerical sensitivity demonstration. This case is explicitly tagged `exact_saddle_roundoff_escape_not_basin_evidence` in the run and trajectory CSVs and labelled in the figure. It is not an extra attraction-basin initial condition. The other four, non-equilibrium initial states are tagged `independent_initial_condition` and provide the numerical basin illustrations. No initial state or numerical tolerance was changed by this annotation correction.
