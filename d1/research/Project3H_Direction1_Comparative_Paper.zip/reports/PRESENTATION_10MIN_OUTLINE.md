# Ten-minute presentation outline

This is a preparation outline, not a delivered oral presentation.

| Time | Topic | Evidence to show |
|---|---|---|
| 0:00-1:00 | Explain the research question, original equation, and absence of h | Model table in FINAL_REPORT_EN; distinguish four primary responses |
| 1:00-2:00 | Explain fair comparison at one operating point | controlled_parameters.csv; same R=1.8 or 4.8 within scenarios |
| 2:00-3:30 | Shared positivity, boundedness, and invasion/persistence threshold | Analytical report §§2-4; explain R in words |
| 3:30-5:00 | Show why stability still differs and interference need not speed recovery | controlled_enrichment_all_branches.png and recovery table |
| 5:00-6:30 | Present exact joint-mechanism multistability | controlled_joint_multistability.png; exact roots 1,2,3 |
| 6:30-7:30 | Give one exact Hopf and the BT nondegeneracy checks | exact_FA_bifurcations.csv; distinguish local proof from global curve |
| 7:30-9:00 | Explain four whole-experiment prediction tests | ecology_nested_all_folds.png; a/b bounds and no mechanism identification |
| 9:00-10:00 | State the main findings and remaining work | Hypothesis matrix; Tanner and global continuation gaps |

Suggested questions to prepare: Why does c not enter R? Why can three equilibria exist? What distinguishes a nearly periodic transient from a limit cycle? Why do boundary-hitting fits limit identification? Why is predator demographic growth not the prey-free death parameter d? Which results are proofs, and which are numerical evidence?
