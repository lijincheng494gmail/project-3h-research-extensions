# Analytical results: comparative predation mechanisms

These are direct calculations for the stated equations, followed by reproducible algebraic checks. They are distinct from trajectory labels and from estimates obtained using observations. All examples below are synthetic. Their numerical parameter values are dimensionless; no Tanner or chemostat parameter estimate is claimed.

## 1. Equations, identity, and units

Write

\[
\dot x=xq(x)-P(x,y),\qquad \dot y=eP(x,y)-dy,
\quad q(x)=r(1-x/K)(1+\alpha x).
\]

The four main responses are contained in

\[
P=\frac{axy}{D},\qquad D=1+bx+cy.
\]

FA has `b=0,c>0`; LV has `b=c=0`; Holling II has `b>0,c=0`; Beddington-DeAngelis (BD) has `b,c>0`. Assume `r,K,a,e,d>0`, `alpha>=0`, and `b,c>=0`. The main comparison keeps this prey growth family. The optional ratio response is treated separately in Section 10.

The teacher's Eq. (1.1) has `a=m/beta`, `c=1/beta`, hence `m=a/c`, `beta=1/c`. It contains no `-h*y^2`. For an unnormalized BD denominator `A*x+B*y+C`, the teacher response requires `A=0,B=1,C=beta>0`. The hint `A=C=0,B=1` would instead cancel `y` and yield `m*x`; it is incorrect for positive beta. This follows by direct substitution in the supplied brief, pp. 1 and 3.

If prey, predator, and time units are `X,Y,T`, then `r,d:T^-1`, `K:X`, `alpha,b:X^-1`, `c:Y^-1`, `a:(Y T)^-1`, `e:Y/X`, `m:T^-1`, and `beta:Y`. The per-capita growth initially increases only if `alpha*K>1`, because `q'(0)=r(alpha-1/K)`. Positive alpha alone does not establish an initial Allee increase.

Define

\[
q'=r(\alpha-K^{-1}-2\alpha x/K),\quad q''=-2r\alpha/K,\quad
R=\frac{eaK}{d(1+bK)},\quad A=ea/d-b.
\]

## 2. Positivity and boundedness for the four main laws

On the nonnegative quadrant `D>=1`. Each equation is its own population times a continuous per-capita rate. Uniqueness prevents finite-time crossing of an axis; positive initial conditions remain positive.

Also `xdot<=x*q(x)`. A scalar comparison gives `limsup x<=K` and `x(t)<=max(x(0),K)`. To bound predators without assuming a prey lower bound, use `W=e*x+y`. Predation cancels:

\[
\dot W=exq(x)-dy.
\]

Set `delta=d/2` and `M=max_{x>=0} e*x*(q(x)+delta)`, which is finite because the leading growth term is negative for large x, including when alpha is zero. Then

\[
\dot W+\delta W\le M,
\qquad W(t)\le W(0)e^{-\delta t}+M/\delta.
\]

Thus solutions exist for all positive time and enter a bounded absorbing set. The bound depends on parameters but not on the initial state after a transient.

## 3. Predator extinction and permanence: an exact threshold

**Proposition.** For all four smooth responses, every strictly positive solution is uniformly persistent if and only if `R>1`. If `R<=1`, every such solution tends to `(K,0)`.

Here uniform persistence means that parameter-dependent positive lower bounds for both populations hold asymptotically for every strictly positive initial state. The bounds need not be large or biologically measurable.

### 3.1 Global extinction when R<=1, including equality

Use the nonnegative function

\[
V=\frac{e}{1+bK}\left[x-K-K\log(x/K)\right]+y.
\]

It is proper on `x>0,y>=0`: a bounded sublevel set keeps x away from zero and infinity and bounds y. Direct differentiation gives

\[
\dot V=\frac{e}{1+bK}(x-K)q(x)
+y\left[\frac{eaK(1+bx)}{(1+bK)(1+bx+cy)}-d\right].
\]

For every `x>0`, including `x>K`, `(x-K)q(x)=-r(x-K)^2(1+alpha*x)/K<=0`. Since `(1+bx)/(1+bx+cy)<=1`, the square bracket is at most `d(R-1)`. Hence `Vdot<=0` when `R<=1`; the initial `x>K` transient causes no exception.

When `R<1`, equality requires `x=K,y=0`. At `R=1,c>0`, equality still requires `x=K,y=0`. At `R=1,c=0`, `Vdot=0` on `x=K`, but every point there with `y>0` has `xdot=-a*K*y/(1+bK)<0`; it leaves that set. Therefore the largest invariant subset of `{Vdot=0}` is `(K,0)` in every case. LaSalle's invariance principle on a compact sublevel set proves convergence to `(K,0)`. This also proves that permanence is impossible for `R<=1`.

### 3.2 An elementary persistence proof when R>1

The following excursion argument supplies positive uniform lower bounds; it does not use a finite simulation or an unverified persistence theorem.

First choose an eventual uniform predator upper bound `M_y>0` from Section 2, and put

\[
\delta_x=\min\{K/2,d/(2ea)\},\quad
T_x=\max\{0,(2/d)\log(4aM_y/r)\}.
\]

Whenever `x<=delta_x`, `q(x)>=r/2`, `ydot<=-d*y/2`, and `xdot/x>=-a*M_y`. During a downcrossing excursion below `delta_x`, y falls below `r/(4a)` by time `T_x` if the excursion lasts that long. Thereafter `xdot/x>=r/4` while x remains below the threshold. Thus the excursion must end, and its minimum prey density is at least

\[
m_x=\delta_x\exp(-aM_yT_x)>0.
\]

If a trajectory initially lies below the threshold, the same eventual positive prey growth makes it exit in finite time; subsequent excursions have the stated bound. Therefore `liminf x>=m_x`. Fix `m=m_x/2`, so that eventually `x>=m`.

Because `R>1`, choose small positive `epsilon<K/4` and `eta` such that

\[
\lambda=\frac{ea(K-\epsilon)}{1+b(K-\epsilon)+c\eta}-d>0.
\]

Also make `a*eta<=q_min/2`, where `q_min=min_{x in [m,K-epsilon]}q(x)>0`, and set `kappa=q_min/2`. During an excursion with `y<=eta` and `x<=K-epsilon`, `xdot/x>=kappa`. Consequently x reaches `K-epsilon` in at most

\[
T_y=\kappa^{-1}\log[(K-\epsilon)/m].
\]

The vector field at `x=K-epsilon` points toward larger x while `y<=eta`, so x cannot recross downward during that low-predator excursion. Once x is above this threshold, `ydot/y>=lambda`; before it reaches the threshold, `ydot/y>=-d`. Therefore each downcrossing of `y=eta` has minimum at least `m_y=eta*exp(-d*T_y)>0`. An initially smaller y also exits its low-density interval in finite time. Hence `liminf y>=m_y`, completing the proof.

## 4. All nonnegative equilibria and exact root count

The boundary equilibria are `O=(0,0)` and `E_K=(K,0)`. There are no other points on the axes because q is positive on `(0,K)` and predators die on `x=0`.

For an interior equilibrium, the predator equation gives

\[
D=ea x/d,\qquad cy=Ax-1,
\qquad y=exq(x)/d.
\]

Thus `0<x<K` and `Ax>1`. These inequalities are possible exactly when `AK>1`, equivalently `R>1`.

* If `c=0`, the unique interior equilibrium is `x*=1/A`, `y*=e*x* q(x*)/d`, provided `R>1`. This holds for LV and Holling II for every alpha.
* If `c>0`, all interior equilibria are precisely the real roots in `(1/A,K)` of

\[
H(x)=(ce/d)xq(x)-Ax+1=0,\qquad y=(Ax-1)/c.
\]

This is a cubic when alpha is positive and a quadratic when alpha is zero. `H(1/A)>0` and `H(K)<0` for `R>1`, so at least one admissible root exists. There are at most three, counting multiplicity. Away from repeated roots, there are either one or three admissible roots. If `alpha*K<=1`, then q is strictly decreasing on `(0,K)` and `H(x)/x=(ce/d)q(x)-A+1/x` is strictly decreasing. The interior equilibrium is then unique. Alpha zero or interference zero each excludes three interior roots.

The coefficients, in ascending powers, are

\[
\left(1,\;cer/d-A,\;(cer/d)(\alpha-K^{-1}),\;-cer\alpha/(dK)\right).
\]

The polynomial approach enumerates every algebraic root before admissibility checks. A multistart two-dimensional root finder alone does not establish completeness. Near a repeated root, separate event equations are needed because floating-point polynomial roots can split a multiple root into a complex pair.

## 5. Local stability

At the origin the eigenvalues are `r,-d`, so it is a saddle. At `(K,0)` they are `-r(1+alpha*K)` and `d(R-1)`. Thus this point is locally asymptotically stable for `R<1`, a saddle for `R>1`, and nonhyperbolic but globally attracting from the positive quadrant at equality.

At an interior equilibrium the Jacobian is

\[
J=\begin{pmatrix}
xq'+bxq/D & -a x(1+bx)/D^2\\
ea y(1+cy)/D^2 & -dcy/D
\end{pmatrix}.
\]

Its trace and determinant are

\[
T=xq'+bxq/D-dcy/D,
\qquad \Delta=\frac{dq}{D}\left[1-(ce/d)x^2q'\right].
\]

For `c>0`, equivalently `Delta=-(d*q*x/D)*H'(x)`. A negative determinant gives a saddle. A positive determinant and negative trace give local asymptotic stability; positive trace gives instability. Zero trace or determinant requires further analysis. In the three-simple-root case the middle root is a saddle; the other two have positive determinant, but their traces must still be checked.

## 6. A proved global coexistence region

**Sufficient condition:** `R>1` and `K*(alpha+b)<=1` imply a unique globally asymptotically stable interior equilibrium for each of the four smooth laws.

To prove this, use the Dulac multiplier `B=D/(x*y)` in the positive quadrant. Its divergence is

\[
\nabla\cdot(BF,BG)
=\frac{(1+bx)q'+bq}{y}+cq'-dc/x.
\]

Write `L=(1+bx)q'+bq`. Then

\[
L/r=\alpha-K^{-1}+b
+[2b(\alpha-K^{-1})-2\alpha/K]x-3b\alpha x^2/K.
\]

Under the stated condition, every coefficient is nonpositive, and `L<0` for `x>0`; also `q'<=0`. The divergence is strictly negative throughout the positive quadrant. This excludes periodic orbits. The condition also implies uniqueness by Section 4 and a negative equilibrium trace by Section 5. Persistence confines omega-limit sets away from the boundary; the planar Poincare-Bendixson theorem then gives convergence to the unique equilibrium. This is a sufficient condition. Failure of the inequality does not establish instability or a cycle.

For FA and LV, it reduces to `alpha*K<=1`. Many biologically increasing weak-Allee scenarios lie outside this simple global theorem. Their global phase portraits are not settled by this sufficient condition.

## 7. Enrichment and invasion-matched interference

For `c=0`, equilibrium prey `x*=d/(ea-db)` is independent of K at fixed response coefficients. Equilibrium predator density increases with K whenever the equilibrium exists. Stability can still change because q' and q change.

For `c>0`, along any simple branch,

\[
\frac{dx_*}{dK}=-H_K/H_x,\qquad
H_K=(ce/d)x\,r x(1+\alpha x)/K^2>0.
\]

Hence prey and predator equilibrium densities increase with K on every nonsaddle branch (`H_x<0`); on a saddle branch the derivatives have the opposite sign. This statement concerns branch position, not stability: the total derivative of T can have either sign.

The invasion ratio R is independent of c. Therefore changing interference at fixed `a,b,r,K,alpha,e,d` exactly preserves invasion while changing the interior trace, determinant, equilibria, and recovery rates. This provides a mathematically controlled H3 contrast. Equal low-predator predation at a reference prey density can be obtained using `a_b=a_ref*(1+b*x_ref)`. Such matching equates one operating point and generally does not equate all densities, all derivatives, or every R when K differs from `x_ref`.

## 8. Verified local bifurcation examples in the original FA model

The examples in this section use positive original parameters and `b=0`. The implicit-function and normal-form calculations are analytical. `src/analytic_checks.py` writes their independent floating-point checks to `results/exact_FA_bifurcations.csv` and `results/analytic_validation.csv`. Coordinates and coefficient conventions are stated so that signs and numerical values are reproducible. No h parameter is introduced.

### 8.1 Forward transcritical bifurcation

At `a_TC=d(1+bK)/(eK)`, R crosses one transversely as a varies, because `d[d(R-1)]/da=eK/(1+bK)>0`. The fast prey eigenvalue is strictly negative. Let `s=r(1+alpha*K)` and `P_0=a_TC*K/(1+bK)`. The center-manifold prey displacement is `u=-(P_0/s)*y+O(y^2,mu*y)`. With `mu=d(R-1)`, the predator equation becomes

\[
\dot y=\mu y-Cy^2+O(y^3,\mu y^2),\quad
C=\frac{ea_{TC}P_0}{s(1+bK)^2}+\frac{dc}{1+bK}>0.
\]

Thus the positive coexistence branch emerges forward for `R>1`. The argument applies to all four laws, with c allowed to be zero.

### 8.2 Nondegenerate positive saddle-node

Take `r=e=d=1,K=8,alpha=1/2,c=4,a=25/4`. Then

\[
H(x)=-\tfrac14(x-1)^2(x-4).
\]

At `(x,y)=(1,21/16)`, `H=H_x=0`, `H_xx=3/2`, `H_a=-1`, and `T=-59/100`. The zero eigenvalue is simple and the scalar fold and parameter-transversality conditions are nonzero. This is a genuine saddle-node in a; another interior equilibrium `(4,6)` remains. Locally `H=-delta_a+(3/4)*delta_x^2+...`, so increasing a creates a stable/saddle pair near x=1.

### 8.3 Nondegenerate supercritical Hopf in FA

Take `r=9/25,K=6,alpha=7/3,a=2,c=e=d=1`. At `E=(1,1)`,

\[
J=\begin{pmatrix}1/2&-1/2\\1&-1/2\end{pmatrix},\quad
T=0,\quad \Delta=1/4,\quad \omega=1/2.
\]

Vary r while holding the other coefficients fixed. On the equilibrium branch, implicit differentiation gives `dx/dr=50/9`. Using `T=x*q'-1+1/(a*x)` on equilibria yields `dT/dr=-1/6`, so the eigenvalue real parts cross transversely.

Use `X=x-1`, `Y=(y-1)-(x-1)`, without rescaling time. The linear part is `Xdot=-omega*Y,Ydot=omega*X`. For the nonlinear terms f,g, the nonzero second derivatives needed here are `f_XX=11/50,f_YY=1/2,g_XX=7/25,g_YY=-1`, with `f_XY=g_XY=0`. The cubic derivative sum is `f_XXX+f_XYY+g_XXY+g_YYY=33/50`; the quadratic bracket is `-351/625`.

Adopt Kuznetsov's planar convention `q=p=(1,-i)/sqrt(2)`:

\[
l_1=\frac{f_{XXX}+f_{XYY}+g_{XXY}+g_{YYY}}{8\omega}
+\frac{f_{XY}(f_{XX}+f_{YY})-g_{XY}(g_{XX}+g_{YY})-f_{XX}g_{XX}+f_{YY}g_{YY}}{8\omega^2}
=-\frac{579}{5000}<0.
\]

The formula and its normalization are described in [Kuznetsov's author-written Hopf article](https://www.scholarpedia.org/article/Andronov-Hopf). Thus this is a supercritical Hopf. Stable small cycles occur on the side with positive equilibrium trace, here r just below `9/25`. This proves local cycle existence; it does not prove global uniqueness or describe distant cycles.

For comparison, LV admits the exact Hopf threshold `K_H=1/alpha+2*x*`, where `x*=d/(ea)` and alpha is positive. Its trace derivative with respect to K is positive at the threshold. In coordinates `X=x-x*`, `Y=(a*x*/omega)*(y-y*)`, the same convention gives `l1=q''/(4*omega)=-r*alpha/(2*K_H*omega)<0`. Therefore weak-Allee growth alone can produce a Hopf; interference is not necessary for every oscillatory mechanism.

### 8.4 Nondegenerate Bogdanov-Takens point in FA

Take `r=8/27,K=6,alpha=10/3,a=2,c=e=d=1`. At `E=(3/2,2)`,

\[
J=\begin{pmatrix}2/3&-1/3\\4/3&-2/3\end{pmatrix},
\quad J^2=0,\quad J\ne0.
\]

Choose the Jordan and adjoint chains

\[
q_0=(1,2),\ q_1=(0,-3),\ p_0=(1,0),\ p_1=(2/3,-1/3).
\]

They satisfy `Jq0=0,Jq1=q0,J^T p1=0,J^T p0=p1`, and the dual normalization. If B is the full second-derivative tensor in the original coordinates, direct differentiation gives

\[
B(q_0,q_0)=(32/81,0),\qquad B(q_0,q_1)=(-2/3,2/3).
\]

Hence

\[
a_{BT}=\tfrac12\langle p_1,B(q_0,q_0)\rangle=32/243,
\quad b_{BT}=\langle p_0,B(q_0,q_0)\rangle+\langle p_1,B(q_0,q_1)\rangle=-22/81.
\]

Both are nonzero. These coefficient definitions follow the [Guckenheimer-Kuznetsov BT article](https://www.scholarpedia.org/article/Bogdanov-Takens_bifurcation). No time scaling is used in the derivative calculation.

For unfolding, hold `r,K,alpha,e,d` fixed and vary `(a,c)`. On the predator nullcline, set `H=c*x*q-a*x+1` and use the equilibrium trace expression `T_short=x*q'-1+1/(a*x)`. The full trace restricted to that nullcline differs from `T_short` by `H/(c*x)`. Thus the rank test using H, H_x, and `T_short` is equivalent at a zero of H. At this point,

\[
D_{(x,a,c)}(H,H_x,T_{short})
=\begin{pmatrix}0&-3/2&2\\32/81&-1&2\\-22/81&-1/6&0\end{pmatrix},
\quad \det=34/243\ne0.
\]

The equilibrium reduction is legitimate because `G_y=-2/3` is nonzero. This rank, together with the nilpotent Jacobian and nonzero quadratic coefficients, gives a generic BT unfolding in `(a,c)`. Since `(a,c)=(m/beta,1/beta)` is a smooth invertible parameter transformation at positive beta, it is also an admissible two-parameter family of the original teacher equation. A computed double-zero spectrum alone would not have established this result. Global homoclinic continuation and quantitative distant cycle boundaries remain outside this local calculation.

## 9. Exact joint-mechanism multistability

Take FA with `r=e=d=1,K=8,alpha=1/2,c=8/3,a=9/2`. Then

\[
H=(1-x)(1-x/2)(1-x/3).
\]

The three interior equilibria and invariants are:

| x | y | trace | determinant | local type |
|---:|---:|---:|---:|---|
| 1 | 21/16 | -19/36 | 7/72 | stable focus |
| 2 | 3 | -23/36 | -1/18 | saddle |
| 3 | 75/16 | -25/27 | 25/216 | stable node |

The two hyperbolic stable equilibria each have an open local basin. Removing interference (`c=0`) gives only one interior equilibrium for every alpha. Removing the Allee factor (`alpha=0`) also gives only one interior equilibrium for every c. Thus, in this model family, three coexistence equilibria and two stable coexistence states are a genuine behavior made possible by the joint mechanisms. This supports an existence version of H5; it is not a claim that every parameter set shows joint-mechanism bistability. The table is reproduced by `results/exact_FA_multistability.csv`.

## 10. Ratio-dependent response as a separate extension

Let `P=a*x*y/(x+c*y)`, with `a,c>0`, and define `P(0,0)=0` by continuity. Here `a:X/(Y T)` and `c:X/Y`; these units differ from the smooth-response parameters. P is continuous and locally Lipschitz on the nonnegative quadrant, but not differentiable at the origin. Its partial derivatives away from the origin are bounded: `P_x=a*c*y^2/(x+c*y)^2`, `P_y=a*x^2/(x+c*y)^2`. A single origin Jacobian or the four-law low-origin proof cannot be reused.

Positive solutions stay positive because both per-capita rates are bounded on bounded x intervals. The same `W=e*x+y` cancellation proves boundedness. The predator-free invasion rate is `ea-d`, independent of K. This is not the four-law R threshold.

For an interior equilibrium, `s=ea/d>1`, `rho=(s-1)/c`, `y=rho*x`, and

\[
q(x)=Q=(a-d/e)/c>0.
\]

If `alpha*K<=1`, there is one positive root when `Q<r`, and none when `Q>=r`. If `alpha*K>1`, write `q_max=r[1+(alpha*K-1)^2/(4*alpha*K)]`. There is one positive root for `Q<r`, one for `Q=r` after excluding x=0, two for `r<Q<q_max`, one double root for `Q=q_max`, and none above `q_max`.

At an interior equilibrium,

\[
\Delta=-\frac{d(s-1)}s xq',\qquad
T=xq'+\frac{d(s-1)}s\left(\frac1{ec}-1\right).
\]

The rising root is a saddle; the falling root is stable if `ec>=1`. A sufficient persistence condition is `r>a/c` together with `ea>d`: prey per-capita growth is then positive uniformly near zero, and the predator gains a positive growth rate when rare after prey recovery. This is a sufficient condition only. A full classification of origin approach and boundary extinction when `r<=a/c` is open in this report. Ratio dependence is not pooled into the four-law permanence theorem.

## 11. Scope by original course question

| Question | Status of this analysis |
|---|---|
| (i) positivity, boundedness, permanence | Proved for four main laws; ratio positivity/boundedness and a sufficient persistence condition are separate. |
| (ii) equilibria and uniqueness | Complete admissible polynomial characterization for main laws; exact three-root and uniqueness regions; ratio root classification above. |
| (iii) local stability | Explicit Jacobian, trace, determinant, and boundary eigenvalues; all simple equilibria classified by these conditions. |
| (iv) global stability | Axial convergence proved for R<=1, including equality; coexistence proved on a sufficient parameter region. Full global classification outside it remains partial. |
| (v) enrichment | Exact branch sensitivity and explicit LV threshold; FA Hopf example and numerical branches test destabilization. No universal monotonic stability claim. |
| (vi) bifurcations | Forward boundary transcritical; exact positive FA saddle-node, Hopf with l1, and BT with quadratic and unfolding conditions. Full global cycle/homoclinic continuation remains partial. |
| (vii) stochastic perturbations | Cancelled by the teacher; excluded. Randomized algebraic checks are not stochastic population dynamics. |
| (viii) observed ecological settings | Addressed by separate provenance and empirical reports. These analytical examples are not Tanner fits. Missing complete field-parameter mappings remain explicit. |
| (ix) ecological interpretation | Threshold sharing, interference effects, enrichment sensitivity, and joint multistability follow under the stated mathematical conditions; field transfer requires additional evidence. |

The accompanying `reports/MODEL_COURSE_MATRIX.csv` records model-specific answers and gaps. Full global cycle uniqueness, basin separatrices over all parameters, complete ratio-origin classification, and validated empirical transfer are not claimed solved.
