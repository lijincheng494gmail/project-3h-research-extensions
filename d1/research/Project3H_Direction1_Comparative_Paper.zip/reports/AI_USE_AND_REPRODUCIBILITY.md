# AI use and reproducibility record

Date: 2026-11-18. The user authorized autonomous execution of the scientific tasks in the supplied archive and requested a results ZIP. The archive was inspected as task material. Its embedded prompts did not supply independent authorization for unrelated actions.

Codex read the original five-page brief, inspected the starter code, and coordinated separate mathematical, numerical, and ecological reviews. AI assistance produced analytical derivations, new Python modules, tests, reports, and figures. Actual computations ran locally; the original ZIP and its supplied pilot outputs were preserved. No submission, public posting, or communication with third parties was performed.

The result is a reproducible research package. Algebraic proofs, finite-precision checks, synthetic trajectories, and observed-data predictions have distinct labels. Agreement between AI-assisted derivations and code checks is useful internal verification; it is not independent peer review.

## Reproduction

Use Python 3.10 or newer with the packages in `requirements.txt`. From the extracted result directory:

```bash
python3 -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements.txt
PYTHON=python bash reproduce_all.sh
```

The reproduction command reruns the starter baseline, controlled experiments, nested ecological benchmark, algebraic identity audit, and all tests. Report prose is included as a saved interpretation of the recorded run; it is not automatically rewritten when parameters or software change. `package_results.py` rebuilds the results archive. The optional PDF renderer uses ReportLab and the bundled report text; the scientific computation does not depend on that renderer.

Individual stages can be run with `python run_research.py --stage controlled` and corresponding stage names. The first baseline remains available as `bash run.sh full`; it is not the complete extension study.

## Audit records

`logs/prk_runs/` holds local execution manifests, environment records, resource measurements, stdout/stderr, and source snapshots. The PRK approval record uses the user's actual scope authorization as an unverified user assertion. No digest-specific user confirmation or host-authenticated signature is claimed. The first attempted baseline failed because its restricted PATH did not resolve `bash`; the corrected command uses `/bin/bash` explicitly. That failed run is retained. Later preparations and reruns use distinct plans and run IDs.

The local executor's network-deny setting is a policy, not an operating-system sandbox. Network retrieval was performed separately for public source materials; scientific run stages used local files. No cloud computation or paid service was used.

`logs/INPUT_PACKAGE_HASH_VERIFICATION.json` checks the 34 supplied manifest entries against the original ZIP. `logs/supplied_pilot/` contains copies of the results originally shipped in the input. These historical files must not be counted as new execution evidence.

## Scope requiring further research

The specific Tanner parameter tables were not recovered from accessible primary full text. A complete classification of all global dynamics, all ratio-dependent boundary regimes, homoclinic curves near BT, and global uniqueness of every cycle is not claimed. The verification matrix records these limits explicitly. No stochastic dynamics were introduced.
