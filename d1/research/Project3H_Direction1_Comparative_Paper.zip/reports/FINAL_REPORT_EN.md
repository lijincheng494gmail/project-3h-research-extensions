# Comparative predation mechanisms with weak-Allee prey growth

Research report · 18 November 2026

## Background

The supplied Project 3H brief asks how weak-Allee prey growth and predator interference affect coexistence, stability, enrichment, and bifurcations. Its displayed equation (1.1) has no predator competition term, although the prose mentions one. We therefore use that equation exactly for the original foraging-arena model. Stochastic dynamics are excluded, as specified in the research plan. Haque's study motivates the questions, but its logistic growth and competition assumptions cannot be imported into this model without checking them [1].

## Research question and hypotheses

Which coexistence and stability results persist when the predation function changes? H1 concerns shared results. H2 asks whether prey self-limitation explains some shared dynamics. H3 tests interference at a fixed invasion threshold. H4 tests an interaction between weak-Allee growth and interference. H5 asks whether their joint presence permits behavior absent from either component ablation. These are mathematical and controlled numerical questions. A separate observed-data benchmark examines predictive performance, rather than identifying a biological mechanism.

## Model definitions

Write q(x)=r(1-x/K)(1+alpha*x). Every primary model has x'=x*q(x)-P and y'=e*P-d*y, with positive r,K,alpha,a,e,d and nonnegative b,c. The four responses are:

| Model | Total prey loss P |
|---|---|
| Original FA | a*x*y/(1+c*y) |
| LV mass action | a*x*y |
| Holling II | a*x*y/(1+b*x) |
| Beddington-DeAngelis (BD) | a*x*y/(1+b*x+c*y) |

For the teacher's original notation, a=m/beta, c=1/beta; conversely, beta=1/c and m=a/c. In the alternative denominator A*x+B*y+C, the original has A=0, B=1, C=beta>0. The brief's hint C=0 would change the functional response.

The optional ratio-dependent response is a*x*y/(x+c*y). It is treated separately because the origin has no common smooth linearization and c has different units. The total loss has a continuous zero extension at the origin, but the smooth-model boundary proof is not transferred to it.

If prey density has unit X, predator density Y, and time T, then r,d have unit T^-1; K has X; alpha,b have X^-1; a has Y^-1*T^-1; c has Y^-1; and e has Y/X in the four smooth models. For the ratio model, a has X/(Y*T) and c has X/Y. The synthetic experiments use dimensionless coordinates. In the real benchmark, T is days, X is 10^6 algae cells/ml, and Y is 20 rotifers/ml. Positive alpha creates an initially increasing per-capita growth rate only when alpha*K>1; alpha>0 alone is insufficient.

## Design

The starter full baseline was actually rerun: 216 trajectories across 18 assumed scenarios and four models. Because its common attack coefficient does not match intake across responses, it is retained as a baseline rather than the main controlled evidence.

The new main comparison uses two synthetic scenarios with r=0.7, K=10, e=0.6, d=0.3, and reference prey density xref=10. Scenario A has alpha=0.12 and reference intake 0.9. Scenario B has alpha=0.4 and reference intake 2.4. Set a=intake*(1+b*xref)/xref, b=0.15 where applicable, and c=0.2 where applicable. This exactly matches low-predator intake and the invasion number within each scenario: R=1.8 or 4.8. It matches one operating point, rather than the entire response surface. During enrichment, a remains fixed.

Four main responses and the separate ratio extension were each integrated from three initial states to T=1200, with summaries at T=600 and T=1200. Ten trajectories were repeated with smaller tolerances and maximum steps. Cubic or quadratic reductions enumerate admissible equilibria rather than relying on multistart root searches. The study records 2,612 enrichment branch rows, 2,500 two-parameter grid rows, 32 interference/recovery rows, 12 growth ablations, and eight primary factorial rows. Exact analytical examples supplement these grids.

The empirical analysis uses all four observed algae-rotifer chemostat experiments C1-C4 [2,3]. The original files and published checksums were recovered. All four full transformations match the supplied positive complete records: 877 raw records, 865 retained records, and 861 adjacent retained pairs. No values were imputed or smoothed. The actual elapsed times are preserved across excluded observations.

Each outer fold holds out an entire experiment. Three inner whole-experiment validation folds select between two predetermined initializations, using only the remaining experiments. The selected initialization is refitted on the three available experiments. All models receive the same selection structure and 40-evaluation optimizer cap; their parameter counts and actual residual calls differ. Alpha=0.25 and e=0.6 are fixed numerical controls in the stated coordinates. The task predicts the next observation from the currently measured held-out state. It is not a free-running or prospective forecast. Training targets alone determine normalization scales.

## Findings: positive results

### Shared mathematical structure

For all four smooth models, positive initial states remain positive and solutions are ultimately bounded. The invasion number is R=e*a*K/[d*(1+b*K)], independent of interference c. If R<=1, the predator-free state (K,0) globally attracts positive solutions. If R>1, the system is permanent. The analytical supplement gives a weighted logarithmic Lyapunov function for extinction and an explicit boundary-excursion argument for permanence.

Set A=e*a/d-b. For c=0, an interior equilibrium exists exactly when R>1 and is unique: x*=1/A and y*=e*x* q(x*)/d. For c>0, all positive equilibria solve H(x)=(c*e/d)*x*q(x)-A*x+1=0 on 1/A<x<K, with y=(A*x-1)/c. There are at most three. Local stability follows the exact Jacobian trace and determinant. R>1 together with K*(alpha+b)<=1 is a sufficient global coexistence-stability condition, proved using uniqueness, permanence, and a Dulac function. This is not a necessary condition.

### Joint mechanisms admit multistability

The original FA model with r=e=d=1, K=8, alpha=1/2, a=9/2, and c=8/3 has H(x)=-(x-1)*(x-2)*(x-3)/6. Its three positive equilibria are (1,21/16), (2,3), and (3,75/16). The first and third are locally attracting; the middle is a saddle. Removing alpha or c separately leaves one positive equilibrium. This proves an H5 existence result in this model. Long integrations from different nonequilibrium initial states illustrate the two attracting states. The exact saddle initial state should remain constant mathematically; its floating-point escape is labelled separately and is not additional basin evidence. The example does not establish how common this behavior is in measured ecosystems.

![Joint mechanism example](../figures/controlled_joint_multistability.png)

### Feasible local bifurcations in the original model

All parameters below are positive except b=0, which defines FA. The calculations retain the original growth law and do not add competition.

| Event | Parameters in addition to e=d=1,b=0 | Equilibrium | Nondegeneracy evidence |
|---|---|---|---|
| Saddle-node | r=1,K=8,alpha=1/2,a=25/4,c=4 | (1,21/16) | H_x=0,H_xx=3/2,H_a=-1,trace=-59/100 |
| Supercritical Hopf | r=9/25,K=6,alpha=7/3,a=2,c=1 | (1,1) | det=1/4,d(trace)/dr=-1/6,l1=-579/5000 |
| Bogdanov-Takens | r=8/27,K=6,alpha=10/3,a=2,c=1 | (3/2,2) | J^2=0,aBT=32/243,bBT=-22/81,unfolding determinant=34/243 |

The Hopf coefficient uses the explicitly stated rotated-coordinate, unit-eigenvector convention in the analytical supplement [4]. Its magnitude is coordinate dependent; its negative sign establishes the local stable-cycle direction. The BT calculation checks quadratic nondegeneracy and an (a,c) unfolding. A homoclinic curve is not claimed from the surrounding equilibrium grid.

The broader K scans found seven Hopf events and four saddle-node events that pass floating-point local checks. These numerical events are distinct from the exact examples above. They are not an exhaustive classification over all positive parameters.

### Observed-data prediction

All 112 optimizer runs reported convergence. The following scores are unweighted means of the four outer-fold joint normalized RMSEs. Lower is better. Each model is evaluated on the same 861 target pairs.

| Model | Mean fold NRMSE |
|---|---:|
| FA | 0.867367 |
| BD | 0.867378 |
| LV | 0.906098 |
| Holling II | 0.906112 |
| Last observation | 1.040276 |

Each fitted model improves the joint score in every held experiment. FA's mean score is 16.62% below the baseline. This does not imply improvement in every component metric: for example, FA's C3 prey MAE is worse than the baseline. There are four experimental units, not 861 independent replicates. No significance claim is made.

![Four held-experiment results](../figures/ecology_nested_all_folds.png)

## Findings: unexpected and negative results

Matching invasion does not match stability. In scenario A, Holling II has persistent oscillation candidates while FA, LV, and BD approach their equilibria at the tested horizon. In scenario B, FA approaches equilibrium while LV, Holling II, and BD show oscillatory behavior; one Holling initial state remains unclassified by the declared convergence rule.

Interference does not always speed recovery. In scenario A, FA's sampled 2% settling time increases from 8 to 12 time units across the tested c values. Scenario A BD changes from unstable to stable with interference, but its stable-state recovery times are nonmonotone. These results support an effect of interference, rather than a universal benefit.

The H4 trace interaction is -0.595089 in scenario A and -1.359131 in scenario B. Scenario A has zero late-amplitude interaction because all four FA factorial arms approach equilibrium. H5 multistability requires its separate exact parameter construction; it did not appear in the two primary factorial cases.

Removing prey self-limitation reaches the declared 10^6 population stop in all four tested FA/LV ablations. This supports the importance of self-limitation in these contrasts; a terminated finite simulation alone is not a blow-up proof. Replacing weak-Allee growth by logistic growth suppresses the scenario B LV oscillation in the tested run.

At the exact Hopf point, cubic attraction is slow. An almost constant oscillation amplitude over a finite window can therefore be misleading. The analytically known critical trajectory is labelled slow decay rather than a demonstrated cycle. Cycle uniqueness and attraction from every initial state remain unresolved outside the stated global theorem.

All outer FA/BD attack estimates hit the upper bound a=7. All outer Holling/BD prey-saturation estimates hit the lower bound b=0.001. BD nearly reduces to FA, and Holling nearly reduces to LV. Differences within these pairs are also close to the scale of the numerical endpoint audit. The benchmark therefore does not identify the true response function. Fixed e and alpha, parameter bounds, omitted chemostat dilution and nutrients, and observation noise limit interpretation.

The detailed Tanner parameter table could not be verified from accessible primary full text. Its values are not substituted for seven FA parameters. Official NPS wolf-moose abundance data were recovered separately [5], but annual abundance is not a calibrated density model or an intrinsic-rate estimate. This part of the original field-calibration request remains partial.

## Interpretation

H1 is supported for positivity, boundedness, invasion, extinction, and a sufficient global-stability region. It is false as a claim of identical stability under matched invasion. H2 receives controlled numerical support and a structural boundedness argument, without establishing a unique causal explanation. H3 is supported as a change in stability and recovery; faster recovery is not universal. H4 has nonzero interactions in specified metrics, with zero interactions in others. H5 is established as a mathematical existence result by the exact joint-mechanism example.

Prey growth and the predator-free invasion threshold explain part of the shared structure. Saturation and interference change the interior geometry, the number of equilibria, and stability. This is a conclusion about the equations and the tested controlled comparisons. Predictive gains on chemostat data are a separate, limited empirical result.

## Verification and remaining scope

All 19 tests and eight algebraic audit classes passed, including 320 full-Jacobian comparisons, 306 equilibrium residual checks, determinant identities, Lyapunov identities, and exact bifurcation checks. The maximum equilibrium residual was 4.62e-14. Ten controlled solver comparisons had maximum scaled trajectory difference 8.57e-7. The ecological audit checked 124 intervals against smaller RK4 steps and high-accuracy DOP853; the maximum training-scaled discrepancy decreased from 1.39e-5 to 9.62e-7 when the step was halved. These checks validate the numerical implementations within their tested scope.

The complete criterion ledger is `VERIFICATION_MATRIX.csv`. The six-question comparison across four models is `MODEL_COURSE_MATRIX.csv`. Analytical proofs and their gaps are in `ANALYTICAL_RESULTS.md`; H1-H5 evidence paths are in `RESULTS_BY_HYPOTHESIS.md`. General cycle uniqueness, a complete global bifurcation diagram, ratio-dependent boundary classification, and Tanner-based calibration are not claimed complete.

## Next feasible experiments

First, repeat the ecological benchmark with prespecified wider parameter bounds and independently justified e and alpha. Add a dilution-aware nutrient model as a separate comparison and retain the same outer folds. Second, use pseudo-arclength continuation to trace periodic and homoclinic branches near the verified FA BT point. Third, recover Tanner's original numerical tables and observation mappings before calibrating a separate terrestrial model. These follow-ups are proposed work, not completed results.

## Sources

[1] Haque (2011). A detailed study of the Beddington-DeAngelis predator-prey model. https://doi.org/10.1016/j.mbs.2011.07.003. Related model and analytical programme; no unchecked theorem is transferred.

[2] Blasius et al. (2020). Long-term cyclic persistence in an experimental predator-prey system. https://doi.org/10.1038/s41586-019-1857-0.

[3] Blasius dataset, version 1, CC BY 4.0. https://doi.org/10.6084/m9.figshare.10045976.v1. Author data: https://github.com/berndblasius/WaveletAnalysis/tree/master/data/chemostat_experiments.

[4] Kuznetsov (2006). Andronov-Hopf bifurcation. Scholarpedia 1(10):1858. https://doi.org/10.4249/scholarpedia.1858; https://www.scholarpedia.org/article/Hopf_bifurcation.

[5] National Park Service, Isle Royale wolf and moose populations. https://www.nps.gov/isro/learn/nature/wolf-moose-populations.htm.

[6] Tanner (1975). The stability and the intrinsic growth rates of prey and predator populations. https://doi.org/10.2307/1936296. Detailed parameter table not independently recovered.

[7] Cantrell and Cosner (2001). On the dynamics of predator-prey models with the Beddington-DeAngelis functional response. https://doi.org/10.1006/jmaa.2000.7343. Methodological context; the present propositions are proved in the supplement.
