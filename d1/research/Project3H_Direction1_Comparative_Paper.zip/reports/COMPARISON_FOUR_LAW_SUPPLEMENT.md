# Common mechanisms and exact enrichment transitions

The master comparison uses P0 (original FA), P1 (mass action), P2 (Holling II), P3 (Beddington-DeAngelis), and P4 (ratio dependence). The formulas in this supplement add an exact local-enrichment classification for P1 and P2 to the common four-law proofs in `ANALYTICAL_RESULTS.md`.

## 1. Common growth and response notation

Let `q(x)=r(1-x/K)(1+alpha*x)`, with `r,K,e,d,a>0`, `alpha>=0`, and `b,c>=0`. The four smooth responses have `P=axy/(1+bx+cy)`. Write `D=1+bx+cy`, `R=eaK/[d(1+bK)]`, and `A=ea/d-b`. Positive solutions are permanent exactly when `R>1`; otherwise they tend to `(K,0)`. These statements include the equality `R=1`, initial prey above K, and all positive initial states. The direct proofs are in `ANALYTICAL_RESULTS.md`, Sections 2-3.

In the original teacher equation, `b=0`, `a=m/beta`, and `c=1/beta`. Thus predator interference is a denominator effect. No predator mortality term `-h*y^2` is introduced.

## 2. Exact enrichment classification when c=0

For P1 and P2, put

`u=d/(ea-db)=1/A`.

A coexistence equilibrium exists if and only if `A>0` and `K>u`. It is unique, with `v=e*u*q(u)/d`. Both the positive determinant and the trace follow by differentiating the original equations:

`Delta=d*q(u)/(1+b*u)>0`,

`T=u[(1+b*u)q'(u)+b*q(u)]/(1+b*u)`.

Define

`N=1+2(alpha+b)u+3alpha*b*u^2`,

`L=alpha+b+2alpha*b*u`.

Direct expansion gives

`T = r*u/(1+b*u) * [L-N/K]`.

If `alpha+b>0`, the exact enrichment transition is

`K_H=N/L`.

Moreover,

`N-u*L=(1+alpha*u)(1+b*u)>0`,

so `K_H>u` and the Hopf point lies inside the coexistence region. The equilibrium is locally asymptotically stable for `u<K<K_H`, and unstable for `K>K_H`. The trace crosses zero transversely because

`dT/dK=r*u*N/[(1+b*u)*K_H^2]>0`.

When `alpha=b=0`, `T=-r*u/K<0` for every coexistence value of K. Thus the logistic mass-action case has no enrichment-driven Hopf. When `b=0,alpha>0`, the threshold reduces to `K_H=1/alpha+2u`.

This is an exact local-stability result for all admissible c=0 parameters. It does not classify the global fate of every distant trajectory after the Hopf.

## 3. Direction of every P1/P2 enrichment Hopf

Let `h(x)=a*x/(1+b*x)` and `omega=sqrt(Delta)` at the Hopf point. Use the coordinates

`X=x-u`, `Y=h(u)(y-v)/omega`,

without changing time. The linear part is `Xdot=-omega*Y`, `Ydot=omega*X`. The planar Kuznetsov convention uses unit vectors `q=p=(1,-i)/sqrt(2)`. With this coordinate and eigenvector convention,

`l1={[(2+5bu)/(1+bu)]q''(u)-4b^2*q(u)/(1+bu)^2}/(8omega)`.

Here `q''=-2r*alpha/K_H`. At every Hopf under `alpha+b>0`, at least one numerator term is strictly negative, so `l1<0`. Therefore every such P1/P2 Hopf is supercritical. Increasing K through `K_H` produces stable small periodic orbits on the unstable-equilibrium side.

For completeness, the formula can be obtained without differentiating an implicit equilibrium branch. Write the shifted vector field as `f=xq-yh`, `g=y(eh-d)` and scale the predator displacement as above. At Hopf, `q'=-bq/(1+bu)`. The nonzero second derivatives needed by the planar formula are

`f_XX=u*q''-2b^2*u*q/(1+bu)^2`,

`f_XY=-omega/[u(1+bu)]`,

`g_XX=-2b*omega/(1+bu)`,

`g_XY=e*a/(1+bu)^2`.

The cubic sum is `3q''-6b^2*q/(1+bu)^3-2eab/(1+bu)^3`. Combining it with the quadratic bracket cancels the last eab term and gives the stated l1. For `b=0` this reduces to `q''/(4omega)`.

The numerical value of a first Lyapunov coefficient depends on coordinate and eigenvector normalization. Its sign and supercritical classification here are invariant under admissible positive scalings. `src/comparison_audit.py` verifies the closed form by a separate differentiation of h and by the general third-order Taylor tensors for 120 deterministic parameter draws. The checks are saved in `results/comparison_c0_hopf_probes.csv` and `results/comparison_independent_audits.csv`.

## 4. Why the interference models differ

For `c>0`, all coexistence equilibria satisfy

`H(x)=(ce/d)xq(x)-Ax+1=0`, `1/A<x<K`, `y=(Ax-1)/c`.

At a simple equilibrium,

`Delta=-(d*q*x/D)H_x`,

`x_K=-H_K/H_x`, `H_K=(ce/d)*r*x^2*(1+alpha*x)/K^2>0`.

Thus x and y increase with K on every nonsaddle branch, and both decrease on a saddle branch. The equilibrium branch position has a fixed direction, but the total trace derivative has no universal sign. The exact original-FA examples establish two attracting coexistence states, a saddle-node, a supercritical Hopf, and a Bogdanov-Takens point with positive original parameters. They are examples within the mechanism comparison, rather than the definition of its research question.

For P1/P2, `Delta>0` throughout coexistence excludes all interior saddle-nodes and Bogdanov-Takens points. This non-existence result is as useful to the comparison as an existence example.

## 5. Exact strict-BD bifurcations with b>0

These examples establish transitions in P3 itself. They retain positive prey handling and predator interference, and introduce no quadratic predator mortality. All arithmetic identities below are checked as exact fractions by `src/bd_exact_examples.py`; their original-equation residuals and normal-form signs are also checked using the independent floating-point Taylor implementation. The numeric table is `results/comparison_BD_exact_events.csv`; full rational matrices are in `results/comparison_BD_exact_rational.json`.

### 5.1 Saddle-node

Set `r=e=d=1,K=8,alpha=1/2,b=1/4,c=4,a=13/2`. At `E=(1,21/16)`, the same reduced polynomial as the FA fold holds:

`H=-(x-1)^2(x-4)/4`.

Thus `H=H_x=0`, `H_xx=3/2`, and `H_a=-1`. The trace is `-211/416`, and the determinant is zero. The nonzero transverse eigenvalue, scalar second derivative, and unfolding derivative establish a nondegenerate saddle-node in a.

### 5.2 Supercritical Hopf

Set `r=9/25,K=6,alpha=7/3,b=1/4,c=7/4,a=3,e=d=1`. At `E=(1,1)`,

`J=[[7/12,-5/12],[11/12,-7/12]]`,

with `T=0`, `Delta=1/24`, and `omega=sqrt(6)/12`. Varying r along the coexistence branch gives `dT/dr=-7/6`.

Take the original displacement to be `S*(X,Y)`, with

`S=[[1,0],[7/5,sqrt(6)/5]]`.

The linear part is the same omega rotation used above. With the unit-q planar Kuznetsov convention,

`l1=-(10891/5000)*omega=-10891*sqrt(6)/60000<0`.

The first calculation evaluates all state derivatives in the exact quadratic number field `Q(omega)`, where `omega^2=1/24`. The second uses the independent floating-point tensor implementation; they agree within `1e-11`. Both the trace derivative and l1 are nonzero. This is a supercritical Hopf, with stable small cycles on the r-below-9/25 side.

### 5.3 Bogdanov-Takens point

Set `r=14/27,K=6,alpha=34/21,b=10/33,c=4/3,a=272/99,e=d=1`. At `E=(3/2,2)`,

`J=[[11/17,-6/17],[121/102,-11/17]]`.

It is nonzero and nilpotent. Use

`q0=(1,11/6), q1=(0,-17/6), p0=(1,0), p1=(11/17,-6/17)`.

These vectors satisfy the Jordan, adjoint, and dual-normalization conditions. The quadratic coefficients are

`a_BT=110/1377`, `b_BT=-137/648`.

For a two-parameter unfolding in `(a,c)` at fixed b, use

`H=c*x*q-(a-b)*x+1`,

`T_short=x*qprime+b*q/a-1+b/a+1/(a*x)`.

At this point,

`D_(x,a,c)(H,H_x,T_short)=[[0,-3/2,2],[80/243,-1,11/6],[-137/648,-99/544,0]]`,

whose determinant is `569/14688`, which is nonzero. On the predator nullcline, the full trace differs from this equilibrium trace extension by a smooth multiple of H. Their rank tests are therefore equivalent at H=0. Also `G_y=-11/17` is nonzero, so the equilibrium reduction is legitimate. This establishes a generic local BT unfolding for strict positive-b BD, rather than relying on an FA point at the boundary b=0.

These three examples settle existence of the corresponding P3 events. They do not give a global bifurcation atlas or a complete classification of homoclinic branches.
