# How to read the five-model comparison

The original research question is which dynamical properties survive a change of predation mechanism, with the same weak-Allee growth law. `COMPARISON_P0_P4.csv` contains all 35 required cells, one for each model and research question.

## Notation

`q(x)=r(1-x/K)(1+alpha*x)`, `q'=r(alpha-1/K-2alpha*x/K)`, `q''=-2r*alpha/K`.

For P0-P3, `D=1+bx+cy`, `R=eaK/[d(1+bK)]`, `A=ea/d-b`, and `H=(ce/d)xq-Ax+1`. In these models a has units `1/(Y*T)`, b and alpha have units `1/X`, and c has units `1/Y`.

For P4, `D=x+cy`, `s=ea/d`, `rho=(s-1)/c`, `Q=(a-d/e)/c`, and `M=d(s-1)/s`. P4 a has units `X/(Y*T)` and c has units `X/Y`. Positive coexistence requires `s>1`, `q(x)=Q`, and `y=rho*x`.

The main parameter regime has `r,K,a,e,d>0`, `alpha>=0`. P0 has `b=0,c>0`; P1 `b=c=0`; P2 `b>0,c=0`; P3 `b,c>0`; P4 has `a,c>0`. Every cell states its additional conditions. `Qmax=r[1+(alpha*K-1)^2/(4alpha*K)]` is used only when `alpha*K>1`.

## Evidence levels and coverage

- `complete_result` means that the stated mathematical question has a parameter-complete characterization for this family, including its explicit exceptional cases.
- `conditional_result` gives a verified conditional answer and names the cases not covered by it.
- `partial_classification` means that verified results address the question but a complete classification remains open.

A CSV row does not become complete because its simulation finished. Global attraction is proved only in the stated sufficient regions. Local fold/Hopf/BT examples and numerical continuation describe event neighborhoods and do not constitute a global atlas of all cycles or separatrices.

## Reading order

1. Positivity, boundedness, and permanence: the shared smooth threshold contrasts with the ratio-origin geometry.
2. Equilibria: one root for P1/P2, a cubic for P0/P3, and a q-level quadratic for P4.
3. Local stability: compare trace and determinant, including exclusion results.
4. Global stability: distinguish axial extinction and sufficient coexistence attraction.
5. Enrichment: positive-root movement and stability change are separate outcomes.
6. Bifurcations: compare which transitions exist or are mathematically excluded.
7. Ecology: connect the response elasticities and thresholds with units, calibration, and predictive results.

`COMPARISON_FOUR_LAW_SUPPLEMENT.md` adds the exact P1/P2 enrichment-Hopf theorem. `RATIO_ANALYTICAL_SUPPLEMENT.md` treats P4. `comparison_overview.png` shows all five models in both common-growth matched scenarios, including every admissible equilibrium branch. Response parameters are fixed as K changes. Its trajectories are integrated and saved at dt=0.1 rather than drawn from the coarse archived samples.
