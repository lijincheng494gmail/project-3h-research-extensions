"""Render the saved main English report at 12 pt; no scientific recomputation."""
from pathlib import Path
from html import escape
import json,re
from reportlab.pdfgen.canvas import Canvas
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Image,LongTable,TableStyle,KeepTogether
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.utils import ImageReader

ROOT=Path(__file__).resolve().parent
styles=getSampleStyleSheet()
styles.add(ParagraphStyle(name='ReportBody',fontName='Times-Roman',fontSize=12,leading=14.2,spaceAfter=7,splitLongWords=True))
styles.add(ParagraphStyle(name='ReportH1',fontName='Times-Bold',fontSize=20,leading=24,spaceAfter=14))
styles.add(ParagraphStyle(name='ReportH2',fontName='Times-Bold',fontSize=15,leading=18,spaceBefore=13,spaceAfter=8,keepWithNext=True))
styles.add(ParagraphStyle(name='ReportH3',fontName='Times-Bold',fontSize=12,leading=15,spaceBefore=10,spaceAfter=6,keepWithNext=True))
styles.add(ParagraphStyle(name='ReportCell',fontName='Times-Roman',fontSize=12,leading=13.4,spaceAfter=0))
styles.add(ParagraphStyle(name='ReportCaption',fontName='Times-Italic',fontSize=12,leading=14,spaceAfter=10))

def inline(s):
    s=s.replace('≤','<=').replace('≥','>=').replace('×',' x ').replace('²','^2').replace('−','-').replace('–','-').replace('—','-').replace('·',' | ')
    s=escape(s)
    s=re.sub(r'`([^`]+)`',r'<font name="Courier">\1</font>',s)
    s=re.sub(r'\*\*([^*]+)\*\*',r'<b>\1</b>',s)
    s=re.sub(r'\[([^\]]+)\]\((https?://[^)]+)\)',r'<link href="\2" color="#34304f">\1</link>',s)
    return s

def build():
    lines=(ROOT/'reports/FINAL_REPORT_EN.md').read_text().splitlines();story=[]
    width=A4[0]-100; i=0
    while i<len(lines):
        s=lines[i].strip()
        if not s:i+=1;continue
        if s.startswith('# '):story.append(Paragraph(inline(s[2:]),styles['ReportH1']));i+=1;continue
        if s.startswith('## '):story.append(Paragraph(inline(s[3:]),styles['ReportH2']));i+=1;continue
        if s.startswith('### '):story.append(Paragraph(inline(s[4:]),styles['ReportH3']));i+=1;continue
        if s.startswith('|'):
            rows=[]
            while i<len(lines) and lines[i].strip().startswith('|'):
                cells=[x.strip() for x in lines[i].strip().strip('|').split('|')]
                if not all(re.fullmatch(r':?-+:?',x or ' ') for x in cells):rows.append(cells)
                i+=1
            n=len(rows[0]);weights=([.33,.67] if n==2 else ([.2,.32,.18,.30] if n==4 else [1/n]*n))
            data=[[Paragraph(inline(c),styles['ReportCell']) for c in row] for row in rows]
            table=LongTable(data,colWidths=[width*w for w in weights],repeatRows=1,hAlign='LEFT')
            table.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#eeedf3')),('VALIGN',(0,0),(-1,-1),'TOP'),('LINEBELOW',(0,0),(-1,0),.7,colors.HexColor('#1F1E33')),('LINEBELOW',(0,1),(-1,-1),.25,colors.HexColor('#d3d1dc')),('LEFTPADDING',(0,0),(-1,-1),5),('RIGHTPADDING',(0,0),(-1,-1),5),('TOPPADDING',(0,0),(-1,-1),5),('BOTTOMPADDING',(0,0),(-1,-1),5)]))
            story.extend([table,Spacer(1,9)]);continue
        m=re.fullmatch(r'!\[([^\]]*)\]\(([^)]+)\)',s)
        if m:
            p=(ROOT/'reports'/m[2]).resolve();iw,ih=ImageReader(str(p)).getSize();h=width*ih/iw
            story.append(KeepTogether([Image(str(p),width=width,height=h),Paragraph(inline(m[1]),styles['ReportCaption'])]));i+=1;continue
        paragraph=[s];i+=1
        while i<len(lines) and lines[i].strip() and not lines[i].lstrip().startswith(('#','|','![')):
            paragraph.append(lines[i].strip());i+=1
        story.append(Paragraph(inline(' '.join(paragraph)),styles['ReportBody']))
    pages=[]
    def footer(canvas,doc):
        pages.append(doc.page);canvas.saveState();canvas.setFont('Times-Roman',10)
        canvas.setFillColor(colors.HexColor('#6D6988'));canvas.drawString(50,28,'Comparative predation mechanisms | 18 November 2026')
        canvas.drawRightString(A4[0]-50,28,str(doc.page));canvas.restoreState()
    dest=ROOT/'reports/FINAL_REPORT_EN.pdf'
    doc=SimpleDocTemplate(str(dest),pagesize=A4,rightMargin=50,leftMargin=50,topMargin=43,bottomMargin=43,
                           title='Comparative predation mechanisms with weak-Allee prey growth',author='Research execution package')
    doc.build(story,onFirstPage=footer,onLaterPages=footer)
    audit=dict(file='reports/FINAL_REPORT_EN.pdf',pages=max(pages),maximum_pages=25,body_font_size_pt=12,
               body_leading_pt=14.2,status='rendered_pending_visual_check')
    (ROOT/'logs/PDF_LAYOUT_AUDIT.json').write_text(json.dumps(audit,indent=2))
    if audit['pages']>25:raise RuntimeError('Main report exceeds 25-page limit')
    print(json.dumps(audit))

if __name__=='__main__':build()
