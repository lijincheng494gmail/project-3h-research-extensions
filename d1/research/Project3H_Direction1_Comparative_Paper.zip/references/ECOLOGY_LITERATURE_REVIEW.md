# Ecological literature review and parameter transfer

Checked on 18 November 2026. This review supports the five-model comparison with traceable ecological evidence. The mathematical results in this study are derived separately; these sources are not treated as proofs for equations they did not analyze.

## Tanner: demographic motivation and limits on transfer

Tanner, J. T. (1975). The stability and the intrinsic growth rates of prey and predator populations. *Ecology*, 56(4), 855-867. https://doi.org/10.2307/1936296

The primary publisher abstract describes models incorporating demographic growth rates, prey self-limitation, and predator searching time. It compares eight prey species with their predators and reports approximately equal intrinsic growth rates for snowshoe hare and lynx. This motivates H2 and the comparison of growth and feeding mechanisms.

The full numerical parameter table was not recovered in this run. The publisher main-page request returned HTTP 403, and opening its PDF URL through the search provider yielded the abstract page rather than a readable full article. Exact numerical ranges, table definitions, and their uncertainty therefore remain unverified from the original text. Secondary papers reproduce ranges, but those copies are not used as primary numerical inputs here.

A predator's maximum demographic growth rate is not the same quantity as the death rate d without prey in x'=xq(x)-P, y'=eP-dy. Tanner's demographic comparison alone cannot identify a, b, c, e, alpha, K, or d for any of the five response functions. The example K=100 in the coursework is an illustrative density setting, not a universal measured carrying capacity. None of the empirical coefficients fitted in this study is labeled a Tanner estimate.

## Predator interference as an empirical comparison

Skalski, G. T., & Gilliam, J. F. (2001). Functional responses with predator interference: viable alternatives to the Holling Type II model. *Ecology*, 82(11), 3083-3092. https://doi.org/10.1890/0012-9658(2001)082[3083:FRWPIV]2.0.CO;2

The primary publisher abstract reports comparisons of feeding responses in 19 predator-prey systems. Predator-dependent alternatives can describe the observations better, but no response is best for every dataset. The paper includes Beddington-DeAngelis, Crowley-Martin, and Hassell-Varley responses. It provides a reason to compare interference explicitly; it does not establish that the present P0 or P4 is the true feeding law of the chemostat system. Our comparison keeps this distinction between a feeding experiment and population time-series prediction.

Verified publisher record: https://esajournals.onlinelibrary.wiley.com/doi/10.1890/0012-9658(2001)082%5B3083:FRWPIV%5D2.0.CO;2

## Observed algae-rotifer time series

Blasius, B., Rudolf, L., Weithoff, G., Gaedke, U., & Fussmann, G. F. (2020). Long-term cyclic persistence in an experimental predator-prey system. *Nature*, 577, 226-230. https://doi.org/10.1038/s41586-019-1857-0

The author's publication page identifies plankton microcosm experiments with persistent oscillations over many cycles. It also describes changes between coherent and irregular episodes. This supports using measured time series to compare short-step model predictions. It does not supply measured values of the weak-Allee and conversion coefficients in our reduced two-state models.

Author publication and abstract: https://www.berndblasius.de/publications/2020/blasius_al_nature_2020/

Original observations and metadata: https://doi.org/10.6084/m9.figshare.10045976.v1 (CC BY 4.0). Author repository: https://github.com/berndblasius/WaveletAnalysis/tree/master/data/chemostat_experiments . The source files and exact source-to-analysis transformation are checked by the executable audit, including all published MD5 values for C1-C4. Existing raw source downloads and their source hashes are retained in data/source. No interpolation from the source's optional wavelet-analysis workflow is used.

## Field abundance as a different observation type

National Park Service. Wolf and moose populations, Isle Royale National Park. https://www.nps.gov/isro/learn/nature/wolf-moose-populations.htm (accessed 18 November 2026).

The separately retained official annual abundance series covers 1980-2026. Missing values remain missing. Annual island-wide abundance estimates are not equivalent to chemostat density measurements or demographic intrinsic rates. They are not pooled with C1-C4, and no unmeasured conversion to the seven original FA parameters is assumed.

## Consequences for the present comparison

The shared empirical test uses the same observed C1-C4 target pairs, state units, training scales, held experiments, initialization-selection rule, and optimizer caps for P0-P4. Fixed alpha and e are numerical controls. Fitted coefficients are effective coefficients of this reduced model and use the units in results/five_ecology_parameter_units.csv. The additional full nested bound sensitivity checks whether rankings depend on the originally imposed search region. Both variants remain reported, regardless of their rankings.
