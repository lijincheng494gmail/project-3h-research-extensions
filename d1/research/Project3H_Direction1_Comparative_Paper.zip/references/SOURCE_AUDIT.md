# Primary-source audit, 2026-11-18

The local source downloads use public HTTPS endpoints. `data/source/DOWNLOAD_MANIFEST.json` records download URLs and SHA256 checksums. No account credentials or paid resource was used.

| Source | Verified content | Access and remaining limit |
|---|---|---|
| User-supplied Project3H original PDF, pp.1-5 | Exact equation (1.1), positive coefficients, task list, references, and written-report limit | Locally available; prose mentions h but the displayed original equations omit it |
| [Blasius et al. paper](https://doi.org/10.1038/s41586-019-1857-0) | Article identity and association with experimental chemostat data | Publisher web redirect restricted; no unverified paper theorem imported |
| [Figshare dataset v1](https://doi.org/10.6084/m9.figshare.10045976.v1), [public API](https://api.figshare.com/v2/articles/10045976) | Authors, title, version, C1-C10 file metadata, original MD5, CC BY 4.0, source attribution | API metadata saved verbatim; C1-C4 raw downloads audited against its MD5 |
| [Author GitHub data directory](https://github.com/berndblasius/WaveletAnalysis/tree/master/data/chemostat_experiments) | C1-C4 raw CSV, units in column headings, missing values, README citation, optional Julia interpolation | Raw files and source loader saved; commit metadata saved as `repo_commit.json` |
| [Tanner (1975), publisher](https://esajournals.onlinelibrary.wiley.com/doi/pdf/10.2307/1936296) | Journal, year, pages, DOI, and abstract | Browser search retrieved publisher abstract; direct PDF HTTP 403. Specific numeric tables and exact parameter units remain unverified from original text |
| [NPS wolf-moose observations](https://www.nps.gov/isro/learn/nature/wolf-moose-populations.htm) | Official annual abundance CSV, 1980-2026, with missing years | HTML and downloaded CSV retained; not a fitted Tanner parameter source |
| [Wolf-Moose Project overview](https://www.isleroyalewolf.org/population-dynamics) | Field setting, abundance/density interpretation, and omitted processes | Provides ecological context; does not estimate the present FA coefficients |

The unused CAR-T and phage references in the starter package do not support this direction's ecology benchmark. They are not cited as evidence for predation-mechanism conclusions.

## Source-access failures retained in interpretation

The host system Python initially failed HTTPS certificate verification. Downloading with the system `curl` verified HTTPS successfully; certificate checks were not disabled. The browser fetch of the author GitHub directory was restricted, so raw GitHub and its public API were used. The Nature website redirected to an unavailable authorization endpoint. The AWI repository returned an access-denied page. Tanner's PDF returned HTTP 403. These failures do not prevent the Figshare-verified C1-C4 benchmark, but they block independent confirmation of Tanner's detailed parameter table.

## Citation roles

All mathematical propositions in the analytical report must stand on their written derivations or a specifically checked theorem. A bibliographic pointer is not evidence that a theorem applies. Blasius supports the observed-data origin; Tanner supports a limited demographic motivation; the present comparison results come from the scripts, configuration, and raw CSV outputs in this archive.

## Mathematical reference checks

[Haque publisher record](https://doi.org/10.1016/j.mbs.2011.07.003) and [Cantrell-Cosner publisher record](https://doi.org/10.1006/jmaa.2000.7343) were checked for identity and stated scope. Direct full-text web requests returned HTTP403; no theorem was imported from an inaccessible text. All model-specific propositions have written derivations. [Kuznetsov author-written Hopf article](https://www.scholarpedia.org/article/Hopf_bifurcation), DOI10.4249/scholarpedia.1858, supplies the coefficient convention. [Guckenheimer-Kuznetsov BT article](https://www.scholarpedia.org/article/Bogdanov-Takens_bifurcation) supplies the stated Jordan-chain coefficient definitions. Local formulas were independently hand-checked and then compared with actual tensor and exact-example code outputs.
