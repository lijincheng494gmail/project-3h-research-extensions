"""Validate final five-model evidence and generate the completion ledger."""
from pathlib import Path
import hashlib,json,re
import numpy as np
import pandas as pd
from pypdf import PdfReader

ROOT=Path(__file__).resolve().parent

def main():
    def read(rel):return pd.read_csv(ROOT/rel)
    required=['paper/PAPER_EN.pdf','paper/DETAILED_SUPPLEMENT.pdf','paper/PAPER_EN.tex',
              'reports/COMPARISON_P0_P4.csv','reports/RATIO_ANALYTICAL_SUPPLEMENT.md',
              'reports/COMPARISON_FOUR_LAW_SUPPLEMENT.md','reports/FIVE_MODEL_ECOLOGY.md',
              'references/MATHEMATICAL_PRIOR_WORK.md','references/ECOLOGY_LITERATURE_REVIEW.md',
              'MASTER_SCOPE.md','run.sh','run_master.py','README_START_HERE.md',
              'results/five_ecology_parameter_units.csv','results/five_ecology_bounds.csv',
              'results/five_ecology_literature_mapping.csv']
    for rel in required:assert (ROOT/rel).is_file() and (ROOT/rel).stat().st_size>0,rel
    matrix=read('reports/COMPARISON_P0_P4.csv')
    assert len(matrix)==35 and set(matrix.model_id)=={'P0','P1','P2','P3','P4'}
    assert matrix.groupby('model_id').question_id.apply(lambda x:set(x)==set(range(1,8))).all()
    for field in ['mathematical_result','parameter_conditions','remaining_cases','evidence','coverage_status']:
        assert matrix[field].notna().all() and matrix[field].str.len().gt(2).all(),field
    # Every explicit file in the matrix must resolve inside the package.
    for evidence in matrix.evidence:
        for rel in re.findall(r'(?:reports|results|references)/[A-Za-z0-9_./-]+\.(?:md|csv|json)',evidence):
            assert (ROOT/rel).is_file(),rel
    audit_counts={}
    for rel in ['results/analytic_validation.csv','results/comparison_independent_audits.csv',
                'results/ratio_validation.csv','results/ratio_independent_hopf_audit.csv',
                'results/periodic_independent_audit.csv','results/five_ecology_validation_checks.csv']:
        table=read(rel)
        if 'passed' in table:
            assert table.passed.all(),rel
        else:
            assert len(table)==8 and table.absolute_l1_error.dropna().max()<1e-6
            assert table.absolute_trace_derivative_error.dropna().max()<1e-5
            assert table.verified_positive.dropna().eq(True).all()
        audit_counts[rel]=len(table)
    for prefix in ['five_ecology_','five_ecology_wide_']:
        score=read('results/'+prefix+'scores.csv');fit=read('results/'+prefix+'fit_log.csv')
        pred=read('results/'+prefix+'predictions.csv');sol=read('results/'+prefix+'solver_audit.csv')
        assert len(score)==24 and len(fit)==140 and len(pred)==4305 and len(sol)==155
        assert fit.optimizer_success.all() and fit.nfev.le(40).all()
        assert score.groupby('model').test_pairs.sum().eq(861).all()
        assert (sol.half_step_max_training_scaled<sol.coarse_max_training_scaled).all()
        status=json.loads((ROOT/'logs'/('FIVE_ECOLOGY_WIDE_STATUS.json' if 'wide' in prefix else 'FIVE_ECOLOGY_STATUS.json')).read_text())
        assert status['source_sha256']==hashlib.sha256((ROOT/'src/ecology_five_models.py').read_bytes()).hexdigest()
    periodic=read('results/periodic_FA_continuation.csv')
    assert len(periodic)==19 and periodic.stability.eq('stable').all()
    assert periodic.fine_closure_inf.max()<1e-9 and periodic.neutral_floquet_error.max()<1e-8
    assert len(read('results/comparison_BD_exact_events.csv'))==3
    assert len(read('results/ratio_exact_bifurcations.csv'))==3
    tests=(ROOT/'logs/MASTER_FINAL_TESTS.txt').read_text()
    ntests=int(re.search(r'Ran (\d+) tests',tests)[1]);assert ntests>=33 and '\nOK\n' in tests
    pdf_pages={}
    for name in ['PAPER_EN','DETAILED_SUPPLEMENT']:
        doc=PdfReader(ROOT/'paper'/(name+'.pdf'));pdf_pages[name]=len(doc.pages)
        assert all(len(p.extract_text() or '')>80 for p in doc.pages)
        log=(ROOT/'paper'/(name+'.log'))
        if log.exists():
            text=log.read_text()
            assert not any(s in text for s in ['Overfull','undefined references','Missing character']),name+' layout log'
    assert pdf_pages['PAPER_EN']<=25
    paper=(ROOT/'paper/PAPER_EN.tex').read_text()
    for heading in ['Introduction','Results','Discussion','Methods']:
        assert '\\section{'+heading+'}' in paper
    assert paper.index('\\subsection{The complete five-model comparison}')<paper.index('\\subsection{Positivity')
    criteria=[]
    def criterion(cid,title,status,evidence,gap='No remaining deliverable gap.'):
        criteria.append(dict(criterion_id=cid,criterion=title,status=status,evidence=evidence,remaining_scope=gap))
    deliverables=[('English paper PDF','paper/PAPER_EN.pdf'),('P0-P4 by seven-question matrix','reports/COMPARISON_P0_P4.csv'),
                  ('Detailed mathematical derivations and proofs','paper/DETAILED_SUPPLEMENT.pdf'),
                  ('Phase portraits, time series and bifurcation diagrams','figures/comparison_overview.png; figures/periodic_FA_continuation.png; figures/ratio_enrichment.png'),
                  ('Parameter tables, units and source review','results/five_ecology_parameter_units.csv; results/five_ecology_literature_mapping.csv; references/MATHEMATICAL_PRIOR_WORK.md'),
                  ('Python code and run.sh','src/; run.sh; requirements.txt'),
                  ('Numerical and empirical tables','results/; results/TABLE_PROVENANCE_V2.csv'),
                  ('Completion and verification ledger','reports/MASTER_COMPLETION_MATRIX.csv; logs/MASTER_FINAL_STATUS.json')]
    for i,(title,path) in enumerate(deliverables,1):criterion(f'D{i}',title,'done',path)
    criterion('A1','Original P0 equation preserved','done','references/Project3H_Original_Brief.pdf; paper/PAPER_EN.tex equations1-2')
    criterion('A2','All five models and all seven questions investigated','done','reports/COMPARISON_P0_P4.csv','Conditional results and explicit remaining cases are retained in every relevant cell.')
    criterion('A3','Complete smooth-family extinction-permanence dichotomy','done','reports/ANALYTICAL_RESULTS.md sections2-3')
    criterion('A4','Full ratio-dependent boundary classification','partial','reports/RATIO_ANALYTICAL_SUPPLEMENT.md section3','ea>d with r<=a/c<=r+d, equality surfaces and other origin sectors are not fully classified.')
    criterion('A5','Admissible equilibrium root counts and local stability','done','reports/COMPARISON_P0_P4.csv; results/ratio_validation.csv','Nonhyperbolic surfaces use verified event examples; they are not a parameter-complete normal-form atlas.')
    criterion('A6','General global-stability classification','partial','reports/ANALYTICAL_RESULTS.md section6; reports/RATIO_ANALYTICAL_SUPPLEMENT.md section6','Proved sufficient global regions; attraction, basin boundaries and cycle uniqueness outside them remain unresolved.')
    criterion('A7','Fixed-coefficient enrichment comparison','done','reports/COMPARISON_FOUR_LAW_SUPPLEMENT.md sections2-4; reports/RATIO_ANALYTICAL_SUPPLEMENT.md section7','P0/P3 branch derivatives are explicit; a universal stability direction is not imposed.')
    criterion('A8','Admissible nondegenerate local events and exclusions','done','results/exact_FA_bifurcations.csv; results/comparison_BD_exact_events.csv; results/ratio_exact_bifurcations.csv; results/comparison_c0_hopf_probes.csv')
    criterion('A9','Global periodic and homoclinic continuation','partial','results/periodic_FA_continuation.csv; results/periodic_independent_audit.csv','One local P0 periodic branch is computed; the full cycle atlas, homoclinic branches and distant termination are not established.')
    for i,path in enumerate(['reports/COMPARISON_P0_P4.csv; figures/comparison_overview.png',
                              'results/controlled_factorial.csv; results/controlled_growth_ablation.csv',
                              'results/comparison_five_enrichment.csv; results/periodic_FA_continuation.csv',
                              'reports/FIVE_MODEL_ECOLOGY.md; results/five_ecology_bound_comparison.csv'],1):
        criterion('E'+str(i),'Experiment '+chr(64+i),'done',path)
    criterion('E5','Tanner numerical field calibration','partial','references/ECOLOGY_LITERATURE_REVIEW.md','Primary abstract and biological parameter meanings reviewed; original full numerical table and a validated mapping to all FA parameters were not recovered.')
    hpaths=['reports/COMPARISON_P0_P4.csv','results/controlled_growth_ablation.csv',
            'results/controlled_interference_recovery.csv','results/controlled_factorial_interactions.csv',
            'results/exact_FA_multistability.csv; results/ratio_origin_basin_runs.csv']
    for i,path in enumerate(hpaths,1):criterion('H'+str(i),'Hypothesis H'+str(i)+' tested with parameter-specific conclusions','done',path)
    criterion('V1','Prior calculations reproduced before extensions','done','logs/MASTER_REPRODUCE_STATUS.json; logs/MASTER_REPRODUCE_HASH_COMPARE.json')
    criterion('V2','Independent normal-form and solver checks','done','results/comparison_independent_audits.csv; results/ratio_independent_hopf_audit.csv; results/periodic_independent_audit.csv')
    criterion('V3','Published mathematical overlap reviewed','done','references/MATHEMATICAL_PRIOR_WORK.md','No priority claim; restricted full texts are not treated as checked theorem sources.')
    criterion('V4','Negative findings and failed development runs retained','done','logs/MASTER_EXECUTION_HISTORY.json; logs/RATIO_RUN_HISTORY.json; logs/MASTER_BD_DEVELOPMENT_HISTORY.json','BD and ratio development failures include retrospective agent records; missing full traces or old source snapshots are explicitly identified.')
    pd.DataFrame(criteria).to_csv(ROOT/'reports/MASTER_COMPLETION_MATRIX.csv',index=False)
    # Source mapping is an artifact locator, not a certification of scientific truth.
    table_rows=[]
    for f in sorted((ROOT/'results').glob('*.csv')):
        if f.name=='TABLE_PROVENANCE_V2.csv':continue
        name=f.name
        if name.startswith('five_ecology_'):source='src/ecology_five_models.py; src/ecology_five_summary.py; src/ecology_five_validation.py';unit='days; million cells/ml; 20 rotifers/ml; dimensionless NRMSE';split='four whole-experiment outer folds and nested training-only initialization choice'
        elif name.startswith('ratio_independent_'):source='src/ratio_independent_hopf_audit.py';unit='dimensionless';split='independent local Taylor audit'
        elif name.startswith('ratio_'):source='src/ratio_analysis.py';unit='dimensionless';split='synthetic parameter conditions stated per table'
        elif name.startswith('periodic_independent_'):source='src/periodic_independent_audit.py';unit='dimensionless';split='three independently checked orbits'
        elif name.startswith('periodic_'):source='src/periodic_continuation.py';unit='dimensionless';split='19 amplitudes on one local branch'
        elif name.startswith('comparison_BD'):source='src/bd_exact_examples.py';unit='dimensionless rational exact examples';split='three strict BD events'
        elif name.startswith('comparison_'):source='src/comparison_audit.py';unit='dimensionless';split='matched synthetic scenarios and analytical audit draws'
        elif name.startswith('controlled_'):source='src/controlled_extended.py';unit='dimensionless';split='two matched scenarios; auxiliary exact examples separately labeled'
        elif name.startswith('ecology_'):source='src/ecology_extended.py';unit='same observed data units';split='historical four-model benchmark'
        elif name.startswith(('analytic_','exact_FA')):source='src/analytic_checks.py';unit='dimensionless';split='algebraic audit and exact examples'
        else:source='src/experiments.py';unit='see original TABLE_PROVENANCE.csv and source';split='retained supplied or reproduced baseline'
        hashes={s:hashlib.sha256((ROOT/s).read_bytes()).hexdigest() for s in source.split('; ') if (ROOT/s).is_file()}
        table_rows.append(dict(table=str(f.relative_to(ROOT)),source_code=source,source_code_sha256=json.dumps(hashes,sort_keys=True),units=unit,comparison_or_split=split))
    pd.DataFrame(table_rows).to_csv(ROOT/'results/TABLE_PROVENANCE_V2.csv',index=False)
    status=dict(scope='five-model comparative research question; MASTER_SCOPE.md',
                paper_pages=pdf_pages,comparison_cells=len(matrix),tests_passed=ntests,
                audit_classes=audit_counts,optimizer_fits=280,predictions=8610,observed_pairs_per_model=861,
                solver_interval_checks=310,periodic_orbits=19,
                mathematical_status='verified conditional results and explicit partial classifications',
                artifacts_status='all eight deliverable groups present',
                criteria_counts=pd.DataFrame(criteria).status.value_counts().to_dict(),
                partial_criteria=[r for r in criteria if r['status']=='partial'])
    (ROOT/'logs/MASTER_FINAL_STATUS.json').write_text(json.dumps(status,indent=2))
    print(json.dumps({k:v for k,v in status.items() if k!='partial_criteria'},indent=2))

if __name__=='__main__':main()
