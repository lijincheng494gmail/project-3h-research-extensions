"""Validate recorded outputs and rebuild final summary; no scientific simulation."""
from pathlib import Path
import json,re
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parent
def main():
    def csv(name):return pd.read_csv(ROOT/'results'/name)
    required=['reports/FINAL_REPORT_EN.md','reports/FINAL_REPORT_ZH.md','reports/FINAL_REPORT_EN.pdf',
              'reports/ANALYTICAL_RESULTS.md','reports/RESULTS_BY_HYPOTHESIS.md',
              'reports/VERIFICATION_MATRIX.csv','reports/MODEL_COURSE_MATRIX.csv',
              'README_START_HERE.md','reproduce_all.sh','requirements.lock.txt']
    for rel in required:
        if not (ROOT/rel).is_file() or not (ROOT/rel).stat().st_size:raise RuntimeError('Missing '+rel)
    audits=csv('analytic_validation.csv');assert audits.passed.all() and len(audits)==8
    src=csv('ecology_source_mapping_audit.csv')
    assert len(src)==4 and src.exact_processed_mapping_verified.all() and src.original_matches_figshare_md5.all()
    scores=csv('ecology_nested_scores.csv');fits=csv('ecology_nested_fit_log.csv');pred=csv('ecology_nested_predictions.csv')
    assert len(scores)==20 and len(fits)==112 and len(pred)==3444 and fits.optimizer_success.all()
    assert scores.groupby('model').test_pairs.sum().eq(861).all()
    assert set(scores.held_experiment)=={'C1','C2','C3','C4'}
    assert np.isfinite(scores.test_nrmse).all()
    split=csv('ecology_split_audit.csv');assert split.disjoint_experiment_sets.all()
    for row in split.itertuples():
        assert row.outer_test not in row.training.split(';')
        if row.stage=='inner':assert row.validation not in row.training.split(';')
    cs=csv('controlled_solver_audit.csv');es=csv('ecology_solver_audit.csv')
    assert len(cs)==10 and len(es)==124 and (es.half_step_max_training_scaled<es.coarse_max_training_scaled).all()
    assert len(csv('controlled_failures.csv'))==0
    abl=csv('controlled_growth_ablation.csv');stopped=abl[abl.growth=='no_self_limitation']
    assert len(stopped)==4 and stopped.status.eq('population_stop_1e6').all()
    assert np.allclose(stopped.final_t,stopped.event_t) and np.allclose(stopped.event_population,1e6,rtol=1e-8)
    hopf=csv('controlled_Hopf_exact_r_sides.csv')
    assert hopf.loc[np.isclose(hopf.r,.36),'finite_time_label'].eq('critical_Hopf_slow_decay_not_cycle').all()
    role=csv('controlled_multistability_runs.csv');assert role.loc[role.initial==4,'numerical_role'].eq('exact_saddle_roundoff_escape_not_basin_evidence').all()
    tests=(ROOT/'logs/final_tests.txt').read_text();match=re.search(r'Ran (\d+) tests',tests)
    assert match and 'OK' in tests;ntests=int(match[1]);assert ntests==19
    matrix=pd.read_csv(ROOT/'reports/VERIFICATION_MATRIX.csv')
    assert len(matrix)==38 and matrix.status.isin(['done','partial','blocked']).all()
    count=matrix.status.value_counts().to_dict()
    summary=dict(stage='final_verified_research_package',date_local='2026-11-18',
                 analysis_level=['direct_mathematical_proofs','controlled_synthetic_experiments','nested_observed_data_prediction'],
                 counts=dict(starter_synthetic_trajectories=len(csv('synthetic_structure_runs.csv')),
                             controlled_primary_trajectories=len(csv('controlled_long_horizon.csv'))//2,
                             controlled_solver_audits=len(cs),ecological_optimizer_fits=len(fits),
                             ecological_held_experiments=4,ecological_test_pairs_per_model=861,
                             ecological_prediction_rows=len(pred),ecological_solver_checks=len(es),
                             tests_passed=ntests,algebraic_audit_classes_passed=len(audits),
                             criteria_done=int(count.get('done',0)),criteria_partial=int(count.get('partial',0))),
                 scientific_failure_count_final_controlled=0,
                 completion_scope='All criteria have evidence or explicit partial status; no full global/field-calibration claim.',
                 partial_criteria=matrix.loc[matrix.status!='done',['criterion_id','criterion','remaining_gap_or_limit']].to_dict('records'))
    (ROOT/'logs/RUN_STATUS.json').write_text(json.dumps(summary,indent=2))
    audit=dict(preflight='passed',required_reports_present=True,source_mapping_verified=True,
               all_four_nested_folds_checked=True,source_split_disjointness_checked=True,
               terminal_event_records_checked=True,critical_and_exact_saddle_labels_checked=True,
               tests_passed=ntests,algebraic_audits_passed=8,
               archive_validation='CRC and every FILE_SHA256 entry are checked after final packaging; archive hash is external to avoid self-reference.')
    (ROOT/'logs/DELIVERY_AUDIT.json').write_text(json.dumps(audit,indent=2))
    print(json.dumps(summary['counts']))

if __name__=='__main__':main()
