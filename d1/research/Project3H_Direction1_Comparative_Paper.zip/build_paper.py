"""Create data-bound paper tables, readable supplement, and LaTeX PDFs."""
from pathlib import Path
import json,re,shutil,subprocess
import pandas as pd

ROOT=Path(__file__).resolve().parent
DEST=ROOT/'paper'

def tex_escape(s):
    mapping={'\\':r'\textbackslash{}','&':r'\&','%':r'\%','$':r'\$','#':r'\#',
             '_':r'\_','{':r'\{','}':r'\}','~':r'\textasciitilde{}','^':r'\textasciicircum{}'}
    s=str(s).replace('–','--').replace('—','---').replace('−','-').replace('’',"'").replace('“','"').replace('”','"')
    s=s.replace('→',' -> ').replace('≤',' <= ').replace('≥',' >= ').replace('×',' x ').replace('²','^2').replace('³','^3').replace('α','alpha').replace('β','beta').replace('Δ','Delta').replace('ω','omega')
    return ''.join(mapping.get(c,c) for c in s)

def inline(s):
    # Preserve explicit inline LaTeX; Markdown code remains literal evidence.
    pieces=re.split(r'(\\\(.*?\\\)|`[^`]+`|\[[^\]]+\]\([^)]+\)|\*\*[^*]+\*\*|\*[^*]+\*|https?://[^\s<>]+)',s)
    out=[]
    for p in pieces:
        if p.startswith(r'\('):out.append(p)
        elif p.startswith(('https://','http://')):out.append(r'\url{'+p+'}')
        elif p.startswith('`'):
            text=tex_escape(p[1:-1]);text=text.replace(r'\_',r'\_\allowbreak{}')
            text=re.sub(r'([=+,/])',r'\1\\allowbreak{}',text)
            out.append(r'\texttt{'+text+'}')
        elif p.startswith('**'):out.append(r'\textbf{'+tex_escape(p[2:-2])+'}')
        elif p.startswith('*'):out.append(r'\textit{'+tex_escape(p[1:-1])+'}')
        elif p.startswith('['):
            m=re.fullmatch(r'\[([^\]]+)\]\(([^)]+)\)',p)
            if m and m[2].startswith('http'):out.append(r'\href{'+m[2].replace('%',r'\%')+'}{'+tex_escape(m[1])+'}')
            else:out.append(tex_escape(p))
        else:out.append(tex_escape(p))
    return ''.join(out)

def md_to_tex(text):
    lines=text.splitlines();out=[];i=0
    while i<len(lines):
        line=lines[i].strip()
        if not line:out.append('\n');i+=1;continue
        if line==r'\[' or line=='$$':
            end=r'\]' if line==r'\[' else '$$';math=[];i+=1
            while i<len(lines) and lines[i].strip()!=end:math.append(lines[i]);i+=1
            out.append('\n\\[\n'+'\n'.join(math)+'\n\\]\n');i+=1;continue
        if line.startswith('#'):
            level=len(line)-len(line.lstrip('#'));title=line.lstrip('#').strip()
            command={1:'subsection',2:'subsubsection',3:'paragraph',4:'paragraph'}.get(level,'paragraph')
            out.append('\\'+command+'*{'+inline(title)+'}\n');i+=1;continue
        if line.startswith('|'):
            rows=[]
            while i<len(lines) and lines[i].strip().startswith('|'):
                row=[c.strip() for c in lines[i].strip().strip('|').split('|')]
                if not all(re.fullmatch(r':?-+:?',x) for x in row):rows.append(row)
                i+=1
            n=len(rows[0]);w=166/n-4.3
            out.append(r'\begin{longtable}{'+''.join('p{%.1fmm}'%w for _ in range(n))+'}\n\\toprule\n')
            for j,row in enumerate(rows):
                out.append(' & '.join(inline(c) for c in row)+r'\\'+'\n')
                if j==0:
                    out.append(r'\midrule\endfirsthead\toprule'+'\n')
                    out.append(' & '.join(inline(c) for c in row)+r'\\\midrule\endhead'+'\n')
            out.append(r'\bottomrule\end{longtable}'+'\n');continue
        if line.startswith('```'):
            i+=1;block=[]
            while i<len(lines) and not lines[i].strip().startswith('```'):block.append(lines[i]);i+=1
            out.append(r'\begin{quote}\ttfamily '+inline(' '.join(block))+r'\end{quote}'+'\n');i+=1;continue
        if line.startswith('!['):i+=1;continue
        if re.match(r'^[-*] ',line):out.append(r'\noindent $\bullet$ '+inline(line[2:])+r'\par'+'\n');i+=1;continue
        out.append(inline(line)+'\n');i+=1
    return ''.join(out)

def prepare():
    scores=pd.read_csv(ROOT/'results/five_ecology_bound_comparison.csv')
    names={'FA_original':'P0: foraging arena','LV_mass_action':'P1: Lotka--Volterra',
           'Holling_II':'P2: Holling II','Beddington_DeAngelis':'P3: Beddington--DeAngelis',
           'Ratio_dependent':'P4: ratio dependent','last_observation':'Last observation'}
    main=scores[scores.variant=='Main bounds'].set_index('model')
    wide=scores[scores.variant=='Wider bounds'].set_index('model')
    tab=[r'\begin{table}[htbp]\centering',
         r'\caption{Mean held-experiment joint normalized RMSE. Lower is better. Each entry uses four whole-experiment folds and the same 861 target pairs.}\label{scores}',
         r'\begin{tabular}{lrr}\toprule Model & Primary bounds & Wider bounds\\\midrule']
    for k,name in names.items():tab.append(f'{name} & {main.loc[k,"mean_fold_nrmse"]:.6f} & {wide.loc[k,"mean_fold_nrmse"]:.6f}'+r'\\')
    tab.append(r'\bottomrule\end{tabular}\end{table}')
    (DEST/'ecology_scores.tex').write_text('\n'.join(tab))
    header=r'''\documentclass[12pt,a4paper]{article}
\usepackage[margin=22mm]{geometry}
\PassOptionsToPackage{hyphens}{url}
\usepackage{mathptmx,amsmath,amssymb,booktabs,longtable,array,hyperref,microtype}
\Urlmuskip=0mu plus 1mu
\usepackage[T1]{fontenc}\usepackage[utf8]{inputenc}
\setlength{\parindent}{0pt}\setlength{\parskip}{5pt}
\setlength{\emergencystretch}{3em}
\hypersetup{colorlinks=true,linkcolor=black,urlcolor=blue}
\title{Detailed Mathematical and Empirical Supplement\\Five predation mechanisms with common weak Allee growth}
\author{}\date{18 November 2026}\begin{document}\maketitle
\tableofcontents\clearpage
'''
    sources=[('S1. Common four-response proofs','reports/ANALYTICAL_RESULTS.md'),
             ('S2. Independent smooth-response comparisons','reports/COMPARISON_FOUR_LAW_SUPPLEMENT.md'),
             ('S3. Ratio-dependent mathematical analysis','reports/RATIO_ANALYTICAL_SUPPLEMENT.md'),
             ('S4. Ecological comparison and primary-literature context','reports/FIVE_MODEL_ECOLOGY.md'),
             ('Parameter sources and transfer','references/ECOLOGY_LITERATURE_REVIEW.md'),
             ('Mathematical prior work','references/MATHEMATICAL_PRIOR_WORK.md')]
    body=[]
    for title,rel in sources:
        text=(ROOT/rel).read_text()
        if rel.endswith('ANALYTICAL_RESULTS.md'):
            text=text.split('## 10.')[0]
            text=text.replace('The optional ratio response is treated separately in Section 10.','The ratio response is treated in S3 of this supplement.')
            text=text.replace('l_1=\\frac{f_{XXX}+f_{XYY}+g_{XXY}+g_{YYY}}{8\\omega}\n+\\frac{',
                    '\\begin{aligned}\nl_1={}&\\frac{f_{XXX}+f_{XYY}+g_{XXY}+g_{YYY}}{8\\omega}\\\\\n&+\\frac{')
            text=text.replace('=-\\frac{579}{5000}<0.','\\\\={}&-\\frac{579}{5000}<0.\n\\end{aligned}')
        pagebreak='' if title.startswith('S4.') else r'\clearpage'
        body.append(pagebreak+r'\section{'+tex_escape(title)+'}\n'+
                    r'\noindent Source: '+inline('`'+rel+'`')+r'\par'+'\n'+md_to_tex(text))
    (DEST/'DETAILED_SUPPLEMENT.tex').write_text(header+'\n'.join(body)+r'\end{document}'+'\n')

def compile_tex(name):
    command=shutil.which('pdflatex')
    if not command:raise RuntimeError('pdflatex is needed to rebuild PDFs; existing PDFs remain supplied.')
    for j in range(2):
        proc=subprocess.run([command,'-interaction=nonstopmode','-halt-on-error',name+'.tex'],
                            cwd=DEST,capture_output=True,text=True)
        (ROOT/'logs'/f'LATEX_{name}_{j+1}.txt').write_text(proc.stdout+proc.stderr)
        if proc.returncode:
            raise RuntimeError(name+' compilation failed:\n'+(proc.stdout+proc.stderr)[-2500:])

def main():
    prepare()
    for name in ['PAPER_EN','DETAILED_SUPPLEMENT']:compile_tex(name)
    print('Rebuilt paper and full supplement PDFs.')

if __name__=='__main__':main()
