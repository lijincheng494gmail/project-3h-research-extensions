"""Deterministic controlled predation study; all parameters are synthetic.
Algebraic enumeration replaces multistart root completeness claims.
"""
from __future__ import annotations
from pathlib import Path
import json, math
import numpy as np
import pandas as pd
from numpy.polynomial import Polynomial
from scipy.integrate import solve_ivp
from scipy.optimize import root
from scipy.signal import find_peaks
from scipy.special import expit
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

MAIN = ['FA_original','LV_mass_action','Holling_II','Beddington_DeAngelis']
RATIO = 'Ratio_dependent_separate'
COLORS = ['#1F1E33','#7C78A0','#B07980','#398482','#B58B35']


def scenarios():
    return [dict(scenario='A_moderate',r=.7,K=10.,alpha=.12,e=.6,d=.3,
                 b=.15,c=.2,xref=10.,reference_intake=.9),
            dict(scenario='B_strong_allee',r=.7,K=10.,alpha=.4,e=.6,d=.3,
                 b=.15,c=.2,xref=10.,reference_intake=2.4)]


def matched(base, model):
    p=dict(base,model=model,growth='weak_allee')
    if model == RATIO:
        p.update(a=base['reference_intake'],b=0.,c=2.)
    else:
        if model in ['FA_original','LV_mass_action']: p['b']=0.
        if model in ['LV_mass_action','Holling_II']: p['c']=0.
        p['a']=base['reference_intake']*(1+p['b']*base['xref'])/base['xref']
    return p


def percapita(x,p):
    if p.get('growth')=='no_self_limitation': return p['r']*(1+p['alpha']*x)
    alpha=0. if p.get('growth')=='logistic' else p['alpha']
    return p['r']*(1-x/p['K'])*(1+alpha*x)


def rhs(z,p):
    x,y=np.asarray(z)
    den=x+p['c']*y if p['model']==RATIO else 1+p['b']*x+p['c']*y
    pred=0. if den==0 else p['a']*x*y/den
    return np.array([x*percapita(x,p)-pred,p['e']*pred-p['d']*y])


def jacobian(z,p):
    x,y=z; a,b,c=p['a'],p['b'],p['c']
    if p['model']==RATIO:
        D=x+c*y; Px=a*c*y*y/D**2; Py=a*x*x/D**2
    else:
        D=1+b*x+c*y; Px=a*y*(1+c*y)/D**2; Py=a*x*(1+b*x)/D**2
    alpha=0. if p.get('growth')=='logistic' else p['alpha']
    qp=p['r']*(alpha-1/p['K']-2*alpha*x/p['K'])
    return np.array([[percapita(x,p)+x*qp-Px,-Py],[p['e']*Px,p['e']*Py-p['d']]])


def reduced_polynomial(p):
    """H(x)=C*x*q(x)-A*x+1 for c>0; coefficients ascending."""
    r,K,alpha=p['r'],p['K'],p['alpha']
    C=p['c']*p['e']/p['d']; A=p['e']*p['a']/p['d']-p['b']
    return Polynomial([1.,C*r-A,C*r*(alpha-1/K),-C*r*alpha/K])


def all_equilibria(p):
    """All admissible positive equilibria from a degree <=3 polynomial.
    Completeness is algebraic in exact arithmetic. Near-multiple floating roots
    remain subject to conditioning; residuals and discriminants are retained.
    """
    if p.get('growth','weak_allee')!='weak_allee':
        raise ValueError('equilibrium enumerator is for primary growth only')
    K,alpha,r=p['K'],p['alpha'],p['r']
    if p['model']==RATIO:
        L=(p['a']-p['d']/p['e'])/p['c']
        if L<=0:return []
        poly=Polynomial([r-L,r*(alpha-1/K),-r*alpha/K])
        candidates=poly.roots()
    else:
        A=p['e']*p['a']/p['d']-p['b']
        if A<=0 or A*K<=1:return []
        candidates=[1/A] if p['c']==0 else reduced_polynomial(p).roots()
    records=[]
    for zz in candidates:
        if abs(np.imag(zz))>1e-7*(1+abs(zz)):continue
        x=float(np.real(zz))
        if not (1e-10 < x < K*(1-1e-11)):continue
        y=p['e']*x*percapita(x,p)/p['d']
        if p['model']!=RATIO and p['c']>0:
            y=((p['e']*p['a']/p['d']-p['b'])*x-1)/p['c']
        if y<=1e-10:continue
        resid=np.linalg.norm(rhs([x,y],p),ord=np.inf)
        if resid>1e-6*(1+x+y):continue
        if any(abs(x-row['x'])<1e-7*(1+x) for row in records):continue
        J=jacobian([x,y],p); vals=np.linalg.eigvals(J); realmax=max(vals.real)
        label='stable' if realmax < -1e-7 else ('saddle' if np.linalg.det(J)<-1e-7 else ('unstable' if realmax>1e-7 else 'critical'))
        records.append(dict(x=x,y=y,trace=float(np.trace(J)),determinant=float(np.linalg.det(J)),
                            eigmax_real=float(realmax),local_classification=label,residual=float(resid),
                            relaxation_time=(-1/realmax if realmax< -1e-7 else np.nan)))
    return sorted(records,key=lambda row:row['x'])


def simulate(p,z0,T=1200.,rtol=1e-8,atol=1e-10,max_step=2.,dt=1.):
    """Log-state integration without replacing near-extinction by a floor.
    Ratio per-capita terms use expit(log ratios), including underflow regimes.
    An explicitly removed self-limitation term has a 1e6 population stop.
    """
    log0=np.log(np.asarray(z0,dtype=float))
    def f(t,u):
        x=np.exp(min(u[0],700.)); y=np.exp(min(u[1],700.))
        if p['model']==RATIO:
            L=np.log(p['c'])+u[1]-u[0]
            loss=p['a']/p['c']*expit(L)
            gain=p['e']*p['a']*expit(-L)
        else:
            D=1+p['b']*x+p['c']*y
            loss=p['a']*y/D; gain=p['e']*p['a']*x/D
        return [percapita(x,p)-loss,gain-p['d']]
    def stop(t,u):return np.log(1e6)-max(u)
    stop.terminal=True; stop.direction=-1
    t=np.arange(0,T+dt*.1,dt)
    sol=solve_ivp(f,(0,T),log0,method='DOP853',t_eval=t,rtol=rtol,atol=atol,
                  max_step=max_step,events=stop)
    if not sol.success:raise RuntimeError(sol.message)
    times=sol.t.copy();logstates=sol.y.T.copy()
    status='population_stop_1e6' if sol.status==1 else 'completed'
    event_t=np.nan;event_population=np.nan;event_x=np.nan;event_y=np.nan
    if sol.status==1 and len(sol.t_events[0]):
        event_t=float(sol.t_events[0][-1]);event_state=sol.y_events[0][-1]
        event_z=np.exp(np.minimum(event_state,700.))
        event_population=float(np.max(event_z));event_x=float(event_z[0]);event_y=float(event_z[1])
        # t_eval need not contain the exact terminal time: keep the solver's
        # located event, so an early blow-up stop cannot appear as a small max.
        if not len(times) or event_t>times[-1]+1e-12:
            times=np.append(times,event_t);logstates=np.vstack([logstates,event_state])
        else:logstates[-1]=event_state
    traj=np.exp(np.minimum(logstates,700.))
    return times,traj,dict(status=status,nfev=sol.nfev,min_log_state=float(np.min(logstates)),
                           max_log_state=float(np.max(logstates)),solver='DOP853_log',rtol=rtol,atol=atol,max_step=max_step,
                           event_t=event_t,event_population=event_population,event_x=event_x,event_y=event_y)


def tail_metrics(t,z,horizon):
    q=z[(t>=.75*horizon)&(t<=horizon)]
    earlier=z[(t>=.5*horizon)&(t<=.75*horizon)]
    tm=t[(t>=.75*horizon)&(t<=horizon)]
    means=np.mean(q,axis=0); span=np.ptp(q,axis=0)
    peaks,_=find_peaks(q[:,0],prominence=max(1e-7,.02*span[0]))
    period=float(np.mean(np.diff(tm[peaks]))) if len(peaks)>=3 else np.nan
    ec=np.mean(earlier,axis=0); es=np.ptp(earlier,axis=0)
    drift=float(np.max(np.abs(means-ec)/(1e-7+np.abs(means))))
    ampdrift=float(np.max(np.abs(span-es)/(1e-7+span)))
    relspan=float(np.max(span/(1e-5+np.abs(means))))
    if min(means)<1e-10:label='near_extinction_at_horizon'
    elif relspan<1e-4:label='near_equilibrium_at_horizon'
    elif len(peaks)>=4 and drift<.05 and ampdrift<.05:label='persistent_oscillation_candidate'
    else:label='changing_or_long_transient'
    return dict(horizon=horizon,x_mean=means[0],y_mean=means[1],x_amplitude=span[0],
                y_amplitude=span[1],period=period,tail_peak_count=len(peaks),mean_drift=drift,
                amplitude_drift=ampdrift,finite_time_label=label)


def derivative_tensors(z,p):
    """Exact algebraic Taylor derivatives to order 3, no numerical differencing.
    Rational denominator is linear. Coefficients are expanded at positive z.
    """
    x,y=z; ratio=p['model']==RATIO
    D=x+p['c']*y if ratio else 1+p['b']*x+p['c']*y
    dx=1. if ratio else p['b'];dy=p['c']
    inv={}
    for n in range(4):
        for i in range(n+1):
            j=n-i
            inv[i,j]=(-1)**n*math.comb(n,i)*dx**i*dy**j/D**(n+1)
    numerator={(0,0):p['a']*x*y,(1,0):p['a']*y,(0,1):p['a']*x,(1,1):p['a']}
    pred={}
    for n in range(4):
        for i in range(n+1):
            j=n-i
            pred[i,j]=sum(v*inv.get((i-k,j-l),0.) for (k,l),v in numerator.items() if i>=k and j>=l)
    grow=Polynomial([0,p['r'],p['r']*(p['alpha']-1/p['K']),-p['r']*p['alpha']/p['K']])
    co=[]
    for component in [0,1]:
        dd={key:(-value if component==0 else p['e']*value) for key,value in pred.items()}
        if component==0:
            for n in range(4):dd[n,0]=dd.get((n,0),0)+grow.deriv(n)(x)/math.factorial(n)
        else:
            dd[0,0]-=p['d']*y;dd[0,1]-=p['d']
        co.append(dd)
    J=np.array([[co[i][1,0],co[i][0,1]] for i in range(2)])
    B=np.empty((2,2,2));C=np.empty((2,2,2,2))
    for i in range(2):
        for j in range(2):
            for k in range(2):
                n0=int(j==0)+int(k==0);n1=2-n0
                B[i,j,k]=co[i][n0,n1]*math.factorial(n0)*math.factorial(n1)
                for l in range(2):
                    m0=n0+int(l==0);m1=3-m0
                    C[i,j,k,l]=co[i][m0,m1]*math.factorial(m0)*math.factorial(m1)
    return J,B,C


def lyapunov_from_tensors(J,B,C):
    det=float(np.linalg.det(J));omega=math.sqrt(det)
    eig,vec=np.linalg.eig(J.astype(complex));q=vec[:,np.argmin(abs(eig-1j*omega))]
    eigp,vecp=np.linalg.eig(J.T.astype(complex));p=vecp[:,np.argmin(abs(eigp+1j*omega))]
    p=p/np.conj(np.vdot(p,q))
    def bb(v,w):return np.einsum('ijk,j,k->i',B,v,w)
    cc=np.einsum('ijkl,j,k,l->i',C,q,q,np.conj(q))
    term=cc-2*bb(q,np.linalg.solve(J,bb(q,np.conj(q))))+bb(np.conj(q),np.linalg.solve(2j*omega*np.eye(2)-J,bb(q,q)))
    return float(np.real(np.vdot(p,term))/(2*omega))


def event_search(p,Kmin=1.,Kmax=35.):
    """Local event checks using algebraic roots and exact Taylor derivatives.
    All classifications are floating-point local checks, not interval proofs.
    """
    seeds=[];grid=np.linspace(Kmin,Kmax,181);previous=[]
    for K in grid:
        eq=all_equilibria(dict(p,K=float(K)))
        for a in eq:
            for b in previous:
                if a['trace']*b['trace']<0 and abs(a['x']-b['x'])<2:
                    seeds.append([a['x'],K])
        previous=eq
    records=[]
    if p['model']==RATIO:return records
    A=p['e']*p['a']/p['d']-p['b']
    def fun(xK,kind):
        x,K=xK;pp=dict(p,K=K)
        if K<=0 or x<=0:return [1e3+abs(K),1e3+abs(x)]
        if p['c']==0:
            y=p['e']*x*percapita(x,pp)/p['d'];first=x-1/A
        else:
            y=(A*x-1)/p['c'];first=reduced_polynomial(pp)(x)
        if y<=0:return [first,1e3+abs(y)]
        second=np.trace(jacobian([x,y],pp)) if kind=='Hopf' else reduced_polynomial(pp).deriv()(x)
        return [first,second]
    for kind in ['Hopf','saddle_node']:
        if kind=='saddle_node' and p['c']==0:continue
        starts=seeds if kind=='Hopf' else [[xx,kk] for xx in [1.,2.,3.,4.,6.] for kk in [5.,8.,10.,15.,25.]]
        for start in starts:
            rr=root(lambda z:fun(z,kind),start)
            x,K=rr.x
            if not rr.success or not (Kmin<K<Kmax and 0<x<K):continue
            pp=dict(p,K=float(K));eq=all_equilibria(pp)
            # At an exact fold numerical roots can be ill-conditioned; use nullcline directly.
            y=(A*x-1)/p['c'] if p['c'] else p['e']*x*percapita(x,pp)/p['d']
            if y<=0 or np.linalg.norm(rhs([x,y],pp))>1e-6 or np.linalg.norm(fun([x,K],kind))>1e-6:continue
            if any(row['event_type']==kind and abs(row['K']-K)<1e-5 and abs(row['x']-x)<1e-5 for row in records):continue
            J=jacobian([x,y],pp);tr=float(np.trace(J));det=float(np.linalg.det(J))
            row=dict(scenario=p['scenario'],model=p['model'],event_type=kind,K=K,x=x,y=y,
                     trace=tr,determinant=det,residual=float(np.linalg.norm(rhs([x,y],pp))),
                     a=p['a'],b=p['b'],c=p['c'],alpha=p['alpha'],r=p['r'],e=p['e'],d=p['d'])
            if kind=='Hopf':
                if det<=1e-7:continue
                h=1e-4*max(1.,K);traces=[]
                for sign in [-1,1]:
                    ee=all_equilibria(dict(pp,K=K+sign*h))
                    if not ee:break
                    traces.append(min(ee,key=lambda q:abs(q['x']-x))['trace'])
                if len(traces)!=2:continue
                slope=(traces[1]-traces[0])/(2*h)
                JT,B,C=derivative_tensors([x,y],pp)
                l1=lyapunov_from_tensors(JT,B,C)
                row.update(trace_K_derivative=slope,first_lyapunov_coefficient=l1,
                           derivative_J_error=float(np.max(abs(JT-J))))
                valid=abs(slope)>1e-7 and abs(l1)>1e-7
                row['classification']='nondegenerate_Hopf_numeric_local_checks' if valid else 'Hopf_candidate_degenerate_or_unresolved'
                row['cycle_local_stability']='stable' if l1<0 else 'unstable'
            else:
                poly=reduced_polynomial(pp);hxx=poly.deriv(2)(x)
                hk=pp['c']*pp['e']/pp['d']*pp['r']*x*x*(1+pp['alpha']*x)/K**2
                row.update(reduced_H_xx=hxx,reduced_H_K=hk)
                valid=abs(hxx)>1e-7 and abs(hk)>1e-7 and abs(tr)>1e-7
                row['classification']='nondegenerate_saddle_node_numeric_local_checks' if valid else 'fold_candidate_degenerate_or_unresolved'
            records.append(row)
    return records



def exact_oracle_audits():
    rows=[]
    sn=dict(model='FA_original',growth='weak_allee',r=1.,K=8.,alpha=.5,a=6.25,c=4.,e=1.,d=1.,b=0.)
    H=reduced_polynomial(sn);z=[1.,21/16];J=jacobian(z,sn)
    rows.append(dict(oracle='saddle_node_exact',x=z[0],y=z[1],ode_residual=float(np.linalg.norm(rhs(z,sn))),
        H=float(H(1)),Hx=float(H.deriv()(1)),Hxx=float(H.deriv(2)(1)),H_a=-1.,
        trace=float(np.trace(J)),determinant=float(np.linalg.det(J)),
        expected_Hxx=1.5,expected_trace=-.59,status='exact_formula_float_crosscheck'))
    bt=dict(model='FA_original',growth='weak_allee',r=8/27,K=6.,alpha=10/3,a=2.,c=1.,e=1.,d=1.,b=0.)
    z=np.array([1.5,2.]);J,B,C=derivative_tensors(z,bt)
    q0=np.array([1.,2.]);q1=np.array([0.,-3.]);p0=np.array([1.,0.]);p1=np.array([2/3,-1/3])
    B00=np.einsum('ijk,j,k->i',B,q0,q0);B01=np.einsum('ijk,j,k->i',B,q0,q1)
    aa=.5*np.dot(p1,B00);bb=np.dot(p0,B00)+np.dot(p1,B01)
    x=z[0];q=percapita(x,bt);qp=bt['r']*(bt['alpha']-1/bt['K']-2*bt['alpha']*x/bt['K'])
    qpp=-2*bt['r']*bt['alpha']/bt['K'];H=reduced_polynomial(bt)
    unfolding=np.array([[H.deriv()(x),-x,x*q],[H.deriv(2)(x),-1,q+x*qp],[qp+x*qpp-1/(bt['a']*x*x),-1/(bt['a']**2*x),0.]])
    rows.append(dict(oracle='Bogdanov_Takens_exact',x=z[0],y=z[1],ode_residual=float(np.linalg.norm(rhs(z,bt))),
        trace=float(np.trace(J)),determinant=float(np.linalg.det(J)),nilpotent_J_squared_norm=float(np.linalg.norm(J@J)),
        BT_a=float(aa),BT_b=float(bb),expected_BT_a=32/243,expected_BT_b=-22/81,
        unfolding_det=float(np.linalg.det(unfolding)),expected_unfolding_det=34/243,
        status='exact_formula_float_crosscheck'))
    hp=dict(model='FA_original',growth='weak_allee',r=.36,K=6.,alpha=7/3,a=2.,c=1.,e=1.,d=1.,b=0.)
    z=np.array([1.,1.]);J,B,C=derivative_tensors(z,hp)
    rows.append(dict(oracle='Hopf_exact',x=1.,y=1.,ode_residual=float(np.linalg.norm(rhs(z,hp))),
        trace=float(np.trace(J)),determinant=float(np.linalg.det(J)),first_lyapunov_coefficient=lyapunov_from_tensors(J,B,C),
        expected_l1_sign=-1.,expected_trace_r_derivative=-1/6,status='exact_formula_float_crosscheck'))
    return rows


def write_csv(root,name,rows,columns=None):
    frame=pd.DataFrame(rows,columns=columns) if columns else pd.DataFrame(rows)
    frame.to_csv(root/'results'/('controlled_'+name+'.csv'),index=False)
    return frame


def run(root):
    root=Path(root)
    for f in ['results','figures','logs','reports']:(root/f).mkdir(exist_ok=True)
    failures=[];parameters=[];eqs=[];runs=[];trajectories=[];audits=[];enrichment=[];events=[]
    print('[controlled] matched scenarios and long-horizon simulations',flush=True)
    for base in scenarios():
        for model in MAIN+[RATIO]:
            p=matched(base,model)
            parameters.append({**p,'synthetic_or_real':'synthetic_dimensionless',
                 'reference_P_over_y':p['a'] if model==RATIO else p['a']*p['xref']/(1+p['b']*p['xref']),
                 'invasion_R':p['e']*p['a']/p['d'] if model==RATIO else p['e']*p['a']*p['K']/(p['d']*(1+p['b']*p['K'])),
                 'FA_m':p['a']/p['c'] if model=='FA_original' else np.nan,
                 'FA_beta':1/p['c'] if model=='FA_original' else np.nan})
            for branch,a in enumerate(all_equilibria(p)):eqs.append(dict(scenario=p['scenario'],model=model,branch=branch,**a))
            for initial,z0 in enumerate([[7.,.2],[2.,3.],[9.,1.]]):
                try:
                    t,z,meta=simulate(p,z0)
                    for T in [600.,1200.]:runs.append(dict(scenario=p['scenario'],model=model,initial=initial,**tail_metrics(t,z,T),**meta))
                    for j in range(0,len(t),2):trajectories.append(dict(scenario=p['scenario'],model=model,initial=initial,t=t[j],x=z[j,0],y=z[j,1]))
                    if initial==0:
                        tt,zt,mt=simulate(p,z0,rtol=1e-10,atol=1e-12,max_step=.5)
                        ar=tail_metrics(t,z,1200.);br=tail_metrics(tt,zt,1200.)
                        audits.append(dict(scenario=p['scenario'],model=model,
                            max_abs_trajectory_difference=float(np.max(abs(z-zt))),
                            max_scaled_trajectory_difference=float(np.max(abs(z-zt)/(1+abs(zt)))),
                            final_abs_difference=float(np.max(abs(z[-1]-zt[-1]))),
                            mean_abs_difference=max(abs(ar['x_mean']-br['x_mean']),abs(ar['y_mean']-br['y_mean'])),
                            amplitude_abs_difference=max(abs(ar['x_amplitude']-br['x_amplitude']),abs(ar['y_amplitude']-br['y_amplitude'])),
                            base_rtol=meta['rtol'],tight_rtol=mt['rtol'],base_max_step=meta['max_step'],tight_max_step=mt['max_step'],
                            status='completed'))
                except Exception as exc:failures.append(dict(stage='long_horizon',scenario=p['scenario'],model=model,initial=initial,error=repr(exc)))
            if model in MAIN:
                for K in np.linspace(1.,35.,241):
                    ee=all_equilibria(dict(p,K=float(K)))
                    for branch,a in enumerate(ee):enrichment.append(dict(scenario=p['scenario'],model=model,K=K,branch_rank=branch,n_positive_equilibria=len(ee),**a))
                events+=event_search(p)
    write_csv(root,'parameters',parameters); eqdf=write_csv(root,'equilibria',eqs)
    rundf=write_csv(root,'long_horizon',runs);write_csv(root,'trajectories',trajectories)
    write_csv(root,'solver_audit',audits);endf=write_csv(root,'enrichment_all_branches',enrichment)
    print('[controlled] independent b/c and alpha/c grids',flush=True)
    grids=[]
    for base in scenarios():
        for gridtype in ['b_c','alpha_c']:
            for xx in np.linspace(0.,.5 if gridtype=='b_c' else .8,25):
                for c in np.linspace(0.,.8,25):
                    bb=dict(base,c=float(c));bb['b' if gridtype=='b_c' else 'alpha']=float(xx)
                    pp=matched(bb,'Beddington_DeAngelis')
                    ee=all_equilibria(pp)
                    common=dict(scenario=base['scenario'],grid=gridtype,grid_x=xx,c=c,b=pp['b'],alpha=pp['alpha'],a=pp['a'],
                                invasion_R=pp['e']*pp['a']*pp['K']/(pp['d']*(1+pp['b']*pp['K'])),n_equilibria=len(ee))
                    if not ee:grids.append(dict(**common,branch_rank=-1,local_classification='none'))
                    for branch,a in enumerate(ee):grids.append(dict(**common,branch_rank=branch,**a))
    grdf=write_csv(root,'two_parameter_grids',grids)
    print('[controlled] interference recovery with fixed invasion threshold',flush=True)
    recovery=[]
    for base in scenarios():
        for family in ['FA_original','Beddington_DeAngelis']:
            for c in [0.,.025,.05,.1,.2,.4,.8,1.2]:
                p=matched(dict(base,c=c),family)
                for branch,a in enumerate(all_equilibria(p)):
                    row=dict(scenario=base['scenario'],model=family,c=c,branch_rank=branch,
                        invasion_R=p['e']*p['a']*p['K']/(p['d']*(1+p['b']*p['K'])),**a)
                    if a['local_classification']=='stable':
                        try:
                            t,z,meta=simulate(p,[a['x'],1.1*a['y']],T=600.)
                            dist=np.max(abs(z/np.array([a['x'],a['y']])-1),axis=1)
                            last=np.flatnonzero(dist>.02)
                            settling=t[last[-1]+1] if len(last) and last[-1]+1<len(t) else (0. if not len(last) else np.nan)
                            row.update(settling_time_2pct=settling,recovery_status='settled' if np.isfinite(settling) else 'not_settled_by_600')
                        except Exception as exc:
                            row.update(recovery_status='solver_failed');failures.append(dict(stage='recovery',scenario=base['scenario'],model=family,c=c,error=repr(exc)))
                    else:row.update(recovery_status='not_applicable_unstable')
                    recovery.append(row)
    write_csv(root,'interference_recovery',recovery)
    print('[controlled] growth ablation and alpha/interference factorial',flush=True)
    ablations=[];factor=[];contrasts=[]
    for base in scenarios():
        for model in ['LV_mass_action','FA_original']:
            for growth in ['weak_allee','logistic','no_self_limitation']:
                p=matched(base,model);p['growth']=growth
                try:
                    t,z,meta=simulate(p,[7.,.2],T=1200. if growth!='no_self_limitation' else 40.)
                    row=dict(scenario=base['scenario'],model=model,growth=growth,final_t=t[-1],x_final=z[-1,0],y_final=z[-1,1],
                             max_x=float(z[:,0].max()),max_y=float(z[:,1].max()),**meta)
                    if t[-1]>=1200.:row.update(tail_metrics(t,z,1200.))
                    ablations.append(row)
                except Exception as exc:failures.append(dict(stage='ablation',scenario=base['scenario'],model=model,growth=growth,error=repr(exc)))
        for alpha_on in [0,1]:
            for interference_on in [0,1]:
                bb=dict(base,alpha=base['alpha']*alpha_on,c=base['c']*interference_on)
                p=matched(bb,'FA_original');ee=all_equilibria(p)
                row=dict(scenario=base['scenario'],alpha_on=alpha_on,interference_on=interference_on,
                         alpha=p['alpha'],c=p['c'],n_equilibria=len(ee),stable_equilibria=sum(e['local_classification']=='stable' for e in ee),
                         reference_intake=base['reference_intake'],data_type='synthetic_dimensionless')
                if len(ee)==1:row.update(eq_trace=ee[0]['trace'],eq_x=ee[0]['x'])
                try:
                    t,z,meta=simulate(p,[7.,.2]);row.update(tail_metrics(t,z,1200.));row.update(meta)
                except Exception as exc:failures.append(dict(stage='factorial',scenario=base['scenario'],error=repr(exc)))
                factor.append(row)
        ff={(row['alpha_on'],row['interference_on']):row for row in factor if row['scenario']==base['scenario']}
        for metric in ['eq_trace','eq_x','x_amplitude','y_amplitude']:
            if all(metric in ff[key] for key in ff):
                val=ff[1,1][metric]-ff[1,0][metric]-ff[0,1][metric]+ff[0,0][metric]
                contrasts.append(dict(scenario=base['scenario'],metric=metric,interaction_difference=val,definition='joint - alpha_only - interference_only + neither'))
    write_csv(root,'growth_ablation',ablations);write_csv(root,'factorial',factor);write_csv(root,'factorial_interactions',contrasts)
    print('[controlled] exact multistability and three-root probes',flush=True)
    probe=dict(scenario='H5_exact_multistability',r=1.,K=8.,alpha=.5,e=1.,d=1.,a=4.5,b=0.,c=8/3,
               model='FA_original',growth='weak_allee')
    probe2=dict(scenario='exact_root_enumeration_check',r=1.,K=10.,alpha=1.,e=.6,d=.9,a=2.25,b=0.,c=.625,
                model='FA_original',growth='weak_allee')
    proots=[];ptraj=[];psum=[]
    for pp in [probe,probe2]:
        for alpha_on in [0,1]:
            for c_on in [0,1]:
                p=dict(pp,alpha=pp['alpha']*alpha_on,c=pp['c']*c_on)
                ee=all_equilibria(p)
                for branch,a in enumerate(ee):proots.append(dict(scenario=pp['scenario'],alpha_on=alpha_on,interference_on=c_on,branch_rank=branch,n_equilibria=len(ee),**a))
        for K in np.linspace(1.,18.,341):
            ee=all_equilibria(dict(pp,K=float(K)))
            for branch,a in enumerate(ee):enrichment.append(dict(scenario=pp['scenario'],model=pp['model'],K=K,branch_rank=branch,n_positive_equilibria=len(ee),**a))
        events+=event_search(pp,Kmin=1,Kmax=18)
    for initial,z0 in enumerate([[1.,1.],[3.,4.],[.8,.8],[3.5,4.5],[2.,3.]]):
        try:
            t,z,meta=simulate(probe,z0)
            psum.append(dict(scenario=probe['scenario'],initial=initial,x0=z0[0],y0=z0[1],x_final=z[-1,0],y_final=z[-1,1],**tail_metrics(t,z,1200.),**meta))
            for j in range(0,len(t),2):ptraj.append(dict(initial=initial,t=t[j],x=z[j,0],y=z[j,1]))
        except Exception as exc:failures.append(dict(stage='multistability',initial=initial,error=repr(exc)))
    write_csv(root,'local_exact_oracle_audits',exact_oracle_audits())
    btgrid=[]
    for aval in np.linspace(1.7,2.3,31):
        for cval in np.linspace(.75,1.25,31):
            pp=dict(scenario='BT_local_unfolding',model='FA_original',growth='weak_allee',r=8/27,K=6.,alpha=10/3,
                    a=float(aval),c=float(cval),e=1.,d=1.,b=0.)
            ee=all_equilibria(pp)
            common=dict(a=aval,c=cval,n_equilibria=len(ee),stable_count=sum(z['local_classification']=='stable' for z in ee))
            if not ee:btgrid.append(dict(**common,branch_rank=-1))
            for j,z in enumerate(ee):btgrid.append(dict(**common,branch_rank=j,**z))
    write_csv(root,'BT_local_two_parameter',btgrid)
    hopfsides=[]
    for rval in [.34,.36,.38]:
        pp=dict(model='FA_original',growth='weak_allee',r=rval,K=6.,alpha=7/3,a=2.,c=1.,e=1.,d=1.,b=0.)
        ee=all_equilibria(pp);eq=min(ee,key=lambda z:abs(z['x']-1))
        try:
            t,z,meta=simulate(pp,[eq['x']*1.01,eq['y']*.99])
            metrics=tail_metrics(t,z,1200.)
            metrics['unadjusted_finite_time_label']=metrics['finite_time_label']
            if abs(rval-.36)<1e-12:
                # This exact nondegenerate Hopf point has l1<0: the weak focus
                # decays algebraically. Similar amplitudes in two windows are
                # insufficient to distinguish that decay from a true cycle.
                metrics['finite_time_label']='critical_Hopf_slow_decay_not_cycle'
            hopfsides.append(dict(r=rval,equilibrium_x=eq['x'],equilibrium_y=eq['y'],equilibrium_trace=eq['trace'],
                equilibrium_determinant=eq['determinant'],**metrics,**meta))
        except Exception as exc:failures.append(dict(stage='Hopf_r_sides',error=repr(exc)))
    write_csv(root,'Hopf_exact_r_sides',hopfsides)
    write_csv(root,'exact_root_probes',proots);pfd=write_csv(root,'multistability_trajectories',ptraj)
    write_csv(root,'multistability_runs',psum);write_csv(root,'local_bifurcation_events',events)
    endf=write_csv(root,'enrichment_all_branches',enrichment)
    write_csv(root,'failures',failures,columns=['stage','scenario','model','initial','c','growth','error'])
    # Figures: show all equilibrium branches, including unstable branches.
    fig,axes=plt.subplots(1,2,figsize=(12,4.5))
    for ax,base in zip(axes,scenarios()):
        for col,model in zip(COLORS,MAIN):
            dd=endf[(endf.scenario==base['scenario'])&(endf.model==model)]
            for stable,marker in [('stable','.'),('unstable','x'),('saddle','+')]:
                ss=dd[dd.local_classification==stable]
                ax.scatter(ss.K,ss.x,s=9 if marker=='.' else 12,marker=marker,color=col,
                           label=model if stable=='stable' else None,alpha=.8)
        ax.set(title=base['scenario'],xlabel='K (synthetic)',ylabel='all positive-equilibrium prey x')
    axes[0].legend(fontsize=7);fig.suptitle('Enrichment: dots stable; x unstable; + saddle; a fixed at baseline K')
    fig.tight_layout();fig.savefig(root/'figures/controlled_enrichment_all_branches.png',dpi=180);plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(11,4.2))
    for ax,base in zip(axes,scenarios()):
        dd=rundf[(rundf.scenario==base['scenario'])&(rundf.initial==0)&(rundf.horizon==1200)]
        ax.bar(np.arange(len(dd)),dd.x_amplitude,color=COLORS)
        ax.set_xticks(np.arange(len(dd)),['FA','LV','HII','BD','Ratio*'])
        ax.set(title=base['scenario'],ylabel='late prey amplitude [900,1200]')
    fig.suptitle('Matched low-predator intake; ratio model (*) assessed separately');fig.tight_layout()
    fig.savefig(root/'figures/controlled_long_horizon_amplitudes.png',dpi=180);plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(11,4.2))
    for i,(key,dd) in enumerate(pfd.groupby('initial')):
        axes[0].plot(dd.t,dd.x,label=str(key),color=COLORS[i]);axes[1].plot(dd.x,dd.y,color=COLORS[i])
    axes[0].set(xlabel='t',ylabel='prey x',title='Joint weak-Allee / interference case');axes[0].legend(title='initial',fontsize=7)
    axes[1].set(xlabel='prey x',ylabel='predator y',title='Two attracting equilibria, one saddle')
    fig.tight_layout();fig.savefig(root/'figures/controlled_joint_multistability.png',dpi=180);plt.close(fig)
    fig,axes=plt.subplots(2,2,figsize=(11,8))
    for row,base in enumerate(scenarios()):
        for col,gridtype in enumerate(['b_c','alpha_c']):
            dd=grdf[(grdf.scenario==base['scenario'])&(grdf.grid==gridtype)]
            dd=dd.groupby(['grid_x','c'],as_index=False).agg(max_real=('eigmax_real','max'))
            table=dd.pivot(index='c',columns='grid_x',values='max_real')
            im=axes[row,col].pcolormesh(table.columns,table.index,table.values,shading='auto',cmap='coolwarm',vmin=-.4,vmax=.4)
            axes[row,col].set(xlabel='b' if gridtype=='b_c' else 'alpha',ylabel='c',title=base['scenario']+' '+gridtype)
            fig.colorbar(im,ax=axes[row,col],label='largest equilibrium Re(lambda)')
    fig.tight_layout();fig.savefig(root/'figures/controlled_two_parameter_grids.png',dpi=170);plt.close(fig)
    summary=dict(parameters=len(parameters),primary_trajectories=len(runs)//2,long_horizon_rows=len(runs),
                 solver_audits=len(audits),enrichment_branch_rows=len(enrichment),two_parameter_rows=len(grids),
                 recovery_rows=len(recovery),growth_ablation_rows=len(ablations),factorial_rows=len(factor),
                 local_bifurcation_events=len(events),failures=len(failures),primary_growth='weak_Allee_unchanged',
                 evidence_status='analytic reduction plus floating-point numerical experiments; no stochastic dynamics')
    (root/'logs/CONTROLLED_RUN_STATUS.json').write_text(json.dumps(summary,indent=2))
    print('[controlled] done '+json.dumps(summary),flush=True)
    return summary

if __name__=='__main__':run(Path(__file__).resolve().parents[1])
