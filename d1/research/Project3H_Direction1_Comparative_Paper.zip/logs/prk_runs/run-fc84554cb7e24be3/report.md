# Local experiment receipt

Actual status: Process complete and output validation passed (succeeded)
Process exit code: 0; output validation: passed

allocated None, attempted None, completed None, valid None, scored None, failed None, denominator None. null means unknown.

Run: run-fc84554cb7e24be3; approved plan: 2f002a00f99d456c
Logs: 05_runs/run-fc84554cb7e24be3/stdout.log / 05_runs/run-fc84554cb7e24be3/stderr.log

Failure reason (original detail): No execution failure recorded
Resources are in resources.json; all attempts and partial outputs were retained.

Elapsed time 12.8706 seconds; logs and results 1141 bytes; peak memory was not measured.

- Controlled checks do not replace the host/OS sandbox; approved Python code has the current user permissions.
- network=deny is a policy, not OS network isolation. Read-only input copies do not constrain malicious code with the same permissions.
- Output limits are polled and can overshoot by one interval; memory/GPU usage has no hard cap.
- Process exit and output validation are engineering evidence, not certification of scientific conclusions.

Only the local runner was used; no cloud adapter was called. Researchers retain decisions about later experiments and scientific interpretation.
