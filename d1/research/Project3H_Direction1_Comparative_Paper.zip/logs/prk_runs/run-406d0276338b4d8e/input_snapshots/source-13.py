import unittest
import numpy as np
from src.controlled_extended import (MAIN,RATIO,scenarios,matched,all_equilibria,
    reduced_polynomial,jacobian,rhs,derivative_tensors,lyapunov_from_tensors,exact_oracle_audits)

class ControlledTests(unittest.TestCase):
    def test_matching_reference_and_invasion(self):
        for base in scenarios():
            values=[]
            for model in MAIN:
                p=matched(base,model)
                intake=p['a']*base['xref']/(1+p['b']*base['xref'])
                self.assertAlmostEqual(intake,base['reference_intake'])
                values.append(p['e']*p['a']*p['K']/(p['d']*(1+p['b']*p['K'])))
                self.assertEqual(p['alpha'],base['alpha'])
            np.testing.assert_allclose(values,values[0],rtol=1e-14)

    def test_exact_three_roots_and_stability(self):
        p=dict(model='FA_original',growth='weak_allee',r=1.,K=8.,alpha=.5,e=1.,d=1.,a=4.5,b=0.,c=8/3)
        ee=all_equilibria(p)
        np.testing.assert_allclose([x['x'] for x in ee],[1,2,3],atol=1e-10)
        self.assertEqual([x['local_classification'] for x in ee],['stable','saddle','stable'])
        for q in [dict(p,alpha=0),dict(p,c=0)]:self.assertEqual(len(all_equilibria(q)),1)
        np.testing.assert_allclose(reduced_polynomial(p).coef,[1,-11/6,1,-1/6],atol=1e-14)

    def test_second_exact_polynomial_probe(self):
        p=dict(model='FA_original',growth='weak_allee',r=1.,K=10.,alpha=1.,e=.6,d=.9,a=2.25,b=0.,c=.625)
        np.testing.assert_allclose([z['x'] for z in all_equilibria(p)],[2.,3.,4.],atol=1e-10)

    def test_all_physical_equilibrium_residuals(self):
        for base in scenarios():
            for model in MAIN+[RATIO]:
                p=matched(base,model)
                for q in all_equilibria(p):
                    self.assertLess(np.linalg.norm(rhs([q['x'],q['y']],p)),1e-9)
                    self.assertGreater(q['x'],0);self.assertLess(q['x'],p['K'])
                    self.assertGreater(q['y'],0)

    def test_jacobian_and_taylor_gradient(self):
        for model in MAIN+[RATIO]:
            p=matched(scenarios()[0],model);z=np.array([3.,2.])
            J,B,C=derivative_tensors(z,p)
            np.testing.assert_allclose(J,jacobian(z,p),atol=1e-13)
            h=1e-5
            Jnum=np.column_stack([(rhs(z+np.eye(2)[i]*h,p)-rhs(z-np.eye(2)[i]*h,p))/(2*h) for i in range(2)])
            np.testing.assert_allclose(J,Jnum,atol=1e-9)
            for i in range(2):
                Bnum=(jacobian(z+np.eye(2)[i]*h,p)-jacobian(z-np.eye(2)[i]*h,p))/(2*h)
                np.testing.assert_allclose(B[:,:,i],Bnum,atol=1e-9)
                Cnum=(derivative_tensors(z+np.eye(2)[i]*h,p)[1]-derivative_tensors(z-np.eye(2)[i]*h,p)[1])/(2*h)
                np.testing.assert_allclose(C[:,:,:,i],Cnum,atol=1e-9)

    def test_exact_local_bifurcation_oracles(self):
        sn,bt,hp=exact_oracle_audits()
        self.assertLess(sn['ode_residual'],1e-12)
        self.assertAlmostEqual(sn['Hxx'],sn['expected_Hxx'])
        self.assertAlmostEqual(sn['trace'],sn['expected_trace'])
        self.assertAlmostEqual(bt['BT_a'],bt['expected_BT_a'])
        self.assertAlmostEqual(bt['BT_b'],bt['expected_BT_b'])
        self.assertAlmostEqual(bt['unfolding_det'],bt['expected_unfolding_det'])
        self.assertLess(bt['nilpotent_J_squared_norm'],1e-12)
        self.assertLess(hp['first_lyapunov_coefficient'],0.)
        self.assertAlmostEqual(hp['trace'],0.)
        self.assertAlmostEqual(hp['determinant'],.25)

    def test_lyapunov_sign_normal_form(self):
        # f=-y-x(x^2+y^2), g=x-y(x^2+y^2), at the origin.
        J=np.array([[0.,-1.],[1.,0.]])
        B=np.zeros((2,2,2));C=np.zeros((2,2,2,2))
        C[0,0,0,0]=-6;C[1,1,1,1]=-6
        for inds in [(0,1,1),(1,0,1),(1,1,0)]:C[(0,)+inds]=-2
        for inds in [(0,0,1),(0,1,0),(1,0,0)]:C[(1,)+inds]=-2
        self.assertAlmostEqual(lyapunov_from_tensors(J,B,C),-2.,places=10)
        self.assertAlmostEqual(lyapunov_from_tensors(J,B,-C),2.,places=10)

if __name__=='__main__':unittest.main()
