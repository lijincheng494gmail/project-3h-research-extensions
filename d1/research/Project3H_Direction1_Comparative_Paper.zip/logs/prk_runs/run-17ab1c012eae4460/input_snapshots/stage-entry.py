"""Reproduce named stages; executed by the recorded local PRK runner."""
from pathlib import Path
import argparse, hashlib, json, os, platform, subprocess, sys, time

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--project',type=Path,default=Path(__file__).resolve().parent)
    ap.add_argument('--stage',choices=['baseline','controlled','ecology','analytic','tests'],required=True)
    ap.add_argument('--input-manifest',type=Path)
    args=ap.parse_args(); execution_dir=Path.cwd(); root=args.project.resolve(); os.chdir(root)
    sys.path.insert(0,str(root))
    if args.input_manifest:
        for rel,expected in json.loads(args.input_manifest.read_text()).items():
            actual=hashlib.sha256((root/rel).read_bytes()).hexdigest()
            if actual!=expected: raise RuntimeError('Input changed after preparation: '+rel)
    started=time.time()
    print('START',args.stage,flush=True)
    if args.stage=='baseline':
        env=dict(os.environ,PYTHON=sys.executable,PATH='/usr/bin:/bin')
        subprocess.run(['/bin/bash','run.sh','tests'],check=True,env=env)
        subprocess.run(['/bin/bash','run.sh','full'],check=True,env=env)
    elif args.stage=='tests':
        subprocess.run([sys.executable,'-m','unittest','discover','-s','tests','-v'],check=True)
    elif args.stage=='analytic':
        from src.analytic_checks import main as analytic_main
        analytic_main(root)
    else:
        from importlib import import_module
        module=import_module('src.'+('controlled_extended' if args.stage=='controlled' else 'ecology_extended'))
        module.run(root)
    result={'stage':args.stage,'exit_code':0,'elapsed_seconds':time.time()-started,
            'python':platform.python_version(),'platform':platform.platform(),
            'status':'executed','source_manifest_checked':bool(args.input_manifest)}
    target=Path(os.environ.get('PRK_RUN_SUMMARY',str(execution_dir/'execution_summary.json')))
    # PRK starts this script with a run-specific cwd, supplied through an explicit env var.
    target.write_text(json.dumps(result,indent=2,allow_nan=False))
    (root/'logs'/('EXECUTION_'+args.stage+'.json')).write_text(json.dumps(result,indent=2))
    print(json.dumps(result),flush=True)

if __name__=='__main__':main()
