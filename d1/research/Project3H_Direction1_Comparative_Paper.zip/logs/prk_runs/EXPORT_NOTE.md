# Execution evidence export

These are local PRK execution records and input snapshots. Personal absolute paths in text were replaced with <PROJECT>, <WORK>, or <USER>. EXPORT_INDEX.json preserves both original and exported SHA256 values. Redacted copies are identified and are not byte-identical raw logs. No approval receipt, private root binding, or authentication assertion is exported. Original records remain in the local work directory. Source hashes, process outcomes, timestamps, solver logs, and resource records are retained.
