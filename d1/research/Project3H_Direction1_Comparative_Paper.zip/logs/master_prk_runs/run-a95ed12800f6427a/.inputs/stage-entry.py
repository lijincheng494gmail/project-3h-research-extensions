"""Logged reproduction entry for the five-model comparative paper."""
from pathlib import Path
import argparse, hashlib, importlib, json, os, platform, subprocess, sys, time

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--project',type=Path,default=Path(__file__).resolve().parent)
    ap.add_argument('--stage',choices=['periodic','ratio','five_ecology','comparison','independent','all_tests'],required=True)
    ap.add_argument('--input-manifest',type=Path)
    args=ap.parse_args();start=time.monotonic();execution_dir=Path.cwd()
    project=args.project.resolve();os.chdir(project);sys.path.insert(0,str(project))
    if args.input_manifest:
        for rel,digest in json.loads(args.input_manifest.read_text()).items():
            if hashlib.sha256((project/rel).read_bytes()).hexdigest()!=digest:
                raise RuntimeError('Prepared input changed: '+rel)
    if args.stage=='all_tests':
        out=subprocess.run([sys.executable,'-m','unittest','discover','-s','tests','-v'],
                           capture_output=True,text=True)
        (project/'logs/MASTER_FINAL_TESTS.txt').write_text(out.stdout+out.stderr)
        print(out.stdout+out.stderr,flush=True);out.check_returncode()
    elif args.stage=='comparison':
        for name in ['comparison_audit','bd_exact_examples']:
            importlib.import_module('src.'+name).run(project)
        subprocess.run([sys.executable,'-m','src.build_comparison_matrix'],check=True)
    elif args.stage=='independent':
        for name in ['independent_ratio_review','ratio_independent_hopf_audit',
                     'periodic_independent_audit','ecology_five_validation']:
            importlib.import_module('src.'+name).run(project)
    elif args.stage=='five_ecology':
        module=importlib.import_module('src.ecology_five_models')
        module.run(project);module.run(project,sensitivity=True)
        for name in ['ecology_five_validation','ecology_five_summary']:
            importlib.import_module('src.'+name).run(project)
    else:
        name=dict(periodic='periodic_continuation',ratio='ratio_analysis')[args.stage]
        module=importlib.import_module('src.'+name)
        (module.main if args.stage=='ratio' else module.run)(project)
    status=dict(stage=args.stage,exit_code=0,elapsed_seconds=time.monotonic()-start,
                python=platform.python_version(),input_manifest_checked=bool(args.input_manifest),
                current_scope='MASTER_SCOPE.md; full P0-P4 comparative question')
    (project/'logs'/('MASTER_EXECUTION_'+args.stage+'.json')).write_text(json.dumps(status,indent=2))
    (execution_dir/'execution_summary.json').write_text(json.dumps(status,indent=2))
    print(json.dumps(status),flush=True)

if __name__=='__main__':main()
