"""Direct P4 calculations, independent audits, and synthetic illustrations.

The response is a*x*y/(x+c*y), continuously extended by zero at the origin.
Run ``python -m src.ratio_analysis``. No external theorem is imported as a
weak-Allee theorem. Local normal-form conventions match analytic_checks.py.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from .analytic_checks import q, qprime, qsecond, planar_hopf_l1


def rhs(z, p):
    x, y = np.asarray(z)
    D = x + p['c']*y
    P = 0. if D == 0 else p['a']*x*y/D
    return np.array([x*q(x,p)-P, p['e']*P-p['d']*y])


def jacobian(z,p):
    x,y=z;D=x+p['c']*y
    if D <= 0: raise ValueError('No differentiable Jacobian at the origin')
    Px=p['a']*p['c']*y*y/D**2;Py=p['a']*x*x/D**2
    return np.array([[q(x,p)+x*qprime(x,p)-Px,-Py],
                     [p['e']*Px,p['e']*Py-p['d']]])


def derivative_tensors(z,p):
    """Closed derivatives; independently compared with rational Taylor series."""
    x,y=z;a=p['a'];c=p['c'];D=x+c*y
    P2=np.array([[-2*a*c*y*y/D**3,2*a*c*x*y/D**3],
                 [2*a*c*x*y/D**3,-2*a*c*x*x/D**3]])
    P3=np.empty((2,2,2))
    vals=[6*a*c*y*y/D**4,2*a*c*y*(c*y-2*x)/D**4,
          2*a*c*x*(x-2*c*y)/D**4,6*a*c*c*x*x/D**4]
    for i in range(2):
        for j in range(2):
            for k in range(2): P3[i,j,k]=vals[i+j+k]
    B=np.stack([-P2,p['e']*P2]);C=np.stack([-P3,p['e']*P3])
    B[0,0,0]+=2*qprime(x,p)+x*qsecond(p)
    C[0,0,0,0]+=3*qsecond(p)
    return B,C


def constants(p):
    s=p['e']*p['a']/p['d']
    return dict(s=s,kappa=p['e']*p['c'],B=p['a']/p['c'],
                Q=(p['a']-p['d']/p['e'])/p['c'],
                h=p['d']*(s-1)/s)


def equilibria(p):
    k=constants(p)
    if k['s'] <= 1: return []
    # Exact polynomial characterisation; near-multiple roots use event equations.
    coef=np.array([p['r']-k['Q'],p['r']*(p['alpha']-1/p['K']),
                   -p['r']*p['alpha']/p['K']])
    roots=np.polynomial.polynomial.polyroots(np.trim_zeros(coef,'b'))
    records=[]
    for xx in roots:
        if abs(xx.imag)>1e-7*(1+abs(xx.real)): continue
        x=float(xx.real)
        if not 1e-10<x<p['K']:continue
        if any(abs(x-v['x'])<1e-6*(1+x) for v in records):continue
        y=(k['s']-1)*x/p['c'];T=x*qprime(x,p)+k['h']*(1/k['kappa']-1)
        det=-k['h']*x*qprime(x,p)
        label='saddle' if det < -1e-8 else ('stable' if T < -1e-8 and det>1e-8 else ('unstable' if T>1e-8 and det>1e-8 else 'critical'))
        records.append(dict(x=x,y=y,trace=T,determinant=det,
                            qprime=qprime(x,p),local_classification=label,
                            rhs_residual=float(np.max(np.abs(rhs([x,y],p))))))
    return sorted(records,key=lambda v:v['x'])


def enrichment_derivatives(x,p):
    qp=qprime(x,p)
    if qp == 0: raise ValueError('Simple equilibrium branch required')
    dx=-p['r']*x*(1+p['alpha']*x)/(p['K']**2*qp)
    alpha=p['alpha'];K=p['K']
    dtrace=p['r']*alpha*x*x*(alpha*K+1)/(K*K*(alpha*K-1-2*alpha*x))
    return dx,dtrace


def exact_events():
    common=dict(a=2.,e=1.,d=1.,b=0.)
    return [
        ('P4_saddle_node',dict(common,r=8/25,K=8.,alpha=.5,c=2.),np.array([3.,1.5])),
        ('P4_subcritical_Hopf',dict(common,r=1.5,K=3.,alpha=.5,c=2/3),np.array([1.,1.5])),
        ('P4_Bogdanov_Takens',dict(common,r=16/25,K=8.,alpha=.5,c=1.),np.array([3.,3.])),
    ]


def main(root=None):
    from .core import jacobian as finite_jacobian
    from .controlled_extended import (derivative_tensors as series_tensors,
        lyapunov_from_tensors,scenarios,matched,RATIO,simulate)
    root=Path(root or Path(__file__).resolve().parents[1])
    for d in ['results','reports','logs','figures']:(root/d).mkdir(exist_ok=True)
    rng=np.random.default_rng(20261119)
    err_jac=err_B=err_C=err_trace=err_det=err_resid=err_dx=err_dt=err_dulac=0.
    nroots=nderiv=0;probes=[]
    for i in range(240):
        p=dict(r=float(rng.uniform(.2,2)),K=float(rng.uniform(2,20)),
               alpha=float(rng.uniform(0,.8)),a=float(rng.uniform(.1,4)),
               c=float(rng.uniform(.2,4)),e=float(rng.uniform(.2,1.4)),
               d=float(rng.uniform(.1,1)),model=RATIO,b=0.)
        z=rng.uniform(.3,8,2)
        J=jacobian(z,p);B,C=derivative_tensors(z,p)
        Js,Bs,Cs=series_tensors(z,p)
        err_jac=max(err_jac,float(np.max(np.abs(J-finite_jacobian(rhs,p,z)))))
        err_B=max(err_B,float(np.max(np.abs(B-Bs))))
        err_C=max(err_C,float(np.max(np.abs(C-Cs))))
        x,y=z;D=x+p['c']*y
        # Direct divergence from the quotient rule, versus simplified identity.
        F,G=rhs(z,p)
        direct=J[0,0]/(x*y)-F/(x*x*y)+J[1,1]/(x*y)-G/(x*y*y)
        reduced=qprime(x,p)/y+p['a']*(1-p['e']*p['c'])/D**2
        err_dulac=max(err_dulac,abs(direct-reduced))
        for j,eq in enumerate(equilibria(p)):
            nroots+=1;x,y=eq['x'],eq['y'];J=jacobian([x,y],p)
            err_resid=max(err_resid,eq['rhs_residual'])
            err_trace=max(err_trace,abs(np.trace(J)-eq['trace']))
            err_det=max(err_det,abs(np.linalg.det(J)-eq['determinant']))
            probes.append(dict(case=i,root=j,**{k:v for k,v in p.items() if k not in ['b','model']},**eq))
            if abs(eq['qprime'])>.05:
                step=1e-4*p['K'];sides=[]
                for sign in [-1,1]:
                    candidates=equilibria(dict(p,K=p['K']+sign*step))
                    sides.append(min(candidates,key=lambda w:abs(w['x']-x)))
                dx_fd=(sides[1]['x']-sides[0]['x'])/(2*step)
                dt_fd=(sides[1]['trace']-sides[0]['trace'])/(2*step)
                dx,dt=enrichment_derivatives(x,p)
                err_dx=max(err_dx,abs(dx-dx_fd)/(1+abs(dx)))
                err_dt=max(err_dt,abs(dt-dt_fd)/(1+abs(dt)))
                nderiv+=1
    checks=[]
    def check(name,cases,error,tol):
        checks.append(dict(check=name,cases=cases,max_error=error,tolerance=tol,passed=error<tol))
    check('ratio_jacobian_vs_centered_rhs',240,err_jac,1e-7)
    check('ratio_closed_Hessian_vs_independent_Taylor_series',240,err_B,1e-10)
    check('ratio_closed_third_derivatives_vs_independent_Taylor_series',240,err_C,1e-10)
    check('ratio_equilibria_original_rhs_substitution',nroots,err_resid,1e-9)
    check('ratio_equilibrium_trace_identity',nroots,err_trace,1e-10)
    check('ratio_equilibrium_determinant_identity',nroots,err_det,1e-9)
    check('ratio_Dulac_divergence_identity',240,err_dulac,1e-10)
    check('ratio_enrichment_x_derivative',nderiv,err_dx,2e-5)
    check('ratio_enrichment_trace_derivative',nderiv,err_dt,2e-5)
    eventrows=[]
    for name,p,z in exact_events():
        J=jacobian(z,p);B,C=derivative_tensors(z,p)
        row=dict(event=name,**p,x=z[0],y=z[1],residual=float(np.max(np.abs(rhs(z,p)))),
                 trace=float(np.trace(J)),determinant=float(np.linalg.det(J)))
        if 'saddle_node' in name:
            row.update(q_xx=qsecond(p),q_r=q(z[0],p)/p['r'],
                       classification='generic_saddle_node_in_r')
            check('ratio_exact_fold_conditions',1,max(row['residual'],abs(row['determinant']),
                abs(row['trace']+1/4),abs(row['q_xx']+1/25),abs(row['q_r']-25/16)),1e-12)
        elif 'Hopf' in name:
            omega=np.sqrt(np.linalg.det(J));S=np.array([[1.,0.],[1.,1/np.sqrt(2)]])
            Si=np.linalg.inv(S)
            l1=planar_hopf_l1(B,C,S,omega)
            bb=np.einsum('ia,ajk,jb,kc->ibc',Si,B,S,S)
            cc=np.einsum('ia,ajkl,jb,kc,ld->ibcd',Si,C,S,S,S)
            l1_complex=lyapunov_from_tensors(Si@J@S,bb,cc)
            derivative_K=enrichment_derivatives(z[0],p)[1]
            xp=-q(z[0],p)/(p['r']*qprime(z[0],p))
            derivative_r=z[0]*qprime(z[0],p)/p['r']+(qprime(z[0],p)+z[0]*qsecond(p))*xp
            row.update(omega=omega,l1_rotated=l1,l1_independent_complex=l1_complex,
                       trace_K=derivative_K,trace_r=derivative_r,
                       classification='generic_subcritical_Hopf')
            check('ratio_exact_Hopf_two_independent_l1_formulas',1,max(abs(l1-11*np.sqrt(2)/96),
                abs(l1-l1_complex),abs(row['trace']),abs(row['determinant']-1/8),
                abs(derivative_K+5/12),abs(derivative_r+19/6),row['residual']),1e-12)
        else:
            q0=np.array([1.,1.]);q1=np.array([0.,-2.]);p0=np.array([1.,0.]);p1=np.array([.5,-.5])
            B00=np.einsum('ijk,j,k->i',B,q0,q0);B01=np.einsum('ijk,j,k->i',B,q0,q1)
            aBT=.5*(p1@B00);bBT=p0@B00+p1@B01
            unfolding=np.array([[0.,25/16,1.],[-2/25,0.,0.],[-6/25,0.,-.5]])
            du=float(np.linalg.det(unfolding))
            row.update(a_BT=aBT,b_BT=bBT,unfolding_det_x_r_c=du,
                       classification='generic_BT_in_r_c')
            check('ratio_exact_BT_quadratic_and_unfolding',1,max(row['residual'],abs(aBT+3/50),
                abs(bBT+6/25),abs(du+1/16),np.max(abs(J@J)),np.max(abs(J@q1-q0)),
                np.max(abs(J.T@p0-p1))),1e-12)
        eventrows.append(row)
    branches=[]
    for base in scenarios():
        p=matched(base,RATIO)
        for K in np.linspace(.75,45,601):
            pk=dict(p,K=float(K))
            for j,eq in enumerate(equilibria(pk)):
                dx,dt=enrichment_derivatives(eq['x'],pk)
                branches.append(dict(scenario=p['scenario'],K=K,branch=j,**eq,
                                     x_K=dx,trace_K=dt,synthetic_or_real='synthetic_dimensionless'))
    bf=pd.DataFrame(branches)
    fig,axs=plt.subplots(2,2,figsize=(10.5,7.3),sharex='col')
    for j,scenario in enumerate(bf.scenario.unique()):
        b=bf[bf.scenario==scenario]
        for label,color in [('stable','#267c79'),('unstable','#b56643'),('saddle','#81778f')]:
            part=b[b.local_classification==label]
            axs[0,j].scatter(part.K,part.x,s=4,color=color,label=label)
            for _,branch_part in part.groupby('branch'):
                axs[1,j].plot(branch_part.K,branch_part.trace,color=color,lw=1.5)
        axs[1,j].axhline(0,color='#888888',lw=.8,ls='--')
        axs[0,j].set_title('A: moderate weak-Allee effect' if j==0 else 'B: stronger weak-Allee effect')
        axs[0,j].set_ylabel('Equilibrium prey density x*')
        axs[1,j].set_ylabel('Equilibrium trace');axs[1,j].set_xlabel('Carrying capacity K')
        axs[0,j].legend(frameon=False,fontsize=8)
    fig.suptitle('P4 ratio dependence: enrichment lowers trace on the nonsaddle branch')
    fig.tight_layout();fig.savefig(root/'figures/ratio_enrichment.png',dpi=190);plt.close(fig)
    # One direct counterexample to invasion-threshold-only permanence.
    p=dict(r=1.,K=8.,alpha=.5,a=.8,c=8/15,e=1.,d=.2,b=0.,model=RATIO,growth='weak_allee')
    trajectory=[];summaries=[]
    fig,ax=plt.subplots(1,2,figsize=(10.5,4.0))
    for label,z0,col in [('origin_basin',(0.005,.5),'#b56643'),('coexistence_basin',(5.8,30.),'#267c79')]:
        t,z,status=simulate(p,z0,T=400,dt=.5,rtol=1e-10,atol=1e-12,max_step=.4)
        t2,z2,status2=simulate(p,z0,T=400,dt=.5,rtol=2e-12,atol=2e-14,max_step=.2)
        audit=float(np.max(np.abs(z-z2)/(1+np.abs(z2))))
        summaries.append(dict(case=label,**p,x0=z0[0],y0=z0[1],x_final=z[-1,0],y_final=z[-1,1],
                              invasion_ea_over_d=4.,a_over_c=1.5,r_plus_d=1.2,
                              max_scaled_tighter_solver_difference=audit,finite_time_label=label,
                              mathematical_support='open origin basin proof or hyperbolic stable coexistence'))
        check('ratio_'+label+'_trajectory_tighter_solver',len(t),audit,1e-6)
        for ti,zz in zip(t,z):trajectory.append(dict(case=label,t=ti,x=zz[0],y=zz[1]))
        ax[0].plot(t,z[:,0],color=col,label=label.replace('_',' '))
        ax[1].plot(z[:,0],z[:,1],color=col,label=label.replace('_',' '))
    for eq in equilibria(p):ax[1].plot(eq['x'],eq['y'],'o',color='#202332' if eq['local_classification']=='stable' else '#81778f')
    ax[0].set_yscale('log');ax[0].set_xlabel('Time');ax[0].set_ylabel('Prey density x (log scale)')
    ax[0].set_ylim(1e-92,10);ax[0].set_yticks([1.,1e-20,1e-40,1e-60,1e-80])
    ax[1].set_xlabel('Prey density x');ax[1].set_ylabel('Predator density y')
    ax[0].legend(frameon=False,fontsize=8);ax[1].legend(frameon=False,fontsize=8)
    fig.suptitle('P4: coexistence and joint extinction can occur at the same parameters (ea/d = 4)')
    fig.tight_layout();fig.savefig(root/'figures/ratio_origin_and_coexistence.png',dpi=190);plt.close(fig)
    for filename,data in [('ratio_validation.csv',checks),('ratio_random_root_probes.csv',probes),
                          ('ratio_exact_bifurcations.csv',eventrows),('ratio_enrichment_branches.csv',branches),
                          ('ratio_origin_basin_runs.csv',summaries),('ratio_origin_basin_trajectories.csv',trajectory)]:
        pd.DataFrame(data).to_csv(root/'results'/filename,index=False)
    result=dict(audit_classes=len(checks),passed=int(sum(v['passed'] for v in checks)),random_cases=240,
                substituted_equilibria=nroots,enrichment_derivative_checks=nderiv,
                branch_rows=len(branches),trajectory_rows=len(trajectory),
                status='direct_derivations_and_independent_implementation_audits',
                remaining='full origin-boundary classification; all global cycles and homoclinic curves')
    (root/'logs/RATIO_ANALYSIS_STATUS.json').write_text(json.dumps(result,indent=2))
    print(json.dumps(result,indent=2))
    if not all(v['passed'] for v in checks):raise RuntimeError('P4 audit failed')


if __name__=='__main__':main()
