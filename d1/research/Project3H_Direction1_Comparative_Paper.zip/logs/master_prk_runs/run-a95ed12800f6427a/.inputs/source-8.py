"""Create five-model ecological parameter tables, bound comparison, and readable summary."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from .ecology_five_models import MODELS, MODEL_IDS, LOW, HIGH


def run(root):
    root=Path(root)
    summaries=[]; parameter_frames=[]
    for variant,prefix in [('Main bounds','five_ecology_'),('Wider bounds','five_ecology_wide_')]:
        summary=pd.read_csv(root/'results'/(prefix+'summary.csv'));summary['variant']=variant
        summary['rank']=summary.mean_fold_nrmse.rank(method='min').astype(int)
        base=float(summary[summary.model=='last_observation'].mean_fold_nrmse.iloc[0])
        summary['percent_lower_mean_nrmse_than_persistence']=100*(1-summary.mean_fold_nrmse/base)
        summaries.append(summary)
        f=pd.read_csv(root/'results'/(prefix+'fit_log.csv'))
        f=f[f.stage=='outer_refit'].copy();f['variant']=variant;f['model_id']=f.model.map(MODEL_IDS)
        parameter_frames.append(f)
    both=pd.concat(summaries,ignore_index=True)
    both.to_csv(root/'results/five_ecology_bound_comparison.csv',index=False)
    pd.concat(parameter_frames,ignore_index=True).to_csv(root/'results/five_ecology_outer_parameters.csv',index=False)
    rows=[]
    for name in MODELS:
        for p,u,status,meaning in [
            ('r','T^-1','fitted','prey low-density per-capita growth'),
            ('K','X','fitted','effective prey carrying capacity'),
            ('d','T^-1','fitted','predator loss without prey'),
            ('alpha','X^-1','fixed numerical control: 0.25','weak-Allee factor'),
            ('e','Y/X','fixed numerical control: 0.6','conversion in the scaled state coordinates')]:
            rows.append(dict(model=MODEL_IDS[name],model_name=name,parameter=p,units=u,status=status,meaning=meaning))
        rows.append(dict(model=MODEL_IDS[name],model_name=name,parameter='a',units='X/(Y*T)' if name=='Ratio_dependent' else '1/(Y*T)',status='fitted',meaning='attack coefficient for P0-P3; limiting per-predator intake for P4'))
        if name in ['Holling_II','Beddington_DeAngelis']: rows.append(dict(model=MODEL_IDS[name],model_name=name,parameter='b',units='X^-1',status='fitted',meaning='prey handling saturation coefficient'))
        if name in ['FA_original','Beddington_DeAngelis','Ratio_dependent']: rows.append(dict(model=MODEL_IDS[name],model_name=name,parameter='c',units='X/Y' if name=='Ratio_dependent' else 'Y^-1',status='fitted',meaning='predator-dependence denominator coefficient'))
    for p,u,meaning in [('m','T^-1','a/c'),('beta','Y','1/c')]: rows.append(dict(model='P0',model_name='FA_original',parameter=p,units=u,status='derived',meaning=meaning))
    pd.DataFrame(rows).to_csv(root/'results/five_ecology_parameter_units.csv',index=False)
    pd.DataFrame([dict(parameter=k,main_lower=LOW[k],main_upper=HIGH[k],wide_lower=LOW[k]/10,wide_upper=HIGH[k]*10) for k in LOW]).to_csv(root/'results/five_ecology_bounds.csv',index=False)
    names=MODELS+['last_observation']; labels=['P0: original FA','P1: mass action','P2: Holling II','P3: Beddington-DeAngelis','P4: ratio dependent','Last observation']
    fig,axs=plt.subplots(1,2,figsize=(12,5),sharey=True)
    colors=['#1d5879','#a34c3c']
    for ax,(variant,prefix),color in zip(axs,[('Main bounds','five_ecology_'),('Wider bounds','five_ecology_wide_')],colors):
        scores=pd.read_csv(root/'results'/(prefix+'scores.csv'))
        means=both[both.variant==variant].set_index('model')
        for i,name in enumerate(names):
            vals=scores[scores.model==name].test_nrmse.to_numpy()
            ax.scatter(vals,np.full(len(vals),i),s=25,alpha=.5,color=color)
            ax.scatter([means.loc[name,'mean_fold_nrmse']],[i],marker='D',s=65,edgecolor='white',linewidth=.8,color=color,zorder=4)
        ax.set(title=variant,xlabel='Held-experiment joint NRMSE (lower is better)',yticks=range(6),yticklabels=labels,xlim=(.6,1.65))
        ax.grid(axis='x',alpha=.2)
        ax.tick_params(axis='y',length=0)
    axs[0].invert_yaxis()
    fig.suptitle('Circles: four held experiments; diamonds: unweighted fold mean',fontsize=10)
    fig.tight_layout(rect=[0,0,1,.94]);fig.savefig(root/'figures/five_ecology_bound_comparison.png',dpi=200);plt.close(fig)
    table='| Model | Main bounds | Wider bounds |\n|---|---:|---:|\n'
    indexed=both.set_index(['variant','model'])
    for name,label in zip(names,labels):
        table+='| '+label+' | '+f"{indexed.loc[('Main bounds',name),'mean_fold_nrmse']:.7f}"+' | '+f"{indexed.loc[('Wider bounds',name),'mean_fold_nrmse']:.7f}"+' |\n'
    main_status=json.loads((root/'logs/FIVE_ECOLOGY_STATUS.json').read_text())
    wide_status=json.loads((root/'logs/FIVE_ECOLOGY_WIDE_STATUS.json').read_text())
    text='''# Five-model ecological comparison

## Finding

All five predation models improved the joint next-observation score over last observation in each of the four held experiments. The mechanism ranking changed when the parameter search bounds changed. P4 had the lowest mean score in the main search region; P0 had the lowest mean in the wider region. This provides a common prediction comparison for P0-P4 and shows that this small difference in ranking depends on the fitting specification.

'''+table+'''

These numbers are unweighted means of four whole-experiment test folds. The four experiments, rather than their 861 serially correlated intervals, are the experimental units. The score combines two population RMSE values after division by training-only standard deviations. Population-specific RMSE and MAE remain in the saved scores. Lower joint error does not imply that every population and loss function improves.

## Data, units, and parameter meaning

The observations come from the C1-C4 algae-rotifer chemostat experiments of Blasius et al. (2020), DOI https://doi.org/10.1038/s41586-019-1857-0 . Raw source data are Figshare version 1, https://doi.org/10.6084/m9.figshare.10045976.v1 , CC BY 4.0. Raw MD5 checksums and the complete source-to-analysis arrays were verified again. The 877 original records yield 865 positive complete observations and 861 successive retained intervals. No smoothing, interpolation, or imputation is used; actual elapsed times are retained.

Let X=10^6 algae cells/ml, Y=20 rotifers/ml, and T=one day. Source algae density already uses X, while source rotifer density is divided by 20. The predation law is axy/(1+bx+cy) for P0-P3 with the stated zero coefficients and axy/(x+cy) for P4. In P0-P3, a has units 1/(Y T), b has units 1/X, and c has units 1/Y. In P4, a has units X/(Y T), and c has units X/Y. The numerical bounds therefore refer to coefficients in these fixed scaled coordinates. They are computational controls, rather than shared biological priors. At reference prey x=1, the low-predator per-predator intake equals the numeric a for each response. Away from that reference, the response shapes differ.

All five models keep alpha=0.25 X^-1 and e=0.6 Y/X as numerical controls. These are not measured Allee effects or conversion efficiencies. r, K, d, a, and the applicable b/c coefficients are fitted effective parameters. Full outer-fold coefficients are in results/five_ecology_outer_parameters.csv; definitions and units are in results/five_ecology_parameter_units.csv. The original FA coefficients follow beta=1/c and m=a/c. No fitted value is asserted to come from Tanner's demographic table.

## Common train, validation, and test conditions

For each held experiment, the other three supply all fitting and initialization selection. In three inner folds, fit on two whole experiments and validate on the third. Select one of two fixed initializations by the unweighted mean inner-fold NRMSE. Refit that initialization on all three available experiments, and evaluate the untouched held experiment. The measured current state is used to predict the next observation; this task is distinct from an autonomous forecast initialized only at the first time point.

Each model receives the same split structure, two candidate starts, optimizer tolerances, seed 1107, and maximum of 40 least-squares evaluations per fit. There are 4-6 fitted coefficients, so equal evaluation caps do not mean identical floating-point cost. Actual residual calls, elapsed seconds, convergence messages, optimality, parameter values, and bound hits are retained. The main protocol reproduces the previous four-model benchmark exactly while adding P4. The wider protocol repeats the entire nested comparison with every fitted lower bound divided by 10 and every upper bound multiplied by 10. It keeps the fixed alpha and e, starts, splits, and evaluation limits. Both variants are reported; test outcomes were not used to select one variant for the primary table.

## Numerical and split verification

The two new nested runs together produced 280 optimizer fits, 240 inner-validation scores, 48 outer scores including the same baseline in each variant, 8,610 model/interval prediction records, and 310 sampled solver checks. All fits reported convergence. All 71 independent saved-record checks passed, including exclusion of test/validation experiments, training-only scale reconstruction, identical test records across five models, and initialization selection from inner folds alone. The prior four-model and baseline NRMSEs reproduce with a maximum discrepancy of zero.

Log-state RK4 uses a maximum step of 0.08 days. For each fitted outer model, sampled intervals include the endpoints, evenly spaced intervals, and the longest interval. DOP853 at rtol=1e-11, atol=1e-13 supplies an independent integration reference. The maximum training-scaled discrepancy is 1.3814e-5 in the main run and 2.4800e-5 in the wider run. Halving the RK4 step reduces these maxima to 9.6161e-7 and 1.6127e-6. All 310 sampled intervals improve at the smaller step. These checks validate sampled integration accuracy; the saved benchmark is still a finite-data model comparison.

## Mechanism interpretation and unexpected findings

In the main protocol, P4 beats P0 in C3 and C4, while P0 beats P4 in C1 and C2. P4's r reaches its upper bound 3 in all four main outer fits, and its a reaches 7 in three. P0 and P3 reach a=7 in all four. P2 and P3 set b to the lower bound 0.001 in all four, so P2 nearly reproduces P1 and P3 nearly reproduces P0. This weakens any interpretation that these data identify a nonzero prey-handling effect.

In the wider run, the outer fits have no upper-bound hits. Nevertheless, the relative mean-score order changes from P4/P0/P3 to P0/P3/P4. P2 still approaches its b=0 limit, and P3 reaches its new lower b bound in three folds. The main P4 advantage therefore does not persist across these two search regions. No unique biological feeding mechanism is identified by this short-step prediction experiment. In both variants, all five responses retain lower joint fold errors than the last-observation baseline.

These are reduced two-state models. Nutrient supply, dilution, life-stage structure, observation error, and stochastic forcing are not explicit states. The fixed alpha/e assumptions, effective parameters, limited four-experiment sample, and small difference between leading models determine the scope of the ecological interpretation. The result is useful evidence about predictive behavior under common conditions, alongside the analytical mechanism comparison.

## Ecological sources and Tanner mapping

references/ECOLOGY_LITERATURE_REVIEW.md reviews the checked primary sources. Tanner (1975), https://doi.org/10.2307/1936296 , motivates prey self-limitation and demographic-rate comparisons. Its full numerical table remains unavailable from the original text in this run. A maximum predator growth rate is not d, the predator death rate without prey. No seven-parameter FA calibration is inferred from the abstract or secondary table copies.

Skalski and Gilliam (2001), https://doi.org/10.1890/0012-9658(2001)082[3083:FRWPIV]2.0.CO;2 , report primary feeding-response comparisons across 19 systems and no universally best response. This supports a comparative design rather than an expectation that one response must win all ecological settings. The separately retained NPS Isle Royale annual abundance series is a different observation type and is not pooled with the chemostat records.

## Reproduction and evidence

Run `python -m src.ecology_five_models`, then `python -m src.ecology_five_validation`, then `python -m src.ecology_five_summary` from the project directory. The first command reruns both complete nested protocols. The second independently audits saved records, and the third recreates the parameter-unit/bound tables and comparison figure.

- results/five_ecology_*.csv: main-fold scores, predictions, inner validation, full fit log, split/source/solver audits, and summary.
- results/five_ecology_wide_*.csv: the same outputs for the full wider-bound sensitivity.
- results/five_ecology_bound_comparison.csv: both mean-score tables, ranks, and baseline-relative differences.
- results/five_ecology_outer_parameters.csv: all outer parameter estimates and diagnostics for both variants.
- results/five_ecology_bounds.csv and five_ecology_parameter_units.csv: numerical search bounds, definitions, and units.
- results/five_ecology_validation_checks.csv: 71 saved-record checks.
- figures/five_ecology_bound_comparison.png: four-fold scores and means under both parameter-search regions.
- logs/FIVE_ECOLOGY_PROTOCOL.json and FIVE_ECOLOGY_WIDE_PROTOCOL.json: complete settings.
- logs/FIVE_ECOLOGY_STATUS.json and FIVE_ECOLOGY_WIDE_STATUS.json: actual run counts, source hash, convergence, and elapsed time.
'''
    (root/'reports/FIVE_MODEL_ECOLOGY.md').write_text(text)
    return dict(main_elapsed_seconds=main_status['elapsed_seconds'],wide_elapsed_seconds=wide_status['elapsed_seconds'])


if __name__=='__main__': print(run(Path(__file__).resolve().parents[1]))
