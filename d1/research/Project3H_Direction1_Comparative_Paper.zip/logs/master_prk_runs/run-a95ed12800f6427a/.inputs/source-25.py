"""Scientific regression checks of exact comparative transition calculations."""
import contextlib,csv,io,tempfile,unittest
from pathlib import Path
from src.comparison_audit import c0_hopf
from src.bd_exact_examples import run as bd_run
from src.independent_ratio_review import run as ratio_review

class ComparisonAuditTests(unittest.TestCase):
    def test_logistic_mass_action_has_no_enrichment_hopf(self):
        self.assertIsNone(c0_hopf(r=1.,alpha=0.,b=0.,a=2.,e=1.,d=1.))

    def test_handling_alone_recovers_rosenzweig_transition(self):
        event=c0_hopf(r=1.,alpha=0.,b=.5,a=2.,e=1.,d=1.)
        self.assertGreater(event['K'],event['x'])
        self.assertLess(event['first_lyapunov_rotated'],0.)
        self.assertGreater(event['trace_K_derivative'],0.)

    def test_allee_without_handling_has_exact_threshold(self):
        event=c0_hopf(r=1.,alpha=.5,b=0.,a=2.,e=1.,d=1.)
        self.assertAlmostEqual(event['K'],3.)
        self.assertLess(event['first_lyapunov_rotated'],0.)

    def test_strict_bd_exact_nondegeneracy(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);(root/'results').mkdir()
            with contextlib.redirect_stdout(io.StringIO()):records=bd_run(root)
            self.assertEqual(len(records),3)
            self.assertTrue(all(float(r['parameters']['b'].split('/')[0])>0 for r in records))
            self.assertEqual(records[1]['l1_omega_coefficient'],'-10891/5000')
            self.assertEqual(records[2]['unfolding_det'],'569/14688')

    def test_ratio_independent_exact_review(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);(root/'results').mkdir()
            with contextlib.redirect_stdout(io.StringIO()):records=ratio_review(root)
            self.assertTrue(all(r['passed'] for r in records))
            self.assertEqual(records[1]['l1_omega_coefficient'],'11/24')

    def test_comparison_has_each_required_cell(self):
        root=Path(__file__).resolve().parents[1]
        with (root/'reports/COMPARISON_P0_P4.csv').open() as f:rows=list(csv.DictReader(f))
        self.assertEqual({(r['model_id'],int(r['question_id'])) for r in rows},{(f'P{m}',q) for m in range(5) for q in range(1,8)})
        self.assertTrue(all(r['mathematical_result'] and r['parameter_conditions'] and r['remaining_cases'] and r['evidence'] for r in rows))

if __name__=='__main__':unittest.main()
