"""Independent second-agent exact checks of the P4 normal forms and enrichment.
Uses rational automatic differentiation independent of ratio_analysis.py.
"""
from pathlib import Path
from fractions import Fraction as F
import itertools,json
import pandas as pd
from .bd_exact_examples import exact_tensors,quadratic_field_l1,det3


def run(root=None):
    root=Path(root or Path(__file__).resolve().parents[1]);out=[]
    cases=[('P4_SN',dict(r=F(8,25),K=F(8),alpha=F(1,2),a=F(2),c=F(2),b=F(0),e=F(1),d=F(1)),[F(3),F(3,2)]),('P4_Hopf',dict(r=F(3,2),K=F(3),alpha=F(1,2),a=F(2),c=F(2,3),b=F(0),e=F(1),d=F(1)),[F(1),F(3,2)]),('P4_BT',dict(r=F(16,25),K=F(8),alpha=F(1,2),a=F(2),c=F(1),b=F(0),e=F(1),d=F(1)),[F(3),F(3)])]
    for name,p,z in cases:
        x,y=z;q,qp,qpp,J,B,C=exact_tensors(p,z,ratio=True);tr=J[0][0]+J[1][1];det=J[0][0]*J[1][1]-J[0][1]*J[1][0]
        assert q==(p['a']-p['d']/p['e'])/p['c']
        row=dict(event=name,q=str(q),qprime=str(qp),trace=str(tr),determinant=str(det),jacobian=[[str(v) for v in rr] for rr in J])
        if name=='P4_SN':
            assert qp==0 and det==0 and tr==F(-1,4) and qpp==F(-1,25)
        elif name=='P4_Hopf':
            lf=quadratic_field_l1(J,B,C)
            assert tr==0 and det==F(1,8) and lf['l1_rational_part']=='0' and lf['l1_omega_coefficient']=='11/24'
            row.update(**lf)
            xr=-(q/p['r'])/qp;Tx=qp+x*qpp;Tr=x*qp/p['r'];slope=Tr+Tx*xr
            assert slope==F(-19,6)
            row['total_trace_r_derivative']=str(slope)
        else:
            assert tr==0 and det==0
            q0=[F(1),F(1)];q1=[F(0),F(-2)];p0=[F(1),F(0)];p1=[F(1,2),F(-1,2)]
            B00=[sum(B[i][j][k]*q0[j]*q0[k] for j,k in itertools.product(range(2),repeat=2)) for i in range(2)]
            B01=[sum(B[i][j][k]*q0[j]*q1[k] for j,k in itertools.product(range(2),repeat=2)) for i in range(2)]
            aa=sum(p1[i]*B00[i] for i in range(2))/2;bb=sum(p0[i]*B00[i]+p1[i]*B01[i] for i in range(2))
            assert aa==F(-3,50) and bb==F(-6,25)
            rankdet=det3([[F(0),F(25,16),F(1)],[F(-2,25),F(0),F(0)],[F(-6,25),F(0),F(-1,2)]])
            assert rankdet==F(-1,16)
            row.update(a_BT=str(aa),b_BT=str(bb),unfolding_det=str(rankdet))
        row['passed']=True;out.append(row)
    # Differentiate q(x,K)=Q and x*qprime independently using rational numbers.
    # Sample only falling roots, where qprime<0; no floating sign test is used.
    checked=0
    for K in range(2,12):
        for an in range(1,8):
            alpha=F(an,8);r=F(3,5)
            for xn in range(5,9):
                x=F(xn,10)*K;qp=r*(alpha-F(1,K)-2*alpha*x/K);qpp=-2*r*alpha/K
                if qp>=0:continue
                xK=-r*x*(1+alpha*x)/(K*K*qp)
                dT=(qp+x*qpp)*xK+r*x*(1+2*alpha*x)/(K*K)
                closed=r*alpha*x*x*(alpha*K+1)/(K*K*(alpha*K-1-2*alpha*x))
                assert dT==closed and dT<0 and xK>0
                checked+=1
    out.append(dict(event='P4_enrichment_derivative',rational_cases=checked,passed=True))
    (root/'results/comparison_P4_independent_exact.json').write_text(json.dumps(out,indent=2))
    print(json.dumps(out,indent=2));return out

if __name__=='__main__':run()
