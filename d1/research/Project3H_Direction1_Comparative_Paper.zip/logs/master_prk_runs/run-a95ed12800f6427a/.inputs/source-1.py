"""Strict Beddington-DeAngelis examples with exact rational nondegeneracy checks.
The b>0 denominator is retained, with no predator quadratic mortality.
"""
from fractions import Fraction as F
from pathlib import Path
import itertools, math, json
import numpy as np
import pandas as pd


def det3(m):
    return m[0][0]*(m[1][1]*m[2][2]-m[1][2]*m[2][1])-m[0][1]*(m[1][0]*m[2][2]-m[1][2]*m[2][0])+m[0][2]*(m[1][0]*m[2][1]-m[1][1]*m[2][0])


def exact_tensors(p,z,ratio=False):
    x,y=z;r,K,alpha,a,b,c,e,d=(p[k] for k in ['r','K','alpha','a','b','c','e','d'])
    D=x+c*y if ratio else 1+b*x+c*y;dx=F(1) if ratio else b;q=r*(1-x/K)*(1+alpha*x);qp=r*(alpha-1/K-2*alpha*x/K);qpp=-2*r*alpha/K
    inv={(i,n-i):F((-1)**n*math.comb(n,i))*dx**i*c**(n-i)/D**(n+1) for n in range(4) for i in range(n+1)}
    num={(0,0):a*x*y,(1,0):a*y,(0,1):a*x,(1,1):a}
    pred={(i,n-i):sum((v*inv.get((i-k,n-i-l),F(0)) for (k,l),v in num.items() if i>=k and n-i>=l),F(0)) for n in range(4) for i in range(n+1)}
    grow={0:x*q,1:q+x*qp,2:2*qp+x*qpp,3:3*qpp}
    deriv=[]
    for component in [0,1]:
        co={key:(-v if component==0 else e*v) for key,v in pred.items()}
        if component==0:
            for n in range(4):co[n,0]+=grow[n]/math.factorial(n)
        else:co[0,0]-=d*y;co[0,1]-=d
        deriv.append(co)
    J=[[deriv[i][int(j==0),int(j==1)] for j in range(2)] for i in range(2)]
    B=[[[deriv[i][int(j==0)+int(k==0),int(j==1)+int(k==1)]*math.factorial(int(j==0)+int(k==0))*math.factorial(int(j==1)+int(k==1)) for k in range(2)] for j in range(2)] for i in range(2)]
    C=[[[[deriv[i][int(j==0)+int(k==0)+int(l==0),int(j==1)+int(k==1)+int(l==1)]*math.factorial(int(j==0)+int(k==0)+int(l==0))*math.factorial(int(j==1)+int(k==1)+int(l==1)) for l in range(2)] for k in range(2)] for j in range(2)] for i in range(2)]
    return q,qp,qpp,J,B,C


def quadratic_field_l1(J,B,C):
    """Exact arithmetic in Q(omega), omega^2=det(J)>0.
    Pair (a,b) represents a+b*omega; no decimal reconstruction is used.
    """
    delta=J[0][0]*J[1][1]-J[0][1]*J[1][0]
    class Q:
        def __init__(self,a=0,b=0):self.a=F(a);self.b=F(b)
        def __add__(self,o):
            if not isinstance(o,Q):o=Q(o)
            return Q(self.a+o.a,self.b+o.b)
        __radd__=__add__
        def __neg__(self):return Q(-self.a,-self.b)
        def __sub__(self,o):return self+-o if isinstance(o,Q) else self+Q(-o)
        def __mul__(self,o):
            if not isinstance(o,Q):o=Q(o)
            return Q(self.a*o.a+self.b*o.b*delta,self.a*o.b+self.b*o.a)
        __rmul__=__mul__
        def __truediv__(self,o):
            if not isinstance(o,Q):o=Q(o)
            den=o.a*o.a-o.b*o.b*delta
            return self*Q(o.a/den,-o.b/den)
        def __rtruediv__(self,o):return Q(o)/self
        def __float__(self):return float(self.a)+float(self.b)*math.sqrt(float(delta))
    w=Q(0,1);S=[[Q(1),Q(0)],[Q(-J[0][0]/J[0][1]),-w/J[0][1]]]
    Si=[[Q(1),Q(0)],[-J[0][0]/w,-J[0][1]/w]]
    bt=[[[sum((Si[i][v]*B[v][j][k]*S[j][m]*S[k][n] for v,j,k in itertools.product(range(2),repeat=3)),Q()) for n in range(2)] for m in range(2)] for i in range(2)]
    ct=[[[[sum((Si[i][v]*C[v][j][k][l]*S[j][m]*S[k][n]*S[l][o] for v,j,k,l in itertools.product(range(2),repeat=4)),Q()) for o in range(2)] for n in range(2)] for m in range(2)] for i in range(2)]
    cub=ct[0][0][0][0]+ct[0][0][1][1]+ct[1][0][0][1]+ct[1][1][1][1]
    quad=bt[0][0][1]*(bt[0][0][0]+bt[0][1][1])-bt[1][0][1]*(bt[1][0][0]+bt[1][1][1])-bt[0][0][0]*bt[1][0][0]+bt[0][1][1]*bt[1][1][1]
    out=cub/(8*w)+quad/(8*delta)
    return dict(l1_rational_part=str(out.a),l1_omega_coefficient=str(out.b),l1=float(out),delta=str(delta))


def run(root=None):
    from .controlled_extended import rhs,jacobian,derivative_tensors
    from .analytic_checks import planar_hopf_l1
    root=Path(root or Path(__file__).resolve().parents[1]); rows=[];exact=[]
    cases=[('BD_saddle_node',dict(r=F(1),K=F(8),alpha=F(1,2),a=F(13,2),c=F(4),b=F(1,4),e=F(1),d=F(1)),[F(1),F(21,16)]),('BD_Hopf',dict(r=F(9,25),K=F(6),alpha=F(7,3),a=F(3),c=F(7,4),b=F(1,4),e=F(1),d=F(1)),[F(1),F(1)]),('BD_Bogdanov_Takens',dict(r=F(14,27),K=F(6),alpha=F(34,21),a=F(272,99),c=F(4,3),b=F(10,33),e=F(1),d=F(1)),[F(3,2),F(2)])]
    for name,p,z in cases:
        x,y=z;q,qp,qpp,J,B,C=exact_tensors(p,z);a,b,c=(p[k] for k in ['a','b','c'])
        tr=J[0][0]+J[1][1];det=J[0][0]*J[1][1]-J[0][1]*J[1][0]
        H=c*x*q-(a-b)*x+1;Hx=c*(q+x*qp)-(a-b);Hxx=c*(2*qp+x*qpp)
        assert H==0
        data=dict(event=name,parameters={k:str(v) for k,v in p.items()},x=str(x),y=str(y),H=str(H),Hx=str(Hx),Hxx=str(Hxx),trace=str(tr),determinant=str(det),jacobian=[[str(v) for v in rr] for rr in J])
        floatp={k:float(v) for k,v in p.items()};floatp.update(model='Beddington_DeAngelis',growth='weak_allee');Jf,Bf,Cf=derivative_tensors([float(x),float(y)],floatp)
        record=dict(event=name,**{k:float(v) for k,v in p.items()},x=float(x),y=float(y),trace=float(tr),determinant=float(det),equilibrium_residual=float(np.linalg.norm(rhs([float(x),float(y)],floatp),ord=np.inf)))
        if name=='BD_saddle_node':
            assert Hx==0 and det==0 and Hxx!=0 and tr!=0
            data.update(H_a=str(-x));record.update(Hxx=float(Hxx),H_a=-float(x),classification='nondegenerate_saddle_node_exact')
        elif name=='BD_Hopf':
            assert tr==0 and det>0
            xr=-(c*x*q/p['r'])/Hx
            Tx=qp+x*qpp+b*qp/a-1/(a*x*x)
            Tr=(x*qp+b*q/a)/p['r']
            slope=Tr+Tx*xr
            lf=quadratic_field_l1(J,B,C)
            assert slope!=0 and lf['l1']<0
            omega=math.sqrt(float(det));S=np.array([[1.,0.],[-float(J[0][0]/J[0][1]),-omega/float(J[0][1])]])
            check=planar_hopf_l1(Bf,Cf,S,omega)
            assert abs(check-lf['l1'])<1e-11
            data.update(total_trace_r_derivative=str(slope),coordinate_map='S=[[1,0],[-J11/J12,-omega/J12]]; original_displacement=S@(X,Y)',**lf)
            record.update(total_trace_r_derivative=float(slope),l1=lf['l1'],l1_float_tensor_error=abs(check-lf['l1']),classification='supercritical_Hopf_exact')
        else:
            assert tr==0 and det==0 and Hx==0
            q0=[F(1),-J[0][0]/J[0][1]];q1=[F(0),1/J[0][1]];p0=[F(1),F(0)];p1=J[0]
            B00=[sum(B[i][j][k]*q0[j]*q0[k] for j,k in itertools.product(range(2),repeat=2)) for i in range(2)]
            B01=[sum(B[i][j][k]*q0[j]*q1[k] for j,k in itertools.product(range(2),repeat=2)) for i in range(2)]
            aa=sum(p1[i]*B00[i] for i in range(2))/2;bb=sum(p0[i]*B00[i]+p1[i]*B01[i] for i in range(2))
            rank=[[Hx,-x,x*q],[Hxx,F(-1),q+x*qp],[qp+x*qpp+b*qp/a-1/(a*x*x),-(b*q+b+1/x)/(a*a),F(0)]]
            rankdet=det3(rank)
            assert aa!=0 and bb!=0 and rankdet!=0
            data.update(q0=[str(v) for v in q0],q1=[str(v) for v in q1],p0=[str(v) for v in p0],p1=[str(v) for v in p1],a_BT=str(aa),b_BT=str(bb),rank_matrix=[[str(v) for v in rr] for rr in rank],unfolding_det=str(rankdet),unfolding_variables='(x,a,c); b fixed')
            record.update(a_BT=float(aa),b_BT=float(bb),unfolding_det=float(rankdet),classification='generic_BT_exact_in_a_c_family')
        rows.append(record);exact.append(data)
    pd.DataFrame(rows).to_csv(root/'results/comparison_BD_exact_events.csv',index=False)
    (root/'results/comparison_BD_exact_rational.json').write_text(json.dumps(exact,indent=2))
    print(json.dumps(exact,indent=2));return exact

if __name__=='__main__':run()
