"""Independent saved-record audit for the five-response empirical experiments."""
from pathlib import Path
import json
import numpy as np
import pandas as pd


def run(root):
    root=Path(root); records=[]
    ids={'C1','C2','C3','C4'}
    models={'FA_original','LV_mass_action','Holling_II','Beddington_DeAngelis','Ratio_dependent'}
    for prefix in ['five_ecology_','five_ecology_wide_']:
        sc=pd.read_csv(root/'results'/(prefix+'scores.csv'))
        pred=pd.read_csv(root/'results'/(prefix+'predictions.csv'))
        fit=pd.read_csv(root/'results'/(prefix+'fit_log.csv'))
        val=pd.read_csv(root/'results'/(prefix+'inner_validation.csv'))
        sol=pd.read_csv(root/'results'/(prefix+'solver_audit.csv'))
        source=pd.read_csv(root/'results'/(prefix+'source_mapping_audit.csv'))
        def check(name, value, details):
            if not value: raise AssertionError(prefix+name+': '+details)
            records.append(dict(variant=prefix,check=name,passed=bool(value),details=details))
        check('complete_optimizer_counts',len(fit)==140 and len(val)==120 and len(sc)==24,'140 fits; 120 validation scores; 24 outer model/baseline scores')
        check('optimizer_budget',bool((fit.nfev<=40).all()),'All optimizer nfev within the shared 40-evaluation cap; convergence remains separately recorded')
        check('outer_training_excludes_test',all(set(r.training_experiments.split(';'))==ids-{r.held_experiment} for r in sc.itertuples()),'Exactly the other three experiments are used for each outer fold')
        check('inner_training_excludes_test_and_validation',all(set(r.training_experiments.split(';'))==ids-{r.outer_test,r.validation_experiment} for r in val.itertuples()),'Two whole training experiments; outer test and current inner validation excluded')
        for held in sorted(ids):
            observed={n:pd.read_csv(root/'data/real'/(n+'.csv')) for n in ids-{held}}
            raw_targets=np.concatenate([df[['prey_million_cells_per_ml','predator_20_animals_per_ml']].to_numpy()[1:] for df in observed.values()])
            expected=np.maximum(np.std(raw_targets,axis=0),.1)
            scores=sc[sc.held_experiment==held]
            check('training_only_scale_'+held,np.allclose(scores[['prey_training_scale','predator_training_scale']],expected,rtol=1e-13,atol=1e-13),'Scale recomputed independently from only the three training experiments')
            subsets=[pred[(pred.held_experiment==held)&(pred.model==m)].sort_values('pair_index') for m in sorted(models)]
            cols=['pair_index','input_time_days','target_time_days','dt_days','observed_x','observed_y','input_x','input_y']
            first=subsets[0][cols].to_numpy()
            check('identical_test_pairs_'+held,all(np.array_equal(s[cols].to_numpy(),first) for s in subsets[1:]),'Five models evaluated on precisely the same observed-state and target records')
            for model in models:
                scores_by_candidate=val[(val.outer_test==held)&(val.model==model)].groupby('candidate').test_nrmse.mean()
                expected_choice=int(scores_by_candidate.idxmin())
                actual=int(scores[scores.model==model].iloc[0].selected_initialization)
                check('inner_only_selection_'+held+'_'+model,actual==expected_choice,'Selected initialization is the minimum mean inner-fold NRMSE')
        check('all_sources_verified',bool(source.exact_processed_mapping_verified.all() and source.original_matches_figshare_md5.all()),'All raw MD5 and transformed arrays verified')
        check('finite_predictions',bool(np.isfinite(pred[['predicted_x','predicted_y']]).all().all()),'Finite saved predictions for all 4305 model/interval records')
        check('sampled_solver_accuracy',bool(sol.coarse_max_training_scaled.max()<1e-3),'Maximum sampled training-scaled discrepancy below 1e-3: '+str(sol.coarse_max_training_scaled.max()))
    # Legacy reproduction agreement is an exact numerical check on the original four models and baseline.
    old=pd.read_csv(root/'results/ecology_nested_scores.csv')
    fresh=pd.read_csv(root/'results/five_ecology_scores.csv')
    joined=fresh.merge(old,on=['held_experiment','model'],suffixes=('_fresh','_previous'))
    delta=float(abs(joined.test_nrmse_fresh-joined.test_nrmse_previous).max())
    if delta>1e-12: raise AssertionError('Legacy four-model scores did not reproduce')
    records.append(dict(variant='main_against_previous',check='legacy_reproduction',passed=True,details='Maximum NRMSE discrepancy: '+str(delta)))
    pd.DataFrame(records).to_csv(root/'results/five_ecology_validation_checks.csv',index=False)
    status=dict(checks=len(records),all_passed=True,legacy_max_nrmse_discrepancy=delta)
    (root/'logs/FIVE_ECOLOGY_VALIDATION.json').write_text(json.dumps(status,indent=2))
    return status


if __name__=='__main__': print(run(Path(__file__).resolve().parents[1]))
