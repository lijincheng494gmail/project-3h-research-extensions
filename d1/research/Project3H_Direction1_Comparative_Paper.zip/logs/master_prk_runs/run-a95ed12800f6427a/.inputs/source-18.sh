#!/usr/bin/env bash
# Cross-platform bash runner for macOS / Linux / WSL / Git Bash with Python 3.
set -euo pipefail
cd "$(dirname "$0")"
MODE="${1:-all}"
case "$MODE" in all|quick|full|tests|paper|verify|package) ;; *) echo 'Usage: bash run.sh [all|quick|full|tests|paper|verify|package]'; exit 2;; esac
PYTHON="${PYTHON:-python3}"
if ! "$PYTHON" -c 'import numpy, scipy, pandas, matplotlib' >/dev/null 2>&1; then
  echo '[setup] Creating local virtual environment and installing requirements.'
  "$PYTHON" -m venv .venv
  . .venv/bin/activate
  python -m pip install -r requirements.txt
  PYTHON=python
fi
mkdir -p logs
if [ "$MODE" = package ]; then "$PYTHON" package_results.py; exit 0; fi
if [ "$MODE" = paper ]; then "$PYTHON" build_paper.py; exit 0; fi
if [ "$MODE" = verify ]; then "$PYTHON" verify_master.py; exit 0; fi
if [ "$MODE" = tests ]; then "$PYTHON" run_master.py --stage all_tests; exit 0; fi
if [ "$MODE" = quick ] || [ "$MODE" = full ]; then
  "$PYTHON" run_experiment.py --mode "$MODE"
  exit 0
fi
"$PYTHON" run_research.py --stage baseline
"$PYTHON" run_research.py --stage controlled
"$PYTHON" run_research.py --stage ecology
"$PYTHON" run_research.py --stage analytic
"$PYTHON" run_master.py --stage ratio
"$PYTHON" run_master.py --stage five_ecology
"$PYTHON" run_master.py --stage comparison
"$PYTHON" run_master.py --stage periodic
"$PYTHON" run_master.py --stage independent
"$PYTHON" run_master.py --stage all_tests
"$PYTHON" build_paper.py
"$PYTHON" verify_master.py
"$PYTHON" package_results.py
echo '[done] Five-model paper and reproducible evidence ZIP in deliverables/'
