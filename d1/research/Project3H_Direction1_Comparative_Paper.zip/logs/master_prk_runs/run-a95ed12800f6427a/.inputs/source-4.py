"""Independent Radau/Liouville checks of three sampled P0 shooting orbits.

This module does not import the shooting solver, shared vector field, Jacobian,
or normal-form routines. It reads the saved orbit coordinates and directly
implements the original P0 equations and their divergence. In a planar
autonomous system, a nonstationary closed orbit has a neutral multiplier one;
Liouville's identity therefore recovers its transverse multiplier as the
exponential of the divergence integral over one period.

Run ``python -m src.periodic_independent_audit`` after periodic continuation.
"""
from pathlib import Path
import hashlib
import json
import numpy as np
import pandas as pd
from scipy.integrate import solve_ivp


def run(root=None):
    dest=Path(root or Path(__file__).resolve().parents[1])
    source=dest/'results/periodic_FA_continuation.csv'
    table=pd.read_csv(source)
    if len(table)!=19:
        raise ValueError('Expected the declared 19-row local continuation table')
    rows=[]
    for index in [0,9,18]:
        orbit=table.iloc[index]
        growth_rate=float(orbit.r)

        def augmented_original_equations(t,state):
            x,y,divergence_integral=state
            # Original course equation with m=2, beta=1, K=6,
            # alpha=7/3, conversion e=1, predator mortality d=1.
            growth=growth_rate*(1-x/6)*(1+7*x/3)
            growth_derivative=growth_rate*(7/3-1/6-7*x/9)
            consumption=2*x*y/(1+y)
            divergence=(growth+x*growth_derivative-2*y/(1+y)
                        +2*x/(1+y)**2-1)
            return np.array([x*growth-consumption,consumption-y,divergence])

        initial=np.array([float(orbit.x0),float(orbit.y0),0.])
        sol=solve_ivp(augmented_original_equations,(0.,float(orbit.period)),initial,
                     method='Radau',rtol=1e-11,atol=1e-13,max_step=.08)
        if not sol.success:
            raise RuntimeError(f'Independent Radau integration failed at row {index}: {sol.message}')
        closure=float(np.max(abs(sol.y[:2,-1]-initial[:2])))
        integral=float(sol.y[2,-1])
        multiplier=float(np.exp(integral))
        reported=float(orbit.transverse_floquet_multiplier)
        disagreement=abs(multiplier-reported)
        phase=abs(float(augmented_original_equations(0.,initial)[0]))
        independent_range=float(np.ptp(sol.y[0]))
        minimum_population=float(np.min(sol.y[:2]))
        passed=(closure<1e-9 and disagreement<1e-8 and phase<1e-9
                and 0<multiplier<1 and independent_range>1e-3 and minimum_population>0)
        rows.append(dict(continuation_row=index,amplitude_parameter=float(orbit.amplitude_parameter),
                         r=growth_rate,period=float(orbit.period),x0=initial[0],y0=initial[1],
                         independent_solver='Radau',rtol=1e-11,atol=1e-13,max_step=.08,
                         closure_inf=closure,phase_condition_abs=phase,
                         divergence_integral=integral,liouville_transverse_multiplier=multiplier,
                         reported_variational_multiplier=reported,multiplier_abs_difference=disagreement,
                         independent_prey_range=independent_range,
                         independent_minimum_population=minimum_population,
                         classification='numerically_stable_nontrivial_closed_orbit',passed=passed,
                         evidence_scope='three sampled orbits on one declared local branch'))
    (dest/'results').mkdir(exist_ok=True);(dest/'logs').mkdir(exist_ok=True)
    output=dest/'results/periodic_independent_audit.csv'
    pd.DataFrame(rows).to_csv(output,index=False)
    status=dict(checked_orbits=len(rows),passed=int(sum(row['passed'] for row in rows)),
                sampled_rows=[0,9,18],maximum_independent_closure=max(row['closure_inf'] for row in rows),
                maximum_multiplier_disagreement=max(row['multiplier_abs_difference'] for row in rows),
                source_table='results/periodic_FA_continuation.csv',
                source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
                code='src/periodic_independent_audit.py',
                code_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                output='results/periodic_independent_audit.csv',
                method='direct original P0 equations, independent Radau integration, Liouville divergence integral',
                scope='independent numerical verification of three sampled orbits; no global branch completeness claim')
    (dest/'logs/PERIODIC_INDEPENDENT_AUDIT.json').write_text(json.dumps(status,indent=2))
    print(json.dumps(status,indent=2))
    if not all(row['passed'] for row in rows):
        raise RuntimeError('An independent periodic-orbit check failed')
    return status


if __name__=='__main__':run()
