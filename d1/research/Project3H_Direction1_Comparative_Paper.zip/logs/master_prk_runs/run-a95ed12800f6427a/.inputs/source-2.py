"""Independent P4 Hopf audit using polynomial fits to original vector-field values.

This module does not use analytic_checks or ratio_analysis derivative routines.
Its local polynomial coefficients approximate derivatives from sampled original
ODE values, then the complex normal-form identity computes the coefficient.
"""
from pathlib import Path
import json
import math
import numpy as np
import pandas as pd


def run(root):
    root=Path(root);omega=math.sqrt(2)/4
    J=np.array([[0.,-omega],[omega,0.]])
    q=np.array([1.,-1j])/math.sqrt(2);p=q.copy()
    expected=11*math.sqrt(2)/96
    powers=[(i,j) for degree in range(8) for i in range(degree+1) for j in [degree-i]]
    points=np.array([(s,t) for s in np.linspace(-1,1,11) for t in np.linspace(-1,1,11)])
    V=np.array([[s**i*t**j for i,j in powers] for s,t in points])
    rows=[]
    for h in [.1,.05,.025,.0125]:
        uv=h*points
        x=1+uv[:,0];y=1.5+uv[:,0]+uv[:,1]/math.sqrt(2)
        # Exact original P4 field at the stated candidate; no helper import.
        loss=2*x*y/(x+(2/3)*y)
        dx=1.5*x*(1-x/3)*(1+.5*x)-loss
        dy=loss-y
        transformed=np.column_stack((dx,math.sqrt(2)*(dy-dx)))
        coeff=np.linalg.lstsq(V,transformed,rcond=None)[0]
        def deriv(output,i,j):
            return coeff[powers.index((i,j)),output]*math.factorial(i)*math.factorial(j)/h**(i+j)
        fittedJ=np.array([[deriv(i,1,0),deriv(i,0,1)] for i in range(2)])
        B=np.empty((2,2,2));C=np.empty((2,2,2,2))
        for output in range(2):
            for i in range(2):
                for j in range(2):
                    B[output,i,j]=deriv(output,2-i-j,i+j)
                    for k in range(2):C[output,i,j,k]=deriv(output,3-i-j-k,i+j+k)
        def bb(u,v):return np.einsum('ijk,j,k->i',B,u,v)
        cc=np.einsum('ijkl,j,k,l->i',C,q,q,np.conj(q))
        expression=cc-2*bb(q,np.linalg.solve(J,bb(q,np.conj(q))))+bb(np.conj(q),np.linalg.solve(2j*omega*np.eye(2)-J,bb(q,q)))
        estimate=float(np.vdot(p,expression).real/(2*omega))
        rows.append(dict(method='degree_7_local_polynomial_from_original_ODE_samples',sample_radius=h,points=len(points),jacobian_max_error=float(np.max(abs(fittedJ-J))),l1_estimate=estimate,exact_l1=expected,absolute_l1_error=abs(estimate-expected),verified_positive=estimate>0))
    def trace_on_branch(r,K):
        x=float(max(np.roots([-r*.5/K,r*(.5-1/K),r-1.5])))
        qprime=r*(.5-1/K-x/K)
        return x*qprime+.25
    for variable,base,exact in [('r',1.5,-19/6),('K',3.,-5/12)]:
        for h in [1e-4,5e-5]:
            lo=trace_on_branch(base-h,3.) if variable=='r' else trace_on_branch(1.5,base-h)
            hi=trace_on_branch(base+h,3.) if variable=='r' else trace_on_branch(1.5,base+h)
            estimated=(hi-lo)/(2*h)
            rows.append(dict(method='equilibrium_branch_finite_difference_'+variable,sample_radius=h,points=2,estimated_trace_derivative=estimated,exact_trace_derivative=exact,absolute_trace_derivative_error=abs(estimated-exact)))
    df=pd.DataFrame(rows);df.to_csv(root/'results/ratio_independent_hopf_audit.csv',index=False)
    l1ok=all(r['absolute_l1_error']<1e-6 and r['jacobian_max_error']<1e-8 and r['verified_positive'] for r in rows[:4])
    traceok=all(r['absolute_trace_derivative_error']<1e-5 for r in rows[4:])
    status=dict(all_passed=bool(l1ok and traceok),local_polynomial_checks=4,branch_derivative_checks=4,max_l1_error=max(r['absolute_l1_error'] for r in rows[:4]),coefficient_convention='rotated coordinates, q=p=(1,-i)/sqrt(2), no time rescaling')
    (root/'logs/RATIO_INDEPENDENT_HOPF_AUDIT.json').write_text(json.dumps(status,indent=2))
    if not status['all_passed']:raise AssertionError(status)
    return status


if __name__=='__main__':print(run(Path(__file__).resolve().parents[1]))
