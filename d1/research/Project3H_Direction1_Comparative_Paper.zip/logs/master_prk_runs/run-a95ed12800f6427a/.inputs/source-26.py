import unittest
import numpy as np
from src.ratio_analysis import (rhs,jacobian,equilibria,exact_events,
    enrichment_derivatives,derivative_tensors)
from src.analytic_checks import planar_hopf_l1


class RatioMathematics(unittest.TestCase):
    def test_two_roots_saddle_and_stable_with_origin_basin(self):
        p=dict(r=1.,K=8.,alpha=.5,a=.8,c=8/15,e=1.,d=.2)
        es=equilibria(p)
        np.testing.assert_allclose([v['x'] for v in es],[3-np.sqrt(7),3+np.sqrt(7)],atol=1e-12)
        self.assertEqual([v['local_classification'] for v in es],['saddle','stable'])
        for v in es:np.testing.assert_allclose(rhs([v['x'],v['y']],p),0,atol=1e-12)

    def test_exact_Hopf_sign_and_enrichment_direction(self):
        _,p,z=exact_events()[1]
        J=jacobian(z,p);B,C=derivative_tensors(z,p)
        S=np.array([[1.,0.],[1.,1/np.sqrt(2)]])
        self.assertAlmostEqual(planar_hopf_l1(B,C,S,np.sqrt(1/8)),11*np.sqrt(2)/96)
        self.assertAlmostEqual(enrichment_derivatives(1.,p)[1],-5/12)
        self.assertAlmostEqual(np.trace(J),0.)

    def test_ratio_origin_has_no_jacobian(self):
        _,p,_=exact_events()[0]
        np.testing.assert_array_equal(rhs([0,0],p),[0,0])
        with self.assertRaises(ValueError):jacobian([0,0],p)

    def test_no_positive_equilibrium_without_predator_invasion(self):
        _,p,_=exact_events()[0]
        self.assertEqual(equilibria(dict(p,a=.8)),[])


if __name__=='__main__':unittest.main()
