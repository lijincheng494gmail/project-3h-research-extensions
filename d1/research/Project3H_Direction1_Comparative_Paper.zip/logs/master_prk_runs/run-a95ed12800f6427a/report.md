# Local experiment receipt

Actual status: Process complete and output validation passed (succeeded)
Process exit code: 0; output validation: passed

allocated None, attempted None, completed None, valid None, scored None, failed None, denominator None. null means unknown.

Run: run-a95ed12800f6427a; approved plan: 1b80a8d9919ea5e5
Logs: 05_runs/run-a95ed12800f6427a/stdout.log / 05_runs/run-a95ed12800f6427a/stderr.log

Failure reason (original detail): No execution failure recorded
Resources are in resources.json; all attempts and partial outputs were retained.

Elapsed time 1.1035 seconds; logs and results 2239 bytes; peak memory was not measured.

- Controlled checks do not replace the host/OS sandbox; approved Python code has the current user permissions.
- network=deny is a policy, not OS network isolation. Read-only input copies do not constrain malicious code with the same permissions.
- Output limits are polled and can overshoot by one interval; memory/GPU usage has no hard cap.
- Process exit and output validation are engineering evidence, not certification of scientific conclusions.

Only the local runner was used; no cloud adapter was called. Researchers retain decisions about later experiments and scientific interpretation.
