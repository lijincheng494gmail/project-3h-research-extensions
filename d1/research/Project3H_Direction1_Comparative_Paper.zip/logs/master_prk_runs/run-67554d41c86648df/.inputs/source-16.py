import unittest
import numpy as np
from src.ecology_extended import DEFAULTS, predict, metrics, param_keys
from src.experiments import make, rhs, MODELS


class EcologyTests(unittest.TestCase):
    def test_small_step_matches_vector_field(self):
        x=np.array([[.8,1.1],[1.2,.4]])
        for name in MODELS:
            p=make(DEFAULTS,name)
            y=predict(x,np.full(2,1e-6),p)
            expected=np.stack([rhs(z,p) for z in x])
            np.testing.assert_allclose((y-x)/1e-6,expected,rtol=1e-5,atol=1e-5)

    def test_biological_units_restored(self):
        m=metrics(np.array([[1.,1.],[1.,1.]]),np.array([[2.,3.],[2.,3.]]),np.ones(2))
        self.assertAlmostEqual(m['prey_rmse_million_cells_per_ml'],1.)
        self.assertAlmostEqual(m['predator_rmse_animals_per_ml'],40.)
        self.assertAlmostEqual(m['test_nrmse'],1.5)

    def test_parameter_dimensions(self):
        self.assertEqual([len(param_keys(n)) for n in MODELS],[5,4,5,6])

    def test_invalid_sampling_interval_rejected(self):
        with self.assertRaises(ValueError):
            predict(np.array([[1.,1.]]),np.array([0.]),DEFAULTS)


if __name__=='__main__':
    unittest.main()
