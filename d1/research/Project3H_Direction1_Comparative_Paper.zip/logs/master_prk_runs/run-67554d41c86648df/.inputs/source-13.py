"""Algebraic checks for the four smooth predation laws; no simulated proof claims.

Run with ``python -m src.analytic_checks``. The parent orchestrator executes this
module under its recorded local experiment plan.
"""
from pathlib import Path
import csv
import numpy as np


def q(x, p):
    return p['r'] * (1-x/p['K']) * (1+p['alpha']*x)


def qprime(x, p):
    return p['r'] * (p['alpha'] - 1/p['K'] - 2*p['alpha']*x/p['K'])


def qsecond(p):
    return -2*p['r']*p['alpha']/p['K']


def polynomial(p):
    """Ascending coefficients of H=ce*x*q/d-(ea/d-b)*x+1."""
    C = p['c']*p['e']*p['r']/p['d']
    A = p['e']*p['a']/p['d'] - p['b']
    return np.array([1., C-A, C*(p['alpha']-1/p['K']),
                     -C*p['alpha']/p['K']])


def interior_equilibria(p):
    """All algebraic positive roots, filtered against the original equations.

    Repeated roots at an exact fold should be supplied by the event equations;
    floating point polynomial roots alone do not certify multiplicity.
    """
    A = p['e']*p['a']/p['d'] - p['b']
    if A <= 0 or A*p['K'] <= 1:
        return []
    if p['c'] == 0:
        x = 1/A
        return [np.array([x, p['e']*x*q(x,p)/p['d']])]
    coeff = np.trim_zeros(polynomial(p), 'b')
    found = []
    for z in np.polynomial.polynomial.polyroots(coeff):
        if abs(z.imag) > 1e-7 * (1+abs(z.real)):
            continue
        x = float(z.real)
        if not 1/A < x < p['K']:
            continue
        y = (A*x-1)/p['c']
        if y <= 0 or any(abs(x-w[0]) < 1e-7*(1+abs(x)) for w in found):
            continue
        found.append(np.array([x,y]))
    return sorted(found, key=lambda z:z[0])


def jacobian_analytic(z, p):
    """Full-state Jacobian, valid off equilibrium too."""
    x,y = z
    D = 1+p['b']*x+p['c']*y
    Px = p['a']*y*(1+p['c']*y)/D**2
    Py = p['a']*x*(1+p['b']*x)/D**2
    return np.array([[q(x,p)+x*qprime(x,p)-Px, -Py],
                     [p['e']*Px, p['e']*Py-p['d']]])


def axial_lyapunov_derivative(z, p):
    x,y = z
    D=1+p['b']*x+p['c']*y
    return (p['e']/(1+p['b']*p['K'])*(x-p['K'])*q(x,p)
            +y*(p['e']*p['a']*p['K']*(1+p['b']*x)
                  /((1+p['b']*p['K'])*D)-p['d']))


def fa_derivative_tensors(z,p):
    """Second/third derivative tensors of the FA vector field, in original states."""
    if p['b'] != 0:
        raise ValueError('FA derivative tensors require b=0')
    x,y=z;D=1+p['c']*y
    Pxy=p['a']/D**2
    Pyy=-2*p['a']*p['c']*x/D**3
    Pxyy=-2*p['a']*p['c']/D**3
    Pyyy=6*p['a']*p['c']**2*x/D**4
    B=np.zeros((2,2,2));C=np.zeros((2,2,2,2))
    B[0,0,0]=2*qprime(x,p)+x*qsecond(p)
    B[0,0,1]=B[0,1,0]=-Pxy;B[0,1,1]=-Pyy
    B[1,0,1]=B[1,1,0]=p['e']*Pxy;B[1,1,1]=p['e']*Pyy
    C[0,0,0,0]=3*qsecond(p)
    for inds in [(0,1,1),(1,0,1),(1,1,0)]:
        C[(0,)+inds]=-Pxyy;C[(1,)+inds]=p['e']*Pxyy
    C[0,1,1,1]=-Pyyy;C[1,1,1,1]=p['e']*Pyyy
    return B,C


def planar_hopf_l1(B,C,S,omega):
    """Kuznetsov planar convention, q=p=(1,-i)/sqrt(2), rotated coordinates.

    Original displacement is S @ (X,Y); S^-1 J S must equal
    [[0,-omega],[omega,0]]. This normalization fixes the reported coefficient.
    """
    Si=np.linalg.inv(S)
    b=np.einsum('ia,ajk,jb,kc->ibc',Si,B,S,S)
    c=np.einsum('ia,ajkl,jb,kc,ld->ibcd',Si,C,S,S,S)
    cubic=c[0,0,0,0]+c[0,0,1,1]+c[1,0,0,1]+c[1,1,1,1]
    quadratic=(b[0,0,1]*(b[0,0,0]+b[0,1,1])
               -b[1,0,1]*(b[1,0,0]+b[1,1,1])
               -b[0,0,0]*b[1,0,0]+b[0,1,1]*b[1,1,1])
    return cubic/(8*omega)+quadratic/(8*omega**2)


def main(root=None):
    from .experiments import rhs, make, MODELS
    from .core import jacobian
    root=Path(root or Path(__file__).resolve().parents[1])
    rows=[]
    rng=np.random.default_rng(20261118)
    max_jerr=0.; max_rootres=0.; max_deterr=0.; max_vdiff=0.
    nroots=0
    for i in range(80):
        base=dict(r=float(rng.uniform(.2,2)), K=float(rng.uniform(3,15)),
                  alpha=float(rng.uniform(0,.8)), a=float(rng.uniform(.1,4)),
                  e=float(rng.uniform(.2,1.2)), d=float(rng.uniform(.1,1.2)),
                  b=float(rng.uniform(0,.5)),c=float(rng.uniform(.01,3)))
        for name in MODELS:
            p=make(base,name)
            z=rng.uniform(.2,6,2)
            err=float(np.max(np.abs(jacobian_analytic(z,p)-jacobian(rhs,p,z))))
            max_jerr=max(max_jerr,err)
            x,y=z
            grad=np.array([p['e']/(1+p['b']*p['K'])*(1-p['K']/x),1.])
            vdiff=abs(float(grad@rhs(z,p))-axial_lyapunov_derivative(z,p))
            max_vdiff=max(max_vdiff,vdiff)
            for eq in interior_equilibria(p):
                nroots+=1
                res=float(np.linalg.norm(rhs(eq,p),ord=np.inf))
                max_rootres=max(max_rootres,res)
                x,y=eq;D=1+p['b']*x+p['c']*y
                hp=np.polynomial.polynomial.polyval(x,np.polynomial.polynomial.polyder(polynomial(p)))
                predicted=-p['d']*q(x,p)*x*hp/D
                max_deterr=max(max_deterr,abs(float(np.linalg.det(jacobian_analytic(eq,p)))-predicted))
    rows.extend([
        dict(check='full_jacobian_vs_centered_difference', cases=320, max_error=max_jerr,
             tolerance=2e-7, passed=max_jerr<2e-7),
        dict(check='polynomial_roots_original_rhs_residual',cases=nroots,max_error=max_rootres,
             tolerance=1e-8,passed=max_rootres<1e-8),
        dict(check='equilibrium_determinant_H_derivative_identity',cases=nroots,max_error=max_deterr,
             tolerance=1e-8,passed=max_deterr<1e-8),
        dict(check='axial_lyapunov_derivative_identity',cases=320,max_error=max_vdiff,
             tolerance=1e-9,passed=max_vdiff<1e-9),
    ])
    p=dict(r=1.,K=8.,alpha=.5,a=4.5,e=1.,d=1.,b=0.,c=8/3)
    roots=interior_equilibria(p)
    error=float(np.max(np.abs(np.array(roots)-np.array([[1,21/16],[2,3],[3,75/16]]))))
    rows.append(dict(check='exact_FA_three_positive_equilibria',cases=3,max_error=error,
                     tolerance=1e-10,passed=error<1e-10))
    events=[]
    sn=dict(r=1.,K=8.,alpha=.5,a=25/4,e=1.,d=1.,b=0.,c=4.)
    zsn=np.array([1.,21/16]);jsn=jacobian_analytic(zsn,sn)
    coeff=polynomial(sn)
    events.append(dict(event='FA_saddle_node_exact',x=zsn[0],y=zsn[1],r=sn['r'],
                       K=sn['K'],alpha=sn['alpha'],a=sn['a'],c=sn['c'],e=1.,d=1.,
                       residual=float(np.max(np.abs(rhs(zsn,sn)))),trace=float(np.trace(jsn)),
                       determinant=float(np.linalg.det(jsn)),nondegeneracy_1=1.5,
                       nondegeneracy_2=-1.,coefficient_definition='H_xx; H_a',
                       transversality=-1.,classification='generic_saddle_node'))
    snerr=max(abs(float(np.linalg.det(jsn))),abs(float(np.trace(jsn))+59/100),
              abs(np.polynomial.polynomial.polyval(1,np.polynomial.polynomial.polyder(coeff,2))-1.5))
    rows.append(dict(check='exact_FA_saddle_node_nondegeneracy',cases=1,max_error=snerr,
                     tolerance=1e-10,passed=snerr<1e-10))
    hp=dict(r=9/25,K=6.,alpha=7/3,a=2.,e=1.,d=1.,b=0.,c=1.)
    zhp=np.array([1.,1.]);jhp=jacobian_analytic(zhp,hp)
    B,C=fa_derivative_tensors(zhp,hp)
    S=np.array([[1.,0.],[1.,1.]])
    l1=planar_hopf_l1(B,C,S,.5)
    herr=max(abs(l1+579/5000),float(np.max(np.abs(np.linalg.inv(S)@jhp@S-np.array([[0,-.5],[.5,0]])))))
    rows.append(dict(check='exact_FA_Hopf_Kuznetsov_l1_and_rotation',cases=1,max_error=herr,
                     tolerance=1e-10,passed=herr<1e-10))
    events.append(dict(event='FA_Hopf_exact',x=1.,y=1.,r=hp['r'],K=6.,alpha=hp['alpha'],
                       a=2.,c=1.,e=1.,d=1.,residual=float(np.max(np.abs(rhs(zhp,hp)))),
                       trace=float(np.trace(jhp)),determinant=float(np.linalg.det(jhp)),
                       nondegeneracy_1=l1,nondegeneracy_2=-1/6,
                       coefficient_definition='Kuznetsov l1; total d(trace)/dr',
                       transversality=-1/6,classification='generic_supercritical_Hopf'))
    bt=dict(r=8/27,K=6.,alpha=10/3,a=2.,e=1.,d=1.,b=0.,c=1.)
    zbt=np.array([1.5,2.]);jbt=jacobian_analytic(zbt,bt);B,C=fa_derivative_tensors(zbt,bt)
    q0=np.array([1.,2.]);q1=np.array([0.,-3.]);p0=np.array([1.,0.]);p1=np.array([2/3,-1/3])
    B00=np.einsum('ijk,j,k->i',B,q0,q0);B01=np.einsum('ijk,j,k->i',B,q0,q1)
    abt=.5*(p1@B00);bbt=p0@B00+p1@B01
    unfold=np.array([[0.,-1.5,2.],[32/81,-1.,2.],[-22/81,-1/6,0.]])
    detunfold=float(np.linalg.det(unfold))
    bterr=max(abs(abt-32/243),abs(bbt+22/81),abs(detunfold-34/243),
              float(np.max(np.abs(jbt@jbt))),float(np.max(np.abs(jbt@q1-q0))))
    rows.append(dict(check='exact_FA_BT_quadratic_and_unfolding_nondegeneracy',cases=1,
                     max_error=bterr,tolerance=1e-10,passed=bterr<1e-10))
    events.append(dict(event='FA_Bogdanov_Takens_exact',x=1.5,y=2.,r=bt['r'],K=6.,alpha=bt['alpha'],
                       a=2.,c=1.,e=1.,d=1.,residual=float(np.max(np.abs(rhs(zbt,bt)))),
                       trace=float(np.trace(jbt)),determinant=float(np.linalg.det(jbt)),
                       nondegeneracy_1=abt,nondegeneracy_2=bbt,
                       coefficient_definition='a_BT; b_BT',transversality=detunfold,
                       classification='generic_Bogdanov_Takens_in_a_c_family'))
    (root/'results').mkdir(exist_ok=True)
    with (root/'results/analytic_validation.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    with (root/'results/exact_FA_bifurcations.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(events[0]));w.writeheader();w.writerows(events)
    exact=[]
    for j,eq in enumerate(roots):
        J=jacobian_analytic(eq,p);ev=np.linalg.eigvals(J)
        exact.append(dict(model='FA_original',x=eq[0],y=eq[1],trace=float(np.trace(J)),
                          determinant=float(np.linalg.det(J)),
                          stability='saddle' if np.linalg.det(J)<0 else 'asymptotically_stable',
                          eig1_real=float(ev[0].real),eig2_real=float(ev[1].real)))
    with (root/'results/exact_FA_multistability.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(exact[0]));w.writeheader();w.writerows(exact)
    print('Analytic identity checks:',len(rows),'passed:',sum(r['passed'] for r in rows),flush=True)
    if not all(r['passed'] for r in rows):
        raise RuntimeError('An algebraic implementation check failed')


if __name__=='__main__':
    main()
