"""Amplitude continuation of periodic orbits near the exact FA Hopf.

Shooting solves the original equations, not an amplitude normal form. The
amplitude parameter fixes x(0)-x_equilibrium(r); a prey turning point fixes
phase. A separate finer integration validates closure and Floquet multipliers.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from scipy.integrate import solve_ivp
from scipy.optimize import root
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from .controlled_extended import rhs, jacobian, all_equilibria

BASE=dict(model='FA_original',growth='weak_allee',r=.36,K=6.,alpha=7/3,
          a=2.,c=1.,b=0.,e=1.,d=1.)

def equilibrium(r):
    ee=all_equilibria(dict(BASE,r=r))
    return np.array([ee[0]['x'],ee[0]['y']])

def solve_orbit(amp,guess):
    def residual(v):
        y0,T,r=v
        if min(y0,T,r)<=0 or r>.5 or T>60:
            return np.array([10+abs(y0),10+abs(T),10+abs(r)])
        p=dict(BASE,r=r); z0=np.array([equilibrium(r)[0]+amp,y0])
        sol=solve_ivp(lambda t,z:rhs(z,p),(0,T),z0,method='DOP853',
                      rtol=2e-11,atol=2e-13,max_step=.2)
        return np.r_[sol.y[:,-1]-z0,rhs(z0,p)[0]]
    out=root(residual,guess,tol=2e-9)
    error=np.max(abs(residual(out.x)))
    if not out.success and error>1e-9:
        raise RuntimeError((amp,out.message,error))
    if error>1e-8: raise RuntimeError(('shooting residual',amp,error))
    return out.x,error,int(out.nfev)

def validate(v,amp):
    y0,T,r=v;p=dict(BASE,r=r);eq=equilibrium(r)
    z0=np.array([eq[0]+amp,y0]);u0=np.r_[z0,np.eye(2).ravel()]
    def augmented(t,u):
        z=u[:2];M=u[2:].reshape(2,2)
        return np.r_[rhs(z,p),(jacobian(z,p)@M).ravel()]
    sol=solve_ivp(augmented,(0,T),u0,method='DOP853',rtol=2e-12,atol=2e-14,
                  max_step=.08,t_eval=np.linspace(0,T,401))
    zz=sol.y[:2].T;M=sol.y[2:,-1].reshape(2,2);mult=np.linalg.eigvals(M)
    neutral=int(np.argmin(abs(mult-1)));transverse=float(mult[1-neutral].real)
    record=dict(amplitude_parameter=amp,r=r,period=T,x0=z0[0],y0=y0,
                equilibrium_x=eq[0],equilibrium_y=eq[1],
                prey_min=float(zz[:,0].min()),prey_max=float(zz[:,0].max()),
                predator_min=float(zz[:,1].min()),predator_max=float(zz[:,1].max()),
                fine_closure_inf=float(np.max(abs(zz[-1]-z0))),
                neutral_floquet_error=float(abs(mult[neutral]-1)),
                transverse_floquet_multiplier=transverse,
                stability='stable' if abs(transverse)<1 else 'unstable',
                evidence='numerical_periodic_shooting_with_fine_variational_check')
    return record,sol.t,zz

def run(rootdir=None):
    dest=Path(rootdir or Path(__file__).resolve().parents[1]);rows=[];trajectories=[]
    guess=[1.01,4*np.pi,.36-.3474*.01**2]
    amps=np.r_[.01,.02,.04,.06,.08,.1,np.linspace(.15,.75,13)]
    last_amp=.01;last_v=np.array(guess)
    for amp in amps:
        guess=last_v.copy()
        if amp!=.01:
            guess[2]=last_v[2]-.3474*(amp**2-last_amp**2)
            guess[0]+=amp-last_amp
        v,error,nfev=solve_orbit(float(amp),guess)
        record,t,z=validate(v,float(amp))
        record.update(shooting_residual_inf=error,root_function_evaluations=nfev)
        rows.append(record)
        trajectories.extend(dict(amplitude_parameter=amp,r=v[2],t=tt,x=xx,y=yy)
                            for tt,(xx,yy) in zip(t,z))
        last_v=v;last_amp=amp
    df=pd.DataFrame(rows);df.to_csv(dest/'results/periodic_FA_continuation.csv',index=False)
    pd.DataFrame(trajectories).to_csv(dest/'results/periodic_FA_trajectories.csv',index=False)
    assert len(df)==19 and (df.stability=='stable').all()
    assert df.fine_closure_inf.max()<1e-7 and df.neutral_floquet_error.max()<1e-6
    fig,ax=plt.subplots(1,3,figsize=(11.4,3.2))
    ax[0].plot(df.r,df.prey_min,'-',color='#247d86',label='Periodic minimum / maximum')
    ax[0].plot(df.r,df.prey_max,'-',color='#247d86')
    ax[0].plot(df.r,df.equilibrium_x,'--',color='#9b4858',label='Unstable coexistence')
    ax[0].plot([.36],[1.],'o',color='#24243b',label='Exact Hopf')
    ax[0].set(xlabel='Prey growth rate r',ylabel='Prey density',title='A  Periodic shooting continuation')
    ax[0].legend(fontsize=7)
    for idx in [4,10,18]:
        dd=pd.DataFrame(trajectories);dd=dd[np.isclose(dd.amplitude_parameter,amps[idx])]
        ax[1].plot(dd.x,dd.y,label=f'r={df.r.iloc[idx]:.4f}')
    ax[1].set(xlabel='Prey x',ylabel='Predator y',title='B  Closed orbits');ax[1].legend(fontsize=8)
    ax[2].plot(df.r,df.transverse_floquet_multiplier,'o-',color='#247d86',markersize=3)
    ax[2].axhline(1,color='gray',ls='--',lw=.7)
    ax[2].set(xlabel='Prey growth rate r',ylabel='Transverse Floquet multiplier',title='C  Numerical orbital stability')
    fig.tight_layout();fig.savefig(dest/'figures/periodic_FA_continuation.png',dpi=210);plt.close(fig)
    status=dict(orbits=len(df),maximum_fine_closure=float(df.fine_closure_inf.max()),
                maximum_neutral_multiplier_error=float(df.neutral_floquet_error.max()),
                r_range=[float(df.r.min()),float(df.r.max())],
                method='amplitude-parameter shooting continuation with phase condition; independent finer variational integration',
                scope='one local stable branch; no uniqueness or homoclinic termination claim')
    (dest/'logs/PERIODIC_CONTINUATION.json').write_text(json.dumps(status,indent=2))
    print(json.dumps(status))

if __name__=='__main__':run()
