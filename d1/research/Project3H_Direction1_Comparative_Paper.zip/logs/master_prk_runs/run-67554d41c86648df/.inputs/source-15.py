"""Independent ODE and unit checks for the five-model empirical benchmark."""
import unittest
import numpy as np
from scipy.integrate import solve_ivp
from src.ecology_five_models import MODELS, DEFAULTS, make, rhs, predict, param_keys, metrics
from src.ecology_extended import predict as inherited_predict
from src.experiments import make as inherited_make


class FiveEcologyTests(unittest.TestCase):
    def test_original_four_predictions_preserved(self):
        observed=np.array([[.43,.72],[1.17,.23],[2.1,1.8]])
        dt=np.array([.15,.7,1.2])
        for name in MODELS[:4]:
            np.testing.assert_array_equal(predict(observed,dt,make(DEFAULTS,name)),
                                          inherited_predict(observed,dt,inherited_make(DEFAULTS,name)))

    def test_five_integrators_against_direct_original_equations(self):
        # Independent state-space DOP853: no log-coordinate RHS or shared denominator helper.
        initial=np.array([[.7,.8],[1.3,.2]])
        intervals=np.array([.6,1.8])
        for name in MODELS:
            p=make(DEFAULTS,name)
            pred=predict(initial,intervals,p,step=.02)
            def independent(t,z):
                x,y=z
                if name=='FA_original': loss=p['a']*x*y/(1+p['c']*y)
                elif name=='LV_mass_action': loss=p['a']*x*y
                elif name=='Holling_II': loss=p['a']*x*y/(1+p['b']*x)
                elif name=='Beddington_DeAngelis': loss=p['a']*x*y/(1+p['b']*x+p['c']*y)
                else: loss=p['a']*x*y/(x+p['c']*y)
                return [p['r']*x*(1-x/p['K'])*(1+p['alpha']*x)-loss,p['e']*loss-p['d']*y]
            truth=np.stack([solve_ivp(independent,(0,t),z,rtol=1e-12,atol=1e-13,method='DOP853').y[:,-1]
                            for z,t in zip(initial,intervals)])
            np.testing.assert_allclose(pred,truth,rtol=2e-8,atol=1e-10)

    def test_ratio_total_intake_is_degree_one(self):
        p=make(DEFAULTS,'Ratio_dependent')
        # Homogeneity of total predation is characteristic of the stated P4 law.
        def intake(z):
            return (rhs(z,p)[1]+p['d']*z[1])/p['e']
        z=np.array([.73,1.32])
        self.assertAlmostEqual(intake(3.7*z),3.7*intake(z),places=12)

    def test_actual_dimensions_and_metric_units(self):
        self.assertEqual([len(param_keys(name)) for name in MODELS],[5,4,5,6,5])
        score=metrics(np.ones((2,2)),np.array([[2.,3.],[2.,3.]]),np.ones(2))
        self.assertAlmostEqual(score['predator_rmse_animals_per_ml'],40.)
        self.assertAlmostEqual(score['test_nrmse'],1.5)


if __name__=='__main__': unittest.main()
