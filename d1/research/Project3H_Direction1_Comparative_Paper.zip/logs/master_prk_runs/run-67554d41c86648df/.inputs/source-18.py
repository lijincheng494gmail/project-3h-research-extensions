import unittest
import numpy as np
from src.analytic_checks import interior_equilibria, jacobian_analytic, axial_lyapunov_derivative
from src.experiments import rhs,make,MODELS


class AnalyticTests(unittest.TestCase):
    def test_exact_three_root_FA_example(self):
        p=dict(r=1.,K=8.,alpha=.5,a=4.5,e=1.,d=1.,b=0.,c=8/3)
        roots=interior_equilibria(p)
        np.testing.assert_allclose(roots,[[1,21/16],[2,3],[3,75/16]],atol=1e-11)
        self.assertGreater(np.linalg.det(jacobian_analytic(roots[0],p)),0)
        self.assertLess(np.trace(jacobian_analytic(roots[0],p)),0)
        self.assertLess(np.linalg.det(jacobian_analytic(roots[1],p)),0)
        self.assertGreater(np.linalg.det(jacobian_analytic(roots[2],p)),0)
        self.assertLess(np.trace(jacobian_analytic(roots[2],p)),0)

    def test_no_interior_below_invasion_threshold(self):
        for name in MODELS:
            p=make(dict(r=1.,K=8.,alpha=.5,a=.1,e=1.,d=1.,b=.2,c=2.),name)
            self.assertEqual(interior_equilibria(p),[])

    def test_lyapunov_identity_above_and_below_K(self):
        for name in MODELS:
            p=make(dict(r=1.,K=8.,alpha=.5,a=.1,e=1.,d=1.,b=.2,c=2.),name)
            for x,y in [(1.,.3),(8.,2.),(12.,.3)]:
                grad=np.array([p['e']/(1+p['b']*p['K'])*(1-p['K']/x),1.])
                self.assertAlmostEqual(float(grad@rhs([x,y],p)),axial_lyapunov_derivative([x,y],p))
                self.assertLessEqual(axial_lyapunov_derivative([x,y],p),0)

