from pathlib import Path
import argparse
from src.core import outdirs
from src.experiments import run
if __name__=='__main__':
  a=argparse.ArgumentParser();a.add_argument('--mode',choices=['quick','full'],default='quick');p=a.parse_args()
  root=Path(__file__).resolve().parent;outdirs(root);run(root,p.mode)
