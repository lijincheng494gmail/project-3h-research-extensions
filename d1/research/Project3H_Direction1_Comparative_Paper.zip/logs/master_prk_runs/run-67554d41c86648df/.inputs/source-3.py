"""Direction 1: fixed prey growth, alternative functional responses.
Real chemostat observations are deliberately a secondary empirical check.
"""
from __future__ import annotations
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.optimize import least_squares
from .core import integrate,eq_table,end_label,dumpcsv,rmse,write_status,save_report,COLORS
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

MODELS=['FA_original','LV_mass_action','Holling_II','Beddington_DeAngelis']

def rhs(z,p):
    x,y=z
    den=1+p['b']*x+p['c']*y
    pred=p['a']*x*y/den
    return np.array([p['r']*x*(1-x/p['K'])*(1+p['alpha']*x)-pred,p['e']*pred-p['d']*y])

def make(base,name):
    p=dict(base)
    if name=='FA_original':p['b']=0
    elif name=='LV_mass_action':p['b']=p['c']=0
    elif name=='Holling_II':p['c']=0
    elif name=='Beddington_DeAngelis':pass
    else:raise ValueError(name)
    return p

def sample_cases(n, seed=1107):
    rng=np.random.default_rng(seed)
    rows=[]
    for i in range(n):
        rows.append(dict(scenario=i,r=float(rng.uniform(.35,1.0)),K=float(rng.uniform(6,12)),
          alpha=float(rng.uniform(.17,.28)),a=float(rng.uniform(.18,.6)),e=.6,
          d=float(rng.uniform(.18,.55)),b=float(rng.uniform(.02,.16)),c=float(rng.uniform(.05,.35))))
    return rows

def predict_batch(xy,dt,p):
    # Positive log-space RK4, vectorised across observed point pairs.
    xy=np.asarray(xy);dt=np.asarray(dt)
    n=np.maximum(1,np.ceil(dt/.12).astype(int));h=dt/n
    u=np.log(np.maximum(xy,1e-10))
    def f(w):
        x=np.exp(np.clip(w[:,0],-40,20));y=np.exp(np.clip(w[:,1],-40,20))
        den=1+p['b']*x+p['c']*y
        return np.column_stack([p['r']*(1-x/p['K'])*(1+p['alpha']*x)-p['a']*y/den,
                                p['e']*p['a']*x/den-p['d']])
    for i in range(int(np.max(n))):
        v=np.where(i<n,h,0.0)[:,None]
        a=f(u);b=f(u+v*a/2);c=f(u+v*b/2);d=f(u+v*c)
        u=u+v*(a+2*b+2*c+d)/6
    return np.exp(np.clip(u,-40,20))

def pairs(df):
    obs=df[['prey_million_cells_per_ml','predator_20_animals_per_ml']].to_numpy(dtype=float)
    t=df.time_days.to_numpy(dtype=float)
    return obs[:-1],np.diff(t),obs[1:]

def fit_predict_real(root, models, full):
    frames={f'C{i}':pd.read_csv(root/f'data/real/C{i}.csv') for i in range(1,5)}
    folds=list(frames) if full else ['C4']
    rows=[]; detailed=[]
    for held in folds:
        sources=[pairs(df) for c,df in frames.items() if c!=held]
        X=np.concatenate([s[0] for s in sources]);DT=np.concatenate([s[1] for s in sources]);Y=np.concatenate([s[2] for s in sources])
        scale=np.maximum(np.std(Y,axis=0),.1)
        Xval,DV,Yval=pairs(frames[held])
        for name in models:
            # Relative rates are fit to a common observed dataset; no claim of measured ecological parameter values.
            keys=['r','K','a','d']+[k for k in ['b','c'] if ((k=='b' and name in ['Holling_II','Beddington_DeAngelis']) or (k=='c' and name in ['FA_original','Beddington_DeAngelis']))]
            defaults={'r':.6,'K':1.5,'a':.8,'d':.5,'b':.7,'c':1.,'alpha':.25,'e':.6}
            low={'r':.03,'K':.12,'a':.01,'d':.01,'b':.001,'c':.001};up={'r':3.,'K':8.,'a':7.,'d':4.,'b':9.,'c':12.}
            start=np.log([defaults[k] for k in keys]); lb=np.log([low[k] for k in keys]);ub=np.log([up[k] for k in keys])
            def obj(logtheta):
                params=make({**defaults,**dict(zip(keys,np.exp(logtheta)))},name)
                try:yp=predict_batch(X,DT,params)
                except Exception:return np.ones(Y.size)*1e5
                err=((yp-Y)/scale).ravel()
                return np.where(np.isfinite(err),np.clip(err,-1e5,1e5),1e5)
            seeds=[start]
            if full:seeds.append(np.clip(start+np.random.default_rng(3).normal(0,.18,len(keys)),lb,ub))
            outcomes=[least_squares(obj,s,bounds=(lb,ub),max_nfev=55 if full else 25) for s in seeds]
            best=min(outcomes,key=lambda z:np.sum(z.fun**2))
            params=make({**defaults,**dict(zip(keys,np.exp(best.x)))},name)
            forecast=predict_batch(Xval,DV,params)
            score=rmse(Yval,forecast,scale)
            rows.append({'held_experiment':held,'model':name,'task':'next_observation','test_nrmse':score,
                        'training_pairs':len(X),'test_pairs':len(Yval),'fit_success':bool(best.success),
                        'parameter_estimates':repr({k:round(params[k],5) for k in params})})
            for j,z in enumerate(Yval):
                detailed.append({'held_experiment':held,'model':name,'time_days':float(frames[held].time_days.iloc[j+1]),
                  'observed_x':z[0],'observed_y':z[1],'pred_x':forecast[j,0],'pred_y':forecast[j,1]})
        basex=rmse(Yval,Xval,scale)
        rows.append({'held_experiment':held,'model':'last_observation','task':'next_observation',
                     'test_nrmse':basex,'training_pairs':len(X),'test_pairs':len(Yval),'fit_success':True,
                     'parameter_estimates':'none'})
    return rows,detailed

def run(root,mode):
    root=Path(root);full=(mode=='full')
    cases=sample_cases(18 if full else 5)
    models=MODELS
    records=[];eq=[];enrichment=[]
    ts=np.linspace(0,75,401 if full else 181)
    for base in cases:
        for name in models:
            p=make(base,name)
            invasion=p['e']*p['a']*p['K']/(p['d']*(1+p['b']*p['K']))
            for j,z0 in enumerate(([4.,1.],[9.,.2],[2.,3.]) if full else ([4.,1.],[9.,.2])):
                traj=integrate(rhs,p,ts,z0)
                records.append({'scenario':base['scenario'],'model':name,'initial':j,'invasion_R':invasion,
                         'x_final':traj[-1,0],'y_final':traj[-1,1],
                         'x_span_last_quarter':np.ptp(traj[int(.75*len(ts)):,0]),
                         'y_span_last_quarter':np.ptp(traj[int(.75*len(ts)):,1]),
                         'finite_horizon_label':end_label(traj,ts)})
            eq+= [{'scenario':base['scenario'],**a} for a in eq_table(rhs,name,p,p['K']*1.15,5.)]
            if base['scenario']==0:
                for K in np.linspace(5.,18.,18 if full else 6):
                    pp=dict(p,K=float(K))
                    roots=eq_table(rhs,name,pp,K*1.1,5.)
                    for q in roots:enrichment.append({'model':name,'K':K,'x':q['x'],'y':q['y'],
                         'trace':q['trace'],'determinant':q['determinant'],'local_classification':q['local_classification']})
    df=dumpcsv(root,'synthetic_structure_runs.csv',records)
    dumpcsv(root,'synthetic_equilibrium_candidates.csv',eq)
    enr=dumpcsv(root,'enrichment_equilibrium_candidates.csv',enrichment)
    dumpcsv(root,'synthetic_parameter_scenarios.csv',cases)
    erows,detail=fit_predict_real(root,models,full)
    er=dumpcsv(root,'ecological_real_next_step_scores.csv',erows)
    dumpcsv(root,'ecological_real_next_step_predictions.csv',detail)
    pal=['#1F1E33','#7C78A0','#B07980','#398482']
    fig,ax=plt.subplots(figsize=(8.8,4.6))
    for i,name in enumerate(models):
        dd=enr[(enr.model==name)&(enr.local_classification=='locally_asymptotically_stable')]
        ax.scatter(dd.K,dd.x,label=name,color=pal[i],s=19)
    ax.set(xlabel='K (dimensionless illustrative)',ylabel='candidate positive-equilibrium prey x',
           title='Illustrative equilibrium branches (stable candidates only)')
    ax.legend(fontsize=8);fig.tight_layout();fig.savefig(root/'figures/enrichment_branches.png',dpi=180);plt.close(fig)
    fig,ax=plt.subplots(figsize=(8.5,4.5))
    ordered=er[er.held_experiment==('C4' if not full else 'C1')]
    ax.bar(ordered.model,ordered.test_nrmse,color=pal+['#ABA8BA'])
    ax.tick_params(axis='x',rotation=25);ax.set(ylabel='Held-experiment normalized RMSE (next observation)',
      title='REAL algae-rotifer observations; fixed weak Allee alpha and e')
    fig.tight_layout();fig.savefig(root/'figures/real_next_step_model_comparison.png',dpi=180);plt.close(fig)
    obs=f'Pilot ran {len(df)} synthetic trajectories across {len(cases)} scenarios and 4 response functions. Numerical equilibrium candidates: {len(eq)}. Real ecological next-step tests: {len(er)} model/baseline scores; test error table is in results/ecological_real_next_step_scores.csv.\n\n'
    obs+='No generated time series is being used as proof of a periodic orbit or global theorem.\n'
    save_report(root,'方向一：捕食机制比较 / Predation mechanism comparison',
      '改变捕食方式后，哪些共存、稳定和环境变化结论保持，哪些改变？',
      '保持猎物弱 Allee 增长；对照原 Foraging-arena、LV、Holling II、Beddington-DeAngelis。在相同数值情景下进行配对积分、候选平衡点和环境承载量扫描。用四场真实藻类-轮虫观测做二级的未见实验下一步预测比较。',
      obs,
      'Codex 全量阶段：对每个模型完成正性/有界性/持久性、根数、局部与全局稳定、富营养化和分岔的解析条件；加入 Ratio-dependent 的边界处理；验证与经典论文对应的生态参数情景。',
      '模拟参数为无量纲假设情景；C1–C4 为真实时间观测，含培养装置机制；根为数值候选。')
    write_status(root,mode,{'synthetic_trajectories':len(df),'equilibrium_candidates':len(eq),
        'real_scores':len(er),'real_test_experiments':4 if full else 1},
        'Real observations used only for held-experiment next-step predictions; alpha/e fixed by experimental design, not field measured.')
