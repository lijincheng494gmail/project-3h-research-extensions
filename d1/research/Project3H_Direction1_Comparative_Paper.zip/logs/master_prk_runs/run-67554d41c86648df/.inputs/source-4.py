"""Nested whole-chemostat validation, observed-state next-step prediction only.

All five models keep alpha=.25 and e=.6 in the stated scaled coordinates.
These values are numerical controls, not measured biological parameters.
"""
from __future__ import annotations
from pathlib import Path
import hashlib
import json
import time
import numpy as np
import pandas as pd
from scipy.integrate import solve_ivp
from scipy.optimize import least_squares
from .experiments import pairs
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

DEFAULTS = dict(r=.6, K=1.5, a=.8, d=.5, b=.7, c=1., alpha=.25, e=.6)
LOW = dict(r=.03, K=.12, a=.01, d=.01, b=.001, c=.001)
HIGH = dict(r=3., K=8., a=7., d=4., b=9., c=12.)
MODELS = ['FA_original','LV_mass_action','Holling_II','Beddington_DeAngelis','Ratio_dependent']
MODEL_IDS = dict(zip(MODELS, ['P0','P1','P2','P3','P4']))


def make(base, name):
    p = dict(base)
    p['response'] = name
    if name == 'FA_original': p['b'] = 0.
    elif name == 'LV_mass_action': p['b'] = p['c'] = 0.
    elif name == 'Holling_II': p['c'] = 0.
    elif name == 'Beddington_DeAngelis': pass
    elif name == 'Ratio_dependent': p['b'] = 0.
    else: raise ValueError(name)
    return p


def rhs(z, p):
    x, y = z
    den = x + p['c']*y if p['response'] == 'Ratio_dependent' else 1+p['b']*x+p['c']*y
    loss = p['a']*x*y/den
    return np.array([p['r']*x*(1-x/p['K'])*(1+p['alpha']*x)-loss,
                     p['e']*loss-p['d']*y])


MAX_NFEV = 40
STEP = .08


def predict(xy, dt, p, step=STEP):
    """Vectorized RK4 in log states with prescribed maximum step in days."""
    xy=np.asarray(xy, dtype=float); dt=np.asarray(dt, dtype=float)
    if xy.ndim != 2 or xy.shape[1] != 2 or len(dt) != len(xy):
        raise ValueError('incompatible observation shapes')
    if np.any(xy <= 0) or np.any(dt <= 0):
        raise ValueError('positive states and positive intervals required')
    n=np.maximum(1,np.ceil(dt/step).astype(int)); h=dt/n
    u=np.log(xy)
    def f(w):
        x=np.exp(np.clip(w[:,0],-40,20)); y=np.exp(np.clip(w[:,1],-40,20))
        den=x+p['c']*y if p['response']=='Ratio_dependent' else 1+p['b']*x+p['c']*y
        return np.column_stack((p['r']*(1-x/p['K'])*(1+p['alpha']*x)-p['a']*y/den,
                                p['e']*p['a']*x/den-p['d']))
    for i in range(int(np.max(n))):
        v=np.where(i<n,h,0.)[:,None]
        k1=f(u); k2=f(u+v*k1/2); k3=f(u+v*k2/2); k4=f(u+v*k3)
        u += v*(k1+2*k2+2*k3+k4)/6
    return np.exp(np.clip(u,-40,20))


def metrics(obs,pred,scale):
    er=np.asarray(pred)-np.asarray(obs)
    rms=np.sqrt(np.mean(er**2,axis=0)); mae=np.mean(np.abs(er),axis=0)
    return dict(test_nrmse=float(np.mean(rms/scale)),
                prey_rmse_million_cells_per_ml=float(rms[0]),
                predator_rmse_animals_per_ml=float(20*rms[1]),
                prey_mae_million_cells_per_ml=float(mae[0]),
                predator_mae_animals_per_ml=float(20*mae[1]))


def load_frames(root):
    frames={f'C{i}':pd.read_csv(root/f'data/real/C{i}.csv') for i in range(1,5)}
    for k,df in frames.items():
        x,dt,y=pairs(df)
        if not np.all(np.isfinite(np.c_[x,y])) or np.any(x <= 0) or np.any(y <= 0) or np.any(dt <= 0):
            raise ValueError(f'invalid observed pairs: {k}')
    return frames


def collect(frames,ids):
    ps=[pairs(frames[k]) for k in ids]
    return tuple(np.concatenate([p[j] for p in ps]) for j in range(3))


def scale_for(y):
    return np.maximum(np.std(y,axis=0),.1)


def param_keys(name):
    return ['r','K','a','d']+(['b'] if name in ['Holling_II','Beddington_DeAngelis'] else [])+(['c'] if name in ['FA_original','Beddington_DeAngelis','Ratio_dependent'] else [])


def fit(frames,train_ids,name,candidate,lower_bounds=LOW,upper_bounds=HIGH):
    x,dt,y=collect(frames,train_ids); scale=scale_for(y); keys=param_keys(name)
    lb=np.log([lower_bounds[k] for k in keys]); ub=np.log([upper_bounds[k] for k in keys])
    start=np.log([DEFAULTS[k] for k in keys])
    if candidate:
        start=np.clip(start+np.random.default_rng(1107).normal(0,.3,len(keys)),lb,ub)
    calls=0
    def objective(theta):
        nonlocal calls
        calls+=1
        p=make({**DEFAULTS,**dict(zip(keys,np.exp(theta)))},name)
        pred=predict(x,dt,p)
        return np.nan_to_num(np.clip(((pred-y)/scale).ravel(),-1e5,1e5),nan=1e5,posinf=1e5,neginf=-1e5)
    begin=time.monotonic()
    out=least_squares(objective,start,bounds=(lb,ub),max_nfev=MAX_NFEV,ftol=1e-7,xtol=1e-7,gtol=1e-7)
    p=make({**DEFAULTS,**dict(zip(keys,np.exp(out.x)))},name)
    record=dict(model=name,candidate=candidate,train_experiments=';'.join(train_ids),
                train_pairs=len(y),nfev=int(out.nfev),residual_calls=calls,max_nfev=MAX_NFEV,
                optimizer_success=bool(out.success),optimizer_status=int(out.status),
                optimizer_message=str(out.message),optimality=float(out.optimality),
                train_cost=float(out.cost),seconds=time.monotonic()-begin,
                lower_bound_parameters=';'.join(k for i,k in enumerate(keys) if out.x[i]-lb[i]<1e-4),
                upper_bound_parameters=';'.join(k for i,k in enumerate(keys) if ub[i]-out.x[i]<1e-4))
    record.update(p)
    return p,scale,record


def audit_sources(root,prefix="five_ecology_"):
    records=[]
    meta=json.loads((root/'data/source/figshare_metadata.json').read_text())
    published={f['name']:f for f in meta['files']}
    for i in range(1,5):
        name=f'C{i}'; rawpath=root/f'data/source/{name}_original.csv'
        raw=pd.read_csv(rawpath); raw.columns=[c.strip() for c in raw.columns]
        orig=raw[['time (days)','algae (10^6 cells/ml)','rotifers (animals/ml)']].to_numpy(float)
        keep=np.all(np.isfinite(orig),axis=1)&(orig[:,1]>0)&(orig[:,2]>0)
        converted=orig[keep].copy();converted[:,2]/=20.
        bundled=pd.read_csv(root/f'data/real/{name}.csv').to_numpy(float)
        same=converted.shape==bundled.shape and np.allclose(converted,bundled,rtol=1e-13,atol=1e-13)
        md5=hashlib.md5(rawpath.read_bytes()).hexdigest()
        rec=dict(experiment=name,raw_rows=len(raw),retained_rows=len(converted),excluded_rows=int((~keep).sum()),
                 bundled_rows=len(bundled),exact_processed_mapping_verified=bool(same),
                 original_matches_figshare_md5=md5==published[name+'.csv']['computed_md5'],
                 raw_sha256=hashlib.sha256(rawpath.read_bytes()).hexdigest(),
                 time_min=float(bundled[:,0].min()),time_max=float(bundled[:,0].max()),
                 min_interval_days=float(np.diff(bundled[:,0]).min()),max_interval_days=float(np.diff(bundled[:,0]).max()),
                 external_medium_unique=';'.join(map(str,sorted(raw['external medium (mu mol N / l)'].dropna().unique()))))
        records.append(rec)
        if not same or not rec['original_matches_figshare_md5']:
            raise AssertionError(f'provenance mapping failed for {name}')
    pd.DataFrame(records).to_csv(root/'results'/(prefix+'source_mapping_audit.csv'),index=False)


def run(root, sensitivity=False):
    started=time.monotonic()
    root=Path(root); frames=load_frames(root); ids=list(frames)
    prefix='five_ecology_wide_' if sensitivity else 'five_ecology_'
    logprefix='FIVE_ECOLOGY_WIDE_' if sensitivity else 'FIVE_ECOLOGY_'
    lower_bounds={k:v/10 for k,v in LOW.items()} if sensitivity else dict(LOW)
    upper_bounds={k:v*10 for k,v in HIGH.items()} if sensitivity else dict(HIGH)
    audit_sources(root,prefix)
    scores=[]; predictions=[]; fits=[]; validation=[]; splitrows=[]; solver=[]
    config=dict(task='next_observation_from_observed_held_state',outer_folds=ids,
                inner_folds='each of remaining three whole experiments',
                candidate_initializations=2,max_nfev_per_fit=MAX_NFEV,
                selection='unweighted mean of three inner-experiment NRMSE values',
                fixed_alpha=.25,fixed_e=.6,step_days=STEP,models=MODELS,model_ids=MODEL_IDS,
                predation='P4 a*x*y/(x+c*y); P0-P3 a*x*y/(1+b*x+c*y)',
                bounds=dict(lower=lower_bounds,upper=upper_bounds),variant="wide_bounds" if sensitivity else "main_bounds",defaults=DEFAULTS,seed=1107,
                reference_units='X=10^6 algae cells/ml; Y=20 rotifers/ml; T=day',
                same_numeric_bounds='Bounds are in scaled coordinates. P4 a has X/(Y*T) and c has X/Y; P0-P3 a has 1/(Y*T) and c has 1/Y.',
                note='Equal starts and optimizer iteration caps; parameter dimensions and residual calls differ.')
    (root/'logs'/(logprefix+'PROTOCOL.json')).write_text(json.dumps(config,indent=2))
    for held in ids:
        available=[k for k in ids if k!=held]
        xv,dv,yv=pairs(frames[held])
        for name in MODELS:
            candidate_scores=[]
            for candidate in range(2):
                vals=[]
                for val in available:
                    train=[k for k in available if k!=val]
                    assert held not in train and val not in train and held!=val
                    pp,scale,record=fit(frames,train,name,candidate,lower_bounds,upper_bounds)
                    record.update(stage='inner',outer_test=held,validation_experiment=val)
                    fits.append(record)
                    x,dt,y=pairs(frames[val]);m=metrics(y,predict(x,dt,pp),scale)
                    validation.append(dict(outer_test=held,model=name,candidate=candidate,validation_experiment=val,
                                           training_experiments=';'.join(train),**m))
                    vals.append(m['test_nrmse'])
                    splitrows.append(dict(stage='inner',outer_test=held,validation=val,training=';'.join(train),
                                          disjoint_experiment_sets=True,model=name,candidate=candidate))
                candidate_scores.append(float(np.mean(vals)))
            selected=int(np.argmin(candidate_scores))
            p,scale,record=fit(frames,available,name,selected,lower_bounds,upper_bounds)
            record.update(stage='outer_refit',outer_test=held,validation_experiment='none')
            fits.append(record)
            forecast=predict(xv,dv,p)
            metrics_row=metrics(yv,forecast,scale)
            scores.append(dict(held_experiment=held,model=name,training_experiments=';'.join(available),
                               training_pairs=sum(len(frames[k])-1 for k in available),test_pairs=len(yv),
                               selected_initialization=selected,inner_mean_nrmse=candidate_scores[selected],
                               prey_training_scale=float(scale[0]),predator_training_scale=float(scale[1]),
                               optimizer_success=record['optimizer_success'],**metrics_row))
            splitrows.append(dict(stage='outer_refit',outer_test=held,validation='inner_only',
                                  training=';'.join(available),disjoint_experiment_sets=True,model=name,candidate=selected))
            for j in range(len(yv)):
                predictions.append(dict(held_experiment=held,model=name,pair_index=j,
                                        input_time_days=float(frames[held].time_days.iloc[j]),
                                        target_time_days=float(frames[held].time_days.iloc[j+1]),
                                        dt_days=float(dv[j]),observed_x=float(yv[j,0]),observed_y=float(yv[j,1]),
                                        input_x=float(xv[j,0]),input_y=float(xv[j,1]),
                                        predicted_x=float(forecast[j,0]),predicted_y=float(forecast[j,1])))
            # Endpoint/quantile intervals plus longest interval. No parameter fitting in this audit.
            selected_pairs=np.unique(np.r_[np.linspace(0,len(yv)-1,7).astype(int),np.argmax(dv)])
            fine=predict(xv[selected_pairs],dv[selected_pairs],p,STEP/2)
            for jj,j in enumerate(selected_pairs):
                def log_rhs(_,u):
                    z=np.exp(u)
                    return rhs(z,p)/z
                ref=solve_ivp(log_rhs,(0,float(dv[j])),np.log(xv[j]),method='DOP853',
                              rtol=1e-11,atol=1e-13,max_step=.03)
                if not ref.success: raise RuntimeError(ref.message)
                endpoint=np.exp(ref.y[:,-1])
                solver.append(dict(held_experiment=held,model=name,pair_index=int(j),dt_days=float(dv[j]),
                                   step_days=STEP,coarse_max_abs=float(np.max(abs(forecast[j]-endpoint))),
                                   half_step_max_abs=float(np.max(abs(fine[jj]-endpoint))),
                                   coarse_max_training_scaled=float(np.max(abs(forecast[j]-endpoint)/scale)),
                                   half_step_max_training_scaled=float(np.max(abs(fine[jj]-endpoint)/scale)),
                                   reference='DOP853 log-state rtol=1e-11 atol=1e-13 max_step=.03 days'))
            print('ecology',held,name,'NRMSE',round(metrics_row['test_nrmse'],6),'optimizer',record['optimizer_success'],flush=True)
        # Training-only scale is identical across the five models in an outer fold.
        _,_,trainy=collect(frames,available);scale=scale_for(trainy)
        scores.append(dict(held_experiment=held,model='last_observation',training_experiments=';'.join(available),
                           training_pairs=len(trainy),test_pairs=len(yv),selected_initialization=-1,
                           inner_mean_nrmse=np.nan,prey_training_scale=float(scale[0]),predator_training_scale=float(scale[1]),
                           optimizer_success=True,**metrics(yv,xv,scale)))
    tables={'five_ecology_scores.csv':scores,'five_ecology_predictions.csv':predictions,
            'five_ecology_fit_log.csv':fits,'five_ecology_inner_validation.csv':validation,
            'five_ecology_split_audit.csv':splitrows,'five_ecology_solver_audit.csv':solver}
    for filename,rows in tables.items():
        pd.DataFrame(rows).to_csv(root/'results'/filename.replace('five_ecology_',prefix),index=False)
    sc=pd.DataFrame(scores)
    summary=sc.groupby('model',sort=False).agg(mean_fold_nrmse=('test_nrmse','mean'),
                                            min_fold_nrmse=('test_nrmse','min'),max_fold_nrmse=('test_nrmse','max'),
                                            total_test_pairs=('test_pairs','sum'))
    summary.to_csv(root/'results'/(prefix+'summary.csv'))
    fig,axs=plt.subplots(1,2,figsize=(13,4.8))
    mat=sc.pivot(index='held_experiment',columns='model',values='test_nrmse')
    names=MODELS+['last_observation']; mat=mat[names]
    im=axs[0].imshow(mat.to_numpy(),cmap='viridis',aspect='auto')
    axs[0].set(yticks=range(4),yticklabels=mat.index,xticks=range(6),xticklabels=names,title='Whole-experiment held-out NRMSE')
    axs[0].tick_params(axis='x',rotation=40,labelsize=8)
    for i in range(4):
        for j in range(6): axs[0].text(j,i,f'{mat.iloc[i,j]:.3f}',ha='center',va='center',color='white',fontsize=8)
    fig.colorbar(im,ax=axs[0],shrink=.75)
    vals=summary.loc[names,'mean_fold_nrmse']
    axs[1].bar(range(6),vals,color=['#1F1E33','#7C78A0','#B07980','#398482','#C18B4A','#ABA8BA'])
    axs[1].set(xticks=range(6),xticklabels=names,ylabel='Unweighted mean of four fold NRMSEs',title='Nested initialization selection')
    axs[1].tick_params(axis='x',rotation=40,labelsize=8)
    fig.tight_layout();fig.savefig(root/'figures'/(prefix+'all_folds.png'),dpi=180);plt.close(fig)
    result=dict(execution='fresh_five_model_rerun',variant='wide_bounds' if sensitivity else 'main_bounds',elapsed_seconds=time.monotonic()-started,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),outer_scores=len(scores),optimizer_runs=len(fits),prediction_rows=len(predictions),
                validation_scores=len(validation),solver_checks=len(solver),
                optimizer_nonconverged=sum(not x['optimizer_success'] for x in fits),
                all_source_mappings_verified=True)
    (root/'logs'/(logprefix+'STATUS.json')).write_text(json.dumps(result,indent=2))
    return result


if __name__=='__main__':
    run(Path(__file__).resolve().parents[1])
    run(Path(__file__).resolve().parents[1],sensitivity=True)
