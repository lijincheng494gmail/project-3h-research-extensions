import unittest
import numpy as np
from src.experiments import rhs,make,MODELS
from src.core import integrate

class ModelTests(unittest.TestCase):
 def setUp(self):self.p={'r':.7,'K':10.,'alpha':.2,'a':.4,'e':.6,'d':.3,'b':.08,'c':.12}
 def test_original_parameter_mapping(self):
  p=make(self.p,'FA_original');x,y=5.,2.;m=p['a']/p['c'];beta=1/p['c']
  self.assertAlmostEqual(p['a']*x*y/(1+p['c']*y),m*x*y/(beta+y))
 def test_lv_limit(self):
  p=make(self.p,'LV_mass_action');self.assertEqual(p['b'],0);self.assertEqual(p['c'],0)
 def test_invasion_independent_of_interference(self):
  for name in MODELS:
   p=make(self.p,name);rate=p['e']*p['a']*p['K']/(1+p['b']*p['K'])-p['d']
   q=dict(p,c=100.)
   self.assertAlmostEqual(rate,q['e']*q['a']*q['K']/(1+q['b']*q['K'])-q['d'])
 def test_positive_trajectories(self):
  for name in MODELS:
   z=integrate(rhs,make(self.p,name),np.linspace(0,10,51),[3.,.5]);self.assertTrue(np.all(z>0))
if __name__=='__main__':unittest.main()
