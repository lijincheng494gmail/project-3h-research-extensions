"""Independent comparison audit, exact enrichment/Hopf formulas, and five-model figures.
Synthetic dimensionless scenarios; no simulation is used as a proof.
"""
from pathlib import Path
import json, time
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

MODEL_LABELS={'FA_original':'P0 FA','LV_mass_action':'P1 LV','Holling_II':'P2 Holling II','Beddington_DeAngelis':'P3 BD','Ratio_dependent_separate':'P4 Ratio'}
COLORS=['#304a68','#b56135','#347b69','#8b5d8b','#a58a23']

def c0_hopf(r,alpha,b,a,e,d):
    """Closed-form K threshold for c=0. Return None when no Hopf is possible."""
    A=e*a/d-b
    if A<=0 or alpha+b<=0:return None
    u=1/A; L=alpha+b+2*alpha*b*u; N=1+2*(alpha+b)*u+3*alpha*b*u*u
    K=N/L;D=1+b*u;q=r*(1-u/K)*(1+alpha*u);qpp=-2*r*alpha/K
    omega=np.sqrt(d*q/D)
    l1=((2+5*b*u)*qpp/D-4*b*b*q/D**2)/(8*omega)
    return dict(x=u,y=e*u*q/d,K=K,q=q,omega=omega,
                trace_K_derivative=u*r*N/(D*K*K),first_lyapunov_rotated=l1)

def independent_l1(p,z):
    """Differentiate xq(x)-yh(x), y(eh(x)-d), then apply planar formula.
    X=x-u, Y=h(u)(y-v)/omega, unit q=(1,-i)/sqrt(2).
    """
    r,K,alpha,a,b,e,d=(p[k] for k in ['r','K','alpha','a','b','e','d'])
    u,v=z;D=1+b*u;h=a*u/D
    hp=a/D**2;hpp=-2*a*b/D**3;hppp=6*a*b*b/D**4
    qp=r*(alpha-1/K-2*alpha*u/K);qpp=-2*r*alpha/K
    omega=np.sqrt(e*v*h*hp)
    fxx=2*qp+u*qpp-v*hpp;fxy=-hp*omega/h;fyy=0
    gxx=e*v*hpp*h/omega;gxy=e*hp;gyy=0
    fxxx=3*qpp-v*hppp;fxyy=0;gxxy=e*hpp;gyyy=0
    cubic=fxxx+fxyy+gxxy+gyyy
    quad=fxy*(fxx+fyy)-gxy*(gxx+gyy)-fxx*gxx+fyy*gyy
    return cubic/(8*omega)+quad/(8*omega**2)

def run(root=None):
    from .controlled_extended import scenarios,matched,MAIN,RATIO,all_equilibria,derivative_tensors,jacobian,rhs,percapita
    root=Path(root or Path(__file__).resolve().parents[1]);rows=[];probes=[]
    rng=np.random.default_rng(20261118)
    for i in range(120):
        r=float(rng.uniform(.15,2));alpha=float(rng.uniform(0,.8));b=0. if i%2==0 else float(rng.uniform(.01,.7))
        if i==0:alpha=0.;b=.2
        e=float(rng.uniform(.2,1.3));d=float(rng.uniform(.1,1));a=d/e*(b+float(rng.uniform(.1,3)))
        ev=c0_hopf(r,alpha,b,a,e,d)
        p=dict(r=r,K=ev['K'],alpha=alpha,b=b,c=0.,a=a,e=e,d=d,model='Holling_II' if b else 'LV_mass_action',growth='weak_allee')
        z=[ev['x'],ev['y']];J=jacobian(z,p);_,B,C=derivative_tensors(z,p)
        h=a*z[0]/(1+b*z[0]);S=np.diag([1.,ev['omega']/h]);Si=np.linalg.inv(S)
        bt=np.einsum('ia,ajk,jb,kc->ibc',Si,B,S,S)
        ct=np.einsum('ia,ajkl,jb,kc,ld->ibcd',Si,C,S,S,S)
        tensor=(ct[0,0,0,0]+ct[0,0,1,1]+ct[1,0,0,1]+ct[1,1,1,1])/(8*ev['omega'])
        tensor+=(bt[0,0,1]*(bt[0,0,0]+bt[0,1,1])-bt[1,0,1]*(bt[1,0,0]+bt[1,1,1])-bt[0,0,0]*bt[1,0,0]+bt[0,1,1]*bt[1,1,1])/(8*ev['omega']**2)
        independent=independent_l1(p,z)
        probes.append(dict(probe=i,**{k:p[k] for k in ['model','r','K','alpha','b','a','e','d']},**{k:v for k,v in ev.items() if k!='K'},equilibrium_residual=float(np.linalg.norm(rhs(z,p),ord=np.inf)),trace=float(np.trace(J)),determinant=float(np.linalg.det(J)),l1_independent=independent,l1_tensor=tensor,l1_error=abs(independent-ev['first_lyapunov_rotated']),l1_tensor_error=abs(tensor-ev['first_lyapunov_rotated'])))
    df=pd.DataFrame(probes);df.to_csv(root/'results/comparison_c0_hopf_probes.csv',index=False)
    for check,value,tol in [('c0_Hopf_equilibrium_substitution',df.equilibrium_residual.max(),1e-9),('c0_Hopf_trace_zero',df.trace.abs().max(),1e-9),('c0_Hopf_independent_l1_identity',df.l1_error.max(),1e-9),('c0_Hopf_Taylor_tensor_l1_identity',df.l1_tensor_error.max(),1e-9)]:
        rows.append(dict(check=check,cases=len(df),max_error=value,tolerance=tol,passed=bool(value<tol)))
    rows.append(dict(check='c0_Hopf_l1_strictly_negative',cases=len(df),max_error=float(df.first_lyapunov_rotated.max()),tolerance=0.,passed=bool((df.first_lyapunov_rotated<0).all())))
    # Independently evaluate analytic formulas directly against the unreduced state Jacobian.
    deterrors=[];trerrors=[];dulacerrors=[]
    for j in range(100):
        base=dict(r=float(rng.uniform(.2,2)),K=float(rng.uniform(3,16)),alpha=float(rng.uniform(0,.8)),e=float(rng.uniform(.2,1.1)),d=float(rng.uniform(.1,1)),b=float(rng.uniform(.01,.5)),c=float(rng.uniform(.01,2)),xref=10.,reference_intake=float(rng.uniform(1,4)),scenario='audit')
        for model in MAIN:
            p=matched(base,model)
            for eq in all_equilibria(p):
                x,y=eq['x'],eq['y'];q=percapita(x,p);D=1+p['b']*x+p['c']*y
                qp=p['r']*(p['alpha']-1/p['K']-2*p['alpha']*x/p['K'])
                tr=x*qp+p['b']*x*q/D-p['d']*p['c']*y/D
                det=p['d']*q/D*(1-p['c']*p['e']/p['d']*x*x*qp)
                J=jacobian([x,y],p);deterrors.append(abs(np.linalg.det(J)-det));trerrors.append(abs(np.trace(J)-tr))
            x,y=rng.uniform(.2,12,2);D=1+p['b']*x+p['c']*y
            Bmult=D/(x*y);gradB=np.array([-1/(x*x*y)-p['c']/(x*x),-1/(x*y*y)-p['b']/(y*y)])
            div=gradB@rhs([x,y],p)+Bmult*np.trace(jacobian([x,y],p))
            q=percapita(x,p);qp=p['r']*(p['alpha']-1/p['K']-2*p['alpha']*x/p['K'])
            formula=((1+p['b']*x)*qp+p['b']*q)/y+p['c']*qp-p['d']*p['c']/x
            dulacerrors.append(abs(div-formula))
    for label,values,tol in [('four_law_determinant_identity',deterrors,1e-8),('four_law_trace_identity',trerrors,1e-8),('four_law_Dulac_product_rule_identity',dulacerrors,1e-8)]:
        rows.append(dict(check=label,cases=len(values),max_error=max(values),tolerance=tol,passed=bool(max(values)<tol)))
    pd.DataFrame(rows).to_csv(root/'results/comparison_independent_audits.csv',index=False)
    if not all(r['passed'] for r in rows):raise RuntimeError('Independent comparison audit failed')
    # A common reference point matches P/y as y decreases to zero at x_ref=10.
    # a,b,c are then fixed while K varies, so enrichment is not confounded by refitting.
    models=MAIN+[RATIO];branches=[]
    for base in scenarios():
        for model in models:
            p=matched(base,model)
            for K in np.linspace(.5,35.,451):
                for n,eq in enumerate(all_equilibria(dict(p,K=float(K)))):
                    branches.append(dict(scenario=base['scenario'],model=model,K=float(K),branch_rank=n,**eq))
    branchdf=pd.DataFrame(branches);branchdf.to_csv(root/'results/comparison_five_enrichment.csv',index=False)
    ts=pd.read_csv(root/'results/controlled_trajectories.csv')
    fig,axs=plt.subplots(3,2,figsize=(11.5,11.8))
    for col,base in enumerate(scenarios()):
        for color,model in zip(COLORS,models):
            dd=ts[(ts.scenario==base['scenario'])&(ts.model==model)&(ts.initial==0)&(ts.t<=200)]
            axs[0,col].plot(dd.t,dd.x,color=color,lw=1.25,label=MODEL_LABELS[model])
            axs[1,col].plot(dd.x,dd.y,color=color,lw=1.2)
            dd=branchdf[(branchdf.scenario==base['scenario'])&(branchdf.model==model)]
            for state,marker in [('stable','.'),('unstable','x'),('saddle','+')]:
                ss=dd[dd.local_classification==state]
                axs[2,col].scatter(ss.K,ss.x,color=color,s=5 if state=='stable' else 9,marker=marker,linewidths=.6)
        axs[0,col].set(title=base['scenario'].replace('_',' '),xlabel='Time',ylabel='Prey density')
        axs[1,col].set(xlabel='Prey density',ylabel='Predator density')
        axs[2,col].set(xlabel='Carrying capacity K',ylabel='All positive-equilibrium prey densities')
        axs[0,col].legend(fontsize=8,ncol=2)
        for row in range(3):axs[row,col].spines[['top','right']].set_visible(False)
    fig.suptitle('Five predation mechanisms with common weak-Allee growth\nMatched low-predator intake at x=10; enrichment holds response parameters fixed',fontsize=12)
    fig.text(.5,.012,'Enrichment symbols: dot = locally stable; x = unstable; + = saddle. Synthetic dimensionless parameters.',ha='center',fontsize=9)
    fig.tight_layout(rect=(0,.03,1,.94));fig.savefig(root/'figures/comparison_overview.png',dpi=190);plt.close(fig)
    summary=dict(audit_classes=len(rows),audit_passed=sum(r['passed'] for r in rows),c0_hopf_probes=len(probes),five_model_enrichment_rows=len(branchdf),mathematical_status='direct formulas plus independent numerical identity checks',figure='figures/comparison_overview.png')
    (root/'logs/MASTER_COMPARISON_AUDIT.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary),flush=True)
    return summary

if __name__=='__main__':run()
