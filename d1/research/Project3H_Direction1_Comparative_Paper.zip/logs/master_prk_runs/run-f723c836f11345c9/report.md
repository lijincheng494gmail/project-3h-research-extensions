# Local experiment receipt

Actual status: Run or output validation failed (failed)
Process exit code: 1; output validation: failed

allocated None, attempted None, completed None, valid None, scored None, failed None, denominator None. null means unknown.

Run: run-f723c836f11345c9; approved plan: 3ea5e55ca776f134
Logs: 05_runs/run-f723c836f11345c9/stdout.log / 05_runs/run-f723c836f11345c9/stderr.log

Failure reason (original detail): nonzero exit or invalid output; execution_summary.json: [Errno 2] No such file or directory: 'execution_summary.json'
Resources are in resources.json; all attempts and partial outputs were retained.

Elapsed time 1.7258 seconds; logs and results 3313 bytes; peak memory was not measured.

- Controlled checks do not replace the host/OS sandbox; approved Python code has the current user permissions.
- network=deny is a policy, not OS network isolation. Read-only input copies do not constrain malicious code with the same permissions.
- Output limits are polled and can overshoot by one interval; memory/GPU usage has no hard cap.
- Process exit and output validation are engineering evidence, not certification of scientific conclusions.

Only the local runner was used; no cloud adapter was called. Researchers retain decisions about later experiments and scientific interpretation.
