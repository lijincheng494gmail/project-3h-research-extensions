# 方向一：捕食机制比较 / Predation mechanism comparison

## 研究问题 / Research question
改变捕食方式后，哪些共存、稳定和环境变化结论保持，哪些改变？

## 研究设计 / Research design
保持猎物弱 Allee 增长；对照原 Foraging-arena、LV、Holling II、Beddington-DeAngelis。在相同数值情景下进行配对积分、候选平衡点和环境承载量扫描。用四场真实藻类-轮虫观测做二级的未见实验下一步预测比较。

## 本轮数值观察 / Numerical observations
Pilot ran 216 synthetic trajectories across 18 scenarios and 4 response functions. Numerical equilibrium candidates: 72. Real ecological next-step tests: 20 model/baseline scores; test error table is in results/ecological_real_next_step_scores.csv.

No generated time series is being used as proof of a periodic orbit or global theorem.


## 下一步 / Next experiments
Codex 全量阶段：对每个模型完成正性/有界性/持久性、根数、局部与全局稳定、富营养化和分岔的解析条件；加入 Ratio-dependent 的边界处理；验证与经典论文对应的生态参数情景。

## 数据和结论范围 / Evidence status
模拟参数为无量纲假设情景；C1–C4 为真实时间观测，含培养装置机制；根为数值候选。
