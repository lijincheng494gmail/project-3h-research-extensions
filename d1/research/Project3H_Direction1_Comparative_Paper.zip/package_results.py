"""Pack generated evidence, report, config, logs, and reproducibility code."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import hashlib, json, os
ROOT=Path(__file__).resolve().parent
package_name=ROOT.name+'_RESULTS.zip'
out=ROOT/'deliverables'/package_name
out.parent.mkdir(parents=True,exist_ok=True)
keep=['reports','results','figures','logs','references','data/provenance',
      'README_START_HERE.md','AGENTS.md','RESEARCH_PLAN.md',
      'run.sh','run_experiment.py','package_results.py','requirements.txt','CODEX_START_PROMPT.txt',
          'src','tests','configs','data/real','data/synthetic','data/source',
          'run_research.py','reproduce_all.sh','render_report.py','verify_results.py','requirements.lock.txt',
          'paper','MASTER_SCOPE.md','run_master.py','build_paper.py','verify_master.py']
sha={}
with ZipFile(out,'w',ZIP_DEFLATED) as z:
    for rel in keep:
        p=ROOT/rel
        src=p.rglob('*') if p.is_dir() else [p]
        for f in src:
            if not f.is_file() or '__pycache__' in str(f) or f.name.startswith('.'): continue
            if 'paper' in f.relative_to(ROOT).parts and f.suffix in ['.aux','.log','.out','.toc','.synctex','.gz']:continue
            if f.stat().st_size > 25_000_000:
                print('Skipped file >25 MB (link/provenance kept):',f.relative_to(ROOT));continue
            r=f.relative_to(ROOT)
            if any(s in str(r) for s in ['.venv','deliverables']):continue
            z.write(f,arcname=str(r))
            sha[str(r)]=hashlib.sha256(f.read_bytes()).hexdigest()
    z.writestr('FILE_SHA256.json', json.dumps(sha,indent=2,ensure_ascii=False))
print('Results archive:',out,'files:',len(sha))
