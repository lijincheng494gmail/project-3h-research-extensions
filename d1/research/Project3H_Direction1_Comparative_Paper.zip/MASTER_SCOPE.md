# CODEX MASTER PROMPT — DIRECTION 1
## Comparative Analysis of Predation Mechanisms

### 1. Primary research objective

The original coursework studies a predator–prey model with weak Allee prey growth and a foraging-arena functional response.

Our research asks:

**Which dynamical properties of the original model are shared by other predator–prey models, and which properties depend on the particular predation mechanism?**

This is a comparative study of predation mechanisms. The research must remain centred on this question.

Do not change the research objective to a study of three positive equilibria, Hopf bifurcation, Bogdanov–Takens bifurcation, or any other individual finding.

Such findings are important results within the comparison, but they do not replace the original research question.

### 2. Models to compare

Use the following model definitions consistently:

| Model | Predation mechanism |
|---|---|
| P0 | Original foraging-arena model |
| P1 | Lotka–Volterra |
| P2 | Holling Type II |
| P3 | Beddington–DeAngelis |
| P4 | Ratio-dependent |

P0 must remain the exact original coursework model.

Keep the original weak Allee prey growth mechanism when comparing predation functions.

Use a common mathematical framework where possible. Explain the assumptions and parameter mappings required for fair comparisons.

Do not silently replace the original model with a modified equation.

### 3. Research hypotheses

Investigate the following explanations:

H1. Some dynamical properties are shared across different predation mechanisms.

H2. Prey density limitation may explain some common long-term behaviours.

H3. Predator interference may change coexistence and stability.

H4. Weak Allee growth and predator interference may jointly influence the dynamics.

H5. Multiple ecological mechanisms may jointly determine long-term behaviour.

These hypotheses define the research programme. Test them systematically, including outcomes that do not support them.

### 4. Required mathematical comparisons

For every model P0–P4, investigate:

1. Positivity, boundedness and permanence.
2. Equilibria, including existence, number and uniqueness conditions.
3. Local stability of equilibria.
4. Global stability.
5. The paradox of enrichment.
6. Bifurcation structure and parameter-dependent transitions.
7. Ecological interpretation.

Use a common comparison matrix covering all five models and all seven questions.

Every cell must contain a mathematical result, its parameter conditions, and a reference to supporting evidence.

If a full general result cannot be established, report the strongest verified result and precisely identify the remaining parameter cases. Do not mark a partial result as complete.

### 5. Experimental programme

Complete the following experiments.

**Experiment A — Common and mechanism-dependent properties**

Compare P0–P4 under matched ecological conditions.

Determine which mathematical results remain unchanged when the predation function changes.

Identify the properties that differ between models and explain the mathematical reasons for these differences.

**Experiment B — Controlled mechanism comparisons**

Separate prey handling saturation and predator interference wherever the model family permits.

Compare the effects of each mechanism individually and jointly.

Study how these mechanisms interact with weak Allee growth.

**Experiment C — Enrichment and bifurcation**

Vary prey carrying capacity and relevant predation parameters.

Calculate equilibrium branches, stability changes, and bifurcation conditions.

Generate numerical phase portraits, bifurcation diagrams and time series that illustrate the analytical results.

**Experiment D — Ecological parameter studies**

Review the empirical parameter sources suggested in the coursework, including Tanner and related literature.

Map literature parameters to the model definitions, including units and biological meaning.

Use defensible ecological parameter sets for simulations.

Where suitable time-series data are available, compare model predictions using the same training and testing conditions.

### 6. Research integrity and validation

Reopen and examine the original coursework PDF, previous analytical reports, code and experiment results.

Reproduce existing calculations before extending them.

Verify equilibrium solutions by substitution into the original equations.

Independently verify important stability, bifurcation and normal-form calculations.

Use numerical continuation where appropriate.

Distinguish exact analytical results, numerical evidence and empirical findings.

Preserve negative findings and mathematical non-existence results.

Do not claim novelty solely because a calculation has been completed. Compare the main mathematical findings against relevant published literature.

### 7. Paper structure and writing

Write one complete English research paper:

- Abstract
- Introduction
- Results
- Discussion
- Methods
- References
- Detailed Appendix / Supplementary Information

The Introduction must establish the original model, the new research question, the five hypotheses and the comparative study design.

The Results must begin with the complete P0–P4 comparison, organised around the seven common research questions.

Then explain which properties are shared, which depend on particular mechanisms, and which arise from interactions.

Do not reorganise the entire Results section around one interesting bifurcation or equilibrium example.

Use clear, natural academic English, approximately IELTS 6–7 in language complexity. Prefer short and medium sentences, accurate technical terms and direct explanations.

Present the actual finding first. Place detailed mathematics in Methods and the Appendix.

Separate positive findings from results that did not meet expectations where useful.

Avoid defensive writing, repeated disclaimers, inflated claims and generic AI-style academic prose.

### 8. Required deliverables

Produce:

1. Final English research paper PDF.
2. Complete P0–P4 × seven-question comparison matrix.
3. Full mathematical derivations and verified proofs.
4. Numerical phase portraits, time series and bifurcation diagrams.
5. Parameter tables and literature references.
6. Reproducible Python code and run.sh.
7. All numerical and empirical result tables.
8. Research completion and verification matrix.

Package all deliverables into one ZIP file.

### 9. Final acceptance condition

The research is complete only when the paper systematically answers the original comparative research question.

A collection of interesting mathematical findings is not a substitute for the required five-model comparison.

Do not silently reduce the original research scope to make the paper easier to complete.