# Direction 1 | Comparative Predation Mechanisms — Research Plan

## Background / 研究背景
Original teacher Project 3H Model (1.1) studies weak-Allee prey and predator foraging interference, asking about permanence, equilibria, local/global stability, enrichment, bifurcations and ecological explanation. The random white/colored noise extension (vii) is **cancelled by the teacher**. The *equations* omit h, despite prose mentioning competition; any `-h*y²` term must be explicitly an extension.

## Research question / 研究问题
不同捕食函数下，原模型共存、稳定性和分岔结果哪些属于共同规律？

## Hypotheses / 假说
1. H1: Some coexistence/stability results are shared across response functions.
2. H2: Prey self-limitation explains some shared dynamics, test via a nested prey-growth ablation in extension (not the primary comparison).
3. H3: Predator interference changes stability and recovery, even when invasion threshold is matched.
4. H4: Weak-Allee and interference can interact.
5. H5: Joint mechanisms may produce behaviors absent when either component is disabled.

## Model design / 模型设计
Fixed weak-Allee prey growth, compare the teacher's original FA predation against Lotka–Volterra, Holling Type II and Beddington–DeAngelis. Optional fifth ratio-dependent model with carefully defined singular boundary.

### Four response functions in the primary run

Use unified prey growth `g(x)=r*x*(1-x/K)*(1+alpha*x)` and prey loss `P`, predator gain `e*P`:

- P0 original (FA): `a*x*y/(1+c*y)` (a=m/beta, c=1/beta)
- P1 LV: `a*x*y`
- P2 Holling II: `a*x*y/(1+b*x)`
- P3 Beddington–DeAngelis: `a*x*y/(1+b*x+c*y)`
- P4 Ratio-dependent extension: `a*x*y/(x+c*y)` with singular origin handled separately, not in the same low-origin smoothness proof.

**Do not accidentally count replacing weak-Allee with logistic as a predation-model comparison**; prey growth is fixed in main experiment. Keep the user-provided 5 hypothesis structure.

## Experiments / 实验方案
1. Stage A / mathematics: compute positivity, boundedness, permanence, nonnegative equilibria, root count and local stability for each main response. Derive invasion thresholds and numerical-equilibrium cross-check. Use proof if declaring global stability; numerics alone are not a proof.
2. Stage B / controlled contrasts: use common r,K,alpha,e,d,z0 and normalize response functions to the same low-predator predation at a chosen reference prey density; independently sweep prey saturation b, predator interference c and alpha. Report normalized parameter values and exact mapping to m,beta.
3. Stage C / enrichment and bifurcation: vary K (and separate 2D b,c or alpha,c grids), follow all interior equilibrium branches via continuation; compute Jacobian eigenvalues, detect candidate changes, confirm events with analytic conditions or validated local conditions. Distinguish cycles from long transients with longer horizon, multiple initial states and convergence tests.
4. Stage D / ecological grounding: start with teacher references (Tanner / hare-lynx, muskrat-mink, moose-wolf). For each reference, record original parameter definitions, units, uncertainty, and whether transferable. Add real held-experiment benchmark using bundled C1-C4 algae-rotifer observations. Never present the pilot assumed parameters as Tanner estimates.

## Dataset status / 数据说明
Bundled real C1–C4 chemostat time series supports testing, but data from Tanner or hare/lynx must be recovered, matched, and documented separately.

## Completion checklist / 验收要求
- [ ] Four main response functions, the precise baseline mapping, plus ratio-dependent separately if feasible; keep original weak-Allee term throughout main comparisons.
- [ ] One comparison matrix crossing at least 4 functions and six course questions (permanence, equilibria, local/global stability, enrichment, bifurcations, ecology). Cite proof or specify open for each cell.
- [ ] At least two parameter scenarios with matched predation at a specified operating point and discussion of fairness.
- [ ] Recalculate the ecology held-experiment results with all 4 experiments and no test leakage.
- [ ] Report analytic and numerical outcomes separately; classify Hopf/BT/saddle-node only after checking nondegeneracy and admissible positive parameters.

## Required reporting fields / 结果格式

Each claim must include: [research question; exact model and parameter/units; real or synthetic; data split; evidence table/figure; interpretation; checked limitations if material]. Report **positive findings** and **unexpected or negative findings** in separate sections. Write straightforward English (B2–lower C1) and Chinese; no defensive filler or automatic inflated claims.

**Do not invent 'all 7 questions solved' just because numerical trajectories completed.** Global-stability and permanence proofs, true limit cycles and bifurcation non-degeneracy require explicit mathematics and tests; label numerical candidates as candidates.
