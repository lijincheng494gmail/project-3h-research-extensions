"""Check the numerical statements directly against the preserved study release. No model fitting."""
import csv
import hashlib
import io
import json
from collections import Counter
from itertools import product
from pathlib import Path
from statistics import mean
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parent
MODELS = [f"M{i}" for i in range(6)]
ARMS = ["C1", "C2", "C3", "C4"]
FRAME = "Direction2_General_Comparison_Research_Package.zip"
ORDERING = "prior/Direction2_Competition_Ordering_Theorem_Package.zip"
SIX = "previous_study/Direction2_SixModel_Paper_Package_20261118.zip"

def digest(data):
    return hashlib.sha256(data).hexdigest()

def data(stem):
    with (ROOT / "evidence" / (stem + ".csv")).open(newline="") as stream:
        return list(csv.DictReader(stream))

def preservation():
    payload = (ROOT / "original" / FRAME).read_bytes()
    expected = ["c477339669b4ef5b0aa13e241544563e9ee4a77bd4fde1bfe79ae9daf33d234b",
                "e0a09a10195dec00f54a43d461fd1aa3a0f0d28c394ea85f6c947aea9fb5c1c4",
                "4339f43ddfab3f37978a12437123ec4aba54041ea156629657a29ad030d66c8c"]
    assert digest(payload) == expected[0]
    with ZipFile(io.BytesIO(payload)) as general:
        order_bytes = general.read(ORDERING)
        assert digest(order_bytes) == expected[1]
        assert general.read("GENERAL_COMPARISON_THEOREM.pdf") == (ROOT/"original/GENERAL_COMPARISON_THEOREM.pdf").read_bytes()
        for folder in ["data", "figures", "theory", "numerical", "literature", "audit"]:
            for f in (ROOT / "reports" / folder).rglob("*"):
                if f.is_file():
                    assert f.read_bytes() == general.read(f.relative_to(ROOT/"reports").as_posix()), f
    with ZipFile(io.BytesIO(order_bytes)) as order:
        six_bytes = order.read(SIX)
        assert digest(six_bytes) == expected[2]
        assert order.read("COMPETITION_ORDERING_THEOREM.pdf") == (ROOT/"original/COMPETITION_ORDERING_THEOREM.pdf").read_bytes()
    with ZipFile(io.BytesIO(six_bytes)) as six:
        for f in (ROOT/"evidence").glob("*.csv"):
            subdir = "paper" if f.name.startswith("SIX_MODEL_") else "results"
            assert f.read_bytes() == six.read(f"{subdir}/{f.name}"), f.name
        for f in (ROOT/"figures").iterdir():
            assert f.read_bytes() == six.read("figures/" + f.name), f.name
        for name in ["Direction2_SixModel_Paper.pdf", "Direction2_Supplementary_Information.pdf",
                     "Direction2_Comparison_Matrix.pdf"]:
            assert six.read("paper/" + name) == (ROOT/"original"/name).read_bytes(), name
        for name in ["comparison_matrix.tex", "references.tex", "bifurcation_table.tex", "shock_table.tex",
                     "interaction_table.tex", "real_table.tex", "global_summary.tex",
                     "root_classification_examples_table.tex", "paired_competition.tex"]:
            assert six.read("paper/" + name) == (ROOT/"paper"/name).read_bytes(), name
    return expected

def recovery():
    key = lambda row: (row["model"], row["perturbed_population"], float(row["reduction_fraction"]))
    shocks = {key(row):row["recovered"] for row in data("extended_shock_recovery")}
    cert = data("extended_shock_lyapunov_certificates")
    assert len(shocks) == len(cert) == len({key(r) for r in cert}) == 48
    assert all(shocks[key(r)] == r["observed_recovery"] for r in cert)
    counts = Counter((r["sufficient_guaranteed_return"], r["observed_recovery"]) for r in cert)
    assert counts == {("True","True"):44, ("False","True"):1, ("False","False"):3}
    assert [key(r) for r in cert if (r["sufficient_guaranteed_return"],r["observed_recovery"]) == ("False","True")] == [("M5","prey",0.6)]
    return {"shocks":48, "observed_recoveries":45, "recovered_with_certificate":44,
            "recovered_without_certificate":"M5, prey reduction 60%", "no_recovery_by_horizon":3}

def interactions():
    groups = {}
    for r in data("paper_interaction_grid"):
        positive = float(r["h"]) > 0
        assert float(r["h"]) >= 0
        label = f'{r["scaling"]}/{r["growth"]}/' + ("positive h" if positive else "zero h")
        counts = groups.setdefault(label,Counter())
        if r["valid_largest_stable_equilibria"] == "True":
            v = float(r["interaction_predator"])
            counts["negative" if v < 0 else "positive" if v > 0 else "zero"] += 1
        else:
            assert r["interaction_predator"] == ""
            counts["undefined"] += 1
    for scaling,growth in product(["same_r","matched_reference_growth"], ["strong","weak"]):
        same_strong = (scaling,growth) == ("same_r","strong")
        assert groups[f"{scaling}/{growth}/positive h"] == ({"positive":40,"negative":1000,"undefined":360}
            if same_strong else {"negative":1400})
        assert groups[f"{scaling}/{growth}/zero h"] == ({"zero":26,"undefined":9} if same_strong else {"zero":35})
    return groups

def forecasts():
    scores = {(r["held"],r["model"]):r for r in data("real_benchmark_scores")}
    assert len(scores) == 36
    assert all(float(scores[c,m]["test_nrmse"]) < float(scores[c,"persistence"]["test_nrmse"])
               for m,c in product(MODELS,ARMS))
    means = {col:{m:mean(float(scores[c,m][col]) for c in ARMS)
                  for m in MODELS+["persistence","training_mean","training_drift"]}
             for col in ["test_nrmse","free_trajectory_nrmse"]}
    one,free = means["test_nrmse"],means["free_trajectory_nrmse"]
    assert min(MODELS,key=one.get) == "M3" and min(MODELS,key=free.get) == "M1"
    assert round(one["M3"],4) == 0.8825 and round(one["persistence"],4) == 1.0403
    assert round(free["M1"],4) == 1.0376 and round(free["training_mean"],4) == 1.0370
    cycles = [r for r in data("real_cycle_metrics") if r["forecast_mode"]=="free" and r["model"] in MODELS]
    assert len(cycles) == 48 and {(r["held"],r["model"],r["population"]) for r in cycles} == set(product(ARMS,MODELS,["prey","predator"]))
    assert all(float(r["late_amplitude_A90"]) < float(r["amplitude_floor"]) and r["late_amplitude_above_floor"] == "False" for r in cycles)
    observed = data("real_cycle_observed")
    assert len(observed) == 8 and sum(r["period_status"] == "descriptive_period_estimable" for r in observed) == 3
    return {"all_24_one_step_model_experiment_comparisons_below_persistence":True,"experiment_weighted_means":means,
            "free_run_late_amplitudes_below_floor":len(cycles),"observed_periods_passing_screen":3}

def matrix():
    rows = data("SIX_MODEL_SEVEN_QUESTION_MATRIX")
    assert len(rows) == 42 and {(r["model"],r["question_id"]) for r in rows} == set(product(MODELS,[f"Q{i}" for i in range(1,8)]))
    partial = sorted(r["model"] for r in rows if r["question_id"]=="Q4" and r["verification_status"].startswith("partial"))
    assert partial == ["M0","M2","M4","M5"]
    counts = Counter(r["verification_status"] for r in rows)
    assert sorted(counts.values()) == [4,4,34]
    return {"cell_count":len(rows),"scope_status":counts,"partial_global_Q4_models":partial}

if __name__ == "__main__":
    print(json.dumps({"preserved_release_sha256":preservation(),"recovery":recovery(),"interaction_counts":interactions(),
                      "empirical_forecasts":forecasts(),"six_by_seven":matrix()},indent=2,sort_keys=True))
