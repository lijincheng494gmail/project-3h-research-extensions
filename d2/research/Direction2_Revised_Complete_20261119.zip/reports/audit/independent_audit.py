"""Independent checks for the frozen competition-ordering release.

Use exact rational arithmetic for endpoints and the starting data. Integrate
the tangent to the two equilibrium balances in (x,y,h) for a separate numerical
implementation. The previous release's continuation code is never imported.
"""
from pathlib import Path
import csv
import hashlib
import json

import numpy as np
import sympy as sp
from scipy.integrate import solve_ivp
from scipy.optimize import brentq

HERE = Path(__file__).resolve().parent
I = HERE / 'inputs'
X, Y, H = sp.symbols('x y h', real=True)
Q = sp.Rational


def rows(name):
    with (I / name).open(newline='') as stream:
        return list(csv.DictReader(stream))


def rational_model(row):
    keys = ['x0','y0','K','A_common_design','alpha_common_design','beta','m','e','d']
    x0,y0,K,A,alpha,beta,m,e,d = [Q(row[k]) for k in keys]
    shape = (1-X/K) * {'L':1,'W':1+alpha*X,'S':X/A-1}[row['law']]
    q = m*y0/(beta+y0)
    r = q/shape.subs(X,x0)
    g = sp.expand(r*shape)
    prey_balance = g-m*Y/(beta+Y)
    pred_balance = e*m*X/(beta+Y)-d-H*Y
    balances = sp.Matrix([prey_balance,pred_balance])
    # Positive row factors restore the Jacobian of the full ODE at equilibrium.
    jac = sp.diag(X,Y)*balances.jacobian((X,Y))
    tangent = list(balances.jacobian((X,Y,H)).row(0).cross(
        balances.jacobian((X,Y,H)).row(1)))
    z0 = {X:x0,Y:y0,H:0}
    assert balances.subs(z0) == sp.zeros(2,1)
    trace = sp.factor(jac.trace())
    det = sp.factor(jac.det())
    assert trace.subs(z0)<0 and det.subs(z0)>0
    slope = (tangent[1]/tangent[2]).subs(z0)
    checks = [r, g.subs(X,x0), g.diff(X).subs(X,x0), trace.subs(z0), det.subs(z0), slope]
    assert checks == [Q(row[k]) for k in ('r_growth','g_at_x0','g_prime_at_x0','trace0','det0','dy_dh0')]
    assert sp.cancel(X*Y*tangent[2]-det)==0
    p = m*Y/(beta+Y)
    C = (beta+Y)*(d+H*Y)/(e*m)
    assert sp.cancel(pred_balance.subs(X,C))==0
    gap = p.diff(Y)-g.diff(X).subs(X,C)*C.diff(Y)
    assert sp.cancel(det.subs(X,C) - C*Y*(e*m/(beta+Y))*gap)==0
    return (x0,y0,K,g,beta,m,e,d,balances,jac,trace,det,tangent)


def roots_inside(expr,left,right):
    numerator = sp.Poly(sp.cancel(expr).as_numer_denom()[0],X)
    while numerator.eval(left)==0:
        numerator = numerator.exquo(sp.Poly(X-left,X))
    while numerator.eval(right)==0:
        numerator = numerator.exquo(sp.Poly(X-right,X))
    count = numerator.count_roots(left,right)
    # A separate isolation method returns intervals and multiplicity.
    isolations = [(a,b,k) for (a,b),k in numerator.intervals(
        inf=left,sup=right,eps=Q(1,10**24))]
    assert len(isolations)==count
    return isolations


def exact_endpoint(model):
    x0,_,K,g,beta,m,e,d,_,_,trace,det,_ = model
    y = sp.cancel(beta*g/(m-g))
    h = sp.cancel((e*m*X/(beta+y)-d)/y)
    projected = {label:sp.cancel(expr.subs({H:h,Y:y},simultaneous=True))
                 for label,expr in [('trace',trace),('determinant',det)]}
    tests={**projected,'growth zero':g,'feeding cap':m-g}
    candidates = sorted((a,b,k,label) for label,expr in tests.items()
                        for a,b,k in roots_inside(expr,x0,K))
    if not candidates:
        assert sp.limit(y,X,K,dir='-')==0 and sp.limit(h,X,K,dir='-')==sp.oo
        return {'kind':'unbounded','h':'infinity'}
    a,b,k,label = candidates[0]
    assert label=='determinant' and k==1 and 0<g.subs(X,a)<m
    assert projected['trace'].subs(X,a)<0 and not roots_inside(projected['trace'],a,b)
    assert h.diff(X,2).subs(X,a)<0 and not roots_inside(h.diff(X,2),a,b)
    x_mid=(a+b)/2
    return dict(kind='simple fold',x=float(x_mid),x_exact_isolation=[str(a),str(b)],
                y=float(y.subs(X,x_mid)),h=float(h.subs(X,x_mid)),
                trace=float(projected['trace'].subs(X,x_mid)))


def compare_arclength(model,records,event):
    x0,y0,_,_,_,_,_,_,f,j,_,_,vec = model
    f_num=sp.lambdify((X,Y,H),f,'numpy')
    jac=sp.lambdify((X,Y,H),j,'numpy')
    cross=sp.lambdify((X,Y,H),vec,'numpy')
    def unit_tangent(_, state):
        v=np.asarray(cross(*state),dtype=float).reshape(3)
        return v/np.linalg.norm(v)
    hs = [float(v['h']) for v in records] if records else []
    target = max(hs or [1.])
    def stop(_,state):
        return cross(*state)[2] if event['kind']=='simple fold' else state[2]-target
    stop.direction = -1 if event['kind']=='simple fold' else 1
    stop.terminal=True
    sol=solve_ivp(unit_tangent,[0,50],[float(x0),float(y0),0.],method='DOP853',
                  rtol=2e-12,atol=3e-14,max_step=.035,events=stop,dense_output=True)
    assert sol.success and len(sol.t_events[0])==1
    terminal = sol.y_events[0][0]
    arc_end=sol.t_events[0][0]
    fold_error=None
    if event['kind']=='simple fold':
        fold_error=float(max(abs(terminal-np.array([event['x'],event['y'],event['h']]))))
        assert fold_error<1e-9
    coord_error=eigen_error=residual=0.
    for r in records:
        h=float(r['h'])
        if h==0: state=sol.y[:,0]
        elif abs(h-terminal[2])<2e-13: state=terminal
        else:
            arc=brentq(lambda s:sol.sol(s)[2]-h,0,arc_end,xtol=3e-15)
            state=sol.sol(arc)
        saved=np.array([float(r['prey']),float(r['predator'])])
        coord_error=max(coord_error,float(max(abs(state[:2]-saved))))
        residual=max(residual,float(max(abs(np.ravel(f_num(*state))))))
        eigen=np.linalg.eigvals(jac(*state))
        listed=np.array([complex(float(r['eigen1_real']),float(r['eigen1_imag'])),
                         complex(float(r['eigen2_real']),float(r['eigen2_imag']))])
        eigen_error=max(eigen_error,float(min(max(abs(eigen-listed)),max(abs(eigen-listed[::-1])))))
        if r['status']=='stable':
            assert np.max(eigen.real)<0
    assert coord_error<1e-9 and eigen_error<1e-8 and residual<1e-9
    return dict(compared_rows=len(records),max_abs_coordinate_error=coord_error,
                max_eigenvalue_error=eigen_error,max_balance_residual=residual,
                endpoint_max_abs_error=fold_error)


def main():
    manifest=json.loads((I/'SOURCE_HASHES.json').read_text())
    for p in I.glob('*.csv'):
        assert hashlib.sha256(p.read_bytes()).hexdigest()==manifest[p.name]
    parameters=rows('exact_calibrations.csv')+rows('additional_fold_calibration.csv')
    records=rows('continuation_paths.csv')
    previous={(r['case'],r['law']):r for r in rows('branch_endpoints.csv')}
    results=[]
    for row in parameters:
        case,law=row['case'],row['law']
        model=rational_model(row)
        event=exact_endpoint(model)
        reference=previous.get((case,law))
        if reference:
            if event['kind']=='simple fold':
                assert abs(float(reference['h_endpoint'])-event['h'])<1e-12
                assert abs(float(reference['x_endpoint'])-event['x'])<1e-12
            else:
                assert reference['h_endpoint']=='inf'
        elif law=='S':
            assert abs(event['h']-.029852869745861)<1e-12
        selected=[r for r in records if (r['case'],r['law'])==(case,law)]
        comparisons=compare_arclength(model,selected,event)
        results.append(dict(case=case,law=law,dy_dh_0=row['dy_dh0'],endpoint=event,**comparisons))
    assert sum(r['compared_rows'] for r in results)==2709
    assert sum(r['endpoint']['kind']=='simple fold' for r in results)==2
    evidence=dict(status='pass',method='normalized tangent to the two per-capita balances, arclength DOP853',
                  rational_calibrations=len(results),mathematical_families=4,archived_rows=2709,
                  tolerances={'rtol':2e-12,'atol':3e-14,'max_arclength_step':.035,
                              'exact_root_isolation_width':'1e-24'},branches=results)
    dest=HERE/'INDEPENDENT_AUDIT_RESULTS.json'
    dest.write_text(json.dumps(evidence,indent=2)+'\n')
    print('PASS',len(results),'matched calibrations and 2709 independent continuation comparisons')
    for key in ['max_abs_coordinate_error','max_eigenvalue_error','max_balance_residual']:
        print(key,max(r[key] for r in results))


if __name__=='__main__':
    main()
