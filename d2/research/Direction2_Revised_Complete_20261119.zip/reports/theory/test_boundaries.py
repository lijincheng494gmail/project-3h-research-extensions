import unittest

import sympy as sp

from check_cases import H, X, Y, equilibria_jacobian, profiles, Q


class BoundaryTests(unittest.TestCase):
    def test_matching_the_slope_does_not_match_the_second_response(self):
        # Recover derivatives by implicit differentiation in (y,h), independent
        # of the prey-coordinate continuation used to illustrate the two cubics.
        chart=(1+Y)*(2+H*Y)/2
        slopes=[]
        curvatures=[]
        for coefficient in (Q(1,4), Q(1,2)):
            growth=(3-X)*(1+coefficient*(X-2)**2)/2
            residual=growth.subs(X,chart)-Y/(1+Y)
            point={Y:1,H:0}
            derivative=lambda *variables:residual.diff(*variables).subs(point)
            m=-derivative(H)/derivative(Y)
            n=-(derivative(H,H)+2*derivative(H,Y)*m+derivative(Y,Y)*m*m)/derivative(Y)
            slopes.append(m)
            curvatures.append(n)
        self.assertEqual(slopes,[Q(-2,3)]*2)
        self.assertEqual((curvatures[1]-curvatures[0])/2,Q(1,54))

    def test_growth_recrossing_is_on_stable_equilibria(self):
        for growth, response in [(sp.Integer(1),0),(1+(X-1)*(2-X)/16,Q(-1,10))]:
            v,j=equilibria_jacobian(2*X*Y/(1+Y),growth)
            point={X:2,Y:1,H:1}
            self.assertEqual(v.subs(point),sp.zeros(2,1))
            j=j.subs(point)
            self.assertLess(j.trace(),0)
            self.assertGreater(j.det(),0)
            self.assertEqual((j.inv()*sp.Matrix([0,1]))[1],response)

    def test_growing_total_predation_does_not_order_prey(self):
        records=[profiles(X*Y**2, 1+slope*(X-1)) for slope in [Q(-7,4),Q(-3,2)]]
        low,high=records
        for point in records:
            self.assertTrue(min(point['Px'],point['Py'],point['det'],-point['trace'])>0)
        self.assertTrue(high['yh']>low['yh'] and high['xh']<low['xh'])

    def test_stability_not_required_for_positive_determinant_comparison(self):
        # At h=1/4, the first LV branch is at x=5/4. The upward
        # growth shift displaces the selected second root strictly right.
        t=X-1
        for extra in (0,Q(1,16)):
            g=1-t/4+t*t+extra*t
            curve=(X-1)/g
            poly=sp.Poly(sp.together(4*(X-1)-g),X)
            roots=poly.intervals(inf=Q(5,4),sup=Q(4,3),eps=Q(1,10**12))
            self.assertEqual(len(roots),1)
            (lo,hi),_=roots[0]
            _,jac=equilibria_jacobian(X*Y,g)
            sub={Y:g,H:curve}
            self.assertGreater(jac.trace().subs(sub).subs(X,lo),0)
            self.assertGreater(jac.det().subs(sub).subs(X,hi),0)
            if extra:self.assertGreater(lo,Q(5,4))
            else:self.assertEqual(lo,Q(5,4))


if __name__=='__main__':
    unittest.main()
