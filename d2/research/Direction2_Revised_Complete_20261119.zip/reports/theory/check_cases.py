"""Exact witnesses and functional-response checks independent of the figure code."""
from pathlib import Path
import csv
import json
import sympy as s

ROOT = Path(__file__).resolve().parents[1]
X, Y, H = s.symbols("x y h", positive=True)
Q = s.Rational


def equilibria_jacobian(P, growth):
    vector = s.Matrix([X*growth-P, P-Y-H*Y**2])  # e=d=1 in these witnesses
    return vector, vector.jacobian((X, Y))


def profiles(P, growth, x0=1, y0=1):
    field, jac = equilibria_jacobian(P, growth)
    point = {X:x0, Y:y0, H:0}
    assert field.subs(point)==s.zeros(2,1)
    base = jac.subs(point)
    tangent=base.inv()*s.Matrix([0,y0**2])
    return dict(trace=base.trace(),det=base.det(),xh=tangent[0],yh=tangent[1],
                Px=P.diff(X).subs(point),Py=P.diff(Y).subs(point))


def check_identities():
    ax,gap,b,c,d,y = s.symbols("a v b c d y")
    D=ax*d-b*c
    new=(ax+gap)*d-b*c
    assert s.factor((ax+gap)/new-ax/D-(-b*c)*gap/(D*new))==0
    assert s.factor((ax*(-d/c)+b)+D/c)==0
    # R_y and the Jacobian expression use the same two rows.
    return ["Jacobian cofactor difference", "scalar residual orientation"]


def solve_rectangles():
    checks={}
    t=X-1
    for name,P,slopes,expected in [
        ("decreasing_predator_chart",X*Y**2,[Q(-7,4),Q(-3,2)],[(8,-7),(4,-3)]),
        ("loss_of_positive_Py",X*Y*s.exp(-2*(Y-1)),[-2,-1],[(Q(-1,3),Q(-2,3)),(-1,-1)]),
        ("loss_of_positive_Px",2*X*s.exp(-2*(X-1))*Y/(1+Y),[-5,-4],[(Q(1,2),-3),(1,-4)]),
    ]:
        rows=[profiles(P,1+u*t) for u in slopes]
        assert [(r["xh"],r["yh"]) for r in rows]==expected
        assert all(r["det"]>0 and r["trace"]<0 for r in rows)
        checks[name]=[{k:str(v) for k,v in row.items()} for row in rows]
    return checks


def nozero(expr, left, right):
    n,d=s.cancel(expr).as_numer_denom()
    for part in (n,d):
        assert s.Poly(part,X).count_roots(left,right)==0,(expr,left,right)


def positive_on(expr,left,right):
    nozero(expr,left,right)
    assert expr.subs(X,left)>0


def recross():
    # Original P=2xy/(1+y), d=e=1. Prey x parameter gives exact equilibrium.
    checks={}
    gx=[s.Integer(1),1+(X-1)*(2-X)/16]
    for name,g in zip(("constant","recrossing"),gx):
        y=s.cancel(g/(2-g))
        h=s.cancel((2*X/(1+y)-1)/y)
        _,jac=equilibria_jacobian(2*X*Y/(1+Y),g)
        tr=jac.trace().subs({Y:y,H:h})
        det=jac.det().subs({Y:y,H:h})
        for item in (y,2-g,h.diff(X),-tr,det):
            positive_on(item,1,Q(9,4))
        assert h.subs(X,1)==0 and h.subs(X,2)==y.subs(X,2)==1
        slope=s.factor((y.diff(X)/h.diff(X)).subs(X,2))
        checks[name]=dict(h_end=str(h.subs(X,Q(9,4))),trace_at_contact=str(tr.subs(X,2)),dy_dh_at_contact=str(slope))
    return checks


def trace_crossing():
    checks={}
    for name,extra in [("first",0),("second",Q(1,16))]:
        z=X-1
        g=1+(extra-Q(1,4))*z+z**2
        P=X*Y
        y=g
        h=z/g
        _,jac=equilibria_jacobian(P,g)
        tr=s.factor(jac.trace().subs({Y:y,H:h}))
        det=s.factor(jac.det().subs({Y:y,H:h}))
        positive_on(det,1,Q(4,3))
        positive_on(h.diff(X),1,Q(4,3))
        assert tr.subs(X,1)<0 and tr.subs(X,Q(5,4))>0
        assert len(s.Poly(tr,X).intervals(inf=1,sup=Q(5,4)))==1
        assert h.subs(X,Q(4,3))>Q(1,4)
        checks[name]=dict(trace=str(tr),det=str(det),trace_zero_before_x="5/4",
                          positive_determinant_through="4/3",h_max=str(h.subs(X,Q(4,3))))
    return checks


def four_responses():
    rows=[]
    configurations=[("Lotka-Volterra",0,0),("original arena",0,1),
                    ("Holling II",1,0),("Beddington-DeAngelis",1,1)]
    for name,b,c in configurations:
        a=1+b+c
        P=a*X*Y/(1+b*X+c*Y)
        prev={}
        for label,g in [("lower",2-X),("upper",(2-X)*(1+(X-1)**2/8))]:
            y=s.factor((1+b*X)*g/(a-c*g))
            h=s.factor((P.subs(Y,y)/y-1)/y)
            field,jac=equilibria_jacobian(P,g)
            sub={Y:y,H:h}
            assert all(s.factor(v.subs(sub))==0 for v in field)
            tr=s.factor(jac.trace().subs(sub))
            det=s.factor(jac.det().subs(sub))
            # Remove the zero at K and check open-interval signs by exact root counts.
            for expr in [2-X, a-c*g, h.diff(X), -tr, det, y]:
                n,d=s.cancel(expr).as_numer_denom()
                for part in (n,d):
                    polynomial=s.Poly(part,X)
                    for factor in (X-2,X-1):
                        divisor=s.Poly(factor,X)
                        while polynomial.rem(divisor).is_zero:
                            polynomial=polynomial.exquo(divisor)
                    assert polynomial.count_roots(1,2)==0
                assert expr.subs(X,Q(3,2))>0
            assert h.subs(X,1)==0 and y.subs(X,1)==1 and s.limit(h,X,2,dir="-")==s.oo
            for competition in [Q(1,100),Q(1,10),Q(1,2),1,4]:
                eq=s.Poly(s.cancel(h-competition).as_numer_denom()[0],X)
                intervals=eq.intervals(eps=Q(1,10**28),inf=1,sup=2)
                assert len(intervals)==1
                (lo,hi),mult=intervals[0]
                assert mult==1
                mid=(lo+hi)/2
                # Both rational Y profiles are strictly decreasing here. Use endpoints
                # to compare the algebraic predator densities by disjoint bounds.
                positive_on(-y.diff(X),1,Q(2))
                yrange=(y.subs(X,hi),y.subs(X,lo))
                if label=="lower":
                    prev[competition]=(hi,yrange[1])
                else:
                    assert lo>prev[competition][0] and yrange[0]>prev[competition][1]
                rows.append(dict(response=name,law=label,h=str(competition),x=float(mid),y=float(y.subs(X,mid)),
                                 x_lower=str(lo),x_upper=str(hi),y_lower=str(yrange[0]),y_upper=str(yrange[1]),
                                 trace=float(tr.subs(X,mid)),det=float(det.subs(X,mid))))
    return rows


def main():
    rows=four_responses()
    with (ROOT/"theory/four_responses_exact.csv").open("w",newline="") as stream:
        writer=csv.DictWriter(stream,fieldnames=rows[0])
        writer.writeheader()
        writer.writerows(rows)
    report=dict(identities=check_identities(),examples=solve_rectangles(),recrossing=recross(),
                trace_boundary=trace_crossing(),four_feeding_response_rows=len(rows),
                four_response_intervals="all finite h, two cubic/linear matched branches per response",status="pass")
    (ROOT/"theory/exact_checks.json").write_text(json.dumps(report,indent=2)+"\n")
    print(json.dumps(report,indent=2))


if __name__=="__main__":
    main()
