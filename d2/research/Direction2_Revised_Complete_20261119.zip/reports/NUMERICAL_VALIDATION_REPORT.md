# Numerical validation of the comparison

The matched branches reproduce the three-law predator and prey rankings. A separate pair of cubic growth functions has the same value and first derivative at the common start. Its positive equilibrium gap first appears at second order in competition. The figures illustrate these results for dimensionless populations and time. Stability and branch identity were checked at every plotted equilibrium.

## Parameter choices

All examples use the original foraging-arena response with m = β = 1. Each three-law scenario keeps its own K, death rate d, conversion e and competition h common across the three growth laws. The weak shape parameter is α = 1. The strong threshold is A. In each of the two prior scenarios the three rates r calibrate the original growth functions at the common starting point.

| Scenario | K, starting (x₀, y₀) | A, e, d | Growth scales (L, W, S) | Exact initial predator derivatives | Common stable interval |
|---|---|---|---|---|---|
| Mixed initial responses | 10, (4, 1) | 1, 2, 4 | 5/6, 1/6, 5/18 | −1/5, 1/13, 1 | All finite h ≥ 0 |
| Finite strong-branch fold | 4, (1, 1/2) | 1/2, 4, 8/3 | 4/9, 2/9, 4/9 | −9/224, 9/352, 45/32 | 0 ≤ h < 0.05690695209541968… |
| Two cubic functions | 3, (2, 1) | e = d = 2 | c = 1/4, 1/2, as defined below | −2/3 for both | All finite h ≥ 0 |

The first two rows use the parameters of the earlier competition-ordering release. All coordinates, root intervals and stability diagnostics were recomputed from these inputs. In the original numbering the logistic pair is M1/M3, the weak pair M0/M4 and the strong pair M2/M5.

## Five figures

1. **F1_common_growth.** The open circle is the common growth-rate point. For the three original laws, the difference of any two calibrated curves on 0 < x < K has the sign of the difference in their shape slopes multiplied by x − x₀. This gives the S > W > L order to the right and reverses it to the left. Different slopes at the common point are visible in both configurations.
2. **F2_predator_equilibria.** All three predator branches start at the open circle at h = 0. In the mixed case the two Allee populations initially rise and later fall. The bottom panels show adjacent predator gaps on a log scale for positive h. At h = 6 the mixed-case densities in L, W, S order are approximately 0.556352, 0.691496 and 0.771096. Its interval continues to infinity. In the fold case the vertical dotted line and open purple endpoint mark the limit of the common regular stable interval.
3. **F3_prey_equilibria.** In both cases each prey density increases along its own tracked positive branch. The three densities rank S > W > L for positive h in the common stable interval. Lower panels resolve the two adjacent gaps. The fold-case minor separations near the baseline are visible in these panels.
4. **F4_stability_and_fold.** Trace and determinant are shown with both eigenvalue real parts and the absolute imaginary part of the conjugate pair. The larger real part is solid and the smaller real part is dashed. In the fold case the strong-branch determinant reaches zero while the trace is about −0.610302. The excluded endpoint is marked. The change from a complex pair to two real negative eigenvalues occurs earlier and preserves stability. The other two branches stay regular through the displayed range.
5. **F5_equal_tangent_cubic.** The two growth curves have a common tangent and the two predator branches have equal first derivatives at h = 0. The second column shows the growth gap and positive predator gap on separate axes. The dashed line is the small-h leading term. At h = 6 the two predator densities are approximately 0.314650 and 0.319868. The gap remains strictly positive at all finite positive h.

The two examples with infinite intervals are plotted through h = 6. All five figures are available as vector PDFs and PNGs in the `figures/` folder of the [original general comparison archive](../original/Direction2_General_Comparison_Research_Package.zip).

## Exact cubic case

Let t = x − 2 and g_c(x) = (3 − x)(1 + c t²)/2. At x = 2 both functions take value 1/2 and slope −1/2. Their difference equals (3 − x)(x − 2)²/8 for c = 1/2 minus c = 1/4. It is strictly positive for 2 < x < 3. The slope on that interval is [−1 + c(2t − 3t²)]/2 < 0 for both c values, since 2t − 3t² ≤ 1/3. This gives trace < 0 and determinant > 0 on the physical branches. They continue to x = 3 as h tends to infinity.

Differentiating the exact rational equilibrium curves gives the same initial predator response, −2/3, for both cubic growth laws. The second derivatives are 41/27 for c = 1/4 and 14/9 for c = 1/2. The predator density for c = 1/2 exceeds that for c = 1/4 by h²/54 + O(h³) near the start.

## Branch identification and checks

For a given law write Y(x) = g(x)/(1 − g(x)) and H(x) = [e x/(1 + Y(x)) − d]/Y(x). These are rational functions for every case here. Starting at x₀, exact rational root isolation identifies the first possible zero of the trace, determinant, growth, or 1 − g. The rational interval width is at most 10⁻²³. On the initial physical regular segment H′(x) = det(J)/[−J₁₂ Y(x)²] > 0. This makes the segment a single graph over h. A bound at x = K with H → ∞ gives an infinite branch. The simple determinant root at the finite fold has negative trace, positive Y and H″ < 0, certified over its isolating interval. These tests give the fold x ≈ 1.1627137897338922, y ≈ 0.7177596439652578.

To calculate each plotted point, the code independently solves the quadratic predator equation for its positive root at fixed x and h. It then brackets the prey residual in x on the certified branch interval. The Brent solver uses absolute tolerance 10⁻¹⁴ and relative tolerance 2 × 10⁻¹⁵. It samples 181 shared h values per scenario with closer spacing near both ends. It records 1,448 individual equilibria across eight branches. Of these, 1,447 are regular and stable and one is the excluded fold limit. The maximum absolute original-ODE residual was 4.89 × 10⁻¹⁵. The plotted Jacobian comes from a separate complex-step differentiation of the original vector field with step 10⁻²⁰.

A separate test eliminates prey using x = (1 + y)(d + hy)/e. It isolates every positive root of the resulting exact predator polynomial and checks the root on the tracked prey interval. At 29 branch/competition pairs the independent coordinates agreed with the primary solver to an absolute plus relative tolerance of 2 × 10⁻¹³. Another test goes above the strong fold to h = 3/50. A positive root still exists on a different segment, and the tracked solver correctly rejects it. The cubic test checks the equal slopes, exact second-order coefficient and positive gaps. All three tests passed.

## Reproduction and source data

Extract the original general comparison archive and run these commands from its top-level directory using the listed Python dependencies.

```sh
python numerical/figure_data.py
python -m unittest discover -s numerical -p 'test_*.py' -v
```

The source growth curves are in `data/figure_growth_curves.csv`. The complete coordinates, stability values, real and imaginary eigenvalue parts, original-equation residuals, and endpoint labels are in `data/figure_equilibrium_branches.csv`. The rational growth functions and starting quantities are in `data/figure_parameters.csv`. The complete event numerator polynomials and rational isolation intervals are in `data/figure_event_certificates.json`. A root outside the selected segment is listed for auditing and is excluded from the tracked branch. `data/figure_checks.json` records actual run versions, point counts and the largest residual.
