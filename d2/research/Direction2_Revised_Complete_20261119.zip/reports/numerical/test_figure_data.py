"""Independent predator-polynomial checks on the plotted equilibria and the new example."""

import unittest
import numpy as np
import sympy as sp
from figure_data import Branch, CASES, R, X

Y = sp.Symbol("y",real=True)

def predator_roots_on_segment(branch, h):
    """Isolate every positive root at a rational h and retain only the connected prey segment."""
    case=branch.case
    prey=(1+Y)*(case.d+h*Y)/case.e
    poly=sp.Poly(sp.cancel((1+Y)*branch.g.subs(X,prey)-Y),Y)
    kept=[]
    for (lo,hi),mult in poly.intervals(eps=R(1,10**22)):
        if lo<=0:
            continue
        y=(lo+hi)/2
        x=float(prey.subs(Y,y))
        if case.x0<x<branch.endpoint_x:
            kept.append((x,float(y),mult))
    return kept

class FigureVerification(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.paths={case.name:[Branch(case,law,g) for law,g in case.growth().items()] for case in CASES}

    def test_independent_predator_root_isolation(self):
        for case in CASES:
            hs=[R(1,1000),R(1,50),R(1,20)] if case.name=="fold" else [R(1,100),R(1,2),R(6),R(20)]
            for branch in self.paths[case.name]:
                for h in hs:
                    with self.subTest(case=case.name,law=branch.law,h=h):
                        isolated=predator_roots_on_segment(branch,h)
                        self.assertEqual(len(isolated),1)
                        self.assertEqual(isolated[0][-1],1)
                        np.testing.assert_allclose(branch.coordinates(float(h)),isolated[0][:2],rtol=2e-13,atol=2e-13)

    def test_fold_refuses_disconnected_positive_roots(self):
        branch=self.paths["fold"][-1]
        h=R(3,50)
        self.assertGreater(float(h),branch.endpoint_h)
        self.assertEqual(predator_roots_on_segment(branch,h),[])
        with self.assertRaises(ValueError):
            branch.coordinates(float(h))
        C=(1+Y)*(branch.case.d+h*Y)/branch.case.e
        poly=sp.Poly(sp.cancel((1+Y)*branch.g.subs(X,C)-Y),Y)
        # A global root enumerator still finds a physical positive equilibrium beyond the fold.
        other=[float(C.subs(Y,(lo+hi)/2)) for (lo,hi),_ in poly.intervals(eps=R(1,10**16)) if lo>0]
        self.assertTrue(any(branch.endpoint_x<x<branch.case.K for x in other))

    def test_cubic_same_local_response_and_second_order_separation(self):
        lower,upper=self.paths["tangent"]
        gap=sp.factor(upper.g-lower.g)
        self.assertEqual(sp.factor(gap-(3-X)*(X-2)**2/8),0)
        self.assertEqual((lower.d1,upper.d1),(R(-2,3),R(-2,3)))
        self.assertEqual((upper.d2-lower.d2)/2,R(1,54))
        for branch in [lower,upper]:
            self.assertEqual(branch.endpoint_h,np.inf)
        for h in [.002,.01,.25,3.]:
            low=lower.coordinates(h);up=upper.coordinates(h)
            self.assertGreater(up[1],low[1])
            self.assertGreater(up[0],low[0])
        h=.002
        self.assertAlmostEqual((upper.coordinates(h)[1]-lower.coordinates(h)[1])/h**2,1/54,delta=0.0002)

if __name__=="__main__":
    unittest.main(verbosity=2)
