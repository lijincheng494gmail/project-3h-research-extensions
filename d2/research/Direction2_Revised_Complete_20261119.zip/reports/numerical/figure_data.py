"""Rebuild the five comparison figures from their rational model definitions."""

import csv
import json
import platform
from dataclasses import dataclass
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import scipy
from scipy.optimize import brentq
import sympy as sp

ROOT = Path(__file__).resolve().parents[1]
X = sp.Symbol("x", real=True)
R = sp.Rational
COLORS = {"L":"#26769a", "W":"#b65417", "S":"#67458f", "C1":"#287b73", "C2":"#914353"}
NAMES = {"L":"Logistic", "W":"Weak Allee", "S":"Strong Allee", "C1":"c = 1/4", "C2":"c = 1/2"}
CASE_TITLES = {"mixed":"Mixed initial responses", "fold":"Finite strong-branch fold"}
MODELS = {"L":"M1/M3", "W":"M0/M4", "S":"M2/M5", "C1":"cubic 1", "C2":"cubic 2"}

@dataclass(frozen=True)
class Case:
    name: str
    K: int
    x0: int
    y0: sp.Rational
    e: int
    A: sp.Rational
    h_plot: int

    @property
    def d(self):
        return self.e*self.x0/(1+self.y0)

    def growth(self):
        q = self.y0/(1+self.y0)
        base = q*(self.K-X)/(self.K-self.x0)
        if self.name == "tangent":
            return {law:base*(1+c*(X-self.x0)**2)
                    for law,c in (("C1",R(1,4)),("C2",R(1,2)))}
        return {"L":base, "W":base*(1+X)/(1+self.x0), "S":base*(X-self.A)/(self.x0-self.A)}

CASES = [Case("mixed",10,4,R(1),2,R(1),6), Case("fold",4,1,R(1,2),4,R(1,2),1),
         Case("tangent",3,2,R(1),2,R(0),6)]

def save_csv(path, rows):
    with path.open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)

def fractions_with_roots(expr, left, right):
    polynomial = sp.Poly(sp.cancel(expr).as_numer_denom()[0], X)
    inside = []
    for bounds, mult in polynomial.intervals(eps=R(1,10**23)):
        lo,hi=bounds
        assert not lo < left < hi and not lo < right < hi
        if left < lo <= hi < right:
            inside.append((bounds,mult))
    return inside

class Branch:
    def __init__(self, case, law, growth):
        self.case, self.law = case, law
        xf = case.x0
        self.g = sp.factor(growth)
        self.g_num = sp.lambdify(X,self.g,"numpy")
        self.gp_num = sp.lambdify(X,sp.diff(self.g,X),"numpy")
        y = sp.cancel(self.g/(1-self.g))
        h = sp.cancel((case.e*X/(1+y)-case.d)/y)
        self.y_formula, self.h_formula = y,h
        a = X*self.g.diff(X)
        b = -X/(1+y)**2
        c = case.e*y/(1+y)
        v = -y*(case.e*X/(1+y)**2+h)
        trace = sp.cancel(a+v)
        det = sp.cancel(a*v-b*c)
        self.trace,self.det = trace,det
        assert self.g.subs(X,xf) == case.y0/(1+case.y0)
        assert y.subs(X,xf)==case.y0 and h.subs(X,xf)==0
        assert trace.subs(X,xf)<0 and det.subs(X,xf)>0
        assert sp.cancel(h.diff(X)*(-b)*y*y-det)==0
        d1 = sp.cancel(y.diff(X)/h.diff(X))
        self.d1 = sp.factor(d1.subs(X,xf))
        self.d2 = sp.factor((d1.diff(X)/h.diff(X)).subs(X,xf))
        self.roots = {}
        candidates = []
        for name,expr in (("determinant",det),("trace",trace),("zero growth",self.g),("growth equals m",1-self.g)):
            roots = fractions_with_roots(expr,xf,case.K)
            self.roots[name] = {"numerator":str(sp.factor(expr).as_numer_denom()[0]),
                                "isolating_intervals":[[str(a),str(b),int(n)] for (a,b),n in roots]}
            candidates.extend((bounds,name,mult) for bounds,mult in roots)
        self.endpoint_x = float(case.K)
        self.endpoint_h = np.inf
        self.event = "infinite h"
        self.fold_bracket = []
        self.endpoint_trace = None
        if candidates:
            (lo,hi),name,mult = sorted(candidates)[0]
            mid = (lo+hi)/2
            assert name == "determinant" and mult == 1
            # Either no root of the trace/curvature lies in the closed bracket, or its value could change sign.
            for cond in (-trace, -h.diff(X,2),self.g,1-self.g):
                assert not fractions_with_roots(cond,lo,hi)
                assert cond.subs(X,lo)>0 and cond.subs(X,hi)>0
            self.endpoint_x = float(mid)
            self.endpoint_h = float(h.subs(X,mid))
            self.endpoint_trace = float(trace.subs(X,mid))
            self.fold_bracket = [str(lo), str(hi)]
            self.event = "simple fold"
        else:
            assert sp.limit(h,X,case.K,dir="-")==sp.oo

    def predator_balance(self,x,h):
        # Positive root of h*y^2+(d+h)*y +d-e*x=0, evaluated without cancellation.
        d = float(self.case.d)
        gap = self.case.e*x-d
        return 2*gap/(d+h+np.sqrt((d+h)**2+4*h*gap))

    def coordinates(self,h):
        case = self.case
        if h<0 or h>self.endpoint_h:
            raise ValueError("Competition outside this tracked branch")
        if h==0: return float(case.x0),float(case.y0)
        if h==self.endpoint_h:
            x = self.endpoint_x
        else:
            def residual(x):
                y = self.predator_balance(x,h)
                return self.g_num(x)-y/(1+y)
            x = brentq(residual,case.x0,self.endpoint_x,xtol=1e-14,rtol=2e-15)
        return x,self.predator_balance(x,h)

    def diagnostics(self,x,y,h):
        case = self.case
        def field(xx,yy):
            pred=xx*yy/(1+yy)
            return np.array([xx*self.g_num(xx)-pred,case.e*pred-float(case.d)*yy-h*yy**2])
        # Complex-step differentiation is independent of the analytic Jacobian used to certify the branch.
        step = 1e-20
        jac = np.column_stack((field(x+1j*step,y).imag/step, field(x,y+1j*step).imag/step))
        eig = sorted(np.linalg.eigvals(jac),key=lambda z:(z.real,z.imag),reverse=True)
        return dict(trace=np.trace(jac), determinant=np.linalg.det(jac),
                    eig1_re=eig[0].real, eig1_im=eig[0].imag, eig2_re=eig[1].real, eig2_im=eig[1].imag,
                    ode_residual=float(np.max(np.abs(field(x,y)))))

def draw_series(axis, rows, column, law, linestyle="-", label=None):
    axis.plot([r["h"] for r in rows],[r[column] for r in rows],ls=linestyle,color=COLORS[law],
              label=NAMES[law] if label is None else label,lw=1.9)

def finish(fig, fname):
    for fmt in ("pdf","png"):
        fig.savefig(ROOT/"figures"/f"{fname}.{fmt}",dpi=170,metadata={"Creator":"Direction 2 comparison study"} if fmt=="pdf" else None)
    plt.close(fig)

def axis_style(axis):
    axis.grid(True,alpha=.16,lw=.7)
    axis.spines["right"].set_visible(False)
    axis.spines["top"].set_visible(False)

def fold_marker(axis,case,values,coord):
    if case=="fold":
        row=values[case]["S"][-1]
        axis.axvline(row["h"],color=".35",ls=":",lw=1.1)
        if coord:
            axis.scatter(row["h"],row[coord],s=28,facecolor="white",edgecolor=COLORS["S"],zorder=5)

def figures(growth_rows, values):
    plt.rcParams.update({"font.size":10,"pdf.fonttype":42,"axes.titlesize":11})
    fig,axes=plt.subplots(1,2,figsize=(9.2,3.8),layout="constrained")
    for ax,case in zip(axes,CASES[:2]):
        for law in case.growth():
            subset=[r for r in growth_rows if r["case"]==case.name and r["law"]==law]
            ax.plot([r["x"] for r in subset],[r["g"] for r in subset],lw=2,color=COLORS[law],label=NAMES[law])
        ax.axvline(case.x0,color=".5",ls=":",lw=1)
        ax.scatter(case.x0,float(case.y0/(1+case.y0)),s=33,facecolor="white",edgecolor="black",zorder=5)
        ax.set(xlabel="Prey density, x",ylabel="Per-capita prey growth, g(x)",title=CASE_TITLES[case.name])
        axis_style(ax)
    axes[0].legend(frameon=False,fontsize=9)
    finish(fig,"F1_common_growth")
    for coord, title, fname in [("predator","Predator","F2_predator_equilibria"),("prey","Prey","F3_prey_equilibria")]:
        fig,axes=plt.subplots(2,2,figsize=(9.2,5.6),layout="constrained",height_ratios=[2,1],sharex="col")
        for j,case in enumerate(CASES[:2]):
            name=case.name; ax=axes[0,j]; lower=axes[1,j]
            for law in case.growth(): draw_series(ax,values[name][law],coord,law)
            ax.scatter(0.,values[name]["L"][0][coord],s=32,facecolor="white",edgecolor="black",zorder=4)
            ax.set(ylabel=f"{title} equilibrium density",title=CASE_TITLES[name])
            fold_marker(ax,name,values,coord)
            for law1,law2 in (("S","W"),("W","L")):
                top=np.array([r[coord] for r in values[name][law1][1:]])
                bot=np.array([r[coord] for r in values[name][law2][1:]])
                h=[r["h"] for r in values[name][law1][1:]]
                lower.plot(h,top-bot,color=COLORS[law1],lw=1.6,label=f"{law1} − {law2}")
            lower.set(yscale="log",ylabel="Positive gap (log scale)",xlabel="Direct predator competition, h")
            fold_marker(lower,name,values,None)
            for ax0 in (ax,lower):axis_style(ax0)
        axes[0,0].legend(frameon=False,fontsize=9)
        axes[1,0].legend(frameon=False,fontsize=9)
        finish(fig,fname)
    fig,axes=plt.subplots(4,2,figsize=(9.4,9.0),layout="constrained",sharex="col")
    for j,case in enumerate(CASES[:2]):
        name=case.name; axes[0,j].set_title(CASE_TITLES[name])
        for i,(col,ylabel) in enumerate([("trace","Trace"),("determinant","Determinant"),
                              ("eig1_re","Real eigenvalue parts"),("eig1_im","Imaginary magnitude")]):
            ax=axes[i,j]
            for law in case.growth():
                draw_series(ax,values[name][law],col,law)
                if col=="eig1_re":
                    draw_series(ax,values[name][law],"eig2_re",law,"--","_nolegend_")
            ax.axhline(0,color=".5",lw=.75);fold_marker(ax,name,values,col);axis_style(ax)
            ax.set_ylabel(ylabel)
        axes[-1,j].set_xlabel("Direct predator competition, h")
    axes[0,0].legend(frameon=False,fontsize=8,ncol=3,loc="lower left")
    axes[2,0].text(.02,.04,"Solid: larger     Dashed: smaller",transform=axes[2,0].transAxes,fontsize=8,
                   bbox=dict(fc="white",ec="none",alpha=.8))
    finish(fig,"F4_stability_and_fold")
    fig,axes=plt.subplots(2,2,figsize=(9.2,6.0),layout="constrained")
    axg,axgd,axy,axyd=axes.flat
    subsets={}
    for law in ["C1","C2"]:
        rows=[r for r in growth_rows if r["case"]=="tangent" and r["law"]==law];subsets[law]=rows
        axg.plot([r["x"] for r in rows],[r["g"] for r in rows],label=NAMES[law],color=COLORS[law],lw=2)
        draw_series(axy,values["tangent"][law],"predator",law)
    axg.scatter(2,.5,s=32,facecolor="white",edgecolor="black",zorder=4)
    axg.set(xlabel="Prey density, x",ylabel="Per-capita growth",title="Cubic growth at a common tangent")
    axgd.plot([r["x"] for r in subsets["C1"]],[r2["g"]-r1["g"] for r1,r2 in zip(subsets["C1"],subsets["C2"])],color=COLORS["C2"],lw=2)
    axgd.axvline(2,ls=":",lw=.9,color=".5");axgd.set(xlabel="Prey density, x",ylabel="Growth gap",title="Growth under c = 1/2 minus c = 1/4")
    axy.scatter(0,1,s=33,facecolor="white",edgecolor="black",zorder=4)
    axy.set(xlabel="Direct predator competition, h",ylabel="Predator equilibrium density",title="Two stable branches")
    gap=np.array([r2["predator"]-r1["predator"] for r1,r2 in zip(values["tangent"]["C1"][1:],values["tangent"]["C2"][1:])])
    hs=np.array([r["h"] for r in values["tangent"]["C1"][1:]])
    axyd.loglog(hs,gap,lw=2,color=COLORS["C2"],label="Equilibrium gap")
    mask=hs<.07;axyd.loglog(hs[mask],hs[mask]**2/54,color=".25",ls="--",lw=1.5,label=r"$h^2/54$ near zero")
    axyd.set(xlabel="Competition, h (log scale)",ylabel="Predator gap (log scale)",title="Separation after equal first derivatives")
    axg.legend(frameon=False);axyd.legend(frameon=False,fontsize=9)
    for ax in axes.flat:axis_style(ax)
    finish(fig,"F5_equal_tangent_cubic")

def produce():
    for name in ("figures","data"):
        (ROOT/name).mkdir(exist_ok=True)
    calibrations=[]; traces=[]; growth_rows=[]; evidence={}; values={}
    for case in CASES:
        branches={law:Branch(case,law,g) for law,g in case.growth().items()}
        end=min(br.endpoint_h for br in branches.values())
        display=min(end,case.h_plot)
        # Sample both ends densely; all roots use brackets on the certified connected segment.
        grid=display*(1-np.cos(np.linspace(0,np.pi,181)))/2
        grid[-1]=display
        values[case.name]={}
        for law,branch in branches.items():
            g=branch.g; x0=case.x0
            calibrations.append(dict(case=case.name,law=law,models=MODELS[law],x0=x0,y0=case.y0,K=case.K,A=case.A if law=="S" else "",
                        alpha=1 if law=="W" else "", beta=1,m=1,e=case.e,d=case.d,exact_g=str(g),
                        g_at_x0=g.subs(X,x0),g_prime_at_x0=g.diff(X).subs(X,x0),first_predator_derivative=branch.d1,
                        second_predator_derivative=branch.d2,trace0=branch.trace.subs(X,x0),det0=branch.det.subs(X,x0)))
            x_grid={"mixed":(2.,9.),"fold":(.75,1.70),"tangent":(1.75,3.)}[case.name]
            for x in np.unique(np.append(np.linspace(*x_grid,151),float(case.x0))):
                growth_rows.append(dict(case=case.name,law=law,x=float(x),g=float(branch.g_num(x))))
            rows=[]
            for h in grid:
                x,y=branch.coordinates(h)
                rec=dict(case=case.name,law=law,h=h,prey=x,predator=y,**branch.diagnostics(x,y,h),
                        status="fold limit" if h==branch.endpoint_h else "regular stable")
                assert rec["ode_residual"]<1e-10
                if rec["status"]=="regular stable":
                    assert rec["trace"]<0 and rec["determinant"]>0
                if rows:assert x>rows[-1]["prey"]
                rows.append(rec)
            traces.extend(rows);values[case.name][law]=rows
            evidence[f"{case.name}_{law}"]=dict(first_boundary=branch.event, boundary_h=float(branch.endpoint_h) if np.isfinite(branch.endpoint_h) else "infinity",
                         boundary_x=branch.endpoint_x,negative_trace_at_fold=branch.endpoint_trace,fold_x_interval=branch.fold_bracket,event_roots=branch.roots)
        laws=list(branches)
        for left,right in zip(laws,laws[1:]):
            assert all(r["predator"]>l["predator"] and r["prey"]>l["prey"] for l,r in zip(values[case.name][left][1:],values[case.name][right][1:]))
    save_csv(ROOT/"data"/"figure_growth_curves.csv",growth_rows)
    save_csv(ROOT/"data"/"figure_equilibrium_branches.csv",traces)
    save_csv(ROOT/"data"/"figure_parameters.csv",calibrations)
    (ROOT/"data"/"figure_event_certificates.json").write_text(json.dumps(evidence,indent=2)+"\n")
    metrics=dict(records=len(traces),regular_points=sum(r["status"]=="regular stable" for r in traces),growth_points=len(growth_rows),
                 max_original_ode_residual=max(r["ode_residual"] for r in traces),python=platform.python_version(),numpy=np.__version__,
                 scipy=scipy.__version__,sympy=sp.__version__,matplotlib=matplotlib.__version__)
    (ROOT/"data"/"figure_checks.json").write_text(json.dumps(metrics,indent=2)+"\n")
    figures(growth_rows,values)
    print(json.dumps(metrics,indent=2))

if __name__=="__main__":
    produce()
