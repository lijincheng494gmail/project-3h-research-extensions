# Revision change log

Page numbers refer to the revised PDFs dated 19 November 2026. The review and the original release are included in this package.

| Location | Previous wording or implication | Revised result |
|---|---|---|
| Main text, §2.5, p. 14 | “44 of the 48 recoveries” counted all shocks as recoveries. | Populations recovered after 45 of 48 shocks. A sufficient Lyapunov criterion certified 44 of the 45 returns. M5 recovered after 60% prey removal outside the certified set. |
| Main text, §2.4, pp. 11–12, and Supplement S5, p. 17 | A sign statement for the sampled grid did not distinguish zero competition. | The interaction equals zero at every defined point at zero competition. At positive competition it is negative throughout both weak–logistic grids and the matched strong–logistic grid. The strong–logistic grid at equal nominal growth also contains positive cells and cells without a stable reference. |
| Supplement S4.5, p. 14 | “predator-free trajectories remain exceptions” obscured the different outcomes on the axis. | With no predators, positive initial prey density below A tends to zero. Initial prey density at A stays at A. Above A it tends to K. The origin is stationary. The interior theorem still states its own domain. |
| Supplement S6.1, p. 17 | “the physical v>0 direction attracts the axial state” reversed the direction of approach. | At zero predator invasion exponent, nearby trajectories on the positive center branch approach (K, 0). The negative quadratic coefficient in Eq. S36 gives the direction. |

The abstract gives the single-step comparison against persistence in each held-out experiment. It gives the best mechanistic free-running score alongside the training-mean baseline and reports the late-amplitude screen across both populations. Results and Methods explain the forecast initializations and the amplitude and period screens. The period estimate passed the screen in three of the eight observed population records.

Paired-comparison captions now state which model has higher predator density. Recovery markers identify the shocks that failed the stated time criterion. The cycle results report which records passed the screening rules. A new Further Discussion subsection brings together the low-density observations needed and the remaining global classifications. Conditions for the existing theorems and the four partial entries in Q4 stay with the corresponding results.

The companion proofs state the common stable interval, the conditions for a nondegenerate Hopf bifurcation, and what a common regular root implies about first derivatives. The general proof labels its counterexample “Opposite prey and predator rankings.” The numerical and literature reports state the exact comparisons and their source. The publication report retains Outcome B for a separate short paper.

Numerical values in the saved tables, the plotted data, the displayed equations, and the table cells match the prior release. The four corrections above change the scientific descriptions as intended. The full line-by-line changes in the manuscript sources and revised reports are in `source_changes.diff`.
