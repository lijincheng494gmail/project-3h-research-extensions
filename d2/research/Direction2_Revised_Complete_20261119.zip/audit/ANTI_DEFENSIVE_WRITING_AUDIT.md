# Direction 2 反防御性写作检查

2026-11-19。检查对象为六模型论文及补充材料、五页竞争响应排序定理、最新四页一般比较定理和相关报告。附件以 Direction 3 稿件和 CAR-T 数据举例，并单列了 Direction 2 的六模型要求。下表采用其写作准则，核查本次对话持续讨论的 Direction 2。以下是审阅意见与替换句，已发布原稿和数据均未改动。

## 优先修正的四处表述

| 定位 | 核对结果 | 可直接替换的英文 |
|---|---|---|
| 六模型主稿，扰动结果，RESEARCH_PAPER.tex:131 | “44 of the 48 recoveries” 混淆了扰动总数和恢复数。48 次扰动，45 次在预设标准内恢复，其中 44 次满足 Lyapunov 充分判据。剩余 1 次是 M5 移除 60% 猎物后的恢复。 | “The system recovered after 45 of the 48 shocks. The Lyapunov criterion certified return in 44 of those 45 cases.” |
| 六模型主稿，交互作用图，RESEARCH_PAPER.tex:118 | 未限定竞争强度便写“全为负”。在有参照的网格点，按定义 h=0 时交互项是零。弱模型的两种校准、参考增长匹配的强模型均在各自 1,400 个正 h 网格点取负值。强模型在同 r 校准下还有正值和缺失参照，保留单独报告。 | “At all sampled positive competition strengths, the weak-growth interaction was negative under both calibrations. Under reference-growth matching, the strong-growth interaction was also negative. At zero competition, every defined interaction was zero.” |
| 强 Allee 全局分类补充，global_classification_supplement.tex:140 | 把 “predator-free trajectories” 笼统列为原点吸引的例外，容易误解成整条无捕食者轴都不趋于原点。由轴上方程可直接区分三种初值。正象限内部的原定理仍保留。 | “On the predator-free axis, prey densities initially between 0 and A tend to zero. An initial density of A remains at A, and densities initially above A tend to K.” |
| 六模型补充分岔推导，SUPPLEMENTARY_INFORMATION.tex:167 | “the physical v>0 direction attracts the axial state” 把趋近关系写反。前面的展开给出 λK=0 且 B<0，沿正中心分支，邻近轨道趋向轴平衡点。 | “At λK = 0, nearby trajectories on the positive center branch approach (K, 0).” |

## 让科学结果先出现

- 六模型摘要已经指出单步预测改善，但自由预测用一句“没有一致排名”概括，读者看不到最鲜明的负结果。可写：“All six models reduced one-step error relative to persistence in each of the four held-out experiments. In free-running forecasts, late amplitudes fell below the prespecified threshold in all 48 model–experiment–population records.” 48 指六个模型、四个实验、两个种群的组合。完整正文还可保留自由预测中最佳机制模型 M1 的平均 NRMSE 1.0376，训练均值基线为 1.0370。
- 四页一般定理的反例直接给出两种群的相反排序。将标题 “An exact limit on the prey claim” 改为 “Opposite prey and predator rankings”。这个小标题既交代科学发现，也保留模型边界。
- 正文讨论的 “No missing global proof is replaced by selected paths.” 可删；Q4 哪些参数区域仍待证明，在比较矩阵与补充推导中各有明确位置。图注 “Marked failures do not receive an invented recovery time.” 可改为 “Markers identify shocks that did not meet the recovery criterion by time 600.”
- 将低密度观测的不足、进一步的测量和未解决的全局分类集中在六模型正文的 Further Discussion。定理假设、正行列式、分支终点、实验定义，以及已证的不可能性或实际观察到的失败，保留在原结论旁。Outcome B 则是发表评估本身的问题，适合保留在评估报告。

## 阅读定位

- [六模型原稿及扰动段](<local-home>/Documents/Codex/2026-11-18/zip-zip-zip-zip/work/Direction2_SixModel_Paper/paper/RESEARCH_PAPER.tex:131)
- [强 Allee 边界陈述](<local-home>/Documents/Codex/2026-11-18/zip-zip-zip-zip/work/Direction2_SixModel_Paper/paper/global_classification_supplement.tex:140)
- [一般定理的反例](<local-home>/Documents/Codex/2026-11-18/zip-zip-zip-zip/work/General_Comparison_Stage/GENERAL_COMPARISON_THEOREM.tex:110)
- [恢复与 Lyapunov 证书对照](<local-home>/Documents/Codex/2026-11-18/zip-zip-zip-zip/work/Direction2_SixModel_Paper/results/extended_shock_lyapunov_certificates.csv)
- [各网格点的交互项](<local-home>/Documents/Codex/2026-11-18/zip-zip-zip-zip/work/Direction2_SixModel_Paper/results/paper_interaction_grid.csv)
- [真实数据周期结果](<local-home>/Documents/Codex/2026-11-18/zip-zip-zip-zip/work/Direction2_SixModel_Paper/results/real_cycle_metrics.csv)

以下是各部分筛读后应优先处理的原句、建议写法和应保留的限定。

---

## Direction 2 六模型主论文写作检查

检查对象是 22 页主论文的可编辑正文及其载入的比较矩阵、配对结果、全局分类摘要、预测/周期结果、方法和图表。行号对应 `work/Direction2_SixModel_Paper/paper/` 下的原始文件。以下列出会改变可读性或精度的原句，按其在科学表达中的功能判断。A 为已建立结果，B 为必要条件，C 为研究局限，D 为防御或冗余表述。此次为检查，未修改原稿，未开展新实验。

**整体判断。** 标题和开篇的六模型设计清楚。Results 以 42 格结果矩阵开头，且已保留预测比较的失利、扰动后的灭绝、分岔排除结论。防御性写作集中在若干图注和段末。最优先的问题是两处会改变读者对数据理解的表述，以及摘要没有呈现自由运行预测的主要结果。

| 原文位置 | 原句或原句片段 | 类型与动作 | 建议 |
|---|---|---|---|
| RESEARCH_PAPER.tex:131，扰动 | “A separate Lyapunov test certifies 44 of the 48 recoveries, with no contradiction.” | A+D，REWRITE | 48 是扰动总数，不是恢复总数。写成 “Of the 48 shocks, 45 recovered. The Lyapunov criterion certified 44 of those 45 recoveries.” 保留下一句中 M5 在充分条件外仍恢复的结果，删掉 “with no contradiction”。 |
| RESEARCH_PAPER.tex:118，交互 | “Weak interactions are negative on this grid.” / “Under reference-growth matching all eligible strong grid interactions are negative.” | A+B，REWRITE | 两句都需要 “at positive competition strengths”。两种弱模型校准的每组各有 1,400 个正 h 的负格和 35 个 h=0 的零格；匹配增长的强模型组同样如此。可写 “At every sampled positive competition strength, the weak-growth interaction was negative under both calibrations. The strong-growth interaction was also negative at every sampled positive strength under reference-growth matching.” |
| RESEARCH_PAPER.tex:8，摘要 | “the small differences among structures do not give a consistent empirical ranking” | A，REWRITE | 这句话描述了单步名次随实验改变，不能替代自由运行结果。可将实测部分改为 “All six models reduced one-step error relative to persistence in each of four held-out experiments. Across those experiments, the training-mean baseline had a lower mean free-running error than any mechanistic model. All 48 free-running model–experiment–population records had late amplitudes below the prespecified threshold.” 若篇幅紧，保留第一和第三句。不得将‘低于阈值’写成‘生态系统不振荡’。 |
| RESEARCH_PAPER.tex:8，摘要 | “Disturbance experiments quantify basin and recovery differences.” | A，REWRITE | 这里仅交代做了什么。可写 “At the fixed disturbance baseline, 45 of 48 shocks recovered. The three failures followed prey removal under strong Allee growth.” 摘要篇幅受限时应首先保留六模型主问题。 |
| RESEARCH_PAPER.tex:118,123，交互图 | “an equilibrium effect cannot stand in for a basin-dependent trajectory effect” / “rather than an exact global bifurcation partition” | B+D，MERGE | 两种测量不同是必要信息。正文可写 “The equilibrium grid follows the largest-prey stable branch. The trajectory means also include changes in basin membership.” 图注保留 5,740 格、选取的分支、缺失参照对应未定义格；可以删去对未声称的全局分区的回应。 |
| RESEARCH_PAPER.tex:131，扰动末句 | “they complement the seven dynamical questions” | D，DELETE | 扰动已被作为独立小节呈现。删去对小节为何存在的辩护，保留所获边界区间。 |
| RESEARCH_PAPER.tex:136，图注 | “Marked failures do not receive an invented recovery time.” | D+B，REWRITE | “Recovery time is reported for trajectories that met the criterion within 600 time units.” 保留 2% 容差、至少连续 50 个单位时间及监测至结束。 |
| cycle_summary.tex:1，实测结果 | “The remaining period and phase entries are explicitly unavailable rather than replaced by arbitrary cycle values.” | B+D，REWRITE | “Period estimates met the screening criteria in three of the eight observed population records. Phase estimates required both observed and predicted periods to pass the screen.” 0/48 自由预测振幅达标须在 Results 保留。 |
| RESEARCH_PAPER.tex:153，预测图 | “Period and phase diagnostics do not change forecasts.” | B，MERGE | 评估规则不是防御，但与 cycle_methods.tex 末句重复。保留方法处的诊断时点与冻结预测约定，图中保留折号、形状、颜色、振幅比参照线。 |
| RESEARCH_PAPER.tex:160，讨论 | “Treating either result as the whole competition effect would miss part of the dynamics.” | D，DELETE | 前两句已区分沿稳定分支的丰度改变和改变扰动归宿的吸引域效应。 |
| RESEARCH_PAPER.tex:164,166，讨论 | “Future observations at low prey density …” / “The remaining mathematical questions concern global attractors outside the proved domains …” | C，MOVE | 如按附件准则修订，可归入 Further Discussion。把三件事集中说明：观察密度范围及独立增长测量，尚未覆盖的弱/强 Allee 全局情形，已证明区域之外的周期与连接。矩阵 Q4 的部分分类标记和定理的成立域仍保留原处。 |
| RESEARCH_PAPER.tex:166，讨论末句 | “No missing global proof is replaced by selected paths.” | D，DELETE | 前文已有未解区域，精确位置在 S4。 |
| RESEARCH_PAPER.tex:196，方法 | “not a claimed closed-form plotting of every discriminant surface” | B+D，REWRITE | “The Sturm sign conditions give an implicit classification for each fixed admissible parameter set.” 保留重根和轴碰撞的处理。 |
| RESEARCH_PAPER.tex:170，方法 | “The cancelled stochastic extension and the reaction–diffusion model are outside the deterministic six-model design.” | D，DELETE | 六模型方程和模型表已经定义了研究对象，取消的项目不影响读者复现。 |
| paired_growth.tex:3，比较表图注 | “positive values favour the first named model” | A，REWRITE | “Positive values indicate higher predator tail means in the first model.” 丰度较高没有科学依据可称模型“更好”。 |
| RESEARCH_PAPER.tex:74；comparison_matrix.tex:3,8,17,26,27；global_summary.tex:3 | “cannot undergo an interior saddle-node, Hopf or Bogdanov–Takens …”；“remains partial”；“strictly positive initial state” | A/B，KEEP | 前者是有证明的排除结果，中者是 Q4 的真实完成状态，后者限制强模型吸引域的初始状态。不能作为“消极措辞”移除。 |
| RESEARCH_PAPER.tex:129,144,149 | 两个物种的恢复边界；自由预测基线；“no observed crossing of a fitted threshold” | A/B，KEEP | 单种猎物阈值不足以解释指定冲击的恢复归宿，是实测算例结果。自由预测不胜训练均值、拟合阈值低于实际观测范围同样是完成的结果。阈值范围、单位和四实验的定义应就地保留。 |

**已核对的证据与边界。** 只汇总了之前保存的 CSV，不进行新的模型拟合或仿真。

- `results/extended_shock_lyapunov_certificates.csv` 中，充分条件且恢复 44 条、不满足充分条件但恢复 1 条、不满足且未恢复 3 条。冲击共 48 个。
- `results/paper_interaction_grid.csv` 中，正 h 时弱模型两种校准共 2,800 个负格，h=0 共 70 个零格。强模型同 r 时正 h 得 1,000 个负格、40 个正格、360 个缺参照格；h=0 时为 26 个零格及 9 个缺参照格。匹配增长强模型在正 h 有 1,400 个负格。
- `results/real_benchmark_scores.csv` 按实验等权平均，M3 单步 NRMSE 0.88247330，M1 0.88486210，持续值基线 1.04027645。自由预测中，M1 1.03757899，训练均值 1.03703198。应区分六模型间的名次和包含简单基线的名次。
- `results/real_cycle_metrics.csv` 给出 48/48 个模型×实验×种群的自由预测后期振幅均低于阈值，最大的预测/观测后期振幅比为 1.37950×10⁻¹⁵。`results/real_cycle_observed.csv` 仅 3/8 个实际种群记录得到符合所定筛选规则的周期。其余五个不能据此写成“无周期”。
- 论文当前没有题名为 Further Discussion 的章节。结果开头的矩阵、六节顺序和原问题无需改变。已证明的负结果、正行列式/稳定分支等条件均不能挪走。

---

## Direction 2 补充推导及五页排序证明的写作检查

检查对象是六模型补充材料 S1–S7 和上一阶段五页排序定理。逐段阅读了补充材料主源、S2 和 S4 两个实际载入的证明文件、S2 嵌套的 29 例表、分岔表、周期方法与表，以及五页定理的所有章节。以下记录需要修改或特别值得保留的句子。源文件行号以交付版本为准。本次只作检查。

### 优先修正的两处表述

| 位置 | 原句或片段 | 判断 | 建议英文 |
|---|---|---|---|
| global_classification_supplement.tex:140 | “predator-free trajectories remain exceptions on the closed quadrant” | **必要条件，改写。** “exceptions”容易读成所有无捕食者轨道都不趋原点。定理限定严格正初态是必须的；无捕食者轴上的三个区间由原标量猎物方程直接决定。 | “On the predator-free axis, prey tend to zero for $0<x(0)<A$, stay at $A$ for $x(0)=A$, and approach $K$ for $x(0)>A$.” |
| SUPPLEMENTARY_INFORMATION.tex:167 | “the physical $v>0$ direction attracts the axial state” | **已证结论，改写。** 句法把吸引者和趋近它的轨道颠倒了。由同段中心方程的 $B<0$ 可知 $v$ 从正侧趋零。 | “At $\lambda_K=0$, nearby trajectories on the positive center branch approach $(K,0)$.” |

### 可删或合并的防御性写法

| 位置 | 原句或片段 | 分类与动作 | 建议 |
|---|---|---|---|
| root_classification_supplement.tex:97–99 | “An expanded radical/discriminant atlas is not needed for a fixed-parameter answer and is not claimed.” | 防御性，**删除** | 前一句已准确给出完整隐式分类。保留 “complete implicit parameter classification” 和正根条件。 |
| root_classification_supplement.tex:216–217 | “exact Sturm certificates, not just a continuity argument” | 重复限定，**改写** | “Exact Sturm counts certify three distinct positive equilibria in both positive-competition examples.” |
| root_classification_supplement.tex:239–242 | “not a complete global attractor diagram” | 重复限定，**合并** | “The counting rule determines equilibrium existence, number and uniqueness for all six models. Section S4 treats their global dynamics.” 机器状态码保留在 42 格矩阵。 |
| global_classification_supplement.tex:133 | “A formula for its graph is not required by this classification.” | 防御性，**删除** | 前一句的正面结果更强且更清楚，可压成 “The positive branch of $W^s(A,0)$ is the one-dimensional boundary between the two open basins.” |
| SUPPLEMENTARY_INFORMATION.tex:121 | “not a claim about all initial states or a jump between basins” | 已经陈述分支条件，**合并** | “Along a regular stable coexistence branch, stronger predator competition raises predator density on the ascending limb of the Allee growth curve.” |
| SUPPLEMENTARY_INFORMATION.tex:90、181、243 | “is not included in the local feasibility claim” / “a full higher-codimension parameter unfolding is not claimed” / “remain outside this local classification” | 三处讲到相互关联的开放问题，**合并到 Further Discussion**。在原位置保留非双曲点的判据及普通分岔与退化碰撞的区别。 | “Open problems include higher-order degenerate Hopf points, the full unfolding of the degenerate threshold-axis collisions, cycle counts, and global connections in the remaining Allee parameter regions.” 详细 $\mathcal R_W,\mathcal R_S$ 的公式保留在 S4。 |
| SUPPLEMENTARY_INFORMATION.tex:257 | “not demonstrations of autonomous cycle generation” | 多余反向解释，**改写** | “Conditional forecasts use each observed state to initialize the next prediction. All 48 free-running population records fell below the late-amplitude floor.” 周期筛选条件、八个观察记录中三项通过及相位定义照留。 |
| SUPPLEMENTARY_INFORMATION.tex:262 | “rather than to an unclaimed full global bifurcation atlas” | 防御性，**删除** | “The four Allee models have exact equilibrium counts for fixed parameters. Four global-attractor and basin classifications remain partial.” 保留原 42 格矩阵和分类条件。 |
| COMPETITION_ORDERING_THEOREM.tex:109 | “A different attractor, another positive root at the same $h$, a population time average, or a prediction from a fitted ecological model answers a different question.” | 连同段末对全局吸引域的声明，**合并**。分支选择和失稳终点是必要条件。 | “The comparison follows each equilibrium continuously from the matched starting point and ends at the first boundary of the common positive, hyperbolically stable interval.” 详细终端规则已在第 4 节。 |
| COMPETITION_ORDERING_THEOREM.tex:164 | “the proposed placement in the existing paper, are supplied as separate documents” | 交付导航，**移至 README** | 保留 Example I 和 mixed 图相同、Example II 与 plotted fold 不同，这一对应关系防止混用两种折点。 |

### 不能当作防御性语言删除的地方

- SUPPLEMENTARY_INFORMATION.tex:65、184，以及 global_classification_supplement.tex:112。强 Allee 模型在指定初始条件下双物种灭绝，Logistic 模型排除了三类内部局部分岔。这些是否定式的数学发现。特别保留 $x(0)=A$ 时的 $y(0)>0$。
- SUPPLEMENTARY_INFORMATION.tex:243。四个 Hopf 系数来自不同参数区，不能把符号差异解释为加入竞争的配对效应。可直接写 “The four signs describe the local Hopf bifurcations at four distinct parameter settings.” 同时保留各符号和交叉方向的作用。
- root_classification_supplement.tex:221–228。原先 144 个情景的根数一致是核验结果。某参数上无竞争参考态缺失，导致交互效应未定义，这也是实际比较条件，不能写成数值零。
- global_classification_supplement.tex:179–190。剩余参数集合是精确数学边界；公式和集合上的已证子区域应留在技术证明。可以将未决问题在正文集中讨论一次，不宜删除公式或把“四项局部完成”改成“四项已完成”。
- cycle_table.tex:3、SUPPLEMENTARY_INFORMATION.tex:252–257。自由预测的晚期振幅相对于观察值小于 $1.4\times10^{-15}$；按预设门槛，没有可报告的自由预测周期。这是实测预测性能的负结果。表题可把 “A vanished amplitude does not define a cycle period” 写成 “No free forecast met the amplitude criterion for reporting a period.” 既保留门槛，又避免把接近零说成严格零。
- COMPETITION_ORDERING_THEOREM.tex:86–93、132。共同正稳定分支、$0<h<H_*$、正行列式与零迹的区分都必须保留。有限密度严格排序可以伴随边际导数次序反转，这是独立推论。零迹的性质可表述为 “At positive determinant, zero trace marks a spectral boundary. A nondegenerate Hopf bifurcation also requires transversality and a nonzero first Lyapunov coefficient.”
- 复现文件名、代码入口、哈希记录放在 SI 最后一节或 README 合理。尤其要保留用于根数的精确算术和用于核验的浮点残差之分。无需把所有实现细节都定为防御性写作。

---

## 一般比较定理与配套报告：反防御性写作检查

检查范围为《Comparing predator responses to competition》全部四页（含第 4 页表格）、五幅图的说明、数值验证报告、文献新颖性矩阵与发表评估。以下为全文筛读后的重点句和保留项。页码为 GENERAL_COMPARISON_THEOREM.pdf 上的页码，行号为对应源文件行号。英文本是修改建议，源稿未改。

**判断。** 定理本身写得直接。第 2 页定理在列明条件后立即给出捕食者与猎物各自的排序，第 4 页反例有明确的导数和方向。最值得改的是开头用 “We give conditions” 介绍工作，以及把末尾的反例命名为“对主张的限制”。数值报告和发表报告各有一处典型的预防式措辞。没有理由把四页数学补充拆成一个新的 “Further Discussion” 章节；正行列式、分支身份和实际相交条件在证明里各承担具体作用。

| 位置 | 原句或标题摘录 | 分类／动作 | 建议与理由 |
|---|---|---|---|
| 定理第 1 页，TeX:12 | “We give conditions under which the second system has higher predator density at every subsequent competition strength on the selected branches.” | A 结果，REWRITE | “For the original feeding law, the second system has higher equilibrium predator and prey densities at every positive competition strength on the common positive-determinant branches. For general predation, the orientation of the predator nullcline determines whether prey densities share the predator ordering.” 用在已叙述共同起点和右侧增长率排序的句子后，引导读者进入第 2 页的一般条件。 |
| 定理第 1 页，TeX:29 | “This proves the general-growth result for the original feeding law. No carrying capacity, distinct slope, polynomial degree or global uniqueness of coexistence was used.” | 前句重复结论，DELETE；后句为 B 条件说明及与第 2 页重复，MERGE | 上一句已给出两种群排序，可删 “This proves …”。保留一处关于适用范围的表述，强调能同时容纳一般增长形状和多平衡；第 2 页说明只需沿所选分支检查。不能因删并而暗示两条分支可任意挑选。 |
| 定理第 2 页，TeX:37、39、53 | “The regularity condition in the theorem is …”；“Global uniqueness of a predator-density root or of a stable equilibrium is unnecessary.” | B，KEEP | 正行列式给出约化方程的方向。固定捕食者密度和竞争强度时，由捕食者方程至多确定一个相关猎物密度，是另一种必要区分。多重共存平衡与这条局部／分支条件相容，不能笼统写成 “uniqueness is unnecessary”。 |
| 定理第 3 页，TeX:62 | “This identity does not require the residual to decrease everywhere between distant branches.” | B，MERGE | 可和前后句合为 “The denominator is positive in a neighborhood of the common root, so the sign of the growth gap determines the predator ordering on either side of that contact.” 保留“在接触附近”；远处分支上的全局单调性若需强调，前页弱假设已说明。 |
| 定理第 3 页，TeX:69、71 | “A growth contact at … alone does not guarantee both selected branches reach it.” | B，KEEP | 两条增长曲线在图上相交，与两条指定平衡分支真正到达同一状态，是不同条件。保留两条分支均到达及相交点处的单调性检查。横截相交时反转与偶阶相切时保序是实际发现。 |
| 定理第 3 页，TeX:73、78 | “For n=1 …”／“Equal slopes give equal first responses.” | B 精度，REWRITE | 公式 (5) 直接从两条分支导数公式相减得到，在满足正则性条件的共同根处也适用于左右增长斜率相等时；公式 (4) 的一阶展开只是其中的非零线性项情形。可写 “At a common regular root, subtracting (1) gives the local sensitivity difference.” 消除下一句像是跳出前提的读感，不改公式。 |
| 定理第 3 页，TeX:80 | “A stable-branch statement stops at the first loss of a positive hyperbolic sink …” | B，KEEP | 零迹而行列式仍正时可继续比较平衡位置，仍称其“稳定”则会改变已证明结论。应连同折点、边界及同一分支限定留在定理。末句关于任意捕食函数的全竞争强度分类属于 C，若未来并入论文，可放至 Further Discussion。 |
| 定理第 4 页，TeX:90、110 | “All four requested feeding laws fit”／“An exact limit on the prey claim.” | A 结果，REWRITE | “The four feeding laws have the form …”；反例小标题改成 “Opposite prey and predator rankings.” 该反例两组都是稳定共存平衡，增强竞争后捕食者在第二组保留更多，而猎物反向排序。有独立数学内容，不应移入局限。 |
| 定理第 4 页，TeX:112 | “The root-location argument is related to Milgrom and Roberts …” | B 文献归属，KEEP | 保留前人比较极端根和本研究跟踪指定分支的区别；不把已知根排序方法写成首次提出。 |
| NUMERICAL_VALIDATION_REPORT.md:29、31 | “Independent of any sampled gap, differentiating …” | D 预防语，REWRITE | “Differentiating the exact equilibrium curves gives the same initial predator response, −2/3, for both cubic growth laws. For c = 1/4 and 1/2, the second derivatives are 41/27 and 14/9, respectively. The predator density gap is h²/54 + O(h³).” “exact” 已给出证据类型，无须先回应数值点能否证明定理。 |
| 同报告:19–25、35–39 | “The excluded endpoint is marked.”／“one is the excluded fold limit.” | A 数值结果及 B 范围，KEEP | h≈0.05690695 处强 Allee 分支折返；1,448 个绘图记录含 1 个极限点，不能都写成稳定平衡。两组无限区间只画到 h=6，图注应区分显示范围和定理范围。 |
| PUBLICATION_READINESS_REPORT.md:3、7、9 | “A separate AML submission is not justified by the current novelty evidence.” | C 投稿判断，KEEP | 发表评估的任务正是判断是否支持单独投稿。此处属于结论。保留与已知标量方法的具体比较，不将该判断挪到 Results 或改成原创性声明。矩阵第 15–16 行关于 Bai 全文核查范围的说明也应保留。 |
| PUBLICATION_READINESS_REPORT.md:11 | “This is an assessment of the current research, with no journal editorial decision implied.” | D，DELETE | 段落标题已明确这是项目发表评估，无需预防读者误以为期刊已作决定。保留实际 Decision B、页数条件和方法重合的实质原因。 |
| 同报告:13 | “It does not invalidate the previous three-law theorem.” | D 与 B 混合，REWRITE | “The original foraging-arena model has an increasing predator nullcline and therefore retains both rankings.” 这样交代旧结论仍成立的具体原因。 |
| LITERATURE_NOVELTY_MATRIX.md:24 | “This is our direct calculation from their published equation. We do not attribute a theorem number or a matched cross-growth conclusion to the authors.” | B 归属，MERGE | “We derived this within-law sensitivity from Bai et al.’s Eq. (1.4).” 表中已区分跨增长律问题及原文的可见范围。在此保留来源和独立推导即可。 |

证据回查：三次增长的共同一阶导数以及两个二阶导数见 `data/figure_parameters.csv` 末两行。反例中行列式分别为 1/4、1/2，捕食者局部响应为 −7、−3，猎物局部响应为 8、4，见 `theory/exact_checks.json` 的 `decreasing_predator_chart` 条目。折点和记录数见 `data/figure_event_certificates.json`、`data/figure_checks.json`。这些是已有证据，未重跑计算。
