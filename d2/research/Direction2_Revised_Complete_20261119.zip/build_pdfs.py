"""Build the four revised texts and extract the three-page matrix. Requires pypdf, TeX Live, and Poppler."""
import json
import os
import shutil
import subprocess
import tempfile
from pathlib import Path

from pypdf import PdfReader, PdfWriter

ROOT = Path(__file__).resolve().parent
DOCUMENTS = (
    ("paper/REVISED_MANUSCRIPT.tex", "REVISED_MANUSCRIPT"),
    ("paper/SUPPLEMENTARY_INFORMATION.tex", "REVISED_SUPPLEMENTARY_INFORMATION"),
    ("theorems/COMPETITION_ORDERING_THEOREM.tex", "COMPETITION_ORDERING_THEOREM"),
    ("theorems/GENERAL_COMPARISON_THEOREM.tex", "GENERAL_COMPARISON_THEOREM"),
)

def typeset(source, name, scratch, env):
    source = ROOT / source
    for _ in range(3):
        command = ["pdflatex", "-interaction=nonstopmode", "-halt-on-error", "-no-shell-escape",
                   f"-output-directory={scratch}", f"-jobname={name}", source.name]
        run = subprocess.run(command, cwd=source.parent, env=env, capture_output=True, text=True)
        if run.returncode:
            raise RuntimeError(run.stdout[-3500:] + run.stderr)
    log = (scratch / f"{name}.log").read_text(errors="replace")
    if "undefined references" in log or "Rerun to get" in log or "undefined citations" in log:
        raise RuntimeError(f"Unresolved cross-references in {name}")
    pdf = scratch / f"{name}.pdf"
    pages = subprocess.check_output(["pdftotext", "-layout", str(pdf), "-"]).decode().split("\f")
    if pages[-1].strip() == "":
        pages.pop()
    assert all(p.strip() for p in pages), f"Empty page in {name}"
    return pages, {"pages": len(pages), "overfull_horizontal": log.count(r"Overfull \hbox"),
                   "overfull_vertical": log.count(r"Overfull \vbox")}

def main():
    env = dict(os.environ, TZ="UTC", SOURCE_DATE_EPOCH="1795046400", FORCE_SOURCE_DATE="1")
    destination = ROOT / "pdf"
    destination.mkdir(exist_ok=True)
    counts = {}
    with tempfile.TemporaryDirectory(prefix="direction2-tex-") as tmp:
        scratch = Path(tmp)
        for source, name in DOCUMENTS:
            pages, counts[name] = typeset(source, name, scratch, env)
            if name == "REVISED_MANUSCRIPT":
                matrix = [i for i,page in enumerate(pages, 1)
                          if all(f"Q{j}:" in page for j in range(1, 8))]
                assert len(matrix) == 3 and len(pages) <= 25, (matrix, len(pages))
                reader = PdfReader(scratch/f"{name}.pdf")
                writer = PdfWriter()
                for n in matrix:
                    writer.add_page(reader.pages[n-1])
                writer.write(scratch/"REVISED_COMPARISON_MATRIX.pdf")
                counts["matrix_pages_in_manuscript"] = matrix
        for name in [s for _,s in DOCUMENTS] + ["REVISED_COMPARISON_MATRIX"]:
            shutil.copy2(scratch/f"{name}.pdf", destination/f"{name}.pdf")
    print(json.dumps(counts, indent=2))

if __name__ == "__main__":
    main()
