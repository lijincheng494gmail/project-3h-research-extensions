"""Compare scientific content of the typeset sources with the three archived releases."""
import io
import json
import re
from collections import Counter
from zipfile import ZipFile

from verify_evidence import ROOT, FRAME, ORDERING, SIX

PATTERNS = {
    "display_math": r"(?s)(?<!\\)\\\[(.*?)\\\]",
    "equation_environments": r"(?s)\\begin\{(align\*?|equation\*?|gather\*?)\}(.*?)\\end\{\1\}",
    "table_cells": r"(?s)\\begin\{(tabular\*?|longtable)\}(.*?)\\end\{\1\}",
    "labels": r"\\label\{([^}]+)\}",
    "cited_keys": r"\\cite\{([^}]+)\}",
    "input_sources": r"\\input\{([^}]+)\}",
    "figure_files": r"\\includegraphics(?:\[[^]]*\])?\{([^}]+)\}",
}

def compare():
    counts = {"paper_sources":Counter(),"theorem_sources":Counter()}
    with ZipFile(ROOT/"original"/FRAME) as general, ZipFile(io.BytesIO(general.read(ORDERING))) as order, ZipFile(io.BytesIO(order.read(SIX))) as six:
        for area in ["paper","theorems"]:
            for f in sorted((ROOT/area).glob("*.tex")):
                if area == "paper":
                    archived = six.read("paper/" + f.name.replace("REVISED_MANUSCRIPT","RESEARCH_PAPER"))
                    group = "paper_sources"
                else:
                    archive = order if f.name.startswith("COMPETITION_") else general
                    archived = archive.read(f.name)
                    group = "theorem_sources"
                old = archived.decode()
                revised = f.read_text()
                for name, pattern in PATTERNS.items():
                    left,right = (re.findall(pattern,text) for text in [old,revised])
                    if name == "cited_keys":
                        left,right = (sorted({key for group in matches for key in group.split(",")}) for matches in [left,right])
                    assert left==right,(f.name,name)
                    counts[group][name] += len(right)
    return counts

if __name__ == "__main__":
    print(json.dumps(compare(),indent=2,sort_keys=True))
