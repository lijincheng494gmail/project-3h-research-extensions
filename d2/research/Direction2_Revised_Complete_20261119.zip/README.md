# Direction 2 · 19 November 2026

Open [the revised six-model paper](pdf/REVISED_MANUSCRIPT.pdf) and [its supplement](pdf/REVISED_SUPPLEMENTARY_INFORMATION.pdf). The [three-page comparison matrix](pdf/REVISED_COMPARISON_MATRIX.pdf) reproduces pages 4–6 of the paper. The two companion results have separate proofs in [Competition-response ordering](pdf/COMPETITION_ORDERING_THEOREM.pdf) and [General comparison](pdf/GENERAL_COMPARISON_THEOREM.pdf).

The paper keeps M0–M5 and the seven original research questions. The abstract reports conditional one-step and free-running predictions separately. The main text and supplement correct the recovery denominator, the interaction at zero competition, the strong Allee dynamics on the predator-free axis, and the direction of approach to the carrying-capacity equilibrium. Section 3.1 gathers the empirical and mathematical questions that remain open.

## Revision records

- [Change log with the previous and revised claims](audit/REVISION_CHANGELOG.md)
- [Results and supporting evidence](audit/SCIENTIFIC_FINDINGS_REGISTER.md)
- [Further Discussion](audit/FURTHER_DISCUSSION.md)
- [Final integrity checks](audit/FINAL_SCIENTIFIC_INTEGRITY_AUDIT.md)
- [Earlier writing review in Chinese](audit/ANTI_DEFENSIVE_WRITING_AUDIT.md)
- [Complete source changes](audit/source_changes.diff)

## Materials

The revised LaTeX sources are in `paper/` and `theorems/`. The figures included by the paper are in `figures/`. The eight original result tables used for this revision are in `evidence/`. The general comparison reports, numerical figure data, figures, and previous mathematical checks are in `reports/`.

The `original/` directory contains the five previous PDFs and the complete previous research release. To open the original six-model code, study data, or fit records, extract the archives in this order.

1. `original/Direction2_General_Comparison_Research_Package.zip`
2. `prior/Direction2_Competition_Ordering_Theorem_Package.zip` inside that archive
3. `previous_study/Direction2_SixModel_Paper_Package_20261118.zip` inside the ordering archive

The first archive also contains the original experiment brief. Its historical reports and older PDFs retain their original wording. Use `pdf/` for the revised documents.

## Rebuild and verify

Use Python 3 with pypdf, pdfLaTeX, and Poppler. The release was built with pypdf 7.1.0. From the extracted package directory run the following commands.

```sh
python3 verify_evidence.py
python3 verify_sources.py
python3 build_pdfs.py
```

The first command checks the archived release hashes, the original figures and result tables, and the reported counts and errors. The second compares the displayed mathematics, tables, and reference keys with the archived manuscripts. The last command builds four documents and extracts the matrix from the revised paper. All five outputs go in `pdf/`. These commands use the saved research results. The earlier release contains the procedures for rerunning the original experiments.

`SHA256_MANIFEST.json` lists all supplied files except the manifest itself. Rebuilt PDF metadata may vary across software installations.
