"""Typeset the scientific paper and full derivations with 12-point LaTeX."""
from pathlib import Path
import json
import shutil
import subprocess
from pypdf import PdfReader, PdfWriter

ROOT=Path(__file__).resolve().parent


def main():
    tex=shutil.which('pdflatex')
    if not tex:
        raise RuntimeError('PDF typesetting requires pdflatex (TeX Live, MacTeX or MiKTeX); scientific Python results remain available.')
    build=ROOT/'logs/revision/tex'
    build.mkdir(parents=True,exist_ok=True)
    outputs=[]
    for source,name in [('RESEARCH_PAPER.tex','Direction2_SixModel_Paper'),
                        ('SUPPLEMENTARY_INFORMATION.tex','Direction2_Supplementary_Information')]:
        for passno in range(1,4):
            command=[tex,'-interaction=nonstopmode','-halt-on-error',
                     f'-output-directory={build}',f'-jobname={name}',source]
            result=subprocess.run(command,cwd=ROOT/'paper',capture_output=True,text=True)
            (build/f'{name}_pass{passno}.txt').write_text(result.stdout+result.stderr)
            if result.returncode:
                raise RuntimeError(f'{source} typesetting failed; see logs/revision/tex/{name}_pass{passno}.txt\n'+result.stdout[-2000:])
        dest=ROOT/'paper'/f'{name}.pdf'
        shutil.copy2(build/f'{name}.pdf',dest)
        reader=PdfReader(dest)
        log=(build/f'{name}.log').read_text(errors='replace')
        outputs.append({'file':str(dest.relative_to(ROOT)),'pages':len(reader.pages),
                        'body_point_size':12,'paper_size':'A4, with landscape matrix pages',
                        'undefined_references':'undefined references' in log,
                        'overfull_hboxes':log.count('Overfull \\hbox'),
                        'overfull_vboxes':log.count('Overfull \\vbox')})
    mainpdf=PdfReader(ROOT/'paper/Direction2_SixModel_Paper.pdf')
    matrixpages=[]
    for n,page in enumerate(mainpdf.pages):
        text=page.extract_text() or ''
        if all(f'Q{i}:' in text for i in range(1,8)):
            matrixpages.append(n)
    if len(matrixpages)!=3:
        raise RuntimeError(f'Expected three complete comparison-matrix pages; found {matrixpages}')
    writer=PdfWriter()
    for n in matrixpages:
        writer.add_page(mainpdf.pages[n])
    with (ROOT/'paper/Direction2_Comparison_Matrix.pdf').open('wb') as stream:
        writer.write(stream)
    status={'outputs':outputs,'matrix_page_indices_1based':[n+1 for n in matrixpages],
            'matrix_pdf':'paper/Direction2_Comparison_Matrix.pdf',
            'main_page_limit':25,'main_within_original_page_limit':len(mainpdf.pages)<=25,
            'supplement_is_separate':True,'visual_review':'pending latest renders'}
    (ROOT/'logs/revision/PAPER_PDF_STATUS.json').write_text(json.dumps(status,indent=2))
    print(json.dumps(status,indent=2))


if __name__=='__main__':main()
