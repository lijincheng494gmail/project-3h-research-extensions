"""Reproduce exact equilibrium counts, multiplicities and isolating intervals."""
from pathlib import Path
import json
import time
import numpy as np
import pandas as pd
import sympy as sp
from src.root_classification import classify, PARAMETER_KEYS
from src.experiments import rhs
from src.analytic import jacobian_exact

ROOT=Path(__file__).resolve().parent


def example_cases():
    """Rational canonical cases covering 0/1/2/3 roots and repeated roots."""
    R=sp.Rational
    common=dict(r=R(1,5),K=8,alpha=R(4,5),A=2,beta=1,e=R(13,20),m=R(1,2),d=R(1,5),h=0)
    out=[]
    def add(name,kind,p,expected=None):
        out.append(dict(case=name,parameters={**common,**p,'allee':kind},expected_distinct=expected))
    for kind in ['logistic','weak','strong']:
        for h in [0,R(1,20)]:
            add(f'{kind}_no_invasion_h{h}',kind,dict(d=10,h=h),0)
    for h in [0,R(1,20)]:
        add(f'weak_unique_h{h}','weak',dict(r=R(7,10),alpha=R(9,40),m=R(3,10),beta=R(6,5),d=R(1,4),h=h),1)
        add(f'strong_unique_h{h}','strong',dict(r=R(7,10),m=R(3,10),beta=R(6,5),d=R(3,5),h=h),1)
        add(f'strong_two_simple_h{h}','strong',dict(r=R(7,10),m=R(3,10),beta=R(6,5),d=R(1,4),h=h),2)
    add('strong_no_coexistence_despite_K_invasion','strong',dict(r=R(1,10),m=1,e=1,d=R(1,10)),0)
    # Cusp P/e=c*(x-xc)^3, perturb to c*(x-xc)*[(x-xc)^2-delta²].
    for kind in ['weak','strong']:
        a=R(1,5) if kind=='weak' else -R(1,5)
        b=R(27,200) if kind=='weak' else R(1,8)
        c=R(1,50) if kind=='weak' else R(1,80)
        xc=b/(3*c)
        for delta in [0,R(1,2)]:
            epsilon=c*delta**2
            m=a+b*b/(3*c)-epsilon
            constant=c*xc**3-epsilon*xc
            d=R(13,20)*constant
            if delta==0:
                add(f'{kind}_triple_positive_root',kind,dict(m=m,d=d),1)
            else:
                for h in [0,R(1,10000)]:
                    add(f'{kind}_three_simple_h{h}',kind,dict(m=m,d=d,h=h),3)
    add('weak_double_plus_simple_h0','weak',dict(m=R(41,100),d=R(247,4000)),2)
    add('strong_double_plus_simple_h0','strong',dict(m=R(17,80),d=R(117,400)),2)
    add('weak_double_plus_simple_positive_h','weak',
        dict(m=R(839,2000),beta=R(99099,83900),d=R(1843,34650),h=R(302879,249729480)),2)
    add('strong_double_plus_simple_positive_h','strong',
        dict(m=R(91,400),beta=R(363,280),d=R(531,2200),h=R(42,3025)),2)
    # s=A: z=0 is an axial collision and is explicitly excluded.
    for name,K,m,expected in [('positive_initial_slope',3,R(1,2),1),
                              ('zero_slope_positive_second',3,R(2,3),1),
                              ('negative_slope_two_simple',3,R(7,10),2),
                              ('negative_slope_double',3,R(3,4),1),
                              ('triple_axial_collision',2,R(1,2),0)]:
        add('strong_s_equal_A_'+name,'strong',dict(r=1,K=K,A=1,m=m,e=1,beta=1,d=m),expected)
    add('strong_positive_h_triple_axial_collision','strong',
        dict(r=1,K=R(17,8),A=1,m=R(27,34),e=1,beta=1,d=R(27,34),h=R(27,68)),0)
    return out


def main():
    start=time.time()
    (ROOT/'logs/revision').mkdir(parents=True,exist_ok=True)
    old=pd.read_csv(ROOT/'results/extended_equilibria.csv')
    parameters=pd.read_csv(ROOT/'results/extended_parameters.csv',dtype=str)
    summaries=[];rootrows=[];certificates=[]
    for index,row in parameters.iterrows():
        p=row.to_dict();certificate=classify(p)
        metadata={k:p[k] for k in ['scenario','regime','scaling','model']}
        certificate['design_metadata']=metadata
        previous=old[(old.scenario==int(p['scenario']))&(old.scaling==p['scaling'])&(old.model==p['model'])]
        oldz=previous[['x_eq','y_eq']].to_numpy()
        exact_mids=[]
        numeric_p={k:float(sp.Rational(certificate['parameters'][k])) for k in PARAMETER_KEYS}
        numeric_p['allee']=p['allee']
        for rid,interval in enumerate(certificate['roots']):
            lower=np.asarray([float(sp.Rational(interval['x_lower'])),float(sp.Rational(interval['y_lower']))])
            upper=np.asarray([float(sp.Rational(interval['x_upper'])),float(sp.Rational(interval['y_upper']))])
            mid=(lower+upper)/2;exact_mids.append(mid)
            rootrows.append({**metadata,'root_id':rid,**interval,
                'x_mid':mid[0],'y_mid':mid[1],'rhs_residual_mid':float(np.linalg.norm(rhs(mid,numeric_p)))})
        agreement=len(previous)==certificate['distinct_positive']
        error=(max(min(np.max(np.abs(z-oldz),axis=1)) for z in exact_mids) if len(previous) and agreement else 0. if not len(previous) and agreement else np.nan)
        summaries.append({**metadata,'polynomial_degree':certificate['polynomial_degree'],
            'distinct_positive':certificate['distinct_positive'],
            'positive_with_multiplicity':certificate['positive_with_multiplicity'],
            'zero_root_multiplicity':certificate['zero_root_multiplicity'],
            'positive_critical_points':len(certificate['positive_critical_points']),
            'parameter_region':certificate['parameter_region'],
            'previous_numerical_count':len(previous),'count_agreement':agreement,
            'max_absolute_state_discrepancy':error,'method':certificate['classification_status']})
        certificates.append(certificate)
    pd.DataFrame(summaries).to_csv(ROOT/'results/root_classification_audit.csv',index=False)
    pd.DataFrame(rootrows).to_csv(ROOT/'results/root_classification_roots.csv',index=False)
    example_summary=[];example_certificates=[]
    for case in example_cases():
        cert=classify(case['parameters']);cert['case']=case['case']
        if case['expected_distinct'] is not None and cert['distinct_positive']!=case['expected_distinct']:
            raise AssertionError(f"Unexpected exact count for {case['case']}: {cert['distinct_positive']}")
        example_summary.append(dict(case=case['case'],kind=case['parameters']['allee'],
            h=cert['parameters']['h'],parameter_region=cert['parameter_region'],
            distinct_positive=cert['distinct_positive'],positive_with_multiplicity=cert['positive_with_multiplicity'],
            zero_root_multiplicity=cert['zero_root_multiplicity'],
            H0_sign=cert['H0_sign'],critical_value_signs=repr([q['H_sign'] for q in cert['positive_critical_points']]),
            parameters=json.dumps(cert['parameters'],sort_keys=True)))
        example_certificates.append(cert)
    pd.DataFrame(example_summary).to_csv(ROOT/'results/root_classification_examples.csv',index=False)
    interaction=[];interaction_certificates=[]
    gridpath=ROOT/'results/paper_interaction_grid.csv'
    if gridpath.exists():
        grid=pd.read_csv(gridpath,dtype=str)
        grid=grid[(grid.scaling=='same_r')&(grid.growth=='strong')]
        for target in [.34411764705882353,.3558823529411765]:
            values=grid.shape_parameter.astype(float)
            nearest=values.iloc[(values-target).abs().argmin()]
            for _,row in grid[(values==nearest)&grid.h.astype(float).isin([0.,.15])].iterrows():
                pp=row.to_dict();pp['allee']='strong';cert=classify(pp)
                stable=[];midstates=[]
                pnum={k:float(sp.Rational(cert['parameters'][k])) for k in PARAMETER_KEYS};pnum['allee']='strong'
                for interval in cert['roots']:
                    zz=np.asarray([(float(sp.Rational(interval['x_lower']))+float(sp.Rational(interval['x_upper'])))/2,
                                   (float(sp.Rational(interval['y_lower']))+float(sp.Rational(interval['y_upper'])))/2])
                    eig=np.linalg.eigvals(jacobian_exact(pnum,zz))
                    stable.append(max(eig.real)<0);midstates.append(zz)
                largest=max((z for z,yes in zip(midstates,stable) if yes),key=lambda z:z[0],default=[np.nan,np.nan])
                interaction.append(dict(scaling=row.scaling,growth='strong',A_over_K=row.shape_parameter,h=row.h,
                    exact_distinct_positive=cert['distinct_positive'],numerically_stable_count=sum(stable),
                    largest_stable_x=largest[0],largest_stable_y=largest[1],
                    grid_joint_comparison_valid=row.valid_largest_stable_equilibria,
                    interpretation='Grid validity requires both h and h=0 stable branches; mask does not imply this h arm lacks an equilibrium'))
                cert['design_metadata']={'A_over_K':row.shape_parameter,'h':row.h}
                interaction_certificates.append(cert)
        pd.DataFrame(interaction).to_csv(ROOT/'results/root_classification_interaction_audit.csv',index=False)
    payload=dict(parameter_convention='Exact rationals from supplied decimal strings; no unrecorded rounding',
        root_count_method='Square-free Sturm variations at0+ and positive infinity; exact gcd for repeated roots',
        independent_count_method='At most two positive critical points; exact rational interval signs of H at each critical point',
        parameter_certificates=certificates,example_certificates=example_certificates,
        interaction_point_certificates=interaction_certificates)
    (ROOT/'results/root_classification_certificates.json').write_text(json.dumps(payload,indent=2))
    summary=dict(status='exact algorithmic and implicit analytic classification established',
        audited_previous_parameter_sets=len(summaries),
        all_previous_count_agreements=bool(all(q['count_agreement'] for q in summaries)),
        max_state_discrepancy_previous=float(max(q['max_absolute_state_discrepancy'] for q in summaries)),
        rational_examples=len(example_summary),interaction_points=len(interaction),
        max_example_distinct_positive=max(q['distinct_positive'] for q in example_summary),
        max_example_positive_multiplicity=max(q['positive_with_multiplicity'] for q in example_summary),
        universal_physical_root_bound=3,universal_positive_critical_point_multiplicity_bound=2,
        repeated_roots_tested='positive double and triple; axial double/triple collisions; strictly positive-h folds',
        exact_formula_partition='Complete necessary/sufficient critical-value sign conditions, not an expanded closed-form parameter-space tiling',
        elapsed_seconds=time.time()-start)
    (ROOT/'logs/revision/ROOT_CLASSIFICATION.json').write_text(json.dumps(summary,indent=2))
    print(json.dumps(summary,indent=2))
    if not summary['all_previous_count_agreements']:
        raise AssertionError('Old numerical counts require scientific review')


if __name__=='__main__':
    main()
