"""Audit the current manuscript against the six-model design and result tables."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import sys
import time
import tempfile
import shutil
import numpy as np
import pandas as pd
from pypdf import PdfReader

ROOT=Path(__file__).resolve().parent
MODELS=['M0','M1','M2','M3','M4','M5']


def raster_fingerprints(pdf):
    executable=shutil.which('pdftoppm')
    if not executable:raise RuntimeError('pdftoppm is required to check a newly compiled PDF against its inspected page images.')
    with tempfile.TemporaryDirectory(prefix='direction2_pdf_check_') as folder:
        prefix=Path(folder)/'page'
        result=subprocess.run([executable,'-scale-to','1300','-png',str(pdf),str(prefix)],capture_output=True,text=True)
        if result.returncode:raise RuntimeError(result.stderr)
        return [hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(Path(folder).glob('page-*.png'))]


def main():
    start=time.monotonic(); checks=[]
    def check(name, condition, detail=''):
        checks.append(dict(check=name,passed=bool(condition),detail=detail))
    required=['paper/Direction2_SixModel_Paper.pdf','paper/Direction2_Supplementary_Information.pdf',
        'paper/Direction2_Comparison_Matrix.pdf','paper/SIX_MODEL_SEVEN_QUESTION_MATRIX.csv',
        'paper/RESEARCH_PAPER.tex','paper/SUPPLEMENTARY_INFORMATION.tex','paper/USER_MASTER_PROMPT.md',
        'reports/revision/EQUILIBRIUM_CLASSIFICATION.md','reports/revision/GLOBAL_CLASSIFICATION.md',
        'reports/revision/EMPIRICAL_EXTENSION.md','results/paper_paired_comparisons.csv',
        'results/paper_interaction_grid.csv','results/real_cycle_metrics.csv','run.sh','run_complete.sh']
    check('all_current_deliverables_exist',all((ROOT/p).is_file() and (ROOT/p).stat().st_size>0 for p in required),required)
    tests=subprocess.run([sys.executable,'-m','unittest','discover','-s','tests','-v'],cwd=ROOT,capture_output=True,text=True)
    testtext=tests.stdout+tests.stderr
    (ROOT/'logs/revision/ALL_TESTS.txt').write_text(testtext)
    match=re.search(r'Ran (\d+) tests?',testtext)
    check('unit_tests',tests.returncode==0,{'count':int(match.group(1)) if match else None,'returncode':tests.returncode})
    m=pd.read_csv(ROOT/'paper/SIX_MODEL_SEVEN_QUESTION_MATRIX.csv').fillna('')
    check('all_42_model_question_cells',len(m)==42 and m.groupby('model').size().to_dict()=={x:7 for x in MODELS})
    check('seven_distinct_questions_in_every_model',all(set(q.question_id)=={f'Q{i}' for i in range(1,8)} for _,q in m.groupby('model')))
    check('every_cell_contains_actual_result_and_conditions',m.conclusion_and_parameter_conditions.str.len().min()>100)
    check('every_cell_has_support_and_status',m.derivation.ne('').all() and m.supporting_experiments.ne('').all() and m.verification_status.ne('').all())
    partial=m[m.verification_status.str.startswith('partial')]
    check('four_global_classification_partials_explicit',set(zip(partial.model,partial.question_id))=={(x,'Q4') for x in ['M0','M2','M4','M5']})
    q2=m[(m.question_id=='Q2')&m.model.isin(['M0','M2','M4','M5'])]
    check('Allee_root_counts_upgraded_with_exact_scope',q2.verification_status.eq('established_exact_algorithmic_count').all() and
          q2.conclusion_and_parameter_conditions.str.contains('implicit sign').all())
    evidence_paths=[]
    for cell in m.supporting_experiments:
        for name in cell.split(';'):
            name=name.strip()
            if not any((ROOT/base/name).is_file() for base in ['results','logs','logs/revision']):evidence_paths.append(name)
    check('matrix_experiment_paths_resolve',not evidence_paths,evidence_paths)
    r=json.loads((ROOT/'logs/revision/ROOT_CLASSIFICATION.json').read_text())
    check('exact_count_matches_all144_previous_settings',r['audited_previous_parameter_sets']==144 and r['all_previous_count_agreements'])
    check('sharp_bound_and_attainment_certified',r['universal_physical_root_bound']==3 and r['max_example_distinct_positive']==3 and r['rational_examples']==29)
    exact=json.loads((ROOT/'logs/revision/GLOBAL_CLASSIFICATION.json').read_text())
    check('global_derivative_and_Dulac_identities',exact['status']=='PASS' and len(exact['identities'])==7 and set(exact['identities'].values())=={'0'})
    check('global_regions_have_exact_examples',len(exact['examples'])==8)
    check('degenerate_strong_boundary_verified',len(exact['degenerate_A_center_manifold_checks'])==3 and all(x['formula_agrees_exactly'] for x in exact['degenerate_A_center_manifold_checks']))
    params=pd.read_csv(ROOT/'results/extended_parameters.csv')
    check('canonical_M0_unchanged',params[params.model=='M0'].h.eq(0).all() and params[params.model=='M0'].allee.eq('weak').all())
    oldmanifest=json.loads((ROOT/'logs/ORIGINAL_PACKAGE_SHA256.json').read_text())
    key='Direction_2_Six_Model_Factorial/src/experiments.py'
    check('original_model_implementation_preserved',hashlib.sha256((ROOT/'src/experiments.py').read_bytes()).hexdigest()==oldmanifest[key])
    tab=pd.read_csv(ROOT/'results/paper_paired_comparisons.csv')
    check('all_24_paired_summary_rows',len(tab)==24 and tab.n_pairs.eq(24).all())
    needed={('competition','M1','M3'),('competition','M0','M4'),('competition','M2','M5'),
        ('growth_h0','M1','M0'),('growth_h0','M1','M2'),('growth_h0','M0','M2'),
        ('growth_hplus','M3','M4'),('growth_hplus','M3','M5'),('growth_hplus','M4','M5'),
        ('interaction_weak_vs_logistic','M1->M3','M0->M4'),
        ('interaction_strong_vs_logistic','M1->M3','M2->M5'),('interaction_strong_vs_weak','M0->M4','M2->M5')}
    check('growth_competition_interaction_dimensions_complete',all(set(zip(a.contrast_type,a.from_model,a.to_model))==needed for _,a in tab.groupby('scaling')))
    raw=pd.read_csv(ROOT/'results/extended_contrasts.csv')
    grouped=raw[raw.regime=='starter_distribution'].groupby(['scaling','contrast_type','from_model','to_model']).delta_y_tail_mean.mean()
    differences=[abs(row.mean_delta_predator-grouped.loc[(row.scaling,row.contrast_type,row.from_model,row.to_model)]) for row in tab.itertuples()]
    check('paired_summary_values_recomputed',max(differences)<1e-12,float(max(differences)))
    phase=pd.read_csv(ROOT/'results/paper_phase_trajectories.csv')
    check('all_six_phase_and_time_series_generated',len(phase)==18*501 and phase.groupby(['model','initial']).size().eq(501).all())
    check('matched_initial_states_in_phase_comparison',phase.groupby('initial')[['x0','y0']].nunique().max().max()==1)
    grid=pd.read_csv(ROOT/'results/paper_interaction_grid.csv')
    check('interaction_map_missing_references_are_not_zeroes',len(grid)==5740 and grid[~grid.valid_largest_stable_equilibria].interaction_predator.isna().all() and
          grid[grid.valid_largest_stable_equilibria].interaction_predator.notna().all())
    map_audit=pd.read_csv(ROOT/'results/root_classification_interaction_audit.csv')
    check('map_transition_has_four_exact_root_checks',len(map_audit)==4)
    numerical=json.loads((ROOT/'logs/revision/PAPER_NUMERICS.json').read_text())
    check('new_equilibrium_map_original_ODE_residuals',numerical['phase_max_equilibrium_residual']<1e-8 and numerical['interaction_grid']['max_equilibrium_rhs_residual']<1e-7,numerical)
    emp=json.loads((ROOT/'logs/revision/EMPIRICAL_EXTENSION.json').read_text())
    check('prediction_caches_reproduce_original_scores',emp['cache_score_checks']==72 and emp['max_cache_score_difference']<1e-12 and emp['inputs_unchanged'])
    check('cycle_extension_uses_all_models_and_no_test_refitting',emp['free_model_population_records']==48 and emp['new_model_fits']==0 and emp['new_ODE_simulations']==0)
    cycle=pd.read_csv(ROOT/'results/real_cycle_metrics.csv')
    f=cycle[cycle.model.isin(MODELS)&(cycle.forecast_mode=='free')]
    check('free_cycle_result_and_missing_periods_preserved',len(f)==48 and emp['free_records_with_late_amplitude_above_floor']==0 and emp['free_periods_estimable']==0)
    check('cycle_threshold_sensitivity_retained',emp['threshold_sensitivity_rows']==1296 and emp['observed_threshold_sensitivity_rows']==72)
    source=(ROOT/'paper/RESEARCH_PAPER.tex').read_text()
    headings=['Common properties across all six models','Effects of Allee growth','Effects of predator competition',
        'Interaction between both mechanisms','Population disturbance and recovery','Empirical prediction comparison']
    positions=[source.index(r'\subsection{'+s+'}') for s in headings]
    check('specified_Results_order',positions==sorted(positions) and source.index(r'\input{comparison_matrix.tex}')<positions[0])
    check('all_required_paper_sections',all(s in source for s in [r'\begin{abstract}',r'\section{Introduction}',r'\section{Results}',r'\section{Discussion}',r'\section{Methods}',r'\input{references.tex}',r'\appendix']))
    check('no_draft_placeholders','TODO' not in source and 'PLACEHOLDER' not in source and '???' not in source)
    pdf=json.loads((ROOT/'logs/revision/PAPER_PDF_STATUS.json').read_text())
    check('main_paper_at_most25pages',pdf['main_within_original_page_limit'],pdf['outputs'][0]['pages'])
    check('typeset_formulas_and_tables_do_not_overflow',all(o['overfull_hboxes']==0 and o['overfull_vboxes']==0 and not o['undefined_references'] for o in pdf['outputs']),pdf['outputs'])
    check('three_readable_matrix_pages',len(PdfReader(ROOT/'paper/Direction2_Comparison_Matrix.pdf').pages)==3)
    for filename in ['Direction2_SixModel_Paper.pdf','Direction2_Supplementary_Information.pdf']:
        reader=PdfReader(ROOT/'paper'/filename)
        check(filename+'_no_empty_pages',all(len((p.extract_text() or '').strip())>60 for p in reader.pages))
    visual=ROOT/'logs/revision/PAPER_VISUAL_QA.json'
    if visual.exists():
        qa=json.loads(visual.read_text())
        compatible=qa.get('state')=='pass'
        modes={}
        for p,digest in qa.get('pdf_sha256',{}).items():
            if hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==digest:
                modes[p]='identical inspected PDF bytes'
            else:
                matched=raster_fingerprints(ROOT/p)==qa.get('render_fingerprints',{}).get(p,[])
                compatible &= matched
                modes[p]='identical inspected page renders' if matched else 'changed page renders; visual review required'
        compatible &= len(modes)>=2
        check('latest_PDF_visual_review',compatible,modes)
        if compatible:
            pdf['visual_review']='passed by inspected PDF bytes or exact page-image equivalence'
            (ROOT/'logs/revision/PAPER_PDF_STATUS.json').write_text(json.dumps(pdf,indent=2))
    else:
        check('latest_PDF_visual_review',False,'Render and inspect both PDFs before final packaging.')
    failed=[x['check'] for x in checks if not x['passed']]
    status={'state':'pass' if not failed else 'failed','checks':len(checks),'passed':len(checks)-len(failed),
        'failed':failed,'matrix_cells':42,'established_with_stated_scope':38,'partial_global_classifications':4,
        'full_general_global_attractor_classification':False,'unit_tests':int(match.group(1)) if match else None,
        'elapsed_seconds':time.monotonic()-start,'details':checks}
    (ROOT/'logs/revision/PAPER_VERIFICATION.json').write_text(json.dumps(status,indent=2))
    print(json.dumps({k:v for k,v in status.items() if k!='details'},indent=2))
    if failed:raise SystemExit(1)


if __name__=='__main__':main()
