"""Reproduce algebra, bifurcation witnesses and derivative checks.

All scenarios here are synthetic; units are arbitrary population and time units.
SymPy differentiates the actual vector field, with no finite-difference l1 fit.
"""
from pathlib import Path
from itertools import product
import json
import numpy as np
import pandas as pd
import sympy as sp
from src.analytic import (growth_derivatives, positive_equilibria,
                          jacobian_exact, growth_coefficients)
from src.experiments import MODEL_DEFS, make, rhs, sample_cases

ROOT=Path(__file__).resolve().parent


def symbolic_system(p):
    x,y=sp.symbols('x y', positive=True)
    coeff=[sp.Rational(str(v)) for v in growth_coefficients(p)]
    g=sum(c*x**i for i,c in enumerate(coeff))
    r=lambda k: sp.Rational(str(p[k]))
    F=x*(g-r('m')*y/(r('beta')+y))
    G=y*(r('e')*r('m')*x/(r('beta')+y)-r('d')-r('h')*y)
    return (x,y),sp.Matrix([F,G])


def hopf_lyapunov(p,z):
    """Planar l1 in Kuznetsov's stated canonical-coordinate normalization.

    Original deviations = P @ (u,v), P=[[1,0],[-a/b,-omega/b]],
    so the linear transformed system is u'=-omega*v, v'=omega*u.
    Return l1 as 1/(8w)*(Puuu+Puvv+Quuv+Qvvv)+1/(8w²)*[...].
    """
    J=jacobian_exact(p,z)
    omega=float(np.sqrt(np.linalg.det(J)))
    a,b=J[0]
    P=np.asarray([[1.,0.],[-a/b,-omega/b]])
    Pinv=np.linalg.inv(P)
    symbols,vec=symbolic_system(p)
    sub=dict(zip(symbols,z))
    d2=np.empty((2,2,2)); d3=np.empty((2,2,2,2))
    for out in range(2):
        for i,j in product(range(2),repeat=2):
            d2[out,i,j]=float(sp.diff(vec[out],symbols[i],symbols[j]).subs(sub))
        for i,j,k in product(range(2),repeat=3):
            d3[out,i,j,k]=float(sp.diff(vec[out],symbols[i],symbols[j],symbols[k]).subs(sub))
    D2=np.einsum('ao,oij,ib,jc->abc',Pinv,d2,P,P)
    D3=np.einsum('ao,oijk,ib,jc,kd->abcd',Pinv,d3,P,P,P)
    cubic=D3[0,0,0,0]+D3[0,0,1,1]+D3[1,0,0,1]+D3[1,1,1,1]
    quadratic=(D2[0,0,1]*(D2[0,0,0]+D2[0,1,1])
        -D2[1,0,1]*(D2[1,0,0]+D2[1,1,1])
        -D2[0,0,0]*D2[1,0,0]+D2[0,1,1]*D2[1,1,1])
    l1=cubic/(8*omega)+quadratic/(8*omega**2)
    # Independent multilinear formula in the canonical coordinates, q norm=1.
    A=Pinv@J@P
    q=np.asarray([1.,-1j])/np.sqrt(2)
    pvec=q
    B=lambda u,v: np.einsum('ijk,j,k->i',D2,u,v)
    C=lambda u,v,w: np.einsum('ijkl,j,k,l->i',D3,u,v,w)
    expr=(np.vdot(pvec,C(q,q,q.conj()))
        -2*np.vdot(pvec,B(q,np.linalg.solve(A,B(q,q.conj()))))
        +np.vdot(pvec,B(q.conj(),np.linalg.solve(2j*omega*np.eye(2)-A,B(q,q)))))
    l1_complex=float(expr.real/(2*omega))
    return dict(omega=omega,l1=float(l1),l1_complex=l1_complex,
                l1_formula_difference=float(abs(l1-l1_complex)))


def invariant_derivatives(p,x0):
    """Derivatives on the prey-nullcline for SN/BT and Hopf checks."""
    x,beta,d=sp.symbols('x beta d', positive=True)
    co=[sp.Rational(str(v)) for v in growth_coefficients(p)]
    g=sum(c*x**i for i,c in enumerate(co)); m=sp.Rational(str(p['m']))
    e=sp.Rational(str(p['e']));h=sp.Rational(str(p['h']))
    S=m-g
    E=e*x*S**2-beta*d*S-h*beta**2*g
    T=x*sp.diff(g,x)-e*x*g*S/(beta*m)-h*beta*g/S
    sub={x:x0,beta:p['beta'],d:p['d']}
    val=lambda expr: float(expr.subs(sub))
    Ex=sp.diff(E,x); Exx=sp.diff(E,x,2)
    matrix=sp.Matrix([E,Ex,T]).jacobian([x,beta,d])
    Dmatrix=np.asarray(matrix.subs(sub),dtype=float)
    v=val(E);ex=val(Ex);exx=val(Exx);tx=val(sp.diff(T,x))
    gg,gp,gpp=growth_derivatives(x0,p)
    # In u=x-x*, v=F(x,y), u'=v and v'=H(u,v).
    a20=-x0*gg*exx/(2*p['m']*p['beta'])
    ES=2*p['e']*x0*(p['m']-gg)-p['beta']*p['d']+p['h']*p['beta']**2
    b11=gp+x0*gpp+(ex-gp*ES-gg*(2*p['e']*(p['m']-gg)-2*p['e']*x0*gp))/(p['m']*p['beta'])
    return dict(scalar_E=v, scalar_E_x=ex, scalar_E_xx=exx,
        scalar_E_d=val(sp.diff(E,d)),bt_a20=a20,bt_b11=b11,
        bt_unfolding_determinant=float(np.linalg.det(Dmatrix)),
        trace_derivative_wrt_d=(tx*p['beta']*(p['m']-gg)/ex if abs(ex)>1e-14 else np.nan))


def witness(kind,event,competition):
    base=dict(r=.2,K=8.,alpha=.8,A=2.,m=.8,beta=1.,e=.65,d=.2,h=0.,allee=kind)
    x=1. if kind=='weak' else 3.
    g,gp,gpp=growth_derivatives(x,base);a=x*gp
    if not competition:
        m=(.8 if kind=='weak' else .6) if event=='Hopf' else g+a
        base['m']=m
        if event=='saddle_node':
            base['beta']=1.
            base['d']=base['e']*x*(m-g)/base['beta']
        else:
            base['d']=x*m*gp/g
            base['beta']=base['e']*g*(m-g)/(m*gp)
    else:
        m=g+1.1*a;S=m-g;t=g/m
        wbt=a*a/(g*(1-t))
        if event=='Hopf':
            w=.5*(wbt+a/t);k=a-t*w
        else:
            w=wbt*(.5 if event=='saddle_node' else 1.)
            k=g*(S-a)*w/(m*a)
        base['m']=m;base['beta']=base['e']*x*S/w
        y=base['e']*x*g/w
        base['h']=k/y;base['d']=w-k
    y=base['beta']*g/(base['m']-g)
    model={('weak',False):'M0',('weak',True):'M4',('strong',False):'M2',('strong',True):'M5'}[(kind,competition)]
    J=jacobian_exact(base,[x,y])
    deriv=invariant_derivatives(base,x)
    row=dict(model=model,event=event,x=x,y=y,**base,
             trace=float(np.trace(J)),determinant=float(np.linalg.det(J)),
             rhs_norm=float(np.linalg.norm(rhs([x,y],base))),**deriv)
    if event=='Hopf':
        row.update(hopf_lyapunov(base,[x,y]))
        row['hopf_type']='supercritical' if row['l1']<0 else 'subcritical'
        # Enrichment derivative with alpha and A fixed in no-competition examples.
        eps=base['K']*1e-5
        trace=[]
        for delta in [-eps,eps]:
            pp={**base,'K':base['K']+delta}
            zs=positive_equilibria(pp)
            zz=min(zs,key=lambda zz:abs(zz[0]-x))
            trace.append(np.trace(jacobian_exact(pp,zz)))
        row['trace_derivative_wrt_K']=(trace[1]-trace[0])/(2*eps)
    return row


def exact_certificate(kind,event,competition):
    """Rational-arithmetic checks of equilibrium and critical invariants."""
    R=sp.Rational
    X,Y,B,D=sp.symbols('X Y B D')
    r=R(1,5);K=sp.Integer(8);alpha=R(4,5);A=sp.Integer(2);e=R(13,20)
    x=sp.Integer(1 if kind=='weak' else 3)
    gfun=r*(1-X/K)*(1+alpha*X if kind=='weak' else X/A-1)
    g=gfun.subs(X,x);gp=sp.diff(gfun,X).subs(X,x);a=x*gp
    if not competition:
        m=(R(4,5) if kind=='weak' else R(3,5)) if event=='Hopf' else g+a
        h=sp.Integer(0)
        if event=='saddle_node':
            beta=sp.Integer(1);d=e*x*(m-g)
        else:
            d=x*m*gp/g;beta=e*g*(m-g)/(m*gp)
    else:
        m=g+R(11,10)*a;S=m-g;t=g/m;wbt=a*a/(g*(1-t))
        if event=='Hopf':
            w=(wbt+a/t)/2;k=a-t*w
        else:
            w=wbt*(R(1,2) if event=='saddle_node' else 1)
            k=g*(S-a)*w/(m*a)
        beta=e*x*S/w;y=e*x*g/w;h=k/y;d=w-k
    y=beta*g/(m-g)
    F=X*(gfun-m*Y/(B+Y));G=Y*(e*m*X/(B+Y)-D-h*Y)
    sub={X:x,Y:y,B:beta,D:d}
    J=sp.Matrix([F,G]).jacobian([X,Y]).subs(sub)
    S=m-gfun
    E=e*X*S*S-B*D*S-h*B*B*gfun
    T=X*sp.diff(gfun,X)-e*X*gfun*S/(B*m)-h*B*gfun/S
    ss={X:x,B:beta,D:d}
    Ex=sp.diff(E,X);Exx=sp.diff(E,X,2)
    unfold=sp.Matrix([E,Ex,T]).jacobian([X,B,D]).subs(ss).det()
    a20=sp.simplify((-X*gfun*Exx/(2*m*B)).subs(ss))
    ES=2*e*X*S-B*D+h*B*B
    b11=sp.simplify((sp.diff(gfun,X)+X*sp.diff(gfun,X,2)
        +(Ex-sp.diff(gfun,X)*ES-gfun*(2*e*S-2*e*X*sp.diff(gfun,X)))/(m*B)).subs(ss))
    out=dict(kind=kind,event=event,competition=competition,
        parameters={k:str(v) for k,v in dict(r=r,K=K,alpha=alpha,A=A,e=e,m=m,beta=beta,d=d,h=h,x=x,y=y).items()},
        F=str(sp.simplify(F.subs(sub))),G=str(sp.simplify(G.subs(sub))),
        trace=str(sp.simplify(sp.trace(J))),determinant=str(sp.factor(J.det())),
        E_x=str(sp.simplify(Ex.subs(ss))),E_xx=str(sp.simplify(Exx.subs(ss))),
        E_d=str(sp.simplify(sp.diff(E,D).subs(ss))),
        bt_a20=str(a20),bt_b11=str(b11),unfolding_rank_determinant=str(sp.factor(unfold)))
    if event=='Hopf':
        u,v=sp.symbols('u v');omega=sp.sqrt(sp.factor(J.det()))
        P=sp.Matrix([[1,0],[-J[0,0]/J[0,1],-omega/J[0,1]]])
        trans=P.inv()*sp.Matrix([F,G]).subs({B:beta,D:d}).subs(
            {X:x+u,Y:y+P[1,0]*u+P[1,1]*v},simultaneous=True)
        at0={u:0,v:0}
        diff=lambda i,nu,nv: sp.diff(trans[i],u,nu,v,nv).subs(at0)
        Puu,Puv,Pvv=diff(0,2,0),diff(0,1,1),diff(0,0,2)
        Quu,Quv,Qvv=diff(1,2,0),diff(1,1,1),diff(1,0,2)
        l1=sp.simplify((diff(0,3,0)+diff(0,1,2)+diff(1,2,1)+diff(1,0,3))/(8*omega)
            +(Puv*(Puu+Pvv)-Quv*(Quu+Qvv)-Puu*Quu+Pvv*Qvv)/(8*omega**2))
        out['l1_exact']=str(l1)
        out['l1_exact_sign']=int(sp.sign(l1))
        out['trace_derivative_d']=str(sp.simplify((sp.diff(T,X)*B*S/Ex).subs(ss)))
    crit=out['trace']=='0' if event=='Hopf' else out['determinant']=='0'
    out['symbolic_equilibrium_and_critical_invariant_pass']=(out['F']=='0' and out['G']=='0' and crit)
    if event=='Bogdanov_Takens':
        out['symbolic_BT_nondegeneracy_pass']=(out['trace']=='0' and a20!=0 and b11!=0 and unfold!=0)
    assert out['symbolic_equilibrium_and_critical_invariant_pass']
    return out


def main():
    ROOT.joinpath('results').mkdir(exist_ok=True)
    rows=[]
    for base in sample_cases(18):
        for model in MODEL_DEFS:
            p=make(base,model)
            xs=[0.,p['K']]+([p['A']] if p['allee']=='strong' else [])
            states=[(np.asarray([x,0.]),'axis') for x in xs]+[(z,'positive') for z in positive_equilibria(p)]
            for index,(z,kind) in enumerate(states):
                J=jacobian_exact(p,z);eig=np.linalg.eigvals(J);det=np.linalg.det(J)
                row=dict(scenario=base['scenario'],model=model,root_id=index,kind=kind,x=z[0],y=z[1],
                    trace=np.trace(J),determinant=det,max_eig_real=max(eig.real),
                    rhs_norm=np.linalg.norm(rhs(z,p)),alpha_K=p['alpha']*p['K'],
                    predator_invasion_at_K=p['e']*p['m']*p['K']/p['beta']-p['d'])
                if kind=='positive':
                    row.update(dx_dh=-J[0,1]*z[1]**2/det,dy_dh=J[0,0]*z[1]**2/det)
                    row['weak_GAS_sufficient']=(p['allee']=='weak' and z[0]>=p['K']-1/p['alpha'])
                rows.append(row)
    pd.DataFrame(rows).to_csv(ROOT/'results/analytical_equilibria.csv',index=False)
    witnesses=[witness(kind,event,h) for kind,event,h in product(['weak','strong'],['Hopf','saddle_node','Bogdanov_Takens'],[False,True])]
    W=pd.DataFrame(witnesses)
    W.to_csv(ROOT/'results/analytical_bifurcation_witnesses.csv',index=False)
    checks=[]
    for row in witnesses:
        checks.append(dict(model=row['model'],event=row['event'],
            equilibrium_residual_ok=row['rhs_norm']<1e-11,
            critical_invariant_ok=abs(row['trace'] if row['event']=='Hopf' else row['determinant'])<1e-10,
            second_invariant_ok=(row['determinant']>1e-8 if row['event']=='Hopf' else
                abs(row['trace'])>1e-8 if row['event']=='saddle_node' else abs(row['trace'])<1e-10),
            nondegeneracy_ok=(abs(row['l1'])>1e-6 and abs(row['trace_derivative_wrt_d'])>1e-6 if row['event']=='Hopf' else
                abs(row['scalar_E_xx'])>1e-6 and abs(row['scalar_E_d'])>1e-6 if row['event']=='saddle_node' else
                abs(row['bt_a20'])>1e-6 and abs(row['bt_b11'])>1e-6 and abs(row['bt_unfolding_determinant'])>1e-9),
            independent_l1_agreement_ok=(row.get('l1_formula_difference',0.)<1e-8)))
    C=pd.DataFrame(checks);C.to_csv(ROOT/'results/analytical_bifurcation_checks.csv',index=False)
    certificates=[exact_certificate(kind,event,h) for kind,event,h in product(['weak','strong'],['Hopf','saddle_node','Bogdanov_Takens'],[False,True])]
    ROOT.joinpath('logs/ANALYTICAL_EXACT_CERTIFICATES.json').write_text(json.dumps(certificates,indent=2))
    enrichment=[{**row,'note':'K variation holds alpha and A fixed'} for row in witnesses if row['event']=='Hopf' and row['model']!='M5']
    # A separate positive-h M5 point near its h=0 Hopf shows destabilization
    # under increasing K; the primary M5 witness has the opposite K direction.
    pp=dict(r=.2,K=8.,alpha=0.,A=2.,e=.65,m=.6,beta=1.,d=.2,h=0.,allee='strong')
    xx=3.;gg,gp,_=growth_derivatives(xx,pp);aa=xx*gp;tt=gg/pp['m']
    ww=.999*aa/tt;kk=aa-tt*ww;yy=pp['e']*xx*gg/ww
    pp['beta']=pp['e']*xx*(pp['m']-gg)/ww;pp['d']=ww-kk;pp['h']=kk/yy
    traces=[]
    for delta in [-8e-5,8e-5]:
        pq={**pp,'K':pp['K']+delta}
        zz=min(positive_equilibria(pq),key=lambda z:abs(z[0]-xx))
        traces.append(np.trace(jacobian_exact(pq,zz)))
    JJ=jacobian_exact(pp,[xx,yy])
    enrichment.append(dict(model='M5',event='Hopf',**pp,x=xx,y=yy,trace=np.trace(JJ),determinant=np.linalg.det(JJ),
        **hopf_lyapunov(pp,[xx,yy]),trace_derivative_wrt_K=(traces[1]-traces[0])/1.6e-4,
        note='Distinct positive-h near-h0 witness; K variation holds A fixed'))
    pd.DataFrame(enrichment).to_csv(ROOT/'results/analytical_enrichment_witnesses.csv',index=False)
    status=dict(witness_count=len(W),all_checks_pass=bool(C.iloc[:,2:].all().all()),
        max_equilibrium_residual=float(W.rhs_norm.max()),
        max_independent_l1_difference=float(W.l1_formula_difference.max()),
        model_roles='Synthetic existence witnesses, not observed ecological parameter estimates.',
        l1_normalization='canonical real coordinates; q=(1,-i)/sqrt(2), Euclidean q norm1 in canonical coordinates',
        sources=['https://www.scholarpedia.org/article/Andronov-Hopf_bifurcation',
                 'https://www.scholarpedia.org/article/Bogdanov-Takens_bifurcation'])
    ROOT.joinpath('logs/ANALYTICAL_CHECKS.json').write_text(json.dumps(status,indent=2))
    print(W[['model','event','h','trace','determinant','l1','bt_a20','bt_b11','bt_unfolding_determinant']].to_string(index=False))
    print(json.dumps(status,indent=2))
    if not status['all_checks_pass']:
        raise RuntimeError('At least one analytical witness failed its checks')


if __name__=='__main__':
    main()
