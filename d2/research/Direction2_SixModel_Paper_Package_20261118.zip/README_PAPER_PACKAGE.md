# Six-model research paper and reproducible evidence

Current version: 18 November 2026, Asia/Shanghai. The research objective and canonical M0–M5 numbering follow `paper/USER_MASTER_PROMPT.md`. M0 is exactly the original weak-Allee equation without −hy². All six models use mxy/(β+y).

Start with `paper/Direction2_SixModel_Paper.pdf`, `paper/Direction2_Supplementary_Information.pdf` and `paper/Direction2_Comparison_Matrix.pdf`. The full 42-cell record is `paper/SIX_MODEL_SEVEN_QUESTION_MATRIX.csv`. `paper/READING_GUIDE_ZH.md` gives a Chinese reading guide.

## Current evidence

All six models receive all seven questions, all three growth contrasts in both competition arms, all three competition pairs and all three interaction contrasts. The matrix has 38 established entries within their stated scope and four explicitly partial Q4 global-attractor classifications. Exact remaining sets are in `paper/UNRESOLVED_CASES.md` and Supplement S4.

The revision establishes a sharp three-positive-equilibrium bound for every Allee model, exact implicit root-count conditions including degeneracies, larger weak-Allee GAS regions and strong-Allee axial/extinction classifications. It adds readable six-model phase/time/equilibrium figures, a 5,740-cell equilibrium interaction grid, and held-experiment cycle diagnostics. The existing validated 432 extended trajectories, 864 contrasts, 48 shocks and four-experiment ecological fits are retained and checked. The cycle extension uses the unchanged prediction caches and performs no new fitting.

## Reproduction

Python 3.13 and the recorded packages were used. Exact versions are in `logs/environment.lock.txt`. PDF typesetting uses `pdflatex` with standard packages `cmap`, `lmodern`, `amsmath`, `amssymb`, `amsthm`, `geometry`, `graphicx`, `booktabs`, `longtable`, `array`, `pdflscape` and `hyperref`, available in TeX Live, MacTeX or MiKTeX. Poppler (`pdftoppm`) is used for PDF rendering and visual equivalence checks.

From this extracted directory:

```bash
bash run.sh paper
```

This creates a Python environment when needed, recomputes the new exact classifications and cycle diagnostics from the bundled evidence, regenerates the new synthetic displays and comparison tables, typesets both PDFs, verifies the current paper and creates the ZIP in `deliverables/`. It reuses the documented earlier fitted parameters and raw results.

```bash
bash run.sh verify
```

This runs the unit tests, audits the preserved earlier evidence and audits the current paper. The current acceptance record is `logs/revision/PAPER_VERIFICATION.json`.

```bash
bash run.sh reproduce
```

This additionally reruns the complete original and extended scientific calculations, including all empirical fits, validation, profiles, sensitivities and convergence checks, before rebuilding the paper. It takes longer than rebuilding from the bundled evidence. Whole-experiment splits and optimization settings remain fixed. Floating-point optimization may vary across software platforms; the acceptance records and solver tolerances define the checks.

`bash run.sh full` and `bash run.sh quick` retain the earlier numerical baseline interface. `bash run.sh tests` runs the model tests. The source data required for scoring are bundled; upstream downloads are retained for attribution and provenance rather than required at runtime.

The PDF visual check accepts either the inspected PDF hash or exact equality of all rendered page images after recompilation. This permits changed PDF creation metadata without weakening the layout check. A genuinely changed layout requires new visual review before the packaging gate passes.

## Files and history

- `paper/`: current paper, full derivations, complete matrix, source TeX and user's master prompt.
- `reports/revision/`: new equilibrium, global and empirical analyses.
- `results/`: all original numerical tables and the new `paper_*`, `root_classification_*`, `global_classification_*` and `real_cycle_*` records.
- `figures/`: PNG and PDF figures; `paper_*` are the new paper displays.
- `src/`, root Python scripts and `tests/`: reproducible model code, exact counting and verification.
- `data/` and `references/`: observed data, primary source provenance, original brief and source-use audit.
- `logs/revision/`: current exact checks, tests, manuscript audit and visual QA.

The pre-revision `reports/FINAL_REPORT_*`, its 34/8 matrices and the corresponding `logs/FINAL_VERIFICATION.json` describe the earlier execution report. They are preserved as history. The authoritative current matrix and paper are under `paper/`; the new exact equilibrium analysis supersedes the earlier four Q2 partial entries. The new final verification lives under `logs/revision/` and explicitly retains four Q4 partial entries.

The ZIP contains `FILE_SHA256.json` for every packaged file. Its CRC and every file hash are checked, followed by a separate fresh-unpack evidence audit. Data attribution is retained; no synthetic parameter is relabeled as a measured ecological constant. AI-use documentation remains in `reports/AI_USE_AND_AUTHOR_REVIEW.md`.
