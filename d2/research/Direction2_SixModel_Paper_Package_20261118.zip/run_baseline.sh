#!/usr/bin/env bash
# Cross-platform bash runner for macOS / Linux / WSL / Git Bash with Python 3.
set -euo pipefail
cd "$(dirname "$0")"
MODE="${1:-quick}"
case "$MODE" in quick|full|tests|package) ;; *) echo 'Usage: bash run.sh [quick|full|tests|package]'; exit 2;; esac
PYTHON="${PYTHON:-python3}"
if ! "$PYTHON" -c 'import numpy, scipy, pandas, matplotlib' >/dev/null 2>&1; then
  echo '[setup] Creating local virtual environment and installing requirements.'
  "$PYTHON" -m venv .venv
  . .venv/bin/activate
  python -m pip install -r requirements.txt
  PYTHON=python
fi
mkdir -p logs
    if [ "$MODE" = package ]; then "$PYTHON" package_results.py; exit 0; fi
if [ "$MODE" = tests ]; then "$PYTHON" -m unittest discover -s tests -v 2>&1 | tee logs/tests.txt; exit 0; fi
"$PYTHON" -m unittest discover -s tests -v 2>&1 | tee logs/tests.txt
"$PYTHON" run_experiment.py --mode "$MODE"
"$PYTHON" package_results.py
echo '[done] Results ZIP in deliverables/'
