# Real ecological observations (already processed)
Source: Bernd Blasius et al., Nature 577:226–230 (2020), DOI 10.1038/s41586-019-1857-0.
Original released CSVs: https://github.com/berndblasius/WaveletAnalysis/tree/master/data/chemostat_experiments
C1–C4 are time series of algae and rotifers with matching nominal external medium (80 mu mol N/l). The supplied files were previously processed into positive complete pairs. They are *observed* ecological data; no synthetic values were inserted.
Verify original dataset license/attribution if redistributing further. Time unit = days; algae scaled to 10^6 cells/ml, rotifers divided by 20 for numerical normalization. This is a chemostat with medium input/dilution, which the two-state classroom equation does not explicitly represent.
Files: `data/real/C1.csv` ... `C4.csv`. No values from these series are to be interpreted as direct field estimates for hare/lynx etc.
