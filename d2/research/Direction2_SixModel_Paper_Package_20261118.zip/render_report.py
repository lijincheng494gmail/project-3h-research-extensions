"""Render the concise English main report in 12-point type, with a live TOC."""
from pathlib import Path
import re, html, json
from reportlab.platypus import BaseDocTemplate,Frame,PageTemplate,Paragraph,Spacer,Table,TableStyle,Image,PageBreak,KeepTogether
from reportlab.platypus.tableofcontents import TableOfContents
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.utils import ImageReader
import matplotlib
from pypdf import PdfReader

ROOT=Path(__file__).resolve().parent
fontroot=Path(matplotlib.get_data_path())/'fonts/ttf'
for name,file in [('StudySerif','DejaVuSerif.ttf'),('StudySerif-Bold','DejaVuSerif-Bold.ttf'),('StudyMono','DejaVuSansMono.ttf')]:
    pdfmetrics.registerFont(TTFont(name,str(fontroot/file)))
pdfmetrics.registerFontFamily('StudySerif',normal='StudySerif',bold='StudySerif-Bold',italic='StudySerif',boldItalic='StudySerif-Bold')
INK=colors.HexColor('#1F1E33');MUTED=colors.HexColor('#6D6988');LIGHT=colors.HexColor('#EFEFF4')
body=ParagraphStyle('Body',fontName='StudySerif',fontSize=12,leading=14.4,spaceAfter=7,textColor=INK,splitLongWords=True)
h1=ParagraphStyle('H1',parent=body,fontName='StudySerif-Bold',fontSize=15,leading=18,spaceBefore=10,spaceAfter=8,keepWithNext=True)
h2=ParagraphStyle('H2',parent=body,fontName='StudySerif-Bold',fontSize=12,leading=14.4,spaceBefore=8,spaceAfter=5,keepWithNext=True)
caption=ParagraphStyle('Caption',parent=body,fontSize=12,leading=14.4,textColor=MUTED)
cellstyle=ParagraphStyle('Cell',parent=body,fontSize=12,leading=14.4,spaceAfter=0)
tocstyle=ParagraphStyle('TOCentry',parent=body,fontSize=12,leading=16,spaceBefore=4,leftIndent=0,firstLineIndent=0)

def inline(s):
    s=html.escape(s)
    s=re.sub(r'\[([^\]]+)\]\(([^)]+)\)',lambda m:'<link href="'+m.group(2)+'" color="#2E756D">'+m.group(1)+'</link>',s)
    s=re.sub(r'`([^`]+)`',r'<font name="StudyMono">\1</font>',s)
    s=re.sub(r'\*\*([^*]+)\*\*',r'<b>\1</b>',s)
    return s

class ReportDoc(BaseDocTemplate):
    def afterFlowable(self,flowable):
        if isinstance(flowable,Paragraph) and getattr(flowable,'toc_level',None) is not None:
            self.notify('TOCEntry',(flowable.toc_level,flowable.getPlainText(),self.page))

def footer(canvas,doc):
    canvas.saveState();canvas.setStrokeColor(colors.HexColor('#D7D5E2'));canvas.line(43,39,552,39)
    canvas.setFillColor(MUTED);canvas.setFont('StudySerif',9)
    canvas.drawString(44,25,'Project 3H | Direction 2 | Research execution report | 18 Nov 2026')
    canvas.drawRightString(551,25,str(doc.page));canvas.restoreState()

def main():
    source=ROOT/'reports/FINAL_REPORT_EN.md';dest=source.with_suffix('.pdf')
    doc=ReportDoc(str(dest),pagesize=(595.28,841.89),leftMargin=44,rightMargin=44,topMargin=42,bottomMargin=49,
        title='Allee growth and predator competition in six matched models',author='Project 3H research execution package')
    frame=Frame(doc.leftMargin,doc.bottomMargin,doc.width,doc.height,id='normal',leftPadding=0,rightPadding=0,topPadding=0,bottomPadding=0)
    doc.addPageTemplates(PageTemplate(id='Main',frames=frame,onPage=footer))
    toc=TableOfContents();toc.levelStyles=[tocstyle]
    title=Paragraph('Allee growth and predator competition<br/>in six matched models',ParagraphStyle('Title',parent=h1,fontSize=20,leading=24))
    story=[title,Spacer(1,8),Paragraph('Project 3H - Direction 2<br/>18 November 2026',body),
           Paragraph('Research execution report. Exact equations, analytic results, matched synthetic experiments, and held-experiment observation benchmarks. Detailed proofs and machine-readable evidence are supplied separately.',body),
           Spacer(1,8),Paragraph('Contents',h1),toc,PageBreak()]
    lines=source.read_text().splitlines();i=0;image_no=0
    while i<len(lines):
        line=lines[i].strip()
        if not line or line.startswith('# '):i+=1;continue
        if line.startswith('## '):
            p=Paragraph(inline(line[3:]),h1);p.toc_level=0;story.append(p);i+=1;continue
        if line.startswith('### '):story.append(Paragraph(inline(line[4:]),h2));i+=1;continue
        if line.startswith('|'):
            rows=[]
            while i<len(lines) and lines[i].strip().startswith('|'):
                raw=[x.strip() for x in lines[i].strip().strip('|').split('|')]
                if not all(re.fullmatch(r':?-+:?',x) for x in raw):rows.append(raw)
                i+=1
            n=len(rows[0]);weights={3:[.19,.49,.32],4:[.22,.29,.245,.245]}.get(n,[1/n]*n)
            if n==4 and rows[0][0]=='Contrast':weights=[.24,.28,.24,.24]
            data=[[Paragraph(('<b>'+inline(x)+'</b>') if j==0 else inline(x),cellstyle) for x in row] for j,row in enumerate(rows)]
            t=Table(data,colWidths=[doc.width*w for w in weights],repeatRows=1,hAlign='LEFT')
            t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),LIGHT),('VALIGN',(0,0),(-1,-1),'TOP'),
                ('LINEBELOW',(0,0),(-1,0),.5,MUTED),('LINEBELOW',(0,1),(-1,-1),.25,colors.HexColor('#D7D5E2')),
                ('LEFTPADDING',(0,0),(-1,-1),5),('RIGHTPADDING',(0,0),(-1,-1),5),
                ('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6)]))
            story.extend([KeepTogether([t]),Spacer(1,8)]);continue
        image_match=re.fullmatch(r'!\[([^]]*)\]\(([^)]+)\)',line)
        if image_match:
            image_no+=1;p=(source.parent/image_match.group(2)).resolve();w,h=ImageReader(str(p)).getSize();width=doc.width
            im=Image(str(p),width=width,height=width*h/w)
            if im.drawHeight>doc.height*.65:im.drawWidth*=doc.height*.65/im.drawHeight;im.drawHeight=doc.height*.65
            story.append(KeepTogether([im,Paragraph(f'Figure {image_no}. '+inline(image_match.group(1)),caption),Spacer(1,7)]));i+=1;continue
        block=[line];i+=1
        while i<len(lines) and lines[i].strip() and not lines[i].lstrip().startswith(('#','|','![')):
            if re.match(r'^\d+\.\s',lines[i].strip()):break
            block.append(lines[i].strip());i+=1
        story.append(Paragraph(inline(' '.join(block)),body))
    doc.multiBuild(story)
    reader=PdfReader(dest);pages=len(reader.pages)
    if pages>25:raise RuntimeError(f'Main report exceeds25page maximum: {pages}')
    texts=[p.extract_text() or '' for p in reader.pages]
    if any(len(t.strip())<30 for t in texts):raise RuntimeError('Unexpected empty report page')
    status={'pdf':'reports/FINAL_REPORT_EN.pdf','pages':pages,'page_limit':25,'body_font':'embedded DejaVu Serif','body_point_size':12,
            'tables_point_size':12,'single_spaced_leading':14.4,'contents_included':True,
            'supporting_proofs_and_code':'separate files; PDF is main report','visual_inspection':'render separately with pdftoppm'}
    (ROOT/'logs/PDF_REPORT_STATUS.json').write_text(json.dumps(status,indent=2));print(json.dumps(status,indent=2))

if __name__=='__main__':main()
