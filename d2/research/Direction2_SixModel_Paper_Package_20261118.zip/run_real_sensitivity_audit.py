"""Audit all training/held transitions of the fixed-scale sensitivity fits."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from src.experiments import getpairs
from src.real_benchmark import make_train,batch_next,solve_next_dop853,decode,names_for,metrics,PROTOCOL
ROOT=Path(__file__).resolve().parent
s=pd.read_csv(ROOT/'results/real_assumption_sensitivity.csv');assert len(s)==24
frames={f'C{i}':pd.read_csv(ROOT/f'data/real/C{i}.csv') for i in range(1,5)}
_,X,DT,Y,scale=make_train(frames,'C4');XX,T,YY=getpairs(frames['C4']);rows=[]
for idx,row in s.iterrows():
    q=json.loads(row.parameter_json);p=decode(np.log([q[n] for n in names_for(row.model)]),row.model,row.fixed_e,row.fixed_beta)
    pred=batch_next(XX,T,p);assert abs(metrics(YY,pred,scale)['nrmse']-row.test_nrmse)<1e-10
    worst_dop=0.;worst_half=0.
    for split,A,B in [('training',X,DT),('test',XX,T)]:
        a=batch_next(A,B,p);b=batch_next(A,B,p,PROTOCOL['step']/2);err=np.max(np.abs(a-b)/scale,axis=1);i=int(np.argmax(err))
        ref=solve_next_dop853(A[i],B[i],p);dop=float(np.max(np.abs(a[i]-ref)/scale));half=float(err.max())
        rows.append(dict(held='C4',model=row.model,fixed_e=row.fixed_e,fixed_beta=row.fixed_beta,split=split,pairs=len(A),
                         main_step=PROTOCOL['step'],half_step=PROTOCOL['step']/2,worst_pair_index=i,
                         max_normalized_halving_difference=half,DOP853_normalized_error_worst_halving=dop))
        worst_dop=max(worst_dop,dop);worst_half=max(worst_half,half)
    s.loc[idx,'max_all_pair_halving_normalized_difference']=worst_half
    s.loc[idx,'DOP853_normalized_error_worst_halving']=worst_dop
pd.DataFrame(rows).to_csv(ROOT/'results/real_sensitivity_solver_audit.csv',index=False)
s.to_csv(ROOT/'results/real_assumption_sensitivity.csv',index=False)
worst_dop=float(s.DOP853_normalized_error_worst_halving.max());worst_half=float(s.max_all_pair_halving_normalized_difference.max())
status=dict(state='pass' if max(worst_dop,worst_half)<PROTOCOL['solver_normalized_acceptance'] else 'failed',
            fixed_scale_fits=len(s),full_pair_groups=len(rows),pair_evaluations_per_step=sum(r['pairs'] for r in rows),
            max_normalized_DOP853_error=worst_dop,max_normalized_halving_difference=worst_half,
            acceptance=PROTOCOL['solver_normalized_acceptance'])
(ROOT/'logs/REAL_SENSITIVITY_AUDIT_STATUS.json').write_text(json.dumps(status,indent=2));print(json.dumps(status,indent=2))
if status['state']!='pass':raise SystemExit(1)
