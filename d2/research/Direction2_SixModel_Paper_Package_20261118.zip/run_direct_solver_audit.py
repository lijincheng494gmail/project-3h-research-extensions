from pathlib import Path
from src.direct_solver_audit import run
if __name__=='__main__':run(Path(__file__).resolve().parent)
