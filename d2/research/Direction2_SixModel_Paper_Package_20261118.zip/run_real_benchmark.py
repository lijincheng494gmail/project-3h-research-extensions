"""Run the prespecified observed-data comparison, retaining canonical models."""
from pathlib import Path
import argparse
from src.real_benchmark import run
if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('--only',choices=['all','main','extras'],default='all');v=a.parse_args()
    run(Path(__file__).resolve().parent,main=v.only!='extras',sensitivity=v.only!='main',profile=v.only!='main')
