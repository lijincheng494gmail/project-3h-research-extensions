"""Independently audit completed evidence, partitions, equations and artifacts."""
from pathlib import Path
import hashlib,json,subprocess,sys,platform,time
import numpy as np
import pandas as pd
from pypdf import PdfReader
from src.experiments import MODEL_DEFS,getpairs
from src.real_benchmark import metrics,make_train,PROTOCOL

ROOT=Path(__file__).resolve().parent

def main():
    start=time.monotonic();checks=[]
    def check(name,condition,detail=''):
        checks.append({'check':name,'pass':bool(condition),'detail':str(detail)})
    required=['reports/FINAL_REPORT_EN.md','reports/FINAL_REPORT_ZH.md','reports/FINAL_REPORT_EN.pdf',
      'reports/RESULTS_BY_HYPOTHESIS.md','reports/ANALYTICAL_RESULTS.md','reports/VERIFICATION_MATRIX.csv',
      'reports/MODEL_QUESTION_MATRIX.csv','reports/SEVEN_QUESTION_EVIDENCE.csv','reports/REAL_DATA_METHODS.md',
      'reports/SYNTHETIC_METHODS.md','reports/REAL_DATA_FINDINGS.md','reports/PRESENTATION_10MIN.md',
      'reports/AI_USE_AND_AUTHOR_REVIEW.md','run_complete.sh','run_analytical_checks.py','run_extensions.py',
      'run_direct_solver_audit.py','run_real_benchmark.py','run_real_validation.py','run_real_audit.py',
      'summarize_real_results.py','build_reports.py','render_report.py','package_results.py',
      'logs/REAL_SOLVER_AUDIT_STATUS.json','logs/REAL_SENSITIVITY_AUDIT_STATUS.json','logs/ANALYTICAL_EXACT_CERTIFICATES.json']
    check('all_required_artifacts',all((ROOT/p).is_file() and (ROOT/p).stat().st_size>0 for p in required),required)
    tests=subprocess.run([sys.executable,'-m','unittest','discover','-s','tests','-v'],cwd=ROOT,capture_output=True,text=True)
    (ROOT/'logs/FINAL_TESTS.txt').write_text(tests.stdout+tests.stderr)
    check('final_unit_tests',tests.returncode==0,(tests.stdout+tests.stderr).splitlines()[-4:])
    original=json.loads((ROOT/'logs/ORIGINAL_PACKAGE_SHA256.json').read_text())
    for m in range(1,5):
        rel=f'data/real/C{m}.csv';expected=original['Direction_2_Six_Model_Factorial/'+rel]
        check('original_C'+str(m)+'_bytes_preserved',hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()==expected)
    input_audit=json.loads((ROOT/'logs/INPUT_ARCHIVE_AUDIT.json').read_text())
    check('original_archive_manifest',input_audit['manifest_entries']==34 and not input_audit['mismatches'])
    q=pd.read_csv(ROOT/'reports/VERIFICATION_MATRIX.csv')
    check('criteria_statuses_explicit',q.status.isin(['done','partial','blocked','excluded']).all() and q.evidence.notna().all())
    for filename in ['reports/MODEL_QUESTION_MATRIX.csv','reports/SEVEN_QUESTION_EVIDENCE.csv']:
        df=pd.read_csv(ROOT/filename)
        check(filename+'_42cells',len(df)==42 and df.groupby('model').size().to_dict()=={m:7 for m in MODEL_DEFS})
        check(filename+'_34done_8partial',df.status.value_counts().to_dict()=={'done':34,'partial':8})
    missing=[]
    for text in q.evidence:
        for path in text.split(';'):
            if path.strip()=='logs/FINAL_VERIFICATION.json':continue  # produced by this audit itself
            if not (ROOT/path.strip()).exists():missing.append(path)
    check('verification_evidence_paths',not missing,missing)
    f=pd.read_csv(ROOT/'results/extended_factorial.csv');c=pd.read_csv(ROOT/'results/extended_contrasts.csv')
    check('factorial_denominators',len(f)==432 and f.groupby(['scenario','scaling','initial']).size().eq(6).all())
    check('conditional_contrasts_denominator',len(c)==864 and c.groupby(['scenario','scaling','initial']).size().eq(12).all())
    for scaling in ['same_r','reference_growth_matched']:
        sub=c[(c.scaling==scaling)&(c.regime=='starter_distribution')]
        check('paired_sample_denominator_'+scaling,sub.groupby(['contrast_type','from_model','to_model']).size().eq(24).all())
    params=pd.read_csv(ROOT/'results/extended_parameters.csv')
    check('M0_no_added_competition',params.loc[params.model=='M0','h'].eq(0).all())
    check('strict_positive_h_extensions',params.loc[params.model.isin(['M3','M4','M5']),'h'].gt(0).all())
    norm=params[params.scaling=='reference_growth_matched']
    check('reference_growth_calibration',norm.groupby('scenario').g_reference.apply(lambda x:np.ptp(x.to_numpy())).max()<1e-12)
    root=pd.read_csv(ROOT/'results/extended_independent_root_audit.csv')
    check('independent_polynomial_roots',len(root)==144 and root.agreement.all())
    shocks=pd.read_csv(ROOT/'results/extended_shock_recovery.csv')
    check('shock_denominator_and_levels',len(shocks)==48 and shocks.groupby('model').size().eq(8).all() and
          set(shocks.reduction_fraction)=={.05,.25,.60,.85})
    check('shock_successes_exact',shocks.groupby('model').recovered.sum().to_dict()=={'M0':8,'M1':8,'M2':6,'M3':8,'M4':8,'M5':7})
    basin=pd.read_csv(ROOT/'results/extended_basin_boundaries.csv')
    check('basin_brackets_extended_horizon',len(basin)==2 and basin.valid_T1600_bracket.all() and basin.bracket_width_fraction.max()<1e-6)
    audit=pd.read_csv(ROOT/'results/extended_solver_audit.csv')
    check('synthetic_tighter_horizon_audit',len(audit)==48 and audit.max_scaled_path_error_T400.max()<1e-6 and
          audit.outcome_T400.eq(audit.outcome_T800).all(),audit.max_scaled_path_error_T400.max())
    direct=json.loads((ROOT/'logs/DIRECT_SOLVER_AUDIT.json').read_text())
    directrows=pd.read_csv(ROOT/'results/direct_solver_audit.csv')
    check('independent_direct_state_solver',len(directrows)==12 and directrows['pass'].all(),direct)
    bcheck=pd.read_csv(ROOT/'results/analytical_bifurcation_checks.csv')
    check('all_12_bifurcation_checks',len(bcheck)==12 and bcheck.iloc[:,2:].all().all())
    exact=json.loads((ROOT/'logs/ANALYTICAL_EXACT_CERTIFICATES.json').read_text())
    # Exact certificate format is retained in full; numerical check columns independently gate each required property.
    check('exact_symbolic_certificates_present',len(json.dumps(exact))>1000)
    states=pd.read_csv(ROOT/'results/analytical_equilibria.csv')
    strongaxes=states[(states.model.isin(['M2','M5']))&(states.kind=='axis')]
    check('all_strong_axial_equilibria',len(strongaxes)==18*2*3 and strongaxes.groupby(['scenario','model']).size().eq(3).all())
    scores=pd.read_csv(ROOT/'results/real_benchmark_scores.csv');attempts=pd.read_csv(ROOT/'results/real_fit_attempts.csv')
    folded=pd.read_csv(ROOT/'results/real_folds.csv');nested=pd.read_csv(ROOT/'results/real_nested_validation.csv')
    check('real_score_denominator',len(scores)==36 and scores.groupby('held').size().eq(9).all())
    check('real_model_fits_converged',scores[scores.model.isin(MODEL_DEFS)].fit_success.all())
    check('equal_optimizer_budget',len(attempts)==48 and attempts.groupby(['held','model']).size().eq(2).all() and attempts.nfev.le(100).all())
    check('explicit_inner_validation',len(nested)==24 and nested.fit_success.all() and
          not nested.test_observations_used_for_fit.any() and not nested.validation_observations_used_for_fit.any())
    frames={f'C{i}':pd.read_csv(ROOT/f'data/real/C{i}.csv') for i in range(1,5)}
    predictions=pd.read_csv(ROOT/'results/real_predictions.csv')
    scale_ok=True;score_errors=[];split_ok=True
    for held,df in frames.items():
        train,X,DT,Y,scale=make_train(frames,held);fold=folded[folded.held==held].iloc[0]
        split_ok &= fold.train==';'.join(train) and int(fold.train_pairs)==len(X) and int(fold.test_pairs)==len(df)-1
        split_ok &= fold.train_pair_sha256==hashlib.sha256(np.column_stack([X,DT,Y]).tobytes()).hexdigest()
        scale_ok &= np.allclose(scale,[fold.train_scale_x,fold.train_scale_y],rtol=1e-13,atol=1e-13)
        _,_,YY=getpairs(df)
        for model in MODEL_DEFS:
            pr=predictions[(predictions.held==held)&(predictions.model==model)]
            check('held_prediction_length_'+held+'_'+model,len(pr)==len(YY))
            recompute=metrics(YY,pr[['predicted_x','predicted_y']].to_numpy(),scale)
            saved=scores[(scores.held==held)&(scores.model==model)].iloc[0]
            score_errors.append(abs(recompute['nrmse']-saved.test_nrmse))
    check('training_only_data_and_scales',split_ok and scale_ok)
    check('reported_real_scores_recomputed',max(score_errors)<1e-12,max(score_errors))
    precision=json.loads((ROOT/'logs/REAL_SOLVER_AUDIT_STATUS.json').read_text())
    check('real_independent_precision',precision['state']=='pass' and precision['worst_DOP853_normalized_error']<1e-4 and
          precision['worst_all_pair_halving_normalized_difference']<1e-4,precision)
    sensitivity=json.loads((ROOT/'logs/REAL_SENSITIVITY_AUDIT_STATUS.json').read_text())
    check('sensitivity_independent_precision',sensitivity['state']=='pass' and sensitivity['fixed_scale_fits']==24 and
          sensitivity['max_normalized_DOP853_error']<1e-4 and sensitivity['max_normalized_halving_difference']<1e-4,sensitivity)
    profiles=pd.read_csv(ROOT/'results/real_parameter_profiles.csv')
    sens=pd.read_csv(ROOT/'results/real_assumption_sensitivity.csv')
    check('six_model_profiles',set(profiles.model)==set(MODEL_DEFS) and profiles.profile_sse.notna().all())
    check('all_prespecified_sensitivities',len(sens)==24 and sens.fit_success.all())
    pdf=PdfReader(ROOT/'reports/FINAL_REPORT_EN.pdf')
    check('main_report_max25pages',1<=len(pdf.pages)<=25,len(pdf.pages))
    check('English_and_Chinese_report_nontrivial',(ROOT/'reports/FINAL_REPORT_EN.md').stat().st_size>10000 and
          (ROOT/'reports/FINAL_REPORT_ZH.md').stat().st_size>10000)
    failed=[q['check'] for q in checks if not q['pass']]
    status={'state':'pass' if not failed else 'failed','checks':len(checks),'passed':sum(q['pass'] for q in checks),
        'failed':failed,'details':checks,'wall_seconds':time.monotonic()-start,'python':platform.python_version(),
        'coverage_status_counts':q.status.value_counts().to_dict(),
        'scientific_scope':'34 of42 analytic entries done;8 partial; general global/region/cycle classifications and field calibration remain explicit gaps',
        'not_independent_ecological_validation':True}
    (ROOT/'logs/FINAL_VERIFICATION.json').write_text(json.dumps(status,indent=2))
    runstatus={'stage':'completed_execution_and_coverage_audit' if not failed else 'verification_failed',
      'counts':{'baseline_trajectories':432,'extended_trajectories':len(f),'extended_contrasts':len(c),'shock_runs':len(shocks),
        'root_crosschecks':len(root),'exact_bifurcation_witnesses':12,'real_outer_fits':24,'real_score_rows':len(scores)},
      'analysis_level':'explicit_analytic_conditional_proofs_plus_synthetic_and_observed_prediction',
      'verification':'logs/FINAL_VERIFICATION.json','partial_criteria':q[q.status=='partial'].criterion.tolist()}
    (ROOT/'logs/RUN_STATUS.json').write_text(json.dumps(runstatus,indent=2))
    print(json.dumps({k:v for k,v in status.items() if k!='details'},indent=2))
    if failed:raise SystemExit(1)

if __name__=='__main__':main()
