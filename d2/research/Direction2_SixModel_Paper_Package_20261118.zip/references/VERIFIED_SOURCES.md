# Verified primary references and data portals

1. Original user-supplied brief: `Project3H_Original_Brief.pdf`, Model (1.1), pp. 1-4. **The actual equation does not contain the predator competition term `-h*y^2`, although the prose mentions it.** Always use this equation for original M0 / FA.
2. Haque, M. (2011), *A detailed study of the Beddington–DeAngelis predator–prey model*. Mathematical Biosciences 234:1-16. DOI: https://doi.org/10.1016/j.mbs.2011.07.003
3. Cantrell, R. S. and Cosner, C. (2001), *On the dynamics of predator–prey models with the Beddington–DeAngelis functional response*. Journal of Mathematical Analysis and Applications 257:206-222. (Consult primary text for any quoted theorem; never assume a theorem applies automatically.)
4. Tanner, J. T. (1975), *The Stability and the Intrinsic Growth Rates of Prey and Predator Populations*. Ecology 56:855-867. DOI: https://doi.org/10.2307/1936296 . Does not provide all original model parameters by itself.
5. Skalski, G. T. and Gilliam, J. F. (2001), *Functional Responses with Predator Interference: Viable Alternatives to the Holling Type II Model*. Ecology 82:3083-3092. DOI: https://doi.org/10.1890/0012-9658(2001)082[3083:FRWPIV]2.0.CO;2
6. Blasius, B. et al. (2020), *Long-term cyclic persistence in an experimental predator–prey system*. Nature 577:226-230. DOI: https://doi.org/10.1038/s41586-019-1857-0 . Data https://doi.org/10.6084/m9.figshare.10045976.v1 , public code/data https://github.com/berndblasius/WaveletAnalysis/tree/master/data/chemostat_experiments
7. Sahoo, P. et al. (2020), *Mathematical deconvolution of CAR T-cell proliferation and exhaustion from real-time killing assay data*. J. R. Soc. Interface 17:20190734. DOI: https://doi.org/10.1098/rsif.2019.0734 . Supplementary collection https://doi.org/10.6084/m9.figshare.c.4796295
8. Geng, Y. et al. (2024), *Using bacterial population dynamics to count phages and their lysogens*. Nature Communications 15:7814. DOI: https://doi.org/10.1038/s41467-024-51913-6 . Source data linked in the paper.

Source links above are bibliographic pointers, not license grants for redistribution of all referenced materials. Only the user's brief, and expressly attributed dataset copies where bundled, are included. Cite at point of use in the final paper.
