"""Recompute final transition audits from the frozen fitted-parameter cache.

Half-step comparisons cover every training and held pair. Accurate DOP853 checks
include worst-halving cases in each split as well as prespecified held samples.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from src.experiments import getpairs,MODEL_DEFS
from src.real_benchmark import make_train,batch_next,solve_next_dop853,PROTOCOL
ROOT=Path(__file__).resolve().parent
frames={f'C{i}':pd.read_csv(ROOT/f'data/real/C{i}.csv') for i in range(1,5)}
cache=json.loads((ROOT/'logs/REAL_FIT_CACHE.json').read_text());rows=[];halving=[]
assert len(cache)==24
assert json.loads((ROOT/'configs/REAL_BENCHMARK_PROTOCOL.json').read_text())['step']==PROTOCOL['step']
main_step=PROTOCOL['step'];half_step=main_step/2
for held,df in frames.items():
    _,X,DT,Y,scale=make_train(frames,held);XX,T,YY=getpairs(df)
    initial_indices=np.unique(np.r_[np.linspace(0,len(XX)-1,8).astype(int),np.argmax(T),np.argmin(XX[:,0]),np.argmin(XX[:,1])])
    for model in MODEL_DEFS:
        p=cache[f'{held}/{model}']['p']
        for split,A,B in [('training',X,DT),('test',XX,T)]:
            a=batch_next(A,B,p,main_step);b=batch_next(A,B,p,half_step)
            norm_difference=np.max(np.abs(a-b)/scale,axis=1);worst_index=int(np.argmax(norm_difference))
            halving.append(dict(held=held,model=model,split=split,pairs=len(A),main_step=main_step,half_step=half_step,
                           worst_pair_index=worst_index,max_abs_halving_difference=float(np.max(np.abs(a-b))),
                           max_normalized_halving_difference=float(np.max(norm_difference))))
            indices=np.unique(np.r_[initial_indices,worst_index]) if split=='test' else [worst_index]
            for i in indices:
                ref=solve_next_dop853(A[i],B[i],p)
                rows.append(dict(held=held,model=model,split=split,pair_index=int(i),gap_days=B[i],main_step=main_step,half_step=half_step,
                  included_as_worst_halving=bool(i==worst_index),
                  max_abs_error_main_step=float(np.max(np.abs(a[i]-ref))),
                  max_normalized_error_main_step=float(np.max(np.abs(a[i]-ref)/scale)),
                  max_abs_error_half_step=float(np.max(np.abs(b[i]-ref))),
                  max_normalized_error_half_step=float(np.max(np.abs(b[i]-ref)/scale))))
a=pd.DataFrame(rows);h=pd.DataFrame(halving)
a.to_csv(ROOT/'results/real_solver_audit.csv',index=False);h.to_csv(ROOT/'results/real_solver_halving_all_pairs.csv',index=False)
worst=float(a.max_normalized_error_main_step.max());worst_half=float(h.max_normalized_halving_difference.max())
status=dict(state='pass' if max(worst,worst_half)<PROTOCOL['solver_normalized_acceptance'] else 'failed',
 acceptance=PROTOCOL['solver_normalized_acceptance'],sampled_DOP853_audits=len(a),full_pair_halving_groups=len(h),
 pair_evaluations_per_step=int(h.pairs.sum()),worst_DOP853_normalized_error=worst,
 worst_all_pair_halving_normalized_difference=worst_half,main_step=main_step,half_step=half_step)
(ROOT/'logs/REAL_SOLVER_AUDIT_STATUS.json').write_text(json.dumps(status,indent=2));print(json.dumps(status,indent=2))
if status['state']!='pass':raise SystemExit(1)
