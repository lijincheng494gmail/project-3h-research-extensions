# Codex Autonomous Research Instructions

## Mission
Execute the original research plan end-to-end for **Direction 2 | Allee x Predator Competition, Six Models** in the current folder. Read `RESEARCH_PLAN.md`, `references/VERIFIED_SOURCES.md`, and the *original* `references/Project3H_Original_Brief.pdf` before changing the model. Keep the user's selected research framing; do not reorganize it into another study. No back-and-forth questions are required for ordinary experiment choices. Use reproducible reasonable defaults and document them.

## First actions

1. Run `bash run.sh tests`; fix any failure.
2. Run `bash run.sh full` and inspect `results/`, `figures/`, `logs/RUN_STATUS.json`. This is the implemented numerical baseline, not the end of the research.
3. Examine each hypothesis, the precise classical model equations, and available observed datasets. Check units, times, initial states and published measurement mappings before use.
4. Implement extensions required by the research plan, run **actual** experiments, validate ODE solvers with smaller tolerance/horizon crosschecks, and rerun tests. Cite referenced papers for mathematical and ecological claims.

## Required study coverage

- Keep M0 EXACTLY teacher equation (no -h*y^2) and preserve M0-M5 IDs from RESEARCH_PLAN.md.
- All six models have a seven-question evidence matrix with analytic status + numerical evidence, no empty generic prose.
- Strong-Allee axial equilibrium (A,0) analyzed alongside (0,0),(K,0); nonnegative feasibility checked.
- At least 3 matched competition contrasts, 3 matched Allee-growth contrasts, and quantified interaction effects; initial-state shock scenarios separated from parameter changes.
- Real-data benchmark evaluates six models under identical train/test partitions, baseline forecasts, and complexity-aware scores. Explicitly distinguish held-condition performance from fitting quality.

## Scientific integrity and model discipline

- **Never fabricate empirical parameter values, source papers, mathematical theorems, or experiment outcomes.** Every number in a result table must be computable from bundled or clearly cited downloaded data.
- Original model M0/FA must be *exactly* the instructor's Eq. (1.1) including positive parameters and no `-h*y²`. Any competition term is an explicit model extension. The brief's Beddington–DeAngelis `c=0` mapping in its hint section is inconsistent with positive beta; document the correct mapping, do not silently reproduce it.
- The cancelled stochastic perturbation (vii) is OUT OF SCOPE. Randomized parameter sampling and simulated *measurement* errors are permitted for robustness tests; do not add stochastic dynamics as a research objective.
- Use actual mathematical arguments for permanence, global stability, root count, limit cycles, and local bifurcation claims. A 70-unit simulation and a near-constant tail cannot prove a global theorem. Derive necessary and sufficient vs merely sufficient conditions correctly. For BT/Hopf/saddle-node, check feasible positive parameters and non-degeneracy; if analytically impossible, this is a valid research finding.
- Fix baseline comparability: same growth law and parameter regimes when testing predation mechanisms; same predation law and matched conditions when testing M0–M5; same train/test observations and parameter fitting budget when doing cross-domain transfer.
- Prevent data leakage. Reserve whole experiments/conditions, not random time points only; maintain train/validation/test separation. Do not relabel a synthetic generator or an inferred latent variable as direct observed biology.
- Keep source attributions, verified DOI/URL, model parameter units and software versions with every final result.

## Deliverables before handing off

1. `reports/FINAL_REPORT_EN.md` — concise research report with Background, Research Question, Hypotheses, Model definitions, Design, Findings (positive), Findings (unexpected/negative), Interpretation, Next feasible experiments, source references.
2. `reports/FINAL_REPORT_ZH.md` — same evidence, readable direct Chinese.
3. `reports/RESULTS_BY_HYPOTHESIS.md` — H1-H5 evidence matrix, each question paired with exact results CSV/figure, source type and interpretation.
4. `reports/ANALYTICAL_RESULTS.md` — formulas, assumptions, valid propositions and explicit proof/check gaps. Clear status of the seven original-style research questions when applicable.
5. `reports/VERIFICATION_MATRIX.csv` — each required research-plan criterion marked done/partial/blocked, with exact evidence path and blockers.
6. `results/*.csv` raw numeric results; `figures/*.png` readable figures; `logs/` config, source provenance, run commands, code/test and solver audit.
7. Update `README_START_HERE.md` with reproduction command and short outcome summary. Run `python package_results.py` and deliver a clickable/downloadable `deliverables/*_RESULTS.zip`.

### Completion policy

Do not call the study complete until every relevant criterion in `RESEARCH_PLAN.md` is either supported by a result/proof or explicitly recorded `partial`/`blocked`. A partial genuine result is better than an invented complete study. **Write findings directly, not in a defensive/sycophantic or overly polished AI voice.** Keep positive and unexpected findings separate. English should be plain and correct, mostly short/medium sentences. Keep all scientifically necessary boundaries only where they affect interpretation.
