# Exact remaining mathematical cases

The primary question remains the separate and joint effects of prey growth and predator competition across M0–M5. The complete fixed-parameter equilibrium count is established. The following unresolved global cases are retained in Q4, rather than inferred from simulations.

Let s=βd/(em), λK=emK/β−d, N+ be the distinct positive equilibrium count, and T,Δ be the trace and determinant at a unique positive equilibrium. For weak growth let p=(K−1/α)/2, c=rα/K and M=max gW on [0,K].

For weak M0/M4 with λK>0, the proved interior GAS regions are:

- C_L: αK≤1, or x*≥K−1/α.
- C_B: αK>1, r<m≤M and N+=1.
- C_D: αK>1, m>M and a q≥0 exists such that Dq(x)=βmxg′(x)+q(emx−βd)(m−g(x))≤0 for all x∈[0,K]. The paper gives a finite exact test and an explicit sufficient subregion.

Outside these regions, N+≥2 excludes GAS of any individual coexistence equilibrium. A unique linearly unstable equilibrium also excludes GAS. If that equilibrium is a hyperbolic repeller, permanence implies at least one periodic orbit.

The remaining set, before separate nonlinear local-instability exclusions, is R_W={λK>0,N+=1,Δ≥0,T≤0}\(C_L∪C_B∪C_D). It contains cases needing a global no-cycle or basin proof and nonhyperbolic cases needing nonlinear local analysis. It is not classified as wholly stable or wholly unstable.

For strong M2/M5, coexistence GAS in the entire positive quadrant is excluded for every parameter set. If λK≤0, every strictly positive trajectory converges to (0,0),(A,0) or (K,0); the stable manifold of (A,0) is the separator. If λK>0 and N+=0, the origin attracts every strictly positive initial state, including the degenerate s=A boundary.

The remaining global set is R_S={λK>0,N+≥1}. Within it, full coexistence/extinction basin geometry, cycle counts and stability, saddle connections and attraction within every basin remain unresolved. The proved high-prey barriers and Lyapunov sublevels already resolve specified subsets.

The local bifurcation results certify ordinary folds, Hopf and BT points and exclude them in logistic models. At (A,0), ordinary transcritical direction depends on B_A; degenerate axial collisions have exact root-count and leading-center-flow classifications. A complete higher-codimension unfolding and global homoclinic atlas are not claimed. These scopes are stated alongside the results and do not change the six-model objective.
