# CODEX MASTER PROMPT — DIRECTION 2
## Six-Model Comparison of Allee Effects and Predator Competition

### 1. Primary research objective

This study investigates how prey growth mechanisms and predator intraspecific competition independently and jointly affect predator–prey dynamics.

The central research question is:

**How do different Allee growth mechanisms and predator competition change coexistence, equilibrium structure, stability, bifurcations and empirical predictive performance?**

This is a systematic six-model comparative study.

Do not change its central objective to extinction thresholds, ecological recovery, particular bifurcations or any other selected finding.

Recovery experiments and bifurcation examples are components of the research, not replacements for the six-model comparison.

### 2. Fixed six-model design

Preserve the following model IDs exactly.

| Model | Prey growth | Predator competition |
|---|---|---|
| M0 | Weak Allee | No |
| M1 | No Allee (Logistic) | No |
| M2 | Strong Allee | No |
| M3 | No Allee (Logistic) | Yes |
| M4 | Weak Allee | Yes |
| M5 | Strong Allee | Yes |

**M0 is the exact original coursework model and must always be the baseline.**

All six models use the same original foraging-arena functional response.

The additional predator competition mechanism is represented by an explicit density-dependent loss term.

Define the weak Allee, strong Allee and Logistic growth functions precisely.

Use consistent population units and parameter conventions. Ensure that the chosen weak Allee parameter regimes actually exhibit the intended low-density growth effect.

Do not renumber the models.

### 3. Research hypotheses

H1. Changing the Allee mechanism changes coexistence and extinction conditions.

H2. Predator competition can change equilibrium and stability properties.

H3. Allee growth and predator competition may interact.

H4. These mechanisms may change responses to population disturbances.

H5. Model structure may influence empirical predictive performance.

Evaluate each hypothesis through the complete six-model comparison.

### 4. Mandatory seven-question analysis

For every model M0–M5, complete the same seven research tasks:

1. Positivity, boundedness and permanence.
2. Equilibrium existence, number and uniqueness.
3. Local stability.
4. Global stability.
5. Paradox of enrichment.
6. Bifurcation analysis.
7. Ecological interpretation.

Produce a 6 × 7 comparison matrix.

Each of the 42 cells must contain the actual conclusion, relevant parameter conditions, supporting derivation or experiment, and verification status.

Resolve the incomplete classifications identified in the previous research reports, especially equilibrium root counts and global stability for the Allee models.

Do not replace missing general proofs with selected numerical trajectories.

If a complete result remains mathematically unresolved, preserve the strongest verified partial result and identify the exact missing cases.

### 5. Main comparative analysis

After completing the unified analysis, compare the results in three ways.

**A. Effects of Allee growth**

Compare M1, M0 and M2 without additional predator competition.

Then compare M3, M4 and M5 with competition.

Determine how the three prey growth mechanisms change the seven dynamical properties.

**B. Effects of predator competition**

Use the paired comparisons:

- M1 versus M3
- M0 versus M4
- M2 versus M5

Determine the contribution of predator competition under each growth mechanism.

**C. Interaction effects**

Use the complete 3 × 2 factorial structure.

Investigate whether the effect of predator competition depends on the Allee growth mechanism.

Identify parameter regions where the combined effects differ from the separate effects.

### 6. Numerical experiments

Generate comparable phase portraits, equilibrium diagrams, bifurcation diagrams and population time series for all six models.

Use matched ecological scenarios, parameter settings and initial conditions wherever mathematically meaningful.

Track the seven research questions consistently.

Additionally, perform controlled disturbance and recovery experiments.

For each model, apply comparable prey and predator population shocks.

Measure recovery time, final state, survival and any critical recovery thresholds.

These recovery experiments are an additional result section. They must not replace the original seven-question comparison.

### 7. Real ecological data comparison

Use real predator–prey time-series data with documented provenance.

Fit M0–M5 using the same training data and comparable optimisation budgets.

Evaluate every model on the same held-out observations or experiments.

Report short-term prediction, free-running prediction, relevant population-cycle metrics and model complexity.

Include simple prediction baselines.

Use the results to evaluate whether adding Allee growth or predator competition improves empirical prediction.

Preserve weak improvements, ties and negative results.

### 8. Research validation

Inspect the original coursework, existing six-model code, previous analytical results and experimental reports.

Reproduce the existing results and correct any errors.

Independently verify important equilibrium and bifurcation calculations.

Check mathematical proofs separately from numerical observations.

Run sensitivity and numerical convergence checks.

Maintain a complete record of verified, partially established and unresolved cases.

### 9. Paper structure and writing

Write one complete English research paper:

- Abstract
- Introduction
- Results
- Discussion
- Methods
- References
- Detailed Appendix / Supplementary Information

The Introduction must explain the original model, the two research factors and the six-model design.

**The Results must begin with the complete six-model × seven-question comparison matrix.**

Organise the remaining results in this order:

1. Common properties across all six models.
2. Effects of Allee growth.
3. Effects of predator competition.
4. Interaction between both mechanisms.
5. Population disturbance and recovery.
6. Empirical prediction comparison.

Discuss unexpected results without allowing them to redefine the research objective.

Write in clear, natural academic English, approximately IELTS 6–7 in language complexity.

Explain what was compared and what was found before introducing technical mathematical details.

Place complete derivations and proof details in Methods and the Appendix.

Avoid defensive writing, generic academic filler and promotional language.

### 10. Required deliverables

Produce:

1. Final English research paper PDF.
2. Complete M0–M5 × seven-question matrix.
3. Six-model mathematical analysis and full derivations.
4. Paired Allee and competition comparison tables.
5. Interaction analysis.
6. Numerical phase portraits and bifurcation diagrams.
7. Disturbance and recovery experiment results.
8. Real ecological data comparison results.
9. Reproducible Python code and run.sh.
10. Complete references and verification records.

Package everything into one ZIP file.

### 11. Final acceptance condition

This paper must remain a systematic comparison of six models across seven research questions.

The core deliverable is the complete six-model comparison, not a collection of selected findings.

No model, research question or comparison dimension may be silently omitted.

The final paper must answer how Allee growth and predator competition act separately and jointly.