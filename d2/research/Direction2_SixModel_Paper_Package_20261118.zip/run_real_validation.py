"""Explicit whole-experiment train/validation/test audit.

For each outer test experiment, the alphabetically last remaining experiment is
validation and the other two are training. All protocol choices are fixed; the
validation audit does not tune parameters or models on outer test observations.
The primary benchmark separately refits the same six models on all three
non-test experiments, as is standard after a fixed validation stage.
"""
from pathlib import Path
import json,time
import numpy as np
import pandas as pd
from src.experiments import MODEL_DEFS,getpairs
from src.real_benchmark import fit_one,metrics,PROTOCOL
ROOT=Path(__file__).resolve().parent
frames={f'C{i}':pd.read_csv(ROOT/f'data/real/C{i}.csv') for i in range(1,5)}
rows=[];start=time.time()
for held in frames:
    remaining=[c for c in frames if c!=held];validation=remaining[-1];train=remaining[:-1]
    pairs=[getpairs(frames[c]) for c in train]
    X=np.concatenate([z[0] for z in pairs]);DT=np.concatenate([z[1] for z in pairs]);Y=np.concatenate([z[2] for z in pairs])
    scale=np.maximum(np.std(Y,axis=0),.1);VX,VT,VY=getpairs(frames[validation])
    for model in MODEL_DEFS:
        print('NESTED VALIDATION',held,validation,model,flush=True)
        fit=fit_one(model,X,DT,Y,scale,starts=2,max_nfev=100)
        from src.real_benchmark import batch_next
        pred=batch_next(VX,VT,fit['p']);mm=metrics(VY,pred,scale)
        rows.append(dict(outer_test=held,validation_experiment=validation,training_experiments=';'.join(train),
                         model=model,train_pairs=len(X),validation_pairs=len(VX),train_scale_x=scale[0],train_scale_y=scale[1],
                         validation_nrmse=mm['nrmse'],fit_success=fit['success'],fit_status=fit['status'],
                         test_observations_used_for_fit=False,validation_observations_used_for_fit=False,
                         protocol='fixed audit; final outer fit uses three non-test experiments'))
        pd.DataFrame(rows).to_csv(ROOT/'results/real_nested_validation.csv',index=False)
(ROOT/'logs/REAL_VALIDATION_STATUS.json').write_text(json.dumps(dict(state='completed',fits=len(rows),wall_seconds=time.time()-start,
  split_rule='validation = alphabetically last non-test experiment; training = other two',
  selection='no model, bound, optimizer, or fixed parameter selected using validation or test scores'),indent=2))
