#!/usr/bin/env python3
"""Exact identity and algebraic-example checks for the revised Q4 proofs.

No trajectories are integrated. The proof is in
reports/revision/GLOBAL_CLASSIFICATION.md; these checks independently verify
the displayed derivatives, factorisations, and rational example root counts.
"""
from __future__ import annotations

import csv
import json
from pathlib import Path

import sympy as sp

ROOT = Path(__file__).resolve().parent
LOG = ROOT / "logs" / "revision" / "GLOBAL_CLASSIFICATION.json"
CSV = ROOT / "results" / "global_classification_examples.csv"


def main():
    x, y, xs, ys = sp.symbols("x y xs ys", positive=True)
    beta, e, m, d, h = sp.symbols("beta e m d h", positive=True)
    gx, gs, gprime = sp.symbols("gx gs gprime", real=True)
    cstar = beta / (e * (beta + ys))
    F = x * (gx - m * y / (beta + y))
    G = y * (e * m * x / (beta + y) - d - h * y)
    vdot = (1 - xs / x) * F + cstar * (1 - ys / y) * G
    equilibrium_subs = {
        d: e * m * xs / (beta + ys) - h * ys,
        gs: m * ys / (beta + ys),
    }
    target = (x - xs) * (gx - gs) - cstar * (
        e * m * xs / ((beta + y) * (beta + ys)) + h
    ) * (y - ys) ** 2
    checks = {}
    checks["interior_lyapunov_identity"] = sp.factor(
        (vdot - target).subs(equilibrium_subs)
    )
    lk_dot = (1 - sp.Symbol("K", positive=True) / x) * F + G / e
    K = sp.Symbol("K", positive=True)
    axial_target = (x - K) * gx + y * (m * K / (beta + y) - d / e) - h * y**2 / e
    checks["axial_lyapunov_identity"] = sp.factor(lk_dot - axial_target)

    a, b, c, q = sp.symbols("a b c q", real=True)
    g = a + b * x - c * x**2
    phi = m - g
    # Cancelling a common positive y**(q-1) avoids fragile symbolic powers.
    fnull = beta * g / phi
    div_reduced = sp.diff(fnull, x) + (
        q * (e * m * x - beta * d)
        - (q + 1) * (d + h * beta) * y
        - (q + 2) * h * y**2
    ) / (x * phi)
    Dq = beta * m * x * sp.diff(g, x) + q * (e * m * x - beta * d) * phi
    dulac_target = (
        Dq / phi
        - (q + 1) * (d + h * beta) * y
        - (q + 2) * h * y**2
    ) / (x * phi)
    checks["weighted_dulac_identity"] = sp.factor(div_reduced - dulac_target)

    p, s, gap, peak = sp.symbols("p s gap peak", positive=True)
    gpeak = peak - c * (x - p) ** 2
    phipeak = gap + c * (x - p) ** 2
    qchosen = 2 * beta * c * p / (e * gap)
    Dchosen = beta * (peak + gap) * x * sp.diff(gpeak, x) + qchosen * (
        e * (peak + gap) * (x - s)
    ) * phipeak
    N = (x - p) ** 2 * (p * c * (x - s) - gap) - p * gap * (s - p)
    checks["closed_form_dulac_factorization"] = sp.factor(
        Dchosen - 2 * beta * c * (peak + gap) * N / gap
    )
    alpha, r, A = sp.symbols("alpha r A", positive=True)
    gw = r * (1 - x / K) * (1 + alpha * x)
    gsw = r * (1 - xs / K) * (1 + alpha * xs)
    checks["weak_chord_identity"] = sp.factor(
        (x - xs) * (gw - gsw)
        - r / K * (x - xs) ** 2 * (alpha * K - 1 - alpha * (x + xs))
    )
    gst = r * (1 - x / K) * (x / A - 1)
    gsstar = r * (1 - xs / K) * (xs / A - 1)
    checks["strong_chord_identity"] = sp.factor(
        (x - xs) * (gst - gsstar)
        - r / (A * K) * (x - xs) ** 2 * (K + A - x - xs)
    )
    gpA = sp.diff(gst, x).subs(x, A)
    kappa = sp.symbols("kappa", nonnegative=True)
    H1 = A * gpA * (1 + kappa) - m
    BA = e * m**2 / (beta**2 * gpA) - e * m * A / beta**2 - h
    checks["strong_A_center_quadratic_sign_identity"] = sp.factor(
        (BA + e * m * H1 / (beta**2 * gpA)).subs(
            {kappa: h * beta**2 / (e * m * A)}
        )
    )
    failed = {name: str(value) for name, value in checks.items() if value != 0}
    if failed:
        raise AssertionError(failed)

    R = sp.Rational
    cases = [
        dict(name="M0_new_dulac_outside_old_Lyapunov", model="M0", family="W", r=R(1), K=R(4), alpha=R(1), A=None, m=R(10), beta=R(1), e=R(1), d=R(15), h=R(0), certificate="weighted_Dulac"),
        dict(name="M4_new_dulac_outside_old_Lyapunov", model="M4", family="W", r=R(1), K=R(4), alpha=R(1), A=None, m=R(10), beta=R(1), e=R(1), d=R(15), h=R(1), certificate="weighted_Dulac"),
        dict(name="M0_new_barrier_outside_old_Lyapunov", model="M0", family="W", r=R(1), K=R(4), alpha=R(1), A=None, m=R(3, 2), beta=R(1), e=R(1), d=R(3, 4), h=R(0), certificate="one_way_barrier_and_unique_root"),
        dict(name="M4_new_barrier_outside_old_Lyapunov", model="M4", family="W", r=R(1), K=R(4), alpha=R(1), A=None, m=R(3, 2), beta=R(1), e=R(1), d=R(3, 4), h=R(1, 10), certificate="one_way_barrier_and_unique_root"),
        dict(name="M2_all_positive_extinction", model="M2", family="S", r=R(1), K=R(4), alpha=None, A=R(1), m=R(10), beta=R(1), e=R(1), d=R(5), h=R(0), certificate="lambda_K_positive_and_no_positive_root"),
        dict(name="M5_all_positive_extinction", model="M5", family="S", r=R(1), K=R(4), alpha=None, A=R(1), m=R(10), beta=R(1), e=R(1), d=R(5), h=R(1), certificate="lambda_K_positive_and_no_positive_root"),
        dict(name="M2_high_density_basin_barrier", model="M2", family="S", r=R(1), K=R(4), alpha=None, A=R(1), m=R(1, 2), beta=R(1), e=R(1), d=R(1, 2), h=R(0), certificate="one_way_barrier_x_initial_at_least_2_implies_positive_coexistence"),
        dict(name="M5_high_density_basin_barrier", model="M5", family="S", r=R(1), K=R(4), alpha=None, A=R(1), m=R(1, 2), beta=R(1), e=R(1), d=R(1, 2), h=R(1), certificate="one_way_barrier_x_initial_at_least_2_implies_positive_coexistence"),
    ]
    z = sp.Symbol("z", real=True)
    rows = []
    details = []
    for case in cases:
        rr, kk, mm, bb, ee, dd, hh = (case[k] for k in ("r", "K", "m", "beta", "e", "d", "h"))
        s0 = bb * dd / (ee * mm)
        kap = hh * bb / dd
        xx = s0 * (1 + z) * (1 + kap * z)
        if case["family"] == "W":
            gg = rr * (1 - x / kk) * (1 + case["alpha"] * x)
            pp = (kk - 1 / case["alpha"]) / 2
            cc = rr * case["alpha"] / kk
        else:
            gg = rr * (1 - x / kk) * (x / case["A"] - 1)
            pp = (kk + case["A"]) / 2
            cc = rr / (case["A"] * kk)
        H = sp.Poly(sp.expand((1 + z) * gg.subs(x, xx) - mm * z), z)
        # Remove a boundary root at z=0 before exact positive-root counting.
        positive_poly = H
        while positive_poly.eval(0) == 0:
            positive_poly = sp.div(positive_poly, sp.Poly(z, z))[0]
        count = int(positive_poly.count_roots(0, sp.oo))
        intervals = [
            ((str(lo), str(hi)), int(mult))
            for (lo, hi), mult in positive_poly.intervals(eps=R(1, 10**12))
            if hi > 0 and lo >= 0
        ]
        xintervals = []
        for (lohi, mult) in intervals:
            lo, hi = map(sp.Rational, lohi)
            xlo, xhi = sp.factor(xx.subs(z, lo)), sp.factor(xx.subs(z, hi))
            xintervals.append((str(xlo), str(xhi), mult))
        if case["family"] == "W":
            assert count == 1
            assert all(sp.Rational(hi) < 2 * pp for _, hi, _ in xintervals)
        if case["certificate"] == "weighted_Dulac":
            M = sp.factor(gg.subs(x, pp))
            qval = 2 * bb * cc * pp / (ee * (mm - M))
            DD = sp.factor(bb * mm * x * sp.diff(gg, x) + qval * (ee * mm * x - bb * dd) * (mm - gg))
            candidates = [sp.Integer(0), kk]
            candidates += [v for v in sp.solve(sp.diff(DD, x), x) if v.is_real and 0 <= v <= kk]
            # These examples have rational critical points, allowing exact sign tests.
            assert all(sp.simplify(DD.subs(x, v)) <= 0 for v in candidates)
            extra = {"q": str(qval), "Dq": str(DD), "checked_critical_points": list(map(str, candidates))}
        elif "barrier" in case["certificate"]:
            barrier_roots = sp.solve(gg - mm, x)
            physical_barriers = [u for u in barrier_roots if u.is_real and 0 < u < kk]
            assert len(physical_barriers) == 2
            extra = {"one_way_barriers": list(map(str, physical_barriers))}
        else:
            assert count == 0
            assert ee * mm * kk / bb - dd > 0
            extra = {}
        row = {k: ("" if v is None else str(v)) for k, v in case.items() if k not in ("name",)}
        row = {"name": case["name"], **row, "s": str(s0), "lambda_K": str(ee * mm * kk / bb - dd), "positive_root_count": count, "positive_x_isolating_intervals": json.dumps(xintervals)}
        rows.append(row)
        details.append({"name": case["name"], "H": str(H.as_expr()), "root_count_method": "exact Sturm count; zero endpoint root removed", "positive_root_count": count, "positive_x_isolating_intervals": xintervals, **extra})

    center_cases = []
    for aa, kk, kap in [(R(1), R(4), R(0)), (R(1), R(2), R(0)), (R(3), R(7), R(1))]:
        # Exactly impose s=A, H_1=0, including H_2=0 in the last two cases.
        gg = (1 - x / kk) * (x / aa - 1)
        gp = sp.diff(gg, x).subs(x, aa)
        mm = aa * gp * (1 + kap)
        dd = mm * aa  # e=beta=1
        hh = kap * dd
        XX = aa * (1 + z) * (1 + kap * z)
        HH = sp.Poly(sp.expand((1 + z) * gg.subs(x, XX) - mm * z), z)
        jj = next(k for k in range(1, HH.degree() + 1) if HH.nth(k) != 0)
        coeffs = sp.symbols(f"u1:{jj + 1}")
        UU = aa + sum(uu * y**k for k, uu in enumerate(coeffs, 1))
        FF = UU * (gg.subs(x, UU) - mm * y / (1 + y))
        GG = y * (mm * UU / (1 + y) - dd - hh * y)
        inv = sp.series(FF - sp.diff(UU, y) * GG, y, 0, jj + 1).removeO().expand()
        solved = {}
        for k, uu in enumerate(coeffs, 1):
            possibilities = sp.solve(inv.coeff(y, k).subs(solved), uu)
            assert len(possibilities) == 1
            solved[uu] = possibilities[0]
        reduced = sp.series(GG.subs(solved), y, 0, jj + 2).removeO().expand()
        assert all(reduced.coeff(y, k) == 0 for k in range(1, jj + 1))
        expected = sp.factor(-mm * HH.nth(jj) / gp)
        assert sp.factor(reduced.coeff(y, jj + 1) - expected) == 0
        center_cases.append({
            "r": "1", "A": str(aa), "K": str(kk), "m": str(mm),
            "beta": "1", "e": "1", "d": str(dd), "h": str(hh),
            "H": str(HH.as_expr()), "first_nonzero_H_index": jj,
            "actual_center_coefficients_x_of_y": {str(key): str(val) for key, val in solved.items()},
            "actual_leading_ydot": f"({expected})*y**{jj + 1}",
            "formula_agrees_exactly": True,
        })

    LOG.parent.mkdir(parents=True, exist_ok=True)
    CSV.parent.mkdir(parents=True, exist_ok=True)
    with CSV.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    payload = {
        "status": "PASS",
        "scope": "symbolic identities and exact rational example checks; no trajectory or empirical data used",
        "identities": {name: "0" for name in checks},
        "examples": details,
        "degenerate_A_center_manifold_checks": center_cases,
        "proof_document": "reports/revision/GLOBAL_CLASSIFICATION.md",
        "unresolved": "General weak-Allee unique locally stable cases outside the proved global regions; coexistence-basin/cycle topology for strong Allee when positive equilibria exist.",
    }
    LOG.write_text(json.dumps(payload, indent=2) + "\n")
    print(f"PASS: {len(checks)} exact symbolic identities; {len(details)} exact algebraic examples; {len(center_cases)} degenerate-center checks")
    print(f"Wrote {LOG.relative_to(ROOT)} and {CSV.relative_to(ROOT)}")


if __name__ == "__main__":
    main()
