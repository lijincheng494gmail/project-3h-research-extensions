"""Create direct summaries from completed observed-data evidence."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parent
s=pd.read_csv(ROOT/'results/real_benchmark_scores.csv');p=pd.read_csv(ROOT/'results/real_benchmark_parameters.csv')
from src.experiments import MODEL_DEFS
def role(row):
 if row.parameter in ['e','beta']:return 'fixed_scale_assumption'
 if row.parameter=='alpha':return 'derived_active' if MODEL_DEFS[row.model][0]=='weak' else 'inactive_not_used'
 if row.parameter=='A':return 'derived_active' if MODEL_DEFS[row.model][0]=='strong' else 'inactive_not_used'
 return 'fitted'
p['role']=p.apply(role,axis=1)
unit_map={'r':'day^-1','K':'10^6 cells/ml','m':'day^-1','d':'day^-1','u':'dimensionless','fA':'dimensionless','h':'(20 animals/ml)^-1 day^-1','alpha':'(10^6 cells/ml)^-1','A':'10^6 cells/ml','e':'(20 animals/ml)/(10^6 cells/ml)','beta':'20 animals/ml'}
p['units']=p.parameter.map(unit_map)
p.to_csv(ROOT/'results/real_benchmark_parameters.csv',index=False)
a=pd.read_csv(ROOT/'results/real_fit_attempts.csv');v=pd.read_csv(ROOT/'results/real_nested_validation.csv')
profiles=pd.read_csv(ROOT/'results/real_parameter_profiles.csv');sens=pd.read_csv(ROOT/'results/real_assumption_sensitivity.csv')
audit=json.loads((ROOT/'logs/REAL_SOLVER_AUDIT_STATUS.json').read_text())
assert len(s)==36 and len(a)==48 and len(v)==24 and s[s.model.str.startswith('M')].fit_success.all()
assert audit['state']=='pass'
assert json.loads((ROOT/'logs/REAL_SENSITIVITY_AUDIT_STATUS.json').read_text())['state']=='pass'
for held,g in s.groupby('held'):
 assert g.train_pairs.nunique()==1 and g.test_pairs.nunique()==1
s['delta_AICc_within_fold']=s.conditional_AICc-s.groupby('held').conditional_AICc.transform('min')
rows=[]
for m,g in s.groupby('model',sort=False):
 base=s[s.model=='persistence'].set_index('held').loc[g.held]
 rows.append(dict(model=m,held_experiments=len(g),macro_test_nrmse=g.test_nrmse.mean(),
  macro_free_trajectory_nrmse=g.free_trajectory_nrmse.mean(),
  pair_count_weighted_mean_fold_nrmse=np.average(g.test_nrmse,weights=g.test_pairs),
  test_nrmse_min=g.test_nrmse.min(),test_nrmse_max=g.test_nrmse.max(),
  folds_better_than_persistence=int(np.count_nonzero(g.test_nrmse.to_numpy()<base.test_nrmse.to_numpy())),
  macro_training_nrmse=g.train_nrmse.mean(),mean_delta_AICc_within_fold=g.delta_AICc_within_fold.mean(),
  parameter_rows_at_bounds=int(len(p[(p.model==m)&p.at_bound]))))
summary=pd.DataFrame(rows)
models_only=summary[summary.model.str.startswith('M')]
assert (models_only.folds_better_than_persistence==4).all()
assert models_only.macro_test_nrmse.max()<float(summary.loc[summary.model=='training_mean','macro_test_nrmse'].iloc[0])
assert models_only.macro_free_trajectory_nrmse.min()>=float(summary.loc[summary.model=='training_mean','macro_free_trajectory_nrmse'].iloc[0])
summary.to_csv(ROOT/'results/real_model_summary.csv',index=False)
contrasts=[]
for held,g in s.groupby('held'):
 g=g.set_index('model')
 for typ,ref,alt in [('competition','M1','M3'),('competition','M0','M4'),('competition','M2','M5'),
                     ('Allee','M1','M0'),('Allee','M1','M2'),('Allee','M0','M2'),
                     ('Allee_with_h','M3','M4'),('Allee_with_h','M3','M5'),('Allee_with_h','M4','M5')]:
  contrasts.append(dict(held=held,contrast_type=typ,reference=ref,alternative=alt,
   change_test_nrmse=g.loc[alt,'test_nrmse']-g.loc[ref,'test_nrmse'],
   change_free_nrmse=g.loc[alt,'free_trajectory_nrmse']-g.loc[ref,'free_trajectory_nrmse'],
   change_conditional_AICc=g.loc[alt,'conditional_AICc']-g.loc[ref,'conditional_AICc']))
pd.DataFrame(contrasts).to_csv(ROOT/'results/real_paired_model_contrasts.csv',index=False)
frames={f'C{i}':pd.read_csv(ROOT/f'data/real/C{i}.csv') for i in range(1,5)}
cache=json.loads((ROOT/'logs/REAL_FIT_CACHE.json').read_text());identification=[]
for held in frames:
 train_min=min(d.prey_million_cells_per_ml.min() for c,d in frames.items() if c!=held)
 test_min=frames[held].prey_million_cells_per_ml.min()
 for model in [f'M{i}' for i in range(6)]:
  fitp=cache[f'{held}/{model}']['p'];kind=MODEL_DEFS[model][0]
  identification.append(dict(held=held,model=model,growth_kind=kind,min_train_observed_prey=train_min,
   min_test_observed_prey=test_min,alpha_K=fitp['alpha']*fitp['K'] if kind=='weak' else np.nan,
   fitted_A=fitp['A'] if kind=='strong' else np.nan,
   A_over_min_train_prey=fitp['A']/train_min if kind=='strong' else np.nan,
   A_over_min_test_prey=fitp['A']/test_min if kind=='strong' else np.nan,
   threshold_is_measured=False))
pd.DataFrame(identification).to_csv(ROOT/'results/real_parameter_identification.csv',index=False)

profile_summary=profiles.groupby(['model','parameter']).agg(profile_points=('value','size'),
 min_value=('value','min'),max_value=('value','max'),min_relative_sse_change=('relative_sse_change','min'),
 max_relative_sse_change=('relative_sse_change','max'),all_nuisance_fits_converged=('nuisance_fit_success','all')).reset_index()
profile_summary.to_csv(ROOT/'results/real_profile_summary.csv',index=False)
sens_summary=sens.groupby('model').agg(min_test_nrmse=('test_nrmse','min'),max_test_nrmse=('test_nrmse','max'),
 all_fits_converged=('fit_success','all'),max_sampled_DOP853_normalized_error=('max_sampled_DOP853_normalized_error','max'),max_all_pair_halving_normalized_difference=('max_all_pair_halving_normalized_difference','max'),DOP853_normalized_error_worst_halving=('DOP853_normalized_error_worst_halving','max')).reset_index()
sens_summary.to_csv(ROOT/'results/real_assumption_sensitivity_summary.csv',index=False)
best=summary[summary.model.str.startswith('M')].sort_values('macro_test_nrmse').iloc[0]
info=dict(primary_model_fits=24,primary_starts=len(a),primary_converged_starts=int(a.success.sum()),
 nested_validation_fits=len(v),nested_converged_fits=int(v.fit_success.sum()),
 profiles=len(profiles),profile_nuisance_refits=int(profiles.refit_performed.sum()),profile_nuisance_converged=int(profiles.loc[profiles.refit_performed,'nuisance_fit_success'].sum()),
 profile_groups=len(profile_summary),sensitivity_fits=len(sens),sensitivity_converged_fits=int(sens.fit_success.sum()),
 parameter_rows_at_bounds=int(p.at_bound.sum()),best_macro_one_step_model=best.model,best_macro_one_step_nrmse=best.macro_test_nrmse,
 sensitivity_overall_min=float(sens.test_nrmse.min()),sensitivity_overall_max=float(sens.test_nrmse.max()),
 sampled_DOP853_audits=audit['sampled_DOP853_audits'],solver_status=audit['state'],
 profile_min_relative_sse_change=float(profiles.relative_sse_change.min()))
(ROOT/'logs/REAL_FINAL_SUMMARY.json').write_text(json.dumps(info,indent=2));print(json.dumps(info,indent=2))

def tab(df):
 def cell(v):
  if isinstance(v,(float,np.floating)):return 'n/a' if np.isnan(v) else f'{v:.6g}'
  return str(v)
 return '\n'.join(['| '+' | '.join(df.columns)+' |','|'+'|'.join(['---']*len(df.columns))+'|']+['| '+' | '.join(cell(v) for v in row)+' |' for row in df.itertuples(index=False,name=None)])
text='''# Observed-data findings\n\nThese results use independent held experiments C1–C4 under the same nominal external medium. Each primary fit uses all three non-test experiments. The full methods and source audit are in `REAL_DATA_METHODS.md`.\n\n## Positive findings\n\nAll six structures improve mean one-step conditional prediction over persistence and the training mean, and each beats persistence in all four outer experiments. These predictions reset to the preceding observed state at every interval. The comparison supports short-step predictive usefulness of a fitted deterministic transition; it does not identify the true biological mechanism.\n\n'''
text+=tab(summary[['model','macro_test_nrmse','macro_free_trajectory_nrmse','folds_better_than_persistence','mean_delta_AICc_within_fold']])
text+='\n\n## Unexpected or negative findings\n\nThe mean one-step differences among logistic and weak-Allee structures are small. The sign of the competition improvement varies among held experiments. Adding a structural mechanism does not provide a consistent held-experiment benefit. The training-mean baseline matches or beats the mean free-trajectory score of every six-model structure. Observed-state resetting accounts for an important part of the short-step performance.\n\nThe weak and strong Allee shape/threshold coordinates lie at or near their lower fitting bounds in every outer fit. This limits a biological interpretation of their fitted values. The bounds enforce the chosen structure; a numerical bound hit is not evidence that an Allee mechanism was independently detected.\n\n'
text+='Every fitted strong-Allee A is below both the training and held minimum observed prey density. The fitted A values range from about 0.00372 to 0.00467 in millions of cells/ml, versus observed minima 0.09–0.12. These observations do not directly sample a threshold crossing; see `real_parameter_identification.csv`.\n\n'
text+='Bound hits: '+str(info['parameter_rows_at_bounds'])+' parameter/fold/model rows; see `real_benchmark_parameters.csv`.\n\n'
text+='## Scale-assumption sensitivity\n\nFour prespecified changes in fixed e or beta were refitted on C1–C3 and scored on C4. These variants were not selected to replace the primary fit.\n\n'+tab(sens_summary)+'\n\n'
text+='## Profiles and numerical checks\n\n'+tab(profile_summary)+'\n\n'
text+='Profiles are finite-budget nuisance-reoptimized objective scans, not confidence intervals. A flat scan or ill-conditioned residual Jacobian limits parameter interpretation.\n\n'
text+='Final solver audit: '+json.dumps(audit,ensure_ascii=False)+'.\n\n'
text+='Primary and nested fits, numerical convergence, profiles, sensitivity, and bound-hit counts are recorded in `logs/REAL_FINAL_SUMMARY.json`. Only four experimental replicates are available. Serially dependent one-step pairs do not establish a four-fold prediction ranking as a population-level statistical conclusion.\n'
(ROOT/'reports/REAL_DATA_FINDINGS.md').write_text(text)

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
fig,axes=plt.subplots(2,3,figsize=(11,6.4),sharey=True)
for ax,model in zip(axes.ravel(),[f'M{i}' for i in range(6)]):
 for parameter,g in profiles[profiles.model==model].groupby('parameter',sort=False):
  ax.plot(g.value/g.reference_value,100*g.relative_sse_change,'o-',markersize=4,label=parameter)
 ax.axhline(0,color='#ABA8BA',linewidth=.7);ax.set_xscale('log');ax.set_title(model);ax.legend(fontsize=8)
 ax.set_xlabel('Fixed value / fitted value');ax.set_ylabel('Training SSE change (%)')
fig.suptitle('C4 profile audit; nuisance parameters refitted on C1-C3; no calibrated intervals',fontsize=11)
fig.tight_layout();fig.savefig(ROOT/'figures/real_parameter_profiles.png',dpi=190);plt.close(fig)
