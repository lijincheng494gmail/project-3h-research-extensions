# Direction 2 | Allee x Predator Competition, Six Models — Research Plan

## Background / 研究背景
Original teacher Project 3H Model (1.1) studies weak-Allee prey and predator foraging interference, asking about permanence, equilibria, local/global stability, enrichment, bifurcations and ecological explanation. The random white/colored noise extension (vii) is **cancelled by the teacher**. The *equations* omit h, despite prose mentioning competition; any `-h*y²` term must be explicitly an extension.

## Research question / 研究问题
固定捕食函数时，Allee 类型与捕食者种内竞争怎样分别、共同影响长期生态行为？

## Hypotheses / 假说
1. H1: No/weak/strong-Allee alternatives change coexistence, extinction thresholds and equilibria.
2. H2: Predator within-species competition affects the equilibrium and stability landscape.
3. H3: Allee and competition can interact rather than add independently.
4. H4: Basins of attraction and recovery after shocks can vary across the six models.
5. H5: Some structural changes may improve observed ecological predictions after fair model fitting.

## Model design / 模型设计
Six-model 3x2 factorial: M0=teacher original weak-Allee/no h; M1=Logistic/no h; M2=strong-Allee/no h; M3=Logistic/competition; M4=weak-Allee/competition; M5=strong-Allee/competition.

### CANONICAL model numbering — DO NOT CHANGE

| Model | Prey growth | Predator intraspecific competition | Relationship |
|---|---|---|---|
| **M0** | weak Allee | No | **TEACHER ORIGINAL baseline** |
| M1 | no Allee / logistic | No | remove weak-Allee term |
| M2 | strong Allee | No | strong low-density threshold |
| M3 | no Allee / logistic | Yes | logistic plus `-h*y²` |
| M4 | weak Allee | Yes | original plus `-h*y²` |
| M5 | strong Allee | Yes | strong Allee plus `-h*y²` |

Original teacher equation is `dx=r*x*(1-x/K)*(1+alpha*x) - m*x*y/(beta+y)`, `dy=e*m*x*y/(beta+y)-d*y`. Strong growth example `r*x*(1-x/K)*(x/A-1)`. Weak Allee *feature* near x=0 requires `alpha*K>1` in the original growth law. Explicitly record `alpha*K`, or use zero/strong classification accurately.

## Experiments / 实验方案
1. A: Exact six-model definition. Keep original foraging-arena predation m*x*y/(beta+y) in all models. Strong-Allee growth chosen as r*x*(1-x/K)*(x/A-1), 0<A<K. Explain the scaling choice and optionally normalize reference per-capita growth for fair contrasts.
2. B: For each M0-M5, complete seven original-style analyses: (1) positive/bounded/permanent, (2) nonnegative equilibrium existence and multiplicity, (3) local stability, (4) global stability/basins, (5) enrichment effect, (6) bifurcation feasibility with nondegeneracy, (7) ecological interpretation. Numerical simulations support all seven. Teacher-cancelled stochastic subsection is excluded.
3. C: Allee contrasts M1/M0/M2; competition contrasts M1 vs M3, M0 vs M4, M2 vs M5; calculate paired conditional effects and an interaction contrast, stratified by parameter regime and final-state outcome.
4. D: Shock resilience: select admissible stable coexistence equilibria per model, perturb prey/predator separately at matched relative levels (e.g. 5%, 25%, 60%, 85%), study recovery time, extinction basin, final state. Include strong-Allee threshold and numerically locate a basin boundary with bisection where meaningful.
5. E: Enrichment/bifurcation: sweep K, competition h, Allee threshold A (or alpha) with continuation, local stability and numerical orbit diagnostics. Check existence of requested bifurcations rather than announcing all as present.
6. F: Real C1–C4 observation benchmark. Fit six structures on same training experiments and compare held experiment prediction and simple baselines. Compare complexity, profile parameters and robustness; do not call synthetic scenario parameters field estimates.

## Dataset status / 数据说明
Real C1-C4 ecology data bundled. There is no signed field estimate for the six free-parameter models; this is a mechanistic and predictive comparison, not parameter truth recovery.

## Completion checklist / 验收要求
- [ ] Keep M0 EXACTLY teacher equation (no -h*y^2) and preserve M0-M5 IDs from RESEARCH_PLAN.md.
- [ ] All six models have a seven-question evidence matrix with analytic status + numerical evidence, no empty generic prose.
- [ ] Strong-Allee axial equilibrium (A,0) analyzed alongside (0,0),(K,0); nonnegative feasibility checked.
- [ ] At least 3 matched competition contrasts, 3 matched Allee-growth contrasts, and quantified interaction effects; initial-state shock scenarios separated from parameter changes.
- [ ] Real-data benchmark evaluates six models under identical train/test partitions, baseline forecasts, and complexity-aware scores. Explicitly distinguish held-condition performance from fitting quality.

## Required reporting fields / 结果格式

Each claim must include: [research question; exact model and parameter/units; real or synthetic; data split; evidence table/figure; interpretation; checked limitations if material]. Report **positive findings** and **unexpected or negative findings** in separate sections. Write straightforward English (B2–lower C1) and Chinese; no defensive filler or automatic inflated claims.

**Do not invent 'all 7 questions solved' just because numerical trajectories completed.** Global-stability and permanence proofs, true limit cycles and bifurcation non-degeneracy require explicit mathematics and tests; label numerical candidates as candidates.
