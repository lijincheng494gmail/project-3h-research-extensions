# Current research paper

Open `README_PAPER_PACKAGE.md` and `paper/Direction2_SixModel_Paper.pdf`.

The complete comparison is `paper/SIX_MODEL_SEVEN_QUESTION_MATRIX.csv`; full derivations are `paper/Direction2_Supplementary_Information.pdf`. A Chinese guide is `paper/READING_GUIDE_ZH.md`.

Run `bash run.sh paper`, `bash run.sh verify`, or `bash run.sh reproduce` as described in the package README.

Previous execution reports and matrices are preserved as history. Their older 34-established/8-partial count has been superseded by the current 38-established/4-partial matrix.
