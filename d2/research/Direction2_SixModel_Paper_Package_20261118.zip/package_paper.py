"""Package the current paper and its complete supporting evidence without environments."""
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import hashlib
import json
import os

ROOT=Path(__file__).resolve().parent


def main():
    verification=json.loads((ROOT/'logs/revision/PAPER_VERIFICATION.json').read_text())
    if verification['state']!='pass':
        raise RuntimeError('Current paper verification must pass before packaging.')
    dest=ROOT/'deliverables/Direction2_SixModel_Paper_Package_20261118.zip'
    dest.parent.mkdir(exist_ok=True)
    files=[]
    for current,dirs,names in os.walk(ROOT,followlinks=False):
        dirs[:]=sorted(d for d in dirs if d not in ['.venv','__pycache__','deliverables','.git'] and not d.startswith('.'))
        for name in sorted(names):
            path=Path(current)/name
            rel=path.relative_to(ROOT)
            if path.is_symlink() or name.startswith('.') or path.suffix in ['.pyc','.aux','.out','.toc']:
                continue
            if str(rel).startswith('logs/revision/tex/') and path.suffix=='.pdf':
                continue
            files.append((path,rel))
    manifest={str(rel):hashlib.sha256(path.read_bytes()).hexdigest() for path,rel in files}
    with ZipFile(dest,'w',ZIP_DEFLATED,compresslevel=7) as archive:
        for path,rel in files:
            archive.write(path,str(rel))
        archive.writestr('FILE_SHA256.json',json.dumps(manifest,indent=2,ensure_ascii=False))
    with ZipFile(dest) as archive:
        if archive.testzip() is not None:
            raise RuntimeError('ZIP CRC failed')
        for rel,digest in manifest.items():
            if hashlib.sha256(archive.read(rel)).hexdigest()!=digest:
                raise RuntimeError('ZIP manifest mismatch: '+rel)
    digest=hashlib.sha256(dest.read_bytes()).hexdigest()
    dest.with_suffix('.zip.sha256.txt').write_text(digest+'  '+dest.name+'\n')
    print(json.dumps({'zip':str(dest),'files':len(manifest),'bytes':dest.stat().st_size,
                      'sha256':digest,'all_archived_file_hashes_checked':True},indent=2))


if __name__=='__main__':main()
