# Execution record

The following stages were executed on this machine using the project-local `.venv/bin/python`. Detailed outputs and recorded numerical protocols accompany each stage. `run_complete.sh` collects the final versions into a sequential reproduction command; the scientific stages were executed individually during development and verification.

| Stage | Executed command / entry point | Evidence |
| --- | --- | --- |
| Input | Safe ZIP extraction; original 34-file manifest comparison | INPUT_ARCHIVE_AUDIT.json, ORIGINAL_PACKAGE_SHA256.json, SESSION_SCOPE.json |
| Startup tests | `PYTHON=.venv/bin/python bash run.sh tests` | tests.txt; initial extension-fixture failure retained in INITIAL_TEST_FAILURE_RETAINED.txt and corrected before experiments |
| Original full baseline | `PYTHON=.venv/bin/python bash run.sh full` | baseline_full_stdout.txt, baseline_full_stderr.txt, BASELINE_RUN_STATUS.json |
| Mathematical checks | `.venv/bin/python run_analytical_checks.py` | analytical_stdout.txt, ANALYTICAL_CHECKS.json, ANALYTICAL_EXACT_CERTIFICATES.json |
| Synthetic extensions | `.venv/bin/python run_extensions.py` | EXTENDED_STDOUT.txt, EXTENDED_STDERR.txt, EXTENDED_RUN_STATUS.json |
| Independent coordinates/solver | `.venv/bin/python run_direct_solver_audit.py` | DIRECT_SOLVER_AUDIT.json and direct_solver_audit.csv |
| Real main fits | `.venv/bin/python run_real_benchmark.py --only main` | REAL_MAIN_STDOUT.txt, REAL_MAIN_STDERR.txt, REAL_FIT_CACHE.json |
| Explicit inner validation | `.venv/bin/python run_real_validation.py` | REAL_VALIDATION_STATUS.json, real_nested_validation.csv |
| Parameter/assumption checks | `.venv/bin/python run_real_benchmark.py --only extras` | REAL_EXTRAS_STDOUT.txt, REAL_RUN_STATUS.json, profiles/sensitivity tables |
| Real precision audits | `.venv/bin/python run_real_audit.py`; `.venv/bin/python run_real_sensitivity_audit.py` | REAL_SOLVER_AUDIT_STATUS.json, sensitivity audit status, full-pair halving tables |
| Real summaries | `.venv/bin/python summarize_real_results.py` | REAL_FINAL_SUMMARY.json and REAL_DATA_FINDINGS.md |
| Final report | `.venv/bin/python build_reports.py`; `.venv/bin/python render_report.py` | REPORT_NUMBERS.json, PDF_REPORT_STATUS.json |
| Final checks | `.venv/bin/python verify_results.py` | FINAL_VERIFICATION.json, FINAL_TESTS.txt |
| Packaging | `.venv/bin/python package_results.py` | FILE_SHA256.json inside results ZIP |

The real-data precision rounds used uniform maximum log-RK4 steps 0.1, 0.025, 0.0125, then 0.00625. Refinement responded to numerical reference/halving error, not a choice of model based on held prediction rank. Coarser rounds remain under STEP* files and REAL_PRECISION_HISTORY.json. Primary and sensitivity model bounds, fitting budgets, whole-experiment partitions, and scoring definitions remained fixed. No paid resources or external submissions were used.
