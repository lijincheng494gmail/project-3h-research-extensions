# Project 3H Direction 2：六模型实际执行结果

执行日期：2026-11-18。此目录是**完成实际计算、数学核查和证据审计的结果包**，不是原始试跑包。

## 从这里阅读

1. `reports/FINAL_REPORT_ZH.md`：中文主报告。
2. `reports/FINAL_REPORT_EN.pdf`：英文主报告，12pt，含目录，少于25页。
3. `reports/RESULTS_BY_HYPOTHESIS.md`：H1–H5逐项结果和解释。
4. `reports/ANALYTICAL_RESULTS.md`：详细公式、证明、分岔和未解决的问题。
5. `reports/VERIFICATION_MATRIX.csv`：逐项验收状态；`SEVEN_QUESTION_EVIDENCE.csv`与`MODEL_QUESTION_MATRIX.csv`保留42格证据。
6. `reports/SYNTHETIC_METHODS.md`、`REAL_DATA_METHODS.md`、`REAL_DATA_FINDINGS.md`：完整实验和真实数据方法。

## 主要发现与完成范围

- 保留M0为老师原方程，六模型编号不变。已取消的随机噪声任务未执行。
- 原包full基准432条轨道已重跑；扩展设计另有432条长时轨道、864个配对主效应/交互比较、48次冲击实验。
- Logistic模型有全局稳定性二分，并排除内部Hopf/鞍结/BT；弱/强Allee模型给出12个经符号核查的可行局部分岔例子，包括严格正h。
- 弱Allee与Logistic的比较在配平参考增长率后反向；强Allee冲击恢复边界高于单种群阈值A。
- C1–C4真实数据逐值核对来源，整组留出并设置独立整组验证记录，比较一步预测、自由外推、三种简单基线和描述性条件AICc。未发现稳定的Allee预测优势；六模型自由外推均未超过训练均值基线。
- 数学42格中34项done、8项partial。一般Allee多重根区域、完整全局盆地/周期分类及野外动物参数校准仍有明确缺口。不能把本结果包称为“全部数学问题已解”或“已独立证实真实生态机制”。

## 一条命令复现

```bash
bash run_complete.sh
```

需要Python3.10或以上。脚本在本目录创建`.venv`，依照`logs/environment.lock.txt`安装记录的依赖，然后重跑测试、原包full、解析核查、合成扩展、独立直接状态求解器检查、真实数据主拟合/验证/敏感性/剖面、数值审计、报告和打包。首次安装依赖需要网络；计算和数据核验使用包内文件，无付费云任务。完整运行通常比单独的原包`full`明显更长；以各阶段日志为准，不承诺跨机器固定时长。

分阶段复现：

```bash
.venv/bin/python -m unittest discover -s tests -v
PYTHON=.venv/bin/python bash run.sh full
.venv/bin/python run_analytical_checks.py
.venv/bin/python run_extensions.py
.venv/bin/python run_direct_solver_audit.py
.venv/bin/python run_real_benchmark.py --only main
.venv/bin/python run_real_validation.py
.venv/bin/python run_real_benchmark.py --only extras
.venv/bin/python run_real_audit.py
.venv/bin/python run_real_sensitivity_audit.py
.venv/bin/python summarize_real_results.py
.venv/bin/python build_reports.py
.venv/bin/python render_report.py
.venv/bin/python verify_results.py
.venv/bin/python package_results.py
```

原有`bash run.sh quick/full/tests/package`保留；其中`full`**只重跑原始基准**，不能替代`run_complete.sh`中的后续分析、精度核验和最终报告步骤。

## 文件和证据层级

- 最终观测基准：`results/real_benchmark_scores.csv`、`real_model_summary.csv`、`real_predictions.csv`。
- 原始基准：`results/six_model_*.csv`与`reports/PILOT_REPORT_ZH.md`，是starter/pilot，真实拟合预算和步长较粗，不用于最终排名。
- 新合成结果：`results/extended_*.csv`；解析核查：`results/analytical_*.csv`。
- 34项原包哈希核查：`logs/INPUT_ARCHIVE_AUDIT.json`；原始文件清单：`logs/ORIGINAL_PACKAGE_SHA256.json`。它描述原包，不是最终文件哈希。
- 最终文件哈希：ZIP内`FILE_SHA256.json`；最终科学/产物检查：`logs/FINAL_VERIFICATION.json`。
- `logs/input_pilot/`保留用户原包已有的试跑结果；`STEP01_*`、`STEP025_*`等保留被精度审计淘汰的轮次。不能把这些旧结果与最终精度轮次混用。
- 原始观测、单位、筛选和缩放证据：`data/provenance/original/`与`results/real_source_verification.csv`。
- `reports/PRESENTATION_10MIN.md`为10分钟汇报提纲，`AI_USE_AND_AUTHOR_REVIEW.md`为AI使用和作者审阅记录；未进行外部提交或公开发布。

运行`python package_results.py`在`deliverables/`重新生成结果ZIP。原始ZIP未被修改。所有新情景参数均明确标为合成，不冒充Tanner或其他野外测量。
