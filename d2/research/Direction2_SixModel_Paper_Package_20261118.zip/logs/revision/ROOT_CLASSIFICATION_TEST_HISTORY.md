# Test correction

The first root-classification test run passed the canonical cases, repeated
positive roots, and removed axial collisions. Its fourth test raised
ValueError when the test attempted float("1/10000"). This was a test display
conversion error: the exact classifier had already returned the correct
three positive roots. The assertion now converts through SymPy Rational.
The final test stdout is saved separately. No scientific parameter or
classification algorithm changed to repair this test.
