# 方向二：六模型 3×2 设计 / Six-model factorial comparison

## 研究问题 / Research question
在固定 Foraging-arena 捕食函数的条件下，无/弱/强 Allee 和有/无捕食者种内竞争如何改变共存、恢复与稳定？

## 研究设计 / Research design
M0=老师原模型(weak, no h); M1=Logistic/no h; M2=strong/no h; M3=Logistic/h; M4=weak/h; M5=strong/h。共同参数、初值配对；数值候选平衡点、固定时域轨道与三对种内竞争差值。C1–C4 实测藻类/轮虫时间序列作为同条件下一步预测对照。

## 本轮数值观察 / Numerical observations
本轮生成 432 条配对轨道、113 条数值内部平衡候选、288 条配对机制差值、28 条真实数据预测评分。各模型相同输入的变化可在 CSV 中逐行核对。

## 下一步 / Next experiments
Codex 全量：六模型七项数学分析与解析证明；强 Allee 的边界阈值及盆地；大冲击恢复与分岔；嵌套模型比较；所有真实 C1–C4 留出并进行误差/复杂度分析。

## 数据和结论范围 / Evidence status
人工设置的模型情景不是实测；根仅为数值候选；末段有波动不等于已经证明周期轨道。
