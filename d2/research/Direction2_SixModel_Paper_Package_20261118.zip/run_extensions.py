from pathlib import Path
import argparse
from src.extended_experiments import run
if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--stages',nargs='*',choices=['factorial','recovery','continuation','events','audit','figures'])
    args=parser.parse_args()
    run(Path(__file__).resolve().parent,args.stages)
