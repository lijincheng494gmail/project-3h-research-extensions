import unittest
import sympy as sp
from src.root_classification import classify
from run_root_classification import example_cases


class RootClassificationTests(unittest.TestCase):
    def test_canonical_rational_cases(self):
        for fixture in example_cases():
            with self.subTest(fixture=fixture['case']):
                c=classify(fixture['parameters'])
                self.assertEqual(c['distinct_positive'],fixture['expected_distinct'])
                self.assertEqual(c['distinct_positive'],c['monotonicity_classification_count'])
                self.assertLessEqual(c['positive_with_multiplicity'],3)

    def test_positive_triple_root_is_one_equilibrium(self):
        for fixture in example_cases():
            if fixture['case'].endswith('triple_positive_root'):
                c=classify(fixture['parameters'])
                self.assertEqual(c['distinct_positive'],1)
                self.assertEqual(c['positive_with_multiplicity'],3)
                self.assertEqual(c['roots'][0]['multiplicity'],3)

    def test_axial_collisions_are_removed(self):
        for fixture in example_cases():
            if fixture['case'].endswith('triple_axial_collision'):
                c=classify(fixture['parameters'])
                self.assertEqual(c['distinct_positive'],0)
                self.assertEqual(c['zero_root_multiplicity'],3)

    def test_strict_positive_h_can_have_three_physical_roots(self):
        fixtures=[q for q in example_cases() if 'three_simple_h1/10000' in q['case']]
        self.assertEqual(len(fixtures),2)
        for fixture in fixtures:
            c=classify(fixture['parameters'])
            self.assertEqual(c['distinct_positive'],3)
            self.assertGreater(float(sp.Rational(c['parameters']['h'])),0)


if __name__=='__main__':
    unittest.main()
