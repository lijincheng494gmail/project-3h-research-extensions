import unittest
from pathlib import Path
import numpy as np
import pandas as pd
from src.real_benchmark import batch_next,decode,names_for,DEFAULT,make_train,solve_next_dop853
from src.experiments import MODEL_DEFS

class RealBenchmarkTests(unittest.TestCase):
    def test_equation_and_integrator(self):
        for m in MODEL_DEFS:
            t=np.log([DEFAULT[n] for n in names_for(m)]);p=decode(t,m)
            a=batch_next([[.7,.4],[1.,.2]],[.75,1.4],p,.02)
            for i,(xy,dt) in enumerate([([.7,.4],.75),([1.,.2],1.4)]):
                ref=solve_next_dop853(xy,dt,p)
                np.testing.assert_allclose(a[i],ref,rtol=1e-5,atol=1e-7)
            if m in ['M0','M1','M2']:self.assertEqual(p['h'],0)
            if m in ['M0','M4']:self.assertGreater(p['alpha']*p['K'],1)
    def test_held_data_never_sets_train_scale(self):
        frames={c:pd.DataFrame({'time_days':[0,1,2],
                  'prey_million_cells_per_ml':[v,2*v,3*v],
                  'predator_20_animals_per_ml':[v,3*v,2*v]}) for c,v in [('C1',1),('C2',2),('C3',3),('C4',100)]}
        a=make_train(frames,'C4')
        frames['C4'].iloc[:,1:]*=100
        b=make_train(frames,'C4')
        for x,y in zip(a[1:],b[1:]):np.testing.assert_array_equal(x,y)
        self.assertNotIn('C4',a[0])

if __name__=='__main__':unittest.main()
