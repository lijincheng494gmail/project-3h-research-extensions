import unittest
import numpy as np
from src.analytic import positive_equilibria,jacobian_exact
from src.experiments import make,rhs,MODEL_DEFS,sample_cases
from src.core import jacobian


class AnalyticTests(unittest.TestCase):
    def test_jacobian_matches_independent_difference(self):
        base=sample_cases(1)[0]
        for model in MODEL_DEFS:
            p=make(base,model)
            np.testing.assert_allclose(jacobian_exact(p,[3.,.8]),jacobian(rhs,p,[3.,.8]),rtol=1e-7,atol=1e-8)

    def test_reduced_roots_satisfy_original_equations(self):
        for base in sample_cases(4):
            for model in MODEL_DEFS:
                p=make(base,model)
                for z in positive_equilibria(p):
                    self.assertLess(np.linalg.norm(rhs(z,p)),1e-7)

    def test_logistic_existence_and_stability(self):
        base=sample_cases(1)[0]
        for model in ['M1','M3']:
            p=make(base,model)
            self.assertGreater(p['e']*p['m']*p['K']/p['beta']-p['d'],0)
            roots=positive_equilibria(p)
            self.assertEqual(len(roots),1)
            self.assertLess(max(np.linalg.eigvals(jacobian_exact(p,roots[0])).real),0)
            p['d']=10*p['e']*p['m']*p['K']/p['beta']
            self.assertEqual(positive_equilibria(p),[])


if __name__=='__main__':
    unittest.main()
