import unittest
import numpy as np
from src.experiments import rhs,make,MODEL_DEFS,prey_per_capita
from src.core import integrate

class ModelTests(unittest.TestCase):
 def setUp(self):
  self.p={'r':.7,'K':10.,'alpha':.2,'A':2.5,'m':.6,'beta':1.2,'e':.6,'d':.25,'h':.07}
 def test_canonical_M0(self):
  p=make(self.p,'M0');x,y=5.,2.;food=p['m']*x*y/(p['beta']+y)
  self.assertAlmostEqual(rhs([x,y],p)[0],x*p['r']*(1-x/p['K'])*(1+p['alpha']*x)-food)
  self.assertEqual(p['h'],0.)
 def test_strong_threshold(self):
  p=make(self.p,'M2')
  self.assertLess(prey_per_capita(.5,p,'strong'),0.)
  self.assertGreater(prey_per_capita(5.,p,'strong'),0.)
 def test_competition_pair(self):
  for no,yes in [('M1','M3'),('M0','M4'),('M2','M5')]:
   p=make(self.p,no);q=make(self.p,yes);z=[5.,2.]
   self.assertAlmostEqual(rhs(z,p)[1]-rhs(z,q)[1],self.p['h']*z[1]**2)
 def test_integrate_all(self):
  for model in MODEL_DEFS:
   p=make(self.p,model);z=integrate(rhs,p,np.linspace(0,8,35),[3.,.6])
   self.assertTrue(np.all(np.isfinite(z)) and np.min(z)>0)
if __name__=='__main__':unittest.main()
