"""Meaningful checks for period guards, phase sign, and irregular-time peaks."""
import unittest
import numpy as np
from run_cycle_metrics import HarmonicScan,amplitude,summarize_series,phase_diagnostic,separated_peaks

class CycleMetricTests(unittest.TestCase):
 def setUp(self):
  rng=np.random.default_rng(81)
  self.t=np.r_[0,np.cumsum(rng.uniform(.55,1.05,149))]
  self.scan=HarmonicScan(self.t)
 def test_known_irregular_sinusoid_and_phase_lag(self):
  period=7.;lag=1.2
  obs=1+.3*np.sin(2*np.pi*self.t/period)
  pred=1+.3*np.sin(2*np.pi*(self.t-lag)/period)
  ref=summarize_series(self.t,obs,.2,amplitude(obs),self.scan)
  d=summarize_series(self.t,pred,.2,amplitude(obs),self.scan)
  self.assertEqual(ref['period_status'],'descriptive_period_estimable')
  self.assertAlmostEqual(ref['dominant_period_days'],period,delta=.03)
  signed,absolute,status,_=phase_diagnostic(pred,obs,d,ref,self.scan)
  self.assertEqual(status,'descriptive_phase_comparable')
  self.assertAlmostEqual(signed,lag,delta=.03)
  self.assertAlmostEqual(absolute,lag,delta=.03)
 def test_constant_is_not_given_a_period_or_phase(self):
  obs=1+.3*np.sin(2*np.pi*self.t/7)
  ref=summarize_series(self.t,obs,.2,amplitude(obs),self.scan)
  z=np.ones(len(self.t));d=summarize_series(self.t,z,.2,amplitude(obs),self.scan)
  self.assertTrue(np.isnan(d['dominant_period_days']))
  self.assertEqual(d['period_status'],'insufficient_late_amplitude')
  self.assertEqual(d['prominent_peak_count'],0)
  self.assertEqual(phase_diagnostic(z,obs,d,ref,self.scan)[2],'predicted_period_not_estimable')
 def test_harmonic_projection_agrees_with_full_least_squares(self):
  z=.4+.002*self.t+.3*np.sin(2*np.pi*self.t/7)+.02*np.cos(2*np.pi*self.t/11)
  fit=self.scan.fit(z);i=fit['index'];w=2*np.pi*self.scan.freq[i]*self.scan.t
  design=np.column_stack([self.scan.base,np.sin(w),np.cos(w)])
  theta=np.linalg.lstsq(design,z,rcond=None)[0]
  full_error=np.sum((z-design@theta)**2)
  base_theta=np.linalg.lstsq(self.scan.base,z,rcond=None)[0]
  base_error=np.sum((z-self.scan.base@base_theta)**2)
  self.assertAlmostEqual(fit['r2'],1-full_error/base_error,delta=1e-12)
  self.assertAlmostEqual(fit['phase'],np.arctan2(theta[3],theta[2]),delta=1e-12)
 def test_time_separation_uses_days(self):
  t=np.array([0.,1.,1.1,1.2,1.3,5.,6.])
  z=np.array([0.,2.,0.,1.,0.,3.,0.])
  p=separated_peaks(t,z,.1,2.)
  np.testing.assert_array_equal(p,[1,5])

if __name__=='__main__':unittest.main()
