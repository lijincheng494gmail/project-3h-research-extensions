"""Independent checks of cancellation identities and biological boundaries."""
import unittest
import numpy as np
from src.experiments import rhs,make,MODEL_DEFS,prey_per_capita
from src.analytic import jacobian_exact,positive_equilibria

class ScientificIdentities(unittest.TestCase):
 def setUp(self):
  self.base=dict(r=.7,K=8.,alpha=.25,A=2.,m=.6,beta=1.2,e=.65,d=.25,h=.06)
 def test_biomass_balance(self):
  for model in MODEL_DEFS:
   p=make(self.base,model)
   for x,y in [(0.,0.),(.1,5.),(3.,2.),(11.,.3)]:
    f=rhs([x,y],p)
    expected=p['e']*x*prey_per_capita(x,p,p['allee'])-p['d']*y-p['h']*y*y
    self.assertAlmostEqual(p['e']*f[0]+f[1],expected,places=11)
 def test_invariant_boundary_fields(self):
  for model in MODEL_DEFS:
   p=make(self.base,model)
   self.assertEqual(rhs([0.,2.],p)[0],0.)
   self.assertLess(rhs([0.,2.],p)[1],0.)
   self.assertEqual(rhs([3.,0.],p)[1],0.)
   self.assertEqual(rhs([p['K'],0.],p)[0],0.)
   if p['allee']=='strong':self.assertEqual(rhs([p['A'],0.],p)[0],0.)
 def test_exact_jacobian_against_directional_differences(self):
  rng=np.random.default_rng(42)
  for model in MODEL_DEFS:
   p=make(self.base,model)
   for _ in range(5):
    z=rng.uniform(.3,5.,2);v=rng.normal(size=2);step=2e-6
    actual=(rhs(z+step*v,p)-rhs(z-step*v,p))/(2*step)
    np.testing.assert_allclose(jacobian_exact(p,z)@v,actual,rtol=2e-7,atol=2e-8)
 def test_equilibrium_lyapunov_cancellation(self):
  for model in MODEL_DEFS:
   p=make(self.base,model)
   for eq in positive_equilibria(p):
    xs,ys=eq;c=p['beta']/(p['e']*(p['beta']+ys))
    for z in [eq*np.array([.7,1.6]),eq*np.array([1.3,.4])]:
     x,y=z;f=rhs(z,p)
     direct=(1-xs/x)*f[0]+c*(1-ys/y)*f[1]
     identity=(x-xs)*(prey_per_capita(x,p,p['allee'])-prey_per_capita(xs,p,p['allee']))-c*(p['e']*p['m']*xs/((p['beta']+y)*(p['beta']+ys))+p['h'])*(y-ys)**2
     self.assertAlmostEqual(direct,identity,places=9)
if __name__=='__main__':unittest.main()
