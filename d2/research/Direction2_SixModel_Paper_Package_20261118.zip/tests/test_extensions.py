import unittest
import numpy as np
from src.extended_experiments import (positive_roots,jacobian,simulate,case_parameters,
                                     model_parameters,root_record,growth_coefficients)
from src.experiments import make,rhs,MODEL_DEFS,prey_per_capita

class ExtensionTests(unittest.TestCase):
    def setUp(self):self.base=case_parameters()[10]
    def test_polynomial_roots_are_true_equilibria(self):
        for model in MODEL_DEFS:
            p=make(self.base,model);roots=positive_roots(p)
            self.assertTrue(roots)
            for z in roots:
                self.assertLess(np.linalg.norm(rhs(z,p),np.inf),1e-7)
                self.assertTrue(0<z[0]<p['K'] and z[1]>0)
    def test_exact_jacobian_against_independent_finite_difference(self):
        for model in MODEL_DEFS:
            p=make(self.base,model);z=np.array([4.1,1.7]);J=jacobian(p,z)
            numeric=np.column_stack([(rhs(z+np.eye(2)[i]*1e-5,p)-rhs(z-np.eye(2)[i]*1e-5,p))/2e-5 for i in range(2)])
            np.testing.assert_allclose(J,numeric,rtol=1e-7,atol=1e-8)
    def test_growth_reference_is_matched(self):
        for case in case_parameters():
            vals=[]
            for model in MODEL_DEFS:
                p=model_parameters(case,model,'reference_growth_matched')
                vals.append(prey_per_capita(.6*p['K'],p,p['allee']))
            np.testing.assert_allclose(vals,np.full(6,.4*case['r']),rtol=1e-12)
    def test_strong_subthreshold_extinction(self):
        p=make(self.base,'M2');ts,z,_=simulate(p,[.5*p['A'],1.],T=60,step=1.)
        self.assertLess(z[-1,0],1e-8)
        self.assertTrue(np.all(np.diff(z[:,0])<0))
    def test_stable_equilibrium_stays_fixed(self):
        for model in MODEL_DEFS:
            p=make(self.base,model)
            z=max([z for z in positive_roots(p) if root_record(p,z)['stability']=='stable'],key=lambda z:z[0])
            _,sol,_=simulate(p,z,T=20)
            np.testing.assert_allclose(sol,np.tile(z,(len(sol),1)),rtol=1e-7,atol=1e-8)

if __name__=='__main__':unittest.main()
