#!/usr/bin/env bash
# Reproduce the completed deterministic study and its evidence package.
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p logs
if [ ! -x .venv/bin/python ]; then
  "${PYTHON:-python3}" -m venv .venv
fi
RUN_PYTHON=.venv/bin/python
if ! "$RUN_PYTHON" -c 'import numpy,scipy,pandas,matplotlib,sympy,reportlab,pypdf' >/dev/null 2>&1; then
  "$RUN_PYTHON" -m pip install -r logs/environment.lock.txt
fi
"$RUN_PYTHON" -m unittest discover -s tests -v > logs/reproduction_tests.txt 2>&1
PYTHON="$RUN_PYTHON" bash run_baseline.sh full > logs/baseline_full_stdout.txt 2> logs/baseline_full_stderr.txt
cp logs/RUN_STATUS.json logs/BASELINE_RUN_STATUS.json
"$RUN_PYTHON" run_analytical_checks.py > logs/analytical_stdout.txt 2> logs/analytical_stderr.txt
"$RUN_PYTHON" run_extensions.py > logs/EXTENDED_STDOUT.txt 2> logs/EXTENDED_STDERR.txt
"$RUN_PYTHON" run_direct_solver_audit.py > logs/DIRECT_SOLVER_STDOUT.txt 2> logs/DIRECT_SOLVER_STDERR.txt
"$RUN_PYTHON" run_real_benchmark.py --only main > logs/REAL_MAIN_STDOUT.txt 2> logs/REAL_MAIN_STDERR.txt
"$RUN_PYTHON" run_real_validation.py > logs/REAL_VALIDATION_STDOUT.txt 2> logs/REAL_VALIDATION_STDERR.txt
"$RUN_PYTHON" run_real_benchmark.py --only extras > logs/REAL_EXTRAS_STDOUT.txt 2> logs/REAL_EXTRAS_STDERR.txt
"$RUN_PYTHON" run_real_audit.py > logs/REAL_AUDIT_STDOUT.txt 2> logs/REAL_AUDIT_STDERR.txt
"$RUN_PYTHON" run_real_sensitivity_audit.py > logs/REAL_SENSITIVITY_AUDIT_STDOUT.txt 2> logs/REAL_SENSITIVITY_AUDIT_STDERR.txt
"$RUN_PYTHON" summarize_real_results.py > logs/REAL_SUMMARY_STDOUT.txt 2> logs/REAL_SUMMARY_STDERR.txt
"$RUN_PYTHON" verify_results.py
bash run.sh paper
echo 'Scientific calculations, paper, supplement, and evidence package reproduced.'
