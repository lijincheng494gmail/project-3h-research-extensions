# Allee growth and predator competition in six matched models

Project 3H, Direction 2. Executed 18 November 2026. All synthetic quantities use dimensionless population and time units. Real observations use days and the state scales defined below.

## Executive summary

The six-model study produced explicit mathematical results, 432 extended trajectories, 864 conditional contrasts, 48 shock experiments, and four held-experiment observation benchmarks. M0 remains the teacher's exact equation. Weak and strong Allee models admit ordinary saddle-node, Hopf, and Bogdanov-Takens bifurcations in feasible positive parameter regimes. The logistic models exclude all three interior bifurcations. Predator competition changes recovery basins, but its population effect depends on the growth law and regime.

The apparent weak-Allee benefit reverses when reference growth is matched. In observed algae-rotifer data, M3 has the lowest mean one-step error, but its improvement over logistic M1 is only 0.270%. No mechanistic model improves the mean free-trajectory score over the training-mean baseline. These data do not establish an Allee mechanism. Unrestricted global phase classification and a field-calibrated vertebrate application remain open; the verification matrix records these gaps.

## Background

The teacher's brief studies prey growth with a weak Allee effect and a predator-dependent foraging response. Its research programme follows [Haque (2011)](https://doi.org/10.1016/j.mbs.2011.07.003) and [Cantrell and Cosner (2001)](https://www.math.miami.edu/~rsc/docs/2001dynamics.pdf). Here all mathematical claims are derived for the actual displayed equations, rather than imported from a different denominator. The cancelled stochastic extension is excluded.

## Research question and hypotheses

With the predation law fixed, how do prey Allee growth and direct predator competition separately and jointly change coexistence, stability, and recovery? H1 concerns growth structure and equilibria. H2 concerns competition. H3 concerns interaction effects. H4 concerns shock basins and recovery. H5 asks whether these structural changes improve held-experiment prediction. The exact evidence and interpretation for each hypothesis appear in RESULTS_BY_HYPOTHESIS.md.

## Model definitions

All six models use `x' = x g(x) - mxy/(beta+y)` and `y' = emxy/(beta+y) - dy - hy^2`. All biological parameters are positive, except effective h=0 in the three models without added competition. Strong growth requires `0 < A < K`.

| Model | Prey per-capita growth g(x) | Added predator competition |
| --- | --- | --- |
| M0 | r(1-x/K)(1+alpha x) | None: teacher original |
| M1 | r(1-x/K) | None |
| M2 | r(1-x/K)(x/A-1) | None |
| M3 | r(1-x/K) | h > 0 |
| M4 | r(1-x/K)(1+alpha x) | h > 0 |
| M5 | r(1-x/K)(x/A-1) | h > 0 |

For weak growth, positive low-density density dependence requires `alpha K > 1`. Every synthetic parameter row and sweep records alpha K; a weak-form curve with alpha K at most one is not described as having an increasing low-density per-capita rate. Strong r sets a negative per-capita rate at zero and therefore has a different interpretation from logistic r.

The correct Beddington-DeAngelis denominator mapping is `a=0, b=1, c=beta`, not c=0. The teacher's prose mentions competition, but its displayed original equation omits it. Both discrepancies are documented in SOURCE_AND_SCOPE_AUDIT.md.

## Design

The supplied full baseline was rerun: 18 sampled parameter scenarios, four initial states, and six models give 432 trajectories at T=70. This is retained as starter evidence. The extension uses eight sampled scenarios plus four constructed regimes, three matched initial states, six models, and two growth calibrations, giving 432 trajectories at T=400. Initial states are `(0.8K,0.8)`, `(0.1K,0.8)`, and `(0.45K,2)`. A fixed seed of 2026 reproduces the sampled cases. Constructed regimes explore a bifurcation neighbourhood, a stable shock reference, and failed predator invasion; they are not a random ecological sample.

The first arm fixes r across growth laws. The second sets each growth law's per-capita rate at x=0.6K to `r_base(1-0.6)`. This matches one reference rate, not the entire growth curve. Competition comparisons retain the same growth law, calibration, parameters, and initial state. Growth comparisons retain the same predation law. The interaction is a difference of paired competition effects. Full parameters are in extended_parameters.csv; raw effects and outcome-stratified means are in extended_contrasts.csv and extended_contrast_summary.csv.

Shock tests start from the largest-prey stable coexistence equilibrium under `r=.7, K=8, alpha=.225, A=2, m=.3, beta=1.2, e=.65, d=.25`, with h=0 or .05. Each population is reduced separately by 5%, 25%, 60%, or 85%. Parameters remain fixed. Recovery requires both states to remain within 2% of the reference equilibrium for at least 50 time units, through the remaining observation horizon T=600. Basin bisection fixes predator density at its equilibrium value.

| Model | Stable reference prey x* | Predator y* |
| --- | --- | --- |
| M0 | 6.959152 | 4.228139 |
| M1 | 5.525964 | 3.110252 |
| M2 | 6.915302 | 4.193935 |
| M3 | 5.842221 | 2.037574 |
| M4 | 7.109097 | 2.497810 |
| M5 | 7.090917 | 2.491473 |

For the real-data benchmark, the source is the laboratory study of [Blasius et al. (2020)](https://doi.org/10.1038/s41586-019-1857-0), with the [authors' public CSVs](https://github.com/berndblasius/WaveletAnalysis/tree/master/data/chemostat_experiments). The verified positive complete records number 358, 188, 180, and 139 for C1-C4. The prey unit is 10^6 cells/ml; the predator state is rotifers/ml divided by 20. Their medium has the same nominal nitrogen concentration. Thus this is transfer to a held experiment, not demonstrated transfer across external nutrient conditions. The two-state classroom model does not explicitly represent dilution, nutrients, or rotifer life stages.

Each outer fold reserves one entire experiment. A separate inner check fits two of the remaining experiments and validates on the third. Settings are fixed; validation and test errors do not tune the model. Final outer fits use all three non-test experiments, identical observation pairs, training-only scales, and equal two-start optimizer budgets. Each model fits four to six dynamic parameters; e=.65 and beta=1.2 are assumed scale parameters. One-step forecasts condition on the previous observed state. Free forecasts use only the first state and then integrate without resetting to later observations. Conditional training AICc is descriptive because residuals are serially dependent. See REAL_DATA_METHODS.md for bounds, profiles, and assumption sensitivities.

## Findings: positive results

### Mathematical structure

Positivity and ultimate boundedness hold for all six models. For logistic and weak growth, `emK/beta - d > 0` is the permanence condition; when this quantity is nonpositive the predator-free state (K,0) attracts all positive initial states. For strong growth, (0,0), (A,0), and (K,0) all require separate analysis. Every initial state with `0 < x0 <= A` and `y0 > 0` tends to (0,0), so strong models cannot be permanent for all positive initial states.

A scalar polynomial gives all feasible interior equilibrium candidates: degree at most three when h=0 and at most five when h>0. Each candidate is filtered for `0 < g(x) < m`, positive predator density, and the original ODE residual. Independent prey- and predator-coordinate reductions agree on all 144 tested parameter/model sets. At an interior equilibrium the Jacobian is explicit. Logistic growth makes its trace strictly negative and determinant strictly positive; its coexistence equilibrium is unique and globally attracting when predator invasion is positive.

An explicit relative-entropy Lyapunov function gives sufficient global stability for weak growth when `x* >= K - 1/alpha`. For strong growth it gives a certified local basin when the equilibrium lies on the descending growth limb. These are sufficient domains, not an unrestricted global classification. Proofs, exceptional cases, and the seven-question status for each model are in ANALYTICAL_RESULTS.md and MODEL_QUESTION_MATRIX.csv.

### Matched effects and interaction

The following means use only the eight sampled starter-distribution scenarios and their three initial states: 24 matched runs per displayed contrast and calibration. They are finite-design summaries of predator tail means, not estimates of a natural population average. Positive values mean a larger predator tail mean in the target model. The interaction row compares the indicated competition effects.

| Contrast | Type | Same r | Matched g(0.6K) |
| --- | --- | --- | --- |
| M1 to M3 | competition | -1.031472 | -1.031472 |
| M0 to M4 | competition | -2.432300 | -0.676086 |
| M2 to M5 | competition | -0.371326 | +0.353467 |
| M1 to M0 | growth_h0 | +2.419738 | -0.464952 |
| M1 to M2 | growth_h0 | -2.106783 | -3.437490 |
| M0 to M2 | growth_h0 | -4.526520 | -2.972538 |
| M1->M3 to M0->M4 | interaction: weak_vs_logistic | -1.400829 | +0.355385 |
| M1->M3 to M2->M5 | interaction: strong_vs_logistic | +0.660145 | +1.384939 |

The raw competition contrasts cover M1/M3, M0/M4, and M2/M5. Growth contrasts cover all three pairings within each h arm. Outcome labels accompany every effect, so an extinction-to-coexistence change can be distinguished from a shift between two coexistence states.

![Matched synthetic factorial](../figures/extended_factorial.png)

### Recovery basins

45 of 48 shocks recover within the defined horizon. All eight shocks recover in M0, M1, M3, and M4. M2 loses coexistence after 60% and 85% prey removal. M5 recovers after 60% removal but fails after 85%. Every tested predator-only reduction recovers.

| Model | Recovered / 8 | Longest recovery | Prey removals causing extinction |
| --- | --- | --- | --- |
| M0 | 8 | 20.5 | None in tested levels |
| M1 | 8 | 21.5 | None in tested levels |
| M2 | 6 | 20.0 | 60%, 85% |
| M3 | 8 | 15.5 | None in tested levels |
| M4 | 8 | 12.0 | None in tested levels |
| M5 | 7 | 17.5 | 85% |

The strong-model prey-shock boundary lies above the single-population threshold A=2. Existing predators continue to consume prey after a shock. With predator density fixed at its own equilibrium, bisection gives:

| Model | A | Boundary prey density | Retained equilibrium fraction |
| --- | --- | --- | --- |
| M2 | 2 | 3.006585 to 3.006591 | 0.434773 to 0.434774 |
| M5 | 2 | 2.792532 to 2.792538 | 0.393818 to 0.393819 |

Both endpoints retain opposite outcomes when the horizon increases from 800 to 1600. These are numerical brackets along a specified shock ray, not a proof of a unique global separatrix. The Lyapunov sublevel calculation independently certifies a subset of successful recoveries. Files: extended_shock_recovery.csv, extended_basin_boundaries.csv, and extended_shock_lyapunov_certificates.csv.

![Shock recovery](../figures/extended_shock_recovery.png)

### Enrichment and bifurcations

Logistic M1/M3 exclude interior saddle-node, Hopf, and BT bifurcations for all admissible positive parameters. Weak M0/M4 and strong M2/M5 each have feasible ordinary saddle-node, Hopf, and BT examples, including strictly positive h in M4/M5. Twelve parameter-specific constructions satisfy exact symbolic equilibrium and critical-invariant identities. Their nondegeneracy and unfolding checks pass. They establish feasibility, not a complete partition of parameter space.

| Model | h | First Lyapunov coefficient | Local Hopf type |
| --- | --- | --- | --- |
| M0 | 0.000000 | -0.03753706 | supercritical |
| M4 | 0.002547 | +2.93057689 | subcritical |
| M2 | 0.000000 | +0.00033450 | subcritical |
| M5 | 0.029157 | -1.82800326 | supercritical |

Each row uses its own parameter regime; changes in Hopf type across these rows are not a paired causal effect of adding h. First Lyapunov coefficient signs are symbolically certified, and two coefficient formulas agree numerically. The normalization is stated in the analytical report. Local cycle existence follows from the Hopf theorem at these nondegenerate points; long finite-time oscillations alone are not used as its proof. Global cycle uniqueness and global homoclinic curves are not established.

At the constructed weak M0 Hopf point, increasing K through 8 changes the trace from negative to positive with positive determinant. A strong M2 example also loses stability with enrichment. The reference K sweeps and targeted neighbourhoods use fixed alpha or A, rather than silently rescaling their effects with K. Files: extended_continuation.csv, analytical_bifurcation_witnesses.csv, analytical_bifurcation_checks.csv, and logs/ANALYTICAL_EXACT_CERTIFICATES.json.

![Enrichment near a Hopf point](../figures/extended_enrichment_hopf.png)

## Findings: unexpected and negative results

The weak-growth comparison depends strongly on calibration. At the same r, M0 exceeds M1 in mean predator tail density by +2.419738. After matching reference growth the difference is -0.464952. An apparent structural advantage therefore includes a change in growth magnitude. The weak-versus-logistic competition interaction also reverses sign. Neither contrast supports an unconditional benefit of Allee growth.

Competition does not have one universal effect on predator equilibrium density. On a regular stable branch, `dx*/dh = -J12*y*^2/det(J) > 0`, while `dy*/dh = J11*y*^2/det(J)`. The second sign follows the local slope of prey per-capita growth. In strong models, competition can also change which basin contains the initial state. These mechanisms explain why paired predator effects can have either sign.

The observed-data results are:

| Model / baseline | Held one-step NRMSE | Held free NRMSE | Mean training delta AICc |
| --- | --- | --- | --- |
| M0 | 0.885835 | 1.042039 | 39.27 |
| M1 | 0.884862 | 1.037579 | 33.91 |
| M2 | 0.899020 | 1.080195 | 104.05 |
| M3 | 0.882473 | 1.058200 | 0.00 |
| M4 | 0.885504 | 1.062131 | 7.64 |
| M5 | 0.896572 | 1.097785 | 71.20 |
| persistence | 1.040276 | 2.152103 | N/A |
| training_mean | 1.037032 | 1.037032 | N/A |
| training_drift | 1.040325 | 2.360663 | N/A |

Scores average four held experiments equally; lower is better. Training delta AICc is measured relative to the best mechanistic model within each fold and is not a held-out score. The one-step winner varies by experiment: C1: M1; C2: M5; C3: M3; C4: M3. Added competition improves average conditional fitting and gives the lowest mean held one-step error in M3, but its improvement over M1 is 0.270%. Four experiments provide no strong evidence of a general ranking.

The training-mean baseline has free-trajectory NRMSE 1.037032, while the best mechanistic mean is 1.037579. Resetting the state at each observed time therefore makes the task substantially easier than forecasting a whole trajectory. 19 fitted dynamic parameter entries are near their declared bounds. Allee-shape or threshold parameters repeatedly reach their lower bounds. Fitted strong thresholds A range from 0.00372 to 0.00467 million cells/ml, below both training and held observed minima (the smallest observed prey state is 0.09). The data therefore never directly sample a fitted threshold crossing. See real_parameter_identification.csv. The C4 training profiles (58 rows) and prespecified e/beta sensitivities (24 fits) expose dependence on assumptions; they are not confidence intervals or evidence that thresholds have been biologically identified.

![Held-experiment benchmark](../figures/real_benchmark.png)

## Verification and interpretation

The original package manifest passes all 34 input hash checks. The baseline and extensions were actually executed. Forty-eight tighter synthetic integrations use T=800 rather than 400; the largest scaled discrepancy over the common T=400 path is 2.46e-08, with no endpoint outcome-label changes in those audited runs. The final real-data integrator is checked against tight DOP853 solves and step halving; the largest sampled normalized error is 1.61e-05. Rejected coarser precision rounds remain in logs. Final test and audit counts appear in logs/FINAL_VERIFICATION.json.

The structural mathematics establishes what these equations can do. The synthetic comparisons establish conditional effects within the listed scenarios. The observed benchmark establishes predictive errors under specified fitting and observation assumptions. These are distinct forms of evidence. The model omits known chemostat processes, and no fitted parameter is presented as a measured ecological constant. [Tanner (1975)](https://doi.org/10.2307/1936296) does not by itself supply a complete parameter mapping for Eq. (1.1); a field-calibrated muskrat/mink, moose/wolf, or hare/lynx claim is not made.

The completed coverage includes exact model definitions, all six seven-question entries, matched main and interaction contrasts, parameter/initial-state separation, whole-experiment prediction, baseline forecasts, and complexity-aware scoring. Of the 42 analytical question entries, 34 are done and eight are partial: full multiplicity-region and global/basin classification in the four Allee models. Global uniqueness of cycles and a fully calibrated vertebrate application also remain partial. See VERIFICATION_MATRIX.csv for each criterion and its evidence.

## Next feasible experiments

1. Measure prey growth across low densities without predators, then fit its scale and shape separately. Include densities around a proposed threshold.
2. Perturb predator density at matched prey density to separate interference through beta from direct loss through h. Record recovery trajectories with nutrient and dilution measurements.
3. Test a nutrient- and stage-aware model on additional entire chemostat experiments. Choose the model and fitting settings before opening new test trajectories.
4. Extend the analytic sufficient conditions and use validated continuation if a complete two-parameter global diagram or homoclinic structure is required.

## Reproduction and references

Run `bash run_complete.sh` from the extracted project directory. It creates an isolated environment when needed, reruns the scientific calculations and tests, rebuilds the reports, verifies artifacts, and produces the results ZIP. Exact dependency versions are saved in logs/environment.lock.txt. The source data transformations and original-file hashes are in data/provenance/original/ and real_source_verification.csv. AI use and author-review needs are documented separately in AI_USE_AND_AUTHOR_REVIEW.md.

Primary references: the supplied Project 3H brief; [Haque (2011)](https://doi.org/10.1016/j.mbs.2011.07.003); [Cantrell and Cosner (2001)](https://www.math.miami.edu/~rsc/docs/2001dynamics.pdf); [Tanner (1975)](https://doi.org/10.2307/1936296); [Blasius et al. (2020)](https://doi.org/10.1038/s41586-019-1857-0); [Kuznetsov's Hopf lecture notes](https://webspace.science.uu.nl/~kouzn101/cm/L2.pdf); and [the BT theorem and nondegeneracy conditions](https://www.scholarpedia.org/article/Bogdanov-Takens_bifurcation). Literature-access limits are stated in SOURCE_AND_SCOPE_AUDIT.md.
