# Real ecological benchmark: methods and source audit

## Observations and source verification

The observations are the algae–rotifer chemostat experiments C1–C4 released with Blasius et al. (2020), *Long-term cyclic persistence in an experimental predator–prey system*, Nature 577, 226–230, [DOI](https://doi.org/10.1038/s41586-019-1857-0). The [original data record](https://doi.org/10.6084/m9.figshare.10045976.v1) identifies its license as CC BY 4.0. The authors' [GitHub data directory](https://github.com/berndblasius/WaveletAnalysis/tree/5424602a7e4552cc3d60427c14e61f67bcd9e09b/data/chemostat_experiments) was checked against the supplied data on 2026-11-18. Raw downloaded observations, the source README, software license, and figshare metadata are preserved under `data/provenance/original/`. Download URLs and SHA-256 hashes are in `logs/REAL_SOURCE_DOWNLOADS.json`.

The supplied tables exactly reproduce the original first three columns after retaining rows with finite, strictly positive prey and predator measurements and dividing rotifers by 20. Algae are already expressed in millions of cells per milliliter in the released CSV; no additional multiplication or division was applied. The largest absolute reconstruction discrepancy is 4.44×10^-16, from floating-point representation. The observed state is x = algae in 10^6 cells/ml and y = rotifers/(20 animals/ml). Time is days. C1 has 366 original rows and 358 retained rows; C2 190 and 188; C3 182 and 180; C4 139 and 139. All four have nominal external medium 80 µmol N/L. These are independent held experiments under the same nominal medium, rather than a change in external nutrient conditions.

`results/real_source_verification.csv` lists excluded original row indices. All excluded rows lack at least one population measurement; no complete nonpositive row was discarded. One excluded C1 row records zero rotifers with missing algae, so this paired-state benchmark does not test an observed joint extinction event. Rows are not interpolated. Every consecutive retained pair uses its actual time difference, including gaps across missing measurements; the largest gap is 5.03 days in C1. This avoids silently treating a multi-day interval as one day. It also means the benchmark estimates a conditional transition over observed intervals rather than a uniform-daily transition.

## Fixed model structures and parameter units

All six structures call the canonical definitions in `src/experiments.py`. M0 is the teacher's weak-Allee equation without predator competition. M1 is logistic without competition, M2 strong Allee without competition, M3 logistic with competition, M4 weak Allee with competition, and M5 strong Allee with competition. All use mxy/(β+y). No stochastic dynamics are introduced.

The fitting coordinates are log(r), log(K), log(m), log(d), plus log(u) in weak models with αK = 1+u>1, or log(fA) in strong models with A=fA K. Competition models also fit log(h). Thus logistic models have four free dynamic parameters, weak/strong models five, and competition adds one. Bounds and defaults are saved before scoring in `configs/REAL_BENCHMARK_PROTOCOL.json`. They are numerical modeling choices, not empirical parameter estimates from a source paper.

r, m, and d have units day^-1. K and A use x units; α uses inverse x units; β uses y units; h uses inverse y units per day. The conversion e has y units per x unit in the scaled observations. It is not a dimensionless physiological efficiency estimate here. e=0.65 and β=1.2 are fixed scale assumptions in the primary fit; they are not measured quantities. The classroom equation also omits explicit nutrient dynamics, dilution, predator age structure, and observation error.

## Whole-experiment separation and equal fitting budgets

Four outer folds hold out C1, C2, C3, or C4 in turn. The primary final fit uses all consecutive retained pairs from the other three experiments. It never joins the end of one experiment to the start of another. Test pairs total 861 across the four outer folds. The training target standard deviations, with a floor of 0.1, set the two residual scales. No held values set the scales, bounds, optimizer starts, or fixed parameters. `results/real_folds.csv` gives pair counts, scales, gap counts, and a SHA-256 of each fold's training pair array.

An explicit nested validation audit also reserves an entire non-test experiment. The alphabetically last of the three non-test experiments is validation; the other two are training. Its six fits use only the two training experiments. Validation observations enter only the validation score, and outer test observations do not enter this audit. Results are in `results/real_nested_validation.csv`. The protocol is fixed and no model, bound, or optimizer choice is selected using validation or test scores. The primary outer results are separate refits on all three non-test experiments. This distinguishes an auditable train/validation/test split from the final training-plus-validation refit.

Every model receives the same two-start budget: at most 100 least-squares objective evaluations per start, with identical stopping tolerances and the same seed. Numerical Jacobian calls are additionally recorded, since SciPy's nfev does not count all finite-difference residual calls. The best training standardized sum of squares selects the start. More complex models have more finite-difference columns, so equal optimizer-evaluation limits do not mean identical CPU time. All attempted starts, their actual residual-call counts, termination statuses, and wall times are saved in `results/real_fit_attempts.csv`. Convergence is numerical termination within the prescribed bounds; it does not establish a global optimum or parameter identifiability.

## Forecast tasks, baselines, and metrics

One-step conditional predictions start from each preceding *observed* prey and predator state in the held experiment. The target observation is never used to initialize that interval. This task benefits from repeated state observations and must not be described as autonomous reconstruction of the full experimental record.

Free trajectories use only the first retained observed state and forecast all later held observations without resetting. The same fitted parameters are used in both tasks. All later observed states enter scoring only. Individual predictions and observations are in `results/real_predictions.csv`.

The baselines are persistence (preceding state for one-step prediction; first state for the free trajectory), training target mean, and training mean daily drift with forecasts truncated below at zero. The mean and drift use training experiments only. There is no held-experiment smoothing or test fitting.

For species j, RMSE_j = sqrt(mean((prediction_j−observation_j)^2)). The reported normalized score is the mean of RMSE_j/s_j across the two species, where s_j comes from the corresponding training fold. Species RMSE values remain available in observed units. Summaries report the equal-weight mean across four held experiments; they do not treat 861 serially dependent pairs as 861 independent experimental replications.

Conditional AIC = N log(SSE/N)+2k_total, up to a shared constant within a fold, where N is twice the training-pair count, SSE is the training standardized residual sum of squares, and k_total counts dynamic parameters plus one common residual variance. AICc adds 2k_total(k_total+1)/(N−k_total−1). This is a descriptive conditional Gaussian pseudo-likelihood score. Serial dependence, noisy initial observations, and model mismatch prevent interpreting it as a fully specified observation-process likelihood. It evaluates training fit with a complexity penalty; held-experiment prediction remains a different test. It is not a hypothesis test of the biological truth of Allee effects or competition.

## Numerical accuracy, profiles, and fixed-scale sensitivity

An initial step-0.1 log-RK4 fit was rejected for final comparisons after its sampled DOP853 discrepancy reached 0.0175 training-scale units. Its scores and solver audit are retained in `logs/STEP01_*`. A step-0.025 rerun reached 1.59×10^-4 normalized error, just above the acceptance bound. A full-pair halving check at step 0.0125 found a worst normalized difference of 2.94×10^-4 on a high-prey training observation. All primary fits, validation, sensitivity, and profiles were finally rerun with step 0.00625 days. The final sampled audits compare these predictions with DOP853 at rtol=10^-11, atol=10^-13, and max_step=0.05, and with log-RK4 step 0.003125. Audit intervals include the longest gap, the lowest prey and predator observations, and evenly spaced additional intervals for every model and outer fold. Final discrepancies are in `results/real_solver_audit.csv`; the prespecified acceptance bound is 10^-4 in training-scale units. The independent DOP853 integrator, rather than log-state positivity alone, checks the final fitted transition calculation.

Parameter objective profiles use C4 as the prespecified test fold and C1–C3 for fitting. For each model, r and a second relevant parameter (h when present; otherwise fA for strong Allee or K) are fixed at clipped multiples 0.5, 0.75, 1, 1.5, and 2 of the fitted value. Other parameters are reoptimized with a 60-evaluation budget. These are finite-budget nuisance-reoptimized objective profiles, not calibrated confidence intervals. The reported Jacobian condition number and bound hits provide additional identification diagnostics. `at_bound` in the parameter CSV means within 0.2% relative tolerance of either bound (NumPy isclose with rtol=0.002); the optimizer active-bound count is recorded separately. Parameters unused by a model are marked `inactive_not_used`, derived active quantities are marked `derived_active`, and fixed e/beta are marked as scale assumptions.

Four prespecified fixed-scale variants refit C1–C3 and score C4: e=0.325 or 1.3 at β=1.2, and β=0.6 or 2.4 at e=0.65. Each uses two starts and the same 100-evaluation budget as the primary fit. Results are reported together; the best test score is not selected as a replacement model. These variants assess sensitivity to scale assumptions. They do not recover a measured conversion rate. The sensitivity solver audit also compares every training and held pair with a half step, and checks the worst-halving observation in each split against DOP853; see `real_sensitivity_solver_audit.csv`.

## Reproduction

From the project directory, using the environment recorded in `logs/environment_freeze.txt` (or the final environment log named in the root README):

```bash
.venv/bin/python run_real_benchmark.py --only main
.venv/bin/python run_real_validation.py
.venv/bin/python run_real_audit.py
.venv/bin/python run_real_benchmark.py --only extras
.venv/bin/python run_real_sensitivity_audit.py
.venv/bin/python summarize_real_results.py
.venv/bin/python -m unittest tests.test_real_benchmark -v
```

The `--only extras` stage reads the primary fitted-parameter cache and leaves primary scores unchanged. The outer and nested validation fits are deterministic for the saved software versions and fixed seeds; floating-point and optimizer differences across platforms remain possible.
