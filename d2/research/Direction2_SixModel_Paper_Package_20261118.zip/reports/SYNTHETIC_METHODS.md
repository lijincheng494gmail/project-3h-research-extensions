# Synthetic experiment methods and results

## Scope and reproduction

Run `.venv/bin/python run_extensions.py` from the package root after installing `requirements.txt`. The script writes only `extended_*` results and figures. `logs/EXTENDED_RUN_STATUS.json` records the executed stages, counts, solver settings, and elapsed time. Standard output and errors are in `logs/EXTENDED_STDOUT.txt` and `logs/EXTENDED_STDERR.txt`.

All parameters and populations in this experiment are dimensionless synthetic quantities. These values are not measured rates for algae, rotifers, hares, lynx, or other field populations. The model equations and canonical IDs come from the supplied original brief and `RESEARCH_PLAN.md`: M0 is exactly the instructor's weak-growth equation without predator competition; M1/M2 change its prey growth; M3/M4/M5 explicitly add `-h*y^2`. No stochastic differential equations were introduced.

## Matched design and growth calibration

The design has 12 parameter scenarios, 3 initial states, 2 growth calibrations, and 6 model structures, giving 432 trajectories to T=400. Eight scenarios reproduce the starter parameter sampler with seed 2026. Two scenarios are exact weak/strong Hopf references. One has stable coexistence in all six models and supports recovery experiments. One has predator non-invasion. The last four are designed checks, not a random sample. `results/extended_parameters.csv` records all 144 scenario/calibration/model parameter sets, including `alpha_K`, the actual `r`, and growth at the calibration reference. `results/extended_factorial.csv` records all initial states, outcomes, and tail statistics.

The three common initial states are `(0.8K,0.8)`, `(0.1K,0.8)`, and `(0.45K,2)`. They are initial-state treatments; no parameter is changed within one paired comparison.

The first calibration keeps the same intrinsic `r`. The second matches per-capita growth at `x_ref=0.6K` to `0.4*r_base`. It divides weak-growth `r` by `1+alpha*x_ref` and strong-growth `r` by `x_ref/A-1`. All supplied strong thresholds lie below this reference. This removes one growth-scale difference while preserving the exact growth laws. It does not match the complete growth curves, and it is not a unique ecological calibration.

Each scenario, calibration, and initial state produces three competition contrasts, three growth contrasts at h=0, three growth contrasts with competition, and three difference-in-differences interactions. This gives 864 exact paired rows in `results/extended_contrasts.csv`. Positive differences mean the target model has the larger tail mean. The interaction for weak versus logistic growth is `(M4-M0)-(M3-M1)`; strong-versus-logistic and strong-versus-weak use the corresponding model pairs. `results/extended_contrast_summary.csv` stratifies by parameter regime and both finite-horizon outcomes. Tail means use the last quarter of the simulation.

For the eight starter scenarios and three initial states, the following are descriptive averages over the same 24 paired conditions. They are not population effect estimates or statistical significance tests.

| Contrast in predator tail mean | Same r | Matched g(0.6K) |
|---|---:|---:|
| Logistic competition: M3-M1 | -1.031472 | -1.031472 |
| Weak competition: M4-M0 | -2.432300 | -0.676086 |
| Strong competition: M5-M2 | -0.371326 | +0.353467 |
| Weak versus logistic: M0-M1 | +2.419738 | -0.464952 |
| Strong versus logistic: M2-M1 | -2.106783 | -3.437490 |
| Strong versus weak: M2-M0 | -4.526520 | -2.972538 |
| Weak/logistic competition interaction | -1.400829 | +0.355385 |

The weak-versus-logistic comparison and its competition interaction reverse sign after growth calibration. Thus the same-r comparison alone does not isolate a growth-shape advantage. Strong-model competition effects also depend on the final-state pair: their raw same-r differences range from -3.799784 to +2.468954 over these 24 conditions.

## Equilibria and root verification

The extension independently enumerates positive equilibrium candidates in predator density. The predator nullcline gives `X(y)=(beta+y)(d+h*y)/(e*m)`. Multiplying `g(X(y))=m*y/(beta+y)` by `beta+y` produces a polynomial of degree at most five. All numerical roots are filtered for positive y, `0<x<K`, and a small residual in the original vector field. The exact Jacobian is evaluated at every retained root. `results/extended_equilibria.csv` records the roots, residuals, trace, determinant, and local classification.

`src/analytic.py` uses a different polynomial in prey density. `results/extended_independent_root_audit.csv` compares both reductions for all 144 parameter sets. All root counts agree, with no failed agreement row. These are two independent numerical evaluations of exact algebraic reductions. They do not constitute interval-certified root isolation near arbitrary multiple roots.

## Initial-state shocks and basin brackets

The shared recovery parameters are `r=.7, K=8, alpha=.225, A=2, m=.3, beta=1.2, e=.65, d=.25, h=.05`; h is zero in M0/M1/M2. Each model starts from its own admissible, locally stable coexistence equilibrium. Prey and predator are separately reduced by 5%, 25%, 60%, and 85%, giving 48 runs to T=600.

Recovery is the first sampled time after which both populations stay within 2% of that model's original equilibrium for all remaining samples, with at least 50 time units of confirmed residence. Sampling is every 0.5 time unit. An empty recovery time means that the specified recovery criterion was not reached; it is not replaced by a finite value. `results/extended_shock_recovery.csv` includes the equilibrium, shocked initial state, outcome, and recovery time.

M0, M1, M3, and M4 recover after all eight shocks. M2 recovers after six: prey reductions of 60% and 85% lead to extinction. M5 recovers after seven: the 85% prey reduction leads to extinction. All predator reductions recover in this reference condition. At the 60% prey reduction, M2 starts at x=2.766121, above its bare threshold A=2, but still becomes extinct; M5 starts at x=2.836367 and recovers in 17.5 time units. Predator pressure therefore moves the relevant dynamical threshold above the predator-free Allee threshold in this condition.

For each strong model, bisection holds predator density at its coexistence equilibrium and varies retained prey density. Twenty updates use T=800 classifications. Both final bracket endpoints are rerun to T=1600. The result is one validated transition bracket on this fixed-predator shock ray:

| Model | Coexistence x* | Coexistence y* | Transition prey-density bracket | Retained-fraction bracket |
|---|---:|---:|---:|---:|
| M2 | 6.915302 | 4.193935 | [3.006585, 3.006591] | [0.434773, 0.434774] |
| M5 | 7.090917 | 2.491473 | [2.792532, 2.792538] | [0.393818, 0.393819] |

Both lower endpoints become extinct, and both upper endpoints return to coexistence at T=1600. The tables do not claim a unique global separatrix or monotonic basin classification for every possible initial condition. Exact bisection inputs and outputs are in `results/extended_basin_boundaries.csv` and `results/extended_basin_history_M2.csv` / `extended_basin_history_M5.csv`.

The sufficient Lyapunov conditions in `reports/ANALYTICAL_RESULTS.md` were also evaluated for each shock. `results/extended_shock_lyapunov_certificates.csv` gives the initial V, the strong-model sublevel barrier, and the guarantee. Forty-four of 48 shocked states satisfy a sufficient return condition, and all 44 return numerically. M5 has one further recovery outside that sufficient sublevel. Failure of the sufficient test is not a prediction of extinction.

## Enrichment, competition, and Allee parameter sweeps

`results/extended_continuation_parameters.csv` stores every tested parameter setting. `results/extended_continuation.csv` enumerates all feasible positive polynomial roots independently at each grid value, then assigns display branch labels by nearest prey density. This is parameter continuation by root enumeration, not validated predictor-corrector or pseudo-arclength continuation. Branch labels near root creation or loss are descriptive. Numerical orbit checks are saved separately in `results/extended_continuation_orbits.csv`.

All six models have K sweeps. Competition models also have h sweeps. Weak functional families have alpha sweeps, and strong families have A sweeps. Weak and strong families also have beta sweeps and targeted K sweeps around constructed no-competition Hopf witnesses. K changes keep physical alpha or A fixed; infeasible strong settings with A>=K are excluded explicitly. `alpha_K` is saved for every point. Members of the weak functional family with `alpha_K<=1` have no initially increasing per-capita growth and are not described as having that Allee feature.

The stable recovery reference does not show universal enrichment destabilization. The targeted scans do show it. In M0 at the weak Hopf reference, trace changes from -0.000687832 at K=7.9 to zero at K=8 and +0.000674036 at K=8.1, while determinant remains positive near 0.037. In M2 at the strong reference, the corresponding traces are -0.000409274, zero, and +0.000396751, with positive determinant near 0.088. M4 with h=.035 remains stable near K=8 in that weak reference. These are parameter-specific findings. The exact local bifurcation checks, including first Lyapunov coefficients, are in the analytical report and `results/analytical_bifurcation_witnesses.csv`.

`results/extended_constructed_bifurcations.csv` supplies another set of six no-competition weak/strong Hopf, saddle-node, and BT witnesses. The Hopf calculation uses symbolic second/third derivatives and two independent first-Lyapunov formulas. Saddle-node checks include a nonzero scalar second derivative, parameter derivative, and other eigenvalue. BT checks include normal-form coefficients and unfolding rank. `results/extended_bifurcation_crosschecks.csv` records two-sided finite parameter changes and long numerical trajectories. These local checks do not establish a complete two-parameter global bifurcation diagram or uniqueness of a limit cycle.

## Solver and horizon checks

Primary trajectories use DOP853 in log populations, rtol=1e-8, atol=1e-10, and maximum step 1.5. Exponentiation has a machine-underflow safeguard at log density -740; values at that scale carry no ecological interpretation. Extinction labels use explicit much larger thresholds: final prey/K<1e-8 and predator<1e-7. Coexistence-near-equilibrium requires a relative final distance below 1% from a positive equilibrium and a relative last-quarter span below 1%. Other changing trajectories remain unclassified as attractors.

Forty-eight predeclared cases cover every model, both growth calibrations, and four regimes, including the weak/strong Hopf references. They were rerun to T=800 with rtol=1e-10, atol=1e-12, and maximum step .35. On their common first 400 time units, the maximum scaled trajectory discrepancy is 2.4593e-8. No outcome label changes between T=400 and T=800. The full audit is `results/extended_solver_audit.csv`.

An additional independent check runs `.venv/bin/python run_direct_solver_audit.py`. Direct-state implicit Radau and log-state explicit DOP853 are compared to T=80 at rtol=1e-10 and atol=1e-12. The 12 cases cover every model with a perturbed stable equilibrium and a common low-prey initial state. The latter includes subthreshold collapse in both strong models. All 12 pass; the maximum scaled path discrepancy is 5.4186e-11, and no direct-state negative excursion occurs. Settings, signed minima, final states, and solver work are in `results/direct_solver_audit.csv` and `logs/DIRECT_SOLVER_AUDIT.json`.

The event crosschecks also use T=2000. Close to Hopf points, long transients can still give a changing tail. Peak counts and period summaries are therefore numerical orbit diagnostics, not a proof that a trajectory lies on a unique periodic orbit. General global phase portraits, complete separatrix geometry, cycle uniqueness, and a complete BT global unfolding remain outside the proved results.

## Figures

- `figures/extended_factorial.png`: all scenario/initial-state predator tail means under both calibrations.
- `figures/extended_shock_recovery.png`: matched relative shocks, recovery times, and failed recovery indicators.
- `figures/extended_enrichment.png`: all positive roots in the stable-reference K sweeps.
- `figures/extended_enrichment_hopf.png`: targeted enrichment traces near the weak/strong no-competition Hopf references.

The authoritative numerical values are the CSV files; plotted points and rounded report values can be reproduced from them.
