# Six models x seven questions

| Model | Question | Analytical status | Numerical result |
| --- | --- | --- | --- |
| M0 | Q1 positivity, boundedness, permanence | proved; permanence conditional | 72 actual long-horizon runs; outcomes {'coexistence_near_equilibrium': 60, 'changing_or_oscillatory_at_horizon': 6, 'prey_only_at_horizon': 6} |
| M0 | Q2 equilibria and feasibility | exact scalar reduction; general multiplicity-region classification partial | 18 positive roots across18 baseline scenarios; root residual maximum 9.81e-15 |
| M0 | Q3 local stability | proved via exact Jacobian | 18/18 baseline-scenario positive equilibria strictly stable |
| M0 | Q4 global stability and basins | sufficient domains proved; unrestricted classification partial | 8/8 specified shocks recover; max observed recovery 20.5 |
| M0 | Q5 enrichment | stable-branch sensitivity proved; parameter-specific numerical checks | All feasible roots evaluated over K grid; local critical examples supplied for Allee models |
| M0 | Q6 local bifurcations | SN/Hopf/BT feasible with nondegenerate certified witnesses | 3 certified examples; Hopf l1=-0.03753706 |
| M0 | Q7 ecological interpretation | conditional interpretation tied to explicit evidence | Mean held conditional NRMSE 0.885835; free 1.042039 |
| M1 | Q1 positivity, boundedness, permanence | proved; permanence conditional | 72 actual long-horizon runs; outcomes {'coexistence_near_equilibrium': 66, 'prey_only_at_horizon': 6} |
| M1 | Q2 equilibria and feasibility | unique feasible coexistence criterion proved | 18 positive roots across18 baseline scenarios; root residual maximum 2.26e-15 |
| M1 | Q3 local stability | proved via exact Jacobian | 18/18 baseline-scenario positive equilibria strictly stable |
| M1 | Q4 global stability and basins | proved global coexistence/axial regimes | 8/8 specified shocks recover; max observed recovery 21.5 |
| M1 | Q5 enrichment | stable-branch sensitivity proved; parameter-specific numerical checks | K sweep stable whenever coexistence exists; general negative-trace proof |
| M1 | Q6 local bifurcations | interior SN/Hopf/BT excluded | No feasible interior critical point by sign proof |
| M1 | Q7 ecological interpretation | conditional interpretation tied to explicit evidence | Mean held conditional NRMSE 0.884862; free 1.037579 |
| M2 | Q1 positivity, boundedness, permanence | proved; global permanence disproved | 72 actual long-horizon runs; outcomes {'extinction_at_horizon': 58, 'coexistence_near_equilibrium': 10, 'prey_only_at_horizon': 4} |
| M2 | Q2 equilibria and feasibility | exact scalar reduction; general multiplicity-region classification partial | 20 positive roots across18 baseline scenarios; root residual maximum 2.75e-14 |
| M2 | Q3 local stability | proved via exact Jacobian | 10/20 baseline-scenario positive equilibria strictly stable |
| M2 | Q4 global stability and basins | sufficient domains proved; unrestricted classification partial | 6/8 specified shocks recover; max observed recovery 20.0 |
| M2 | Q5 enrichment | stable-branch sensitivity proved; parameter-specific numerical checks | All feasible roots evaluated over K grid; local critical examples supplied for Allee models |
| M2 | Q6 local bifurcations | SN/Hopf/BT feasible with nondegenerate certified witnesses | 3 certified examples; Hopf l1=+0.00033450 |
| M2 | Q7 ecological interpretation | conditional interpretation tied to explicit evidence | Mean held conditional NRMSE 0.899020; free 1.080195 |
| M3 | Q1 positivity, boundedness, permanence | proved; permanence conditional | 72 actual long-horizon runs; outcomes {'coexistence_near_equilibrium': 66, 'prey_only_at_horizon': 6} |
| M3 | Q2 equilibria and feasibility | unique feasible coexistence criterion proved | 18 positive roots across18 baseline scenarios; root residual maximum 3.44e-15 |
| M3 | Q3 local stability | proved via exact Jacobian | 18/18 baseline-scenario positive equilibria strictly stable |
| M3 | Q4 global stability and basins | proved global coexistence/axial regimes | 8/8 specified shocks recover; max observed recovery 15.5 |
| M3 | Q5 enrichment | stable-branch sensitivity proved; parameter-specific numerical checks | K sweep stable whenever coexistence exists; general negative-trace proof |
| M3 | Q6 local bifurcations | interior SN/Hopf/BT excluded | No feasible interior critical point by sign proof |
| M3 | Q7 ecological interpretation | conditional interpretation tied to explicit evidence | Mean held conditional NRMSE 0.882473; free 1.058200 |
| M4 | Q1 positivity, boundedness, permanence | proved; permanence conditional | 72 actual long-horizon runs; outcomes {'coexistence_near_equilibrium': 63, 'prey_only_at_horizon': 6, 'changing_or_oscillatory_at_horizon': 3} |
| M4 | Q2 equilibria and feasibility | exact scalar reduction; general multiplicity-region classification partial | 18 positive roots across18 baseline scenarios; root residual maximum 1.38e-13 |
| M4 | Q3 local stability | proved via exact Jacobian | 18/18 baseline-scenario positive equilibria strictly stable |
| M4 | Q4 global stability and basins | sufficient domains proved; unrestricted classification partial | 8/8 specified shocks recover; max observed recovery 12.0 |
| M4 | Q5 enrichment | stable-branch sensitivity proved; parameter-specific numerical checks | All feasible roots evaluated over K grid; local critical examples supplied for Allee models |
| M4 | Q6 local bifurcations | SN/Hopf/BT feasible with nondegenerate certified witnesses | 3 certified examples; Hopf l1=+2.93057689 |
| M4 | Q7 ecological interpretation | conditional interpretation tied to explicit evidence | Mean held conditional NRMSE 0.885504; free 1.062131 |
| M5 | Q1 positivity, boundedness, permanence | proved; global permanence disproved | 72 actual long-horizon runs; outcomes {'extinction_at_horizon': 54, 'coexistence_near_equilibrium': 14, 'prey_only_at_horizon': 4} |
| M5 | Q2 equilibria and feasibility | exact scalar reduction; general multiplicity-region classification partial | 22 positive roots across18 baseline scenarios; root residual maximum 2.53e-12 |
| M5 | Q3 local stability | proved via exact Jacobian | 11/22 baseline-scenario positive equilibria strictly stable |
| M5 | Q4 global stability and basins | sufficient domains proved; unrestricted classification partial | 7/8 specified shocks recover; max observed recovery 17.5 |
| M5 | Q5 enrichment | stable-branch sensitivity proved; parameter-specific numerical checks | All feasible roots evaluated over K grid; local critical examples supplied for Allee models |
| M5 | Q6 local bifurcations | SN/Hopf/BT feasible with nondegenerate certified witnesses | 3 certified examples; Hopf l1=-1.82800326 |
| M5 | Q7 ecological interpretation | conditional interpretation tied to explicit evidence | Mean held conditional NRMSE 0.896572; free 1.097785 |

Exact evidence and proof links are in MODEL_QUESTION_MATRIX.csv. Q4 conditional results are not full-parameter global classification.
