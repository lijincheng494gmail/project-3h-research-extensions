# Source, model, and scope audit

Audit date: 18 November 2026 (Asia/Shanghai).

## Supplied brief

The supplied `references/Project3H_Original_Brief.pdf` is a five-page Project 3H Version B brief. Its displayed Eq. (1.1) defines M0. The prose mentions predator competition, but Eq. (1.1) has no `-h y^2`. M0 therefore has exactly `h=0`. M3, M4, and M5 explicitly extend their corresponding prey-growth models with this term.

The global-stability hint maps `mxy/(a x+b y+c)` incorrectly by setting `a=c=0,b=1`. The correct mapping for `mxy/(beta+y)`, with positive beta, is `a=0,b=1,c=beta`. The supplied hint would instead remove the positive denominator constant and change the model.

The teacher-cancelled white/colored stochastic dynamics in subsection (vii) are excluded, as required by the experiment pack. Random parameter designs are synthetic deterministic scenarios, not stochastic population dynamics. The reaction-diffusion extension is also outside this study.

The original brief asks for a report of at most 25 pages in 12-point type, with code/AI documentation allowed separately, plus a 10-minute oral presentation. This package provides the bilingual research reports, an English PDF within that page limit, code and AI-use documentation, and a presentation outline. Delivering the oral presentation is a human activity, not an experiment result.

## Primary literature checked

| Source | Direct source | What was checked | Use and access limit |
|---|---|---|---|
| Haque (2011), Mathematical Biosciences 234:1-16 | https://doi.org/10.1016/j.mbs.2011.07.003 | Publisher metadata and abstract identify competition, stability, and bifurcation analyses for a Beddington-DeAngelis model. | Research-program context only. Full publisher text was not accessible in this run; no numbered theorem is copied or assumed to apply. |
| Cantrell and Cosner (2001), JMAA 257:206-222 | https://www.math.miami.edu/~rsc/publications.htm ; author-hosted PDF https://www.math.miami.edu/~rsc/docs/2001dynamics.pdf | Author publication listing and PDF source verified. | Lyapunov/persistence context. The proofs in ANALYTICAL_RESULTS.md are derived for this study's exact equations; bibliographic access is not evidence of automatic theorem applicability. Direct local PDF download timed out; the author-hosted PDF was accessible through the web reader. |
| Tanner (1975), Ecology 56:855-867 | https://doi.org/10.2307/1936296 ; https://esajournals.onlinelibrary.wiley.com/doi/10.2307/1936296 | Publisher abstract and bibliographic record checked. | Growth-rate context only. A predator intrinsic growth rate is not the death parameter d in Eq. (1.1), and this source alone does not calibrate all seven model parameters. No vertebrate parameter set is fabricated. |
| Blasius et al. (2020), Nature 577:226-230 | https://doi.org/10.1038/s41586-019-1857-0 | Publisher record and official data/code availability pointers. | Source of the laboratory observation benchmark. Chemostat observations are not field estimates for the classroom model. |
| Original experimental data | https://github.com/berndblasius/WaveletAnalysis/tree/master/data/chemostat_experiments ; https://doi.org/10.6084/m9.figshare.10045976.v1 | Original CSVs, units, retained positive complete observations, numerical transformation, hashes, and release metadata checked in the real-data audit. | Exact numerical verification appears in `results/real_source_verification.csv` and `data/provenance/original/`. Public code/data are attributed to their original authors. |

The pack's unrelated CAR-T and phage references are not used as evidence for this Direction 2 experiment. The discrete-time Khan manuscript in the teacher brief lacks a verified complete publication identifier; no theorem or measured parameter is attributed to it.

## Units and interpretation

For general dimensional equations let x have prey-density unit X, y predator-density unit Y, and t unit T. Then r,d,m have unit T^-1; K,A have X; alpha has X^-1; beta has Y; e has Y/X; h has (Y T)^-1. The term `m*x*y/(beta+y)` has unit X/T. Predator interference through beta is already present at h=0; h adds direct density-dependent predator loss.

Synthetic parameters and trajectories use nondimensional X,Y,T. They are chosen model scenarios, not measured ecological rates. In the real-data benchmark, t is days, x is 10^6 algal cells/ml, and y is the original rotifer count per ml divided by 20. Corresponding fitted rates have inverse-day units; fitted density parameters use these scaled state units. Fixed beta and e are assumptions in the scaled equations. The benchmark tests predictive structure under these assumptions and does not identify a biological conversion efficiency.

A strong-Allee growth law uses a different r interpretation from logistic/weak growth: its per-capita growth is -r at x=0. The growth-normalized synthetic arm matches per-capita growth at one reference density only. It does not make the entire growth curves or all initial conditions equivalent.

## Local bifurcation theorem conventions

The model-specific equations, equilibrium constructions, coefficients, and symbolic certificates were derived in this run. The standard Hopf sign and nondegeneracy conventions were checked against the author's lecture notes at https://webspace.science.uu.nl/~kouzn101/cm/L2.pdf and the author's treatment at https://www.scholarpedia.org/article/Andronov-Hopf_bifurcation . The BT regularity and quadratic-coefficient conditions were checked against https://www.scholarpedia.org/article/Bogdanov-Takens_bifurcation . The latter conditions require more than a double-zero numerical eigenvalue; the present analysis checks the coordinate transformation, two quadratic coefficients, and two-parameter unfolding rank explicitly.
