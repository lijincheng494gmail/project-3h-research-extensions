# Code and AI-use documentation

The user authorized autonomous execution of the supplied Direction2 research plan. Codex inspected and retained the original ZIP, verified its manifest, reran the baseline, derived analytical results, wrote and executed extensions and observation benchmarks, and generated this report. Parallel agents separated mathematics, synthetic computation, and observed-data fitting. The primary agent reviewed their equations, evidence, code, and claims, and added independent balance/Jacobian/Lyapunov checks and artifact audits.

The submitted original archive is identified by SHA256 `8b5203014d34a444a8454295513cf31db8f0a00ebd79d04ca8bdd3738b30db1b`. No experimental values, field parameter calibrations, or inaccessible literature theorems were invented. All new scenario parameters are explicitly synthetic. Coarse real-solver rounds and an inadmissible early test fixture failure were retained with their corrections.

This package is a research execution record and draft coursework report. It has not been submitted to a journal, assessment portal, or public repository. The human author should understand and independently review the mathematical arguments and biological interpretation, check the course's AI disclosure format against its student handbook, and take responsibility for any eventual submission. Full global phase and cycle classification and vertebrate calibration are explicitly partial. Oral delivery is not automated.

Source code is in src/ and root run_*.py. Numerical inputs, protocols, exact versions, stdout/stderr, and file hashes are included. The English PDF is the concise main report; detailed proofs, CSVs, and source documentation are separate supporting material.
