# Results by hypothesis / 按假说列出的证据

## H1

Question: Allee growth changes coexistence, thresholds, and equilibria

Finding: Supported conditionally by proofs and synthetic scenarios

Source and split: Analytic + synthetic, all six; matched parameter/initial-state design

Result: Strong growth has axial (A,0) and guaranteed extinction for x0<=A. Sampled weak-vs-logistic tail effect reverses from +2.419738 to -0.464952 after reference calibration.

Evidence: ANALYTICAL_RESULTS.md;results/analytical_equilibria.csv;results/extended_factorial.csv;figures/extended_factorial.png

Interpretation limits: Not a measured ecological advantage; one reference rate does not match full growth curves.

## H2

Question: Predator competition changes equilibria and stability

Finding: Supported conditionally

Source and split: Analytic + synthetic; M1/M3, M0/M4, M2/M5 with matched other inputs

Result: Stable-branch prey density increases with h; predator-density response follows sign(g prime). Positive-h models have directly certified feasible bifurcations.

Evidence: results/extended_contrasts.csv;results/analytical_equilibria.csv;results/analytical_bifurcation_witnesses.csv

Interpretation limits: Witness regimes are not paired causal tests of Hopf type; branch effects and basin switches differ.

## H3

Question: Allee and competition effects are not additive

Finding: Supported in the sampled design

Source and split: Synthetic; difference in paired competition effects; eight sampled regimes x three initial states

Result: Weak/logistic interaction mean is -1.400829 at same r and +0.355385 after calibration.

Evidence: results/extended_contrasts.csv;results/extended_contrast_summary.csv;figures/extended_factorial.png

Interpretation limits: Finite-design descriptive interactions, not a significance test or population estimand.

## H4

Question: Recovery and basins vary by model

Finding: Supported for specified shock protocol

Source and split: Synthetic; stable reference; separate prey/predator shocks at fixed parameters

Result: 45/48 shocks recover. M2 fails prey removals60/85%, M5 only85%. At fixed y_eq the M2 and M5 boundary brackets are recorded above A=2.

Evidence: results/extended_shock_recovery.csv;results/extended_basin_boundaries.csv;results/extended_shock_lyapunov_certificates.csv;figures/extended_shock_recovery.png

Interpretation limits: Brackets are along one shock ray, not unique global separatrices; recovery is finite-horizon unless certified.

## H5

Question: Added structures improve observed ecological prediction

Finding: Limited competition gain; no consistent Allee or free-forecast benefit

Source and split: Observed C1-C4; four whole-experiment test folds, inner held validation, fixed settings

Result: M3 mean conditional NRMSE 0.882473 vs M1 0.884862; best mechanistic free mean 1.037579 vs training mean 1.037032.

Evidence: results/real_benchmark_scores.csv;results/real_nested_validation.csv;results/real_assumption_sensitivity.csv;results/real_parameter_profiles.csv;figures/real_benchmark.png

Interpretation limits: Only four same-medium experiments; many shape bounds active; fixed e/beta; serial residuals; no independent mechanism validation.