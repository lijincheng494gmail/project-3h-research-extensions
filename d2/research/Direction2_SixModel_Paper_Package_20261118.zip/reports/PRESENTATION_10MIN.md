# Ten-minute presentation outline / 10分钟汇报提纲

This is preparation material; the author delivers and adapts the presentation. Use the English main report and the named figures.

| Time | Topic | Evidence and main statement |
| --- | --- | --- |
| 0:00-1:00 | Question and exact model | Fix predation, compare3growth laws x2competition states; M0 is unchanged. |
| 1:00-2:00 | Fair design | Same-r and matched-reference-growth arms; same data partitions and fitting budget. |
| 2:00-3:30 | What can be proved | Positivity/bounds; invasion threshold; logistic GAS and no interior Hopf/SN/BT; strong A-axis and extinction basin. |
| 3:30-5:00 | Main effects and interaction | extended_factorial.png; weak-vs-logistic mean predator effect reverses after growth calibration. |
| 5:00-6:15 | Shock recovery | extended_shock_recovery.png; 45/48recoveries, strong basin boundaries aboveA and lowered byh in reference. |
| 6:15-7:15 | Enrichment and bifurcation | extended_enrichment_hopf.png;12certified local bifurcation witnesses, including positiveh; no universal type comparison. |
| 7:15-8:45 | Observed predictions | real_benchmark.png; M3conditionalNRMSE0.8825; full-trajectory forecasts do not beat training mean. |
| 8:45-10:00 | Interpretation and next experiment | Distinguish equation properties, synthetic conditional effects, and observed predictions. Measure low-density growth and predator-density responses. |

## Likely questions

1. Why is h absent from M0? Because the displayed teacher equation omits it; only extension arms add it.
2. Why is alphaK checked? A positive low-density slope requires alphaK>1, not merely alpha>0.
3. Why can competition increase predator density? Indirect prey release and an increasing growth limb can reverse the stable-branch response; basin switching is another mechanism.
4. Does a varying tail prove a cycle? No. Local cycles at the named Hopf points follow nondegeneracy and l1; global uniqueness remains open.
5. Why is the strong recovery boundary aboveA? Predators continue to remove prey after the shock. The reported bracket fixes their initial density at equilibrium.
6. Why not claim Allee identification from observed fits? Shape/threshold bounds, fixed scale assumptions, omitted chemostat processes, and only4held experiments limit interpretation.
7. Are Tanner predator growth rates d? No; a measured intrinsic growth rate is not the classroom predator death parameter.
