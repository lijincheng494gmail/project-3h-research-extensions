# Analytical results for the six-model Allee–competition study

The original M0 equation is preserved. This analysis proves positivity, boundedness, a sharp permanence criterion for the logistic/weak families, exact equilibrium and stability tests, useful global-stability and basin results, and feasible nondegenerate bifurcations. General weak/strong root-region classification, complete basin geometry, and global cycle uniqueness remain open in this study. Those gaps are distinguished from the results proved below.

All constructive parameter examples are synthetic. Population and time units are arbitrary in the synthetic analysis; the observed-data benchmark uses its separately documented normalization and time in days. No Tanner field estimates are inferred from these examples.

## 1. Fixed model and notation

Write

\[
 \dot x=x\left[g(x)-\frac{my}{\beta+y}\right]=F(x,y),\qquad
 \dot y=y\left[\frac{emx}{\beta+y}-d-hy\right]=G(x,y).
\]

All \(r,K,m,\beta,e,d\) are positive, \(h\ge0\). The model families are

\[
g_L=r(1-x/K),\quad
g_W=r(1-x/K)(1+\alpha x),\quad
g_S=r(1-x/K)(x/A-1),\quad 0<A<K.
\]

M0=(W,0), M1=(L,0), M2=(S,0), M3=(L,h>0), M4=(W,h>0), M5=(S,h>0). The initial weak-Allee increase requires \(\alpha K>1\); \(g_W(0)=r>0\) in either case. The synthetic baseline has \(\alpha K\in[1.2,2.6]\), and the bifurcation witnesses have \(\alpha K=6.4\). The strong growth scale is the requested \(x/A-1\), with a separate normalized-growth numerical sensitivity analysis.

Units: \(r,m,d\) have time\(^{-1}\); \(K,A,x\) have prey-density units; \(\beta,y\) have predator-density units; \(\alpha\) has prey-density\(^{-1}\); \(h\) has (predator-density × time)\(^{-1}\); \(e\) converts prey density to predator density.

The original brief's Beddington–DeAngelis mapping has an error. In the denominator \(a x+b y+c\), the correct choice is \(a=0,b=1,c=\beta>0\), with numerator \(mxy\). Setting \(a=c=0,b=1\) gives \(mxy/y=mx\), which is a different response and loses the regular behavior at \(y=0\). The prose in the brief mentions competition, but its Eq. (1.1) contains no \(-hy^2\). Competition is therefore an explicit extension.

## 2. Positive invariance, boundedness, and permanence

**Proposition 1 (all six models).** Nonnegative initial states stay nonnegative. Strictly positive initial states stay positive for every finite time, and all solutions are globally bounded.

**Proof.** The axes are invariant because each derivative contains its own population. The denominator is bounded below by \(\beta>0\). In the interior, the log derivatives are the continuous per-capita rates, so finite-time crossing of an axis is impossible. Also, \(\dot x\le xg(x)\) and \(g(x)<0\) for \(x>K\), giving \(\limsup x\le K\). A direct joint bound uses \(S=ex+y\):

\[
\dot S=exg(x)-dy-hy^2
 \le C-dS,\qquad
C=e\max_{u\ge0}\{u[g(u)+d]\}<\infty.
\]

The maximum is finite because the leading coefficient of \(u[g(u)+d]\) is negative. Thus \(S(t)\le S(0)e^{-dt}+(C/d)(1-e^{-dt})\). This bound and local smoothness give global existence. Numerical support is in results/extended_factorial.csv and results/extended_solver_audit.csv.

Define the predator invasion rate at the prey carrying capacity:

\[
\lambda_K=\frac{emK}{\beta}-d.
\]

**Proposition 2 (M0, M1, M3, M4).** The system is uniformly permanent in the positive quadrant if and only if \(\lambda_K>0\). Here permanence means positive parameter-dependent lower bounds for both \(\liminf x(t)\) and \(\liminf y(t)\), independent of the positive initial state.

**Proof of sufficiency, using explicit excursion bounds.** An eventual uniform upper bound \(N\) for \(y\) follows from Proposition 1. Choose a small \(\delta_x>0\) such that \(g(x)\ge r/2\) and \(emx/\beta\le d/2\) on \(0<x\le\delta_x\). During an excursion in this strip, \(y\) decays at least as fast as \(e^{-dt/2}\). It falls below a fixed level \(y_c\), chosen so that \(my_c/(\beta+y_c)\le r/4\), within a uniform time \(T=2\max(0,\log(N/y_c))/d\). Before that time, \(\dot x/x\ge-m\); afterward, while \(x\le\delta_x\), \(\dot x/x\ge r/4>0\). Every sufficiently late excursion therefore has \(x\ge\delta_x e^{-mT}\). An initially smaller \(x\) eventually leaves this strip by the same argument.

This gives an eventual positive uniform lower bound \(\eta_x\). If \(\lambda_K>0\), choose \(\delta_K>0\) and a small \(\delta_y>0\) so that the predator per-capita rate is positive for \(x\ge K-\delta_K,\ y\le\delta_y\). Make \(\delta_y\) smaller, if needed, so that prey growth is uniformly positive on \([\eta_x/2,K-\delta_K]\) when \(y\le\delta_y\). While the predator is this small, prey reach \(K-\delta_K\) in a uniform time. Predator decline during that time is bounded by \(-d-h\delta_y\); then predator growth is positive. The same excursion argument gives a positive uniform predator lower bound. Necessity, including equality, follows from Proposition 5 below.

**Proposition 3 (M2, M5).** Global permanence is impossible for every admissible strong-Allee parameter set. If \(0<x(0)\le A\) and \(y(0)>0\), then \((x,y)\to(0,0)\).

**Proof.** At \(x=A,y>0\), \(F<0\), and for \(0<x<A\), \(g_S(x)<0\), so prey decrease and never cross upward through \(A\). Their decreasing limit cannot be positive: after any strict entry below \(A\), a positive limiting prey value would leave a strictly negative per-capita rate. Thus \(x\to0\), after which predator per-capita growth is eventually at most \(-d/2\). The origin consequently has an open extinction basin. The strong-Allee coexistence basin can still support persistent trajectories, but that is a basin-dependent statement.

## 3. All nonnegative equilibria and exact interior-root reduction

The axial equilibria are \((0,0)\), \((K,0)\), and additionally \((A,0)\) for M2/M5. There is no positive predator-only equilibrium because \(G(0,y)=-dy-hy^2<0\).

At every positive equilibrium,

\[
0<g(x)<m,\qquad
y=\frac{\beta g(x)}{m-g(x)}.
\]

Substituting into the predator equation gives the necessary and sufficient scalar condition

\[
E(x)=ex[m-g(x)]^2-\beta d[m-g(x)]-h\beta^2g(x)=0.
\]

Only roots with \(0<x<K,\ 0<g(x)<m\) are retained; strong growth additionally implies \(x>A\). Conversely, every retained root reconstructs a positive equilibrium, so the reduction is exact.

For \(h=0\), divide by the strictly positive factor \(m-g\):

\[
P(x)=ex[m-g(x)]-\beta d=0,\qquad
y=emx/d-\beta.
\]

The resulting degree bounds for the number of distinct positive equilibria are:

| Family | \(h=0\) | \(h>0\) |
|---|---:|---:|
| Logistic | at most 2 algebraic roots, exactly 1 feasible root when \(\lambda_K>0\) | at most 3 algebraic roots, exactly 1 feasible root when \(\lambda_K>0\) |
| Weak/strong | at most 3 | at most 5 |

These are safe general polynomial bounds, not claims that every bound is attained. The exact necessary and sufficient root count is the count of feasible roots of \(P\) or \(E\). src/analytic.py evaluates this reduction independently of the y-polynomial used in the numerical extensions; results/extended_independent_root_audit.csv records their agreement.

For logistic/weak growth, a positive equilibrium exists if and only if \(\lambda_K>0\). To see this, the predator nullcline has

\[
x=C(y)=\frac{(\beta+y)(d+hy)}{em},\qquad C'(y)>0.
\]

If \(\lambda_K\le0\), \(C(y)>K\) for every \(y>0\), which is infeasible. If \(\lambda_K>0\), \(C(0)<K\); \(g(C(0))>0\), while \(g(K)=0<my/(\beta+y)\), giving an interior intersection by continuity. Logistic \(g(C(y))\) strictly decreases while the predation term increases, so its root is unique. Weak roots are also unique if \(\alpha K\le1\), or if \(r\ge m\): in the latter case, every feasible point \(0<g<m\) lies on the descending growth limb. General nonmonotone weak/strong parameter-region classification was not completed; the exact polynomial test and explicit multiplicity witnesses are supplied instead.

## 4. Local stability of every equilibrium

At the origin, eigenvalues are \(r,-d\) for logistic/weak growth, and \(-r,-d\) for strong growth. Thus it is a saddle in M0/M1/M3/M4 and a sink in M2/M5.

At \((K,0)\), eigenvalues are \(Kg'(K)<0\) and \(\lambda_K\). It is a sink if \(\lambda_K<0\), a saddle if \(\lambda_K>0\), and nonhyperbolic at equality. At \((A,0)\), strong growth gives eigenvalues \(A g'_S(A)=r(1-A/K)>0\) and \(\lambda_A=emA/\beta-d\). Hence this equilibrium is a saddle when \(\lambda_A<0\), a source when \(\lambda_A>0\), and nonhyperbolic when equality holds; it is never an asymptotically stable threshold state in the full quadrant.

At a positive equilibrium, the exact Jacobian simplifies to

\[
J=\begin{pmatrix}
xg'(x)&-mx\beta/(\beta+y)^2\\
emy/(\beta+y)&-y[emx/(\beta+y)^2+h]
\end{pmatrix}
=\begin{pmatrix}a&b\\c&-D\end{pmatrix},
\quad b<0,\ c>0,\ D>0.
\]

An equilibrium is locally asymptotically stable when \(T=a-D<0,\ \Delta=-aD-bc>0\). It is a saddle when \(\Delta<0\), and unstable when \(T>0,\Delta>0\). Equality cases require the bifurcation tests in Section 7. If \(g'(x)\le0\), then \(T<0,\Delta>0\) automatically. In particular every logistic coexistence equilibrium is stable.

results/analytical_equilibria.csv includes all axial points and algebraically reduced positive equilibria for the 18 original synthetic scenarios, with residuals, \(\lambda_K\), \(\alpha K\), and exact-form Jacobian evaluations. tests/test_analytic.py checks the Jacobian against independent central differences.

## 5. Global stability and certified basin subsets

**Proposition 4 (interior Lyapunov function).** Let \((x_*,y_*)\) be a positive equilibrium and set

\[
c_*=\frac{\beta}{e(\beta+y_*)},\qquad
V=x-x_*-x_*\log(x/x_*)+
c_*[y-y_*-y_*\log(y/y_*)].
\]

Direct differentiation and cancellation of the mixed terms give

\[
\dot V=(x-x_*)[g(x)-g(x_*)]
-c_*\left[\frac{emx_*}{(\beta+y)(\beta+y_*)}+h\right](y-y_*)^2.
\]

The coefficient \(c_*\) follows from matching \(m\beta/[(\beta+y)(\beta+y_*)]\) with \(c_*em/(\beta+y)\); it is not guessed from a different functional response.

For logistic growth, the first term is \(-r(x-x_*)^2/K\). Thus the unique positive equilibrium in M1/M3 is globally asymptotically stable in the positive quadrant whenever \(\lambda_K>0\). The logarithmic function diverges at either axis and at infinity, so its level sets are compact in the interior; LaSalle's invariance argument applies.

For weak growth,

\[
(x-x_*)[g_W(x)-g_W(x_*)]
=\frac{r}{K}(x-x_*)^2[\alpha K-1-\alpha(x+x_*)].
\]

Therefore M0/M4 have the same global conclusion under the sufficient condition \(x_*\ge K-1/\alpha\). This is automatic when \(\alpha K\le1\). Outside this condition, the proof gives no global conclusion; some feasible examples have Hopf and multiple-equilibrium behavior.

For strong growth,

\[
(x-x_*)[g_S(x)-g_S(x_*)]
=\frac{r}{AK}(x-x_*)^2[K+A-x-x_*].
\]

An equilibrium on the descending growth limb, \(x_*>(K+A)/2\), has a certified basin subset. Let \(L=K+A-x_*<x_*\) and

\[
V_{\rm barrier}=L-x_*-x_*\log(L/x_*)>0.
\]

Every positive state with \(V<V_{\rm barrier}\) remains in \(x>L\), where \(\dot V<0\) away from the equilibrium, and converges to it. The barrier is the minimum of \(V\) on \(x=L\). It is a sufficient recovery certificate, not the true separatrix. results/extended_shock_lyapunov_certificates.csv compares this certificate with actual shock integrations; numerical basin boundaries are in results/extended_basin_boundaries.csv.

**Proposition 5 (global predator-free stability in logistic/weak growth).** If \(\lambda_K\le0\), \((K,0)\) is globally asymptotically stable for \(x(0)>0,y(0)\ge0\).

**Proof.** Set \(L_0=x-K-K\log(x/K)+y/e\). Then

\[
\dot L_0=(x-K)g(x)
+y\left[\frac{mK}{\beta+y}-\frac d e\right]-\frac h e y^2.
\]

The first term is negative unless \(x=K\). The second is nonpositive if \(emK\le\beta d\), and strictly negative for \(y>0\), even at equality. Compact positive-x level sets and LaSalle imply convergence. For strong growth this argument is valid only in a positively invariant subset above \(A\); it does not establish global axial stability because the origin is also attracting.

No global cycle-uniqueness theorem is claimed. The Dulac divergence with \(B=1/(xy)\) is

\[
\partial_x(BF)+\partial_y(BG)
=g'(x)/y-em/(\beta+y)^2-h/x.
\]

It is strictly negative for logistic growth and on domains with \(g'\le0\). It has no fixed sign in general weak/strong cases, so applying the logistic no-cycle conclusion to those entire quadrants would be invalid.

## 6. Competition and enrichment sensitivities

On a nonsingular equilibrium branch, with all other parameters fixed,

\[
\binom{x_h}{y_h}=-J^{-1}\binom0{-y^2}
=\frac{y^2}{\Delta}\binom{-b}{a}.
\]

Thus stable branches always have \(x_h>0\). Predator abundance decreases with competition when \(g'<0\), but can increase when \(g'>0\). A universal claim that competition must lower the predator equilibrium would be false for these models.

Holding \(r,\alpha,A,m,\beta,e,d,h\) fixed while changing \(K\),

\[
\binom{x_K}{y_K}=\frac{xg_K}{\Delta}\binom{D}{c}.
\]

Here \(g_K>0\) at every feasible positive equilibrium: its values are \(rx/K^2\), \(rx(1+\alpha x)/K^2\), and \(rx(x/A-1)/K^2\). Both equilibrium densities therefore rise with enrichment on a stable branch. This does not fix the sign of the trace derivative.

M1/M3 cannot lose interior stability through Hopf for any \(K\), since \(g_L'<0\). Weak and strong models can. At the h=0 Hopf witnesses below, keeping \(\alpha\) or \(A\) fixed gives \(dT/dK\approx0.006809\) for M0 and \(0.002238\) for M2. Positive-h examples give \(0.027869\) for M4 and \(0.002227\) for M5; the latter uses a separate point near its h=0 Hopf, with \(m=.6,\beta=.7285931765,d=1.43841,h=.0017705354\). results/analytical_enrichment_witnesses.csv records all four. These positive derivatives show enrichment destabilization in those synthetic regimes. The primary M5 Hopf witness in Section 7 instead has \(dT/dK<0\), showing that the direction is parameter-dependent. Changing \(\alpha K\) or \(A/K\) together with \(K\) is a different intervention and must be labeled separately.

## 7. Nondegenerate bifurcation feasibility

Normal-form conventions follow the author's treatments by [Kuznetsov, Hopf (2006)](https://www.scholarpedia.org/article/Andronov-Hopf_bifurcation) and [Kuznetsov, Bogdanov–Takens (2007)](https://www.scholarpedia.org/article/Bogdanov-Takens_bifurcation). The model-specific algebra below is derived here. The brief's general references motivate the methods; their theorems are not copied onto an unmatched equation.

### Predator-free transcritical bifurcation

At \(\lambda_K=0\), the negative prey eigenvalue is \(Kg'(K)\). A center manifold has \(x-K=c_1y+O(y^2,\lambda_K y)\), where \(c_1=m/[\beta g'(K)]<0\). Substitution gives

\[
\dot y=y[\lambda_K+B y+\cdots],\qquad
B=\frac{em^2}{\beta^2g'(K)}-\frac{emK}{\beta^2}-h<0.
\]

The zero eigenvalue crosses transversally, for example with \(d\) since \(\partial_d\lambda_K=-1\), and \(B\ne0\). All six structures therefore admit a forward transcritical bifurcation at \(emK=\beta d\). Strong models retain their separate low-prey extinction basin. A crossing at \((A,0)\) can also be tested, but is not needed for this carrying-capacity result.

### Interior Hopf, saddle-node, and BT: logistic impossibility

For M1/M3, \(T<0,\Delta>0\) at every interior equilibrium. No interior Hopf, saddle-node, or BT point is feasible. This is an analytic exclusion over all positive parameters, not merely an absence in a numerical sweep.

### Interior feasibility for M0, M2, M4, M5

For \(h=0\), choose an \(x\) with \(g(x)>0,g'(x)>0\), set \(a=xg'(x)>0\), and choose \(m>g+a\). Setting

\[
d=\frac{xm g'}g,\qquad
\beta=\frac{e g(m-g)}{m g'}
\]

gives \(T=0,\ \Delta=a[(m-g)-a]>0\), hence a Hopf candidate. The exact first Lyapunov and transversality checks below make it nondegenerate.

Setting instead \(m=g+a\) gives \(\Delta=T=0\). In local coordinates \(u=x-x_*,v=F(x,y)\), where \(F_y<0\) makes the transformation invertible, the system has \(u'=v\). Its BT quadratic coefficients for \(h=0\) are

\[
a_{20}=\tfrac12(m-g)(2g'+xg''),\qquad
b_{11}=g'+xg''-\frac{x(g')^2}{g}.
\]

For the weak BT example they are \(57/8000\) and \(83/3150\); for the strong example they are \(3/1600\) and \(-29/200\). Both products are nonzero. For the unfolding calculation, normalize the Section 3 polynomial as \(\widehat P=P/e=x(m-g)-\beta d/e\). The Jacobian of \((\widehat P,\widehat P_x,T)\) with respect to \((x,\beta,d)\) has nonzero determinant when \(\widehat P_{xx}=-2g'-xg''\ne0\). This verifies a two-parameter unfolding, rather than inferring BT from two nearly zero eigenvalues.

For an ordinary saddle-node, keep \(m=g+a\) but choose \(\beta=1\), \(d=ex(m-g)\). The supplied witnesses have \(\widehat P_x=0,\widehat P_{xx}\ne0,\widehat P_d=-\beta/e\ne0,T\ne0\).

Positive-h cases are verified directly, rather than counted from the h=0 boundary. A constructive form uses \(S=m-g,\ t=g/m,\ w=d+hy,\ k=hy\):

\[
\beta=exS/w,\quad y=exg/w,\quad h=k/y,\quad d=w-k.
\]

At BT take \(m=g+1.1a,\ w=a^2/[g(1-t)],\ k=g(S-a)w/(ma)\). For an ordinary fold halve this \(w\) and use the same expression for \(k\). For Hopf take \(w\) halfway between the BT value and \(a/t\), and set \(k=a-tw\). The rational certificates verify all positivity, criticality, nondegeneracy, and unfolding checks.

All witnesses use \(r=0.2,K=8,e=0.65\). Weak witnesses have \(\alpha=0.8,x_*=1\); strong witnesses have \(A=2,x_*=3\). Other parameters are listed without rounding loss in logs/ANALYTICAL_EXACT_CERTIFICATES.json.

| Model | Event | \(m\) | \(\beta\) | \(d\) | \(h\) |
|---|---|---:|---:|---:|---:|
| M0 | Hopf | .800000 | 1.306628 | .241270 | 0 |
| M0 | saddle-node | .410000 | 1.000000 | .061750 | 0 |
| M0 | BT | .410000 | .499390 | .123651 | 0 |
| M4 | Hopf | .419500 | .562455 | .116447 | .002547 |
| M4 | saddle-node | .419500 | 1.181156 | .053189 | .001213 |
| M4 | BT | .419500 | .590578 | .106378 | .004851 |
| M2 | Hopf | .600000 | .727865 | 1.440000 | 0 |
| M2 | saddle-node | .212500 | 1.000000 | .292500 | 0 |
| M2 | BT | .212500 | .573529 | .510000 | 0 |
| M5 | Hopf | .227500 | .617347 | .514364 | .029157 |
| M5 | saddle-node | .227500 | 1.296429 | .241364 | .013884 |
| M5 | BT | .227500 | .648214 | .482727 | .055537 |

For positive h, the BT coefficients \((a_{20},b_{11})\) are \((8531/1210000,2029/190575)\) in M4 and \((351/193600,-3709/24200)\) in M5. Their exact unfolding determinants are \(893542507/10080000000000\) and \(4451733/32000000000\), respectively. These values are nonzero.

The Hopf l1 calculation first transforms the linear part to \(u'=-\omega v,\ v'=\omega u\), using original deviations \(=P(u,v)\) with \(P=\left(\begin{smallmatrix}1&0\\-J_{11}/J_{12}&-\omega/J_{12}\end{smallmatrix}\right)\). It then uses the planar cubic/quadratic derivative formula in the cited normalization. An independent complex multilinear calculation uses \(q=(1,-i)/\sqrt2\) in these canonical coordinates. The two floating evaluations agree within \(1.5\times10^{-14}\); the signs below are also obtained symbolically:

| Model | Exact l1 in the stated coordinates | Type | \(dT/dd\) |
|---|---|---|---:|
| M0 | \(-263\sqrt{1482}/269724\) | supercritical; local stable cycles on the unstable-equilibrium side | −.257937 |
| M4 | \(83124167\sqrt5/63424812\) | subcritical; local unstable cycles on the stable-equilibrium side | 2.465740 |
| M2 | \(\sqrt{93}/28830\) | subcritical | −.523185 |
| M5 | \(-179537\sqrt5/219615\) | supercritical | −18.301698 |

These l1 magnitudes depend on the stated coordinate and eigenvector normalization. The four rows use different parameter regimes, so their differences are not a matched estimate of a competition effect. Exact symbolic equilibrium and critical-invariant identities, together with nonzero coefficients and transversality, establish local bifurcations; a finite-time oscillatory tail alone would not do so. No complete global two-parameter curve or homoclinic orbit has been computed.

Reproduce with .venv/bin/python run_analytical_checks.py. The script writes analytical_bifurcation_witnesses.csv, analytical_bifurcation_checks.csv, and exact symbolic certificates. All 12 witness checks passed. Logistic impossibility and carrying-capacity transcritical proofs supplement these numerical/symbolic witnesses.

## 8. Seven original-style questions: status for every model

reports/SEVEN_QUESTION_EVIDENCE.csv provides 42 explicit model–question entries, each with analytical content, exact numerical evidence paths, and limitations. The model-level picture is:

| Question | M0/M4 weak | M1/M3 logistic | M2/M5 strong |
|---|---|---|---|
| 1. Positive/bounded/permanent | all positive and bounded; permanence iff \(\lambda_K>0\) | same | positive/bounded; global permanence impossible |
| 2. Equilibria/root count | exact feasible polynomial test, degree bounds, existence iff \(\lambda_K>0\); full multiplicity regions partial | unique coexistence iff \(\lambda_K>0\) | axial \(A\) included; exact feasible polynomial test; full multiplicity regions partial |
| 3. Local stability | exact trace/determinant and all axial eigenvalues | coexistence always stable | origin stable, \(A\) unstable; exact interior tests |
| 4. Global/basins | global axial theorem and sufficient interior Lyapunov criterion; remaining global classification partial | full axial/interior dichotomy proved | extinction wedge plus explicit coexistence-basin subset and bisection; full separatrix geometry partial |
| 5. Enrichment | stable densities rise; actual destabilizing witnesses and sweeps | densities rise but no Hopf destabilization | stable densities rise; destabilizing witnesses and sweeps |
| 6. Bifurcations | TC plus certified Hopf/fold/BT, h=0 or positive h as appropriate | TC possible; interior Hopf/fold/BT impossible | TC plus certified Hopf/fold/BT |
| 7. Interpretation | low-density growth stays positive; density feedback changes stability | no low-density threshold and globally stable coexistence when invasible | positive low-density threshold; predator pressure can enlarge extinction basin |

For every model, local analytical statements are checked with numerical equilibrium residuals and independent Jacobians. Trajectory, shock, enrichment, and tolerance/horizon evidence are in the extended CSVs cited above. The cancelled stochastic item (vii) is excluded. General limit-cycle uniqueness, complete parameter-plane partitioning, and field-based vertebrate calibration are not claimed.

## 9. Source use and proof boundaries

- Original mathematical specification: references/Project3H_Original_Brief.pdf, pp. 1–4; its actual equation governs M0.
- Cantrell and Cosner (2001), [author copy](https://www.math.miami.edu/~rsc/docs/2001dynamics.pdf), develops Beddington–DeAngelis dynamics and global-stability methods. The Lyapunov derivative in Section 5 is derived explicitly for the present response.
- Haque (2011), [DOI](https://doi.org/10.1016/j.mbs.2011.07.003), motivates the analysis programme. Its equilibrium classifications are not assumed to hold for a changed growth or response.
- Kuznetsov's author-written [Hopf](https://www.scholarpedia.org/article/Andronov-Hopf_bifurcation) and [BT](https://www.scholarpedia.org/article/Bogdanov-Takens_bifurcation) treatments specify normal-form and nondegeneracy conventions.
- Empirical benchmark provenance and biological interpretation use Blasius et al. (2020), [DOI](https://doi.org/10.1038/s41586-019-1857-0), as documented separately. These chemostat measurements do not calibrate the synthetic bifurcation witnesses.

This is an explicit local/conditional analytical study with reproducible synthetic checks. The unresolved general classifications are recorded as partial in the verification matrix rather than replaced by trajectory labels.
