# Empirical extension for the six-model paper

## Actual status and scope

This extension adds retrospective cycle diagnostics to the frozen C1–C4 held-experiment predictions. It performs **zero new model fits and zero new ODE simulations**. The 72 reconstructed model/baseline/forecast-mode NRMSE values agree with their cached scores within 4.44e-16. Input hashes before and after the run agree. No original data, model equation, parameter fit, old report, or main manuscript was changed.

There are 861 distinct held target states, eight observed population records (four experiments, two populations), and 144 forecast population records (nine prediction rules, two modes, two populations, four experiments). The six mechanistic models account for 48 free-running population records. These counts are not independent experimental replications. Training folds overlap and successive observations are serially dependent.

The study has **two factors in a 3 x 2 design**, not three independent factors. Its three comparison dimensions are growth, competition, and their interaction. M0 remains the original weak-Allee model. The empirical contrasts compare separately refitted structures under the same fitting protocol; they are not parameter-matched causal effects of changing an ecological mechanism.

## Findings for H5

The earlier short-step improvement remains unchanged: M3 has mean held one-step NRMSE 0.882473, M1 0.884862, and persistence 1.040276. M3 gives the lowest descriptive conditional training AICc in all four folds. This identifies a useful fitted short-step transition, together with small differences among the six structures.

The added cycle metrics show a clear limitation. Every one of the 48 free-running model/population/experiment records has negligible late amplitude. The maximum late amplitude divided by its observed counterpart is 1.38e-15. No free trajectory receives an estimated sustained period or phase. This describes the saved finite prediction windows; it is not a proof about all attractors or parameter values of a model family.

The observed records retain repeated prominent peaks and substantial late amplitude. Conditional model predictions retain some of this variation because they restart from the preceding observed state, but their amplitude is attenuated. The following values are equal-weight means over the four held experiments. Amplitude means the central 90% sample span in the final half of elapsed target time, divided by the corresponding observed span.

| model | conditional_prey | conditional_predator | free_prey | free_predator |
|---|---|---|---|---|
| M0 | 0.612493 | 0.818938 | 4.79785e-17 | 4.30486e-17 |
| M1 | 0.58099 | 0.840369 | 4.79785e-17 | 8.60972e-17 |
| M2 | 0.612559 | 0.818452 | 2.1684e-16 | 3.91227e-16 |
| M3 | 0.555794 | 0.763475 | 0 | 2.31758e-17 |
| M4 | 0.593743 | 0.751466 | 0 | 0 |
| M5 | 0.650006 | 0.76127 | 0 | 0 |

Persistence has mean conditional late-amplitude ratios about 0.998 for prey and 1.000 for predators because it shifts the observed sequence by one interval. Its preservation of amplitude does not make it the better one-step RMSE predictor. Conversely, the mechanistic models' smaller RMSE does not show that they reproduce autonomous population cycles. Amplitude and forecasting error describe different properties.

H5 is supported as a statement that structure affects these fitted prediction scores. The evidence does not show a consistent predictive advantage from adding weak/strong Allee growth or direct predator competition. It also does not establish a biological Allee threshold, a measured conversion efficiency, or successful autonomous reconstruction of the experimental cycles. The previously recorded bound hits and fixed e/beta assumptions remain relevant.

## Paired growth, competition, and predictive interaction

Negative score differences favor the first named alternative. The interaction is a difference of differences relative to the logistic competition effect. The following table reports mean one-step NRMSE contrasts and the full four-experiment range; it contains no independence-based standard errors or p-values.

| comparison_class | comparison | estimable_folds | mean_contrast | minimum_contrast | maximum_contrast | negative_folds |
|---|---|---|---|---|---|---|
| competition | Logistic: M3 - M1 | 4 | -0.0023888 | -0.0176826 | 0.0199453 | 2 |
| competition | Weak: M4 - M0 | 4 | -0.000331114 | -0.0161285 | 0.0223557 | 2 |
| competition | Strong: M5 - M2 | 4 | -0.00244805 | -0.0111702 | 0.0173656 | 3 |
| Allee_no_h | Weak - Logistic: M0 - M1 | 4 | 0.000972715 | -0.0109865 | 0.00759167 | 1 |
| Allee_no_h | Strong - Logistic: M2 - M1 | 4 | 0.0141579 | -0.0058276 | 0.0383665 | 2 |
| Allee_no_h | Strong - Weak: M2 - M0 | 4 | 0.0131852 | -0.0100055 | 0.0339577 | 1 |
| Allee_with_h | Weak - Logistic: M4 - M3 | 4 | 0.0030304 | -0.0084956 | 0.00914581 | 1 |
| Allee_with_h | Strong - Logistic: M5 - M3 | 4 | 0.0140986 | -0.016823 | 0.0357869 | 1 |
| Allee_with_h | Strong - Weak: M5 - M4 | 4 | 0.0110682 | -0.00832739 | 0.0289676 | 2 |
| interaction | Weak: (M4-M0)-(M3-M1) | 4 | 0.00205769 | 0.00155414 | 0.00249091 | 0 |
| interaction | Strong: (M5-M2)-(M3-M1) | 4 | -5.92436e-05 | -0.0109954 | 0.00682559 | 2 |

For logistic and weak growth, competition worsens one-step prediction in C1 and C2 and improves it in C3 and C4. For strong growth, it worsens C1 and improves C2–C4. The weak-growth predictive interaction is positive in all four experiments, meaning that competition is slightly less favorable for prediction under weak growth than under logistic growth after refitting. Its mean is about +0.00206 NRMSE. The strong-growth interaction averages about -0.000059 and changes sign. These are predictive contrasts after separate parameter estimation, not evidence of ecological synergy or a new matched-parameter mechanism.

`results/real_growth_competition_comparisons.csv` retains every fold, forecast mode, population, endpoint, formula, and unavailable component. It includes all three pairwise growth contrasts in both competition arms, all three competition pairs, and two independent interaction contrasts relative to logistic growth. Their difference gives the redundant strong-versus-weak competition interaction. A missing period/phase component produces a missing contrast rather than a zero effect.

## Periods, peaks, and unavailable quantities

| held | population | prominent_peak_count | median_interpeak_days | dominant_period_days | harmonic_variance_fraction | period_status |
|---|---|---|---|---|---|---|
| C1 | prey | 64 | 5.81 | not estimable | 0.0803433 | weak_single_harmonic_projection |
| C1 | predator | 60 | 6.04 | not estimable | 0.067631 | weak_single_harmonic_projection |
| C2 | prey | 34 | 5 | not estimable | 0.099719 | weak_single_harmonic_projection |
| C2 | predator | 30 | 6 | 7.02255 | 0.123921 | descriptive_period_estimable |
| C3 | prey | 30 | 5.96 | not estimable | 0.0718052 | weak_single_harmonic_projection |
| C3 | predator | 29 | 5.405 | 7.05783 | 0.137187 | descriptive_period_estimable |
| C4 | prey | 17 | 7.1 | 6.70984 | 0.124541 | descriptive_period_estimable |
| C4 | predator | 21 | 5.55 | not estimable | 0.0822253 | weak_single_harmonic_projection |

All eight observed population records have at least 17 selected peaks. However, only three pass the stated single-harmonic coherence screen at its primary 0.10 threshold. The five other records are not declared noncyclic: their repeated peaks are irregular or spread across frequencies, so this simple rule does not assign one coherent period. Candidate scan maxima remain in the CSV. The observed eligibility count changes from eight at a 0.05 harmonic threshold to three at 0.10 and zero at 0.20. This sensitivity is recorded explicitly; the absence of sustained free-forecast amplitude does not depend on that choice.

Period and phase errors are reported only when both the observed and predicted records meet the eligibility rules. Phase also requires compatible periods and sufficient projection onto the observed frequency. The phase is a whole-record harmonic projection, not a time-varying biological delay. Sub-cadence values are fitted diagnostic values and do not establish sub-cadence measurement accuracy. Counts of comparable pairs accompany every mean; the available phase cases are too few and not identical across all models to justify a general phase ranking.

## Reproducible definitions

1. **Common samples and units.** Each diagnostic uses the same target times and target observations as the existing held prediction score. Initial observations used to initialize free trajectories are excluded from scoring. Time is days; prey units are millions of cells/ml; predator units are 20 animals/ml. No data are interpolated or smoothed.
2. **Amplitude.** A90 = Q0.95(z) - Q0.05(z), using ordinary sample quantiles. The late window is t >= t_min + (t_max-t_min)/2. Ratios use the observed span in the same experiment, species, and window. Absolute relative amplitude error is abs(ratio-1). The amplitude itself is reported without thresholding.
3. **Peaks.** Local maxima are found with prominence at least 0.25 times the full-record observed A90. Candidate peaks are processed in descending prominence; retained peaks must be separated by at least two median observation cadences in actual days. Median interpeak interval and its IQR are reported only with at least four retained peaks. These are descriptive event spacings, not proven cycle periods. The source peak operation is documented in the [SciPy reference](https://docs.scipy.org/doc/scipy/reference/generated/scipy.signal.find_peaks.html); the actual-time separation rule is implemented here.
4. **Harmonic scan.** At each of 2048 equally spaced frequencies, least squares fits an intercept, a linear trend, sin(2 pi f t), and cos(2 pi f t). Frequencies run from 4/T to 1/(4 median_delta_t), so searched periods range from four median cadences to one quarter of the record duration. T is the elapsed target-time span. The scan score is the fraction of trend-residual sum of squares explained by the two harmonic terms.
5. **Period eligibility.** The late A90 must reach 0.05 times the training-only residual scale used in the original score, at least four prominent peaks must be present, the maximum harmonic score must be at least 0.10, and the maximizing frequency must not lie on the search boundary. Otherwise the period is missing with a specific reason. The raw candidate period and harmonic score remain available. These thresholds are diagnostic rules, not a calibrated significance test.
6. **Phase.** At the observed selected frequency, the phase of b sin(wt)+c cos(wt) is atan2(c,b). The signed prediction lag is minus the wrapped predicted-minus-observed phase difference divided by w; positive values mean a later prediction. Both periods must be eligible, their relative difference must be at most 10%, and the predicted projection at the observed frequency must explain at least 10% of its detrended variance. Other cases remain missing.
7. **Sensitivity.** Eligibility is recomputed for amplitude floors 0.02, 0.05, and 0.10 times the training scale and harmonic fractions 0.05, 0.10, and 0.20. Forecast and observed sensitivity files retain all combinations. No free mechanistic record becomes amplitude-eligible even at the lowest floor. The rules were added after the original fits, so these are retrospective diagnostics rather than a newly untouched validation dataset.

## Model complexity

| model | dynamic_parameters | data_summary_parameters | parameters_including_residual_variance | mean_conditional_nrmse | mean_free_nrmse | mean_delta_conditional_AICc | near_bound_parameter_rows |
|---|---|---|---|---|---|---|---|
| M0 | 5 | 0 | 6 | 0.885835 | 1.04204 | 39.2706 | 4 |
| M1 | 4 | 0 | 5 | 0.884862 | 1.03758 | 33.9134 | 0 |
| M2 | 5 | 0 | 6 | 0.89902 | 1.08019 | 104.048 | 4 |
| M3 | 5 | 0 | 6 | 0.882473 | 1.0582 | 0 | 1 |
| M4 | 6 | 0 | 7 | 0.885504 | 1.06213 | 7.63635 | 5 |
| M5 | 6 | 0 | 7 | 0.896572 | 1.09779 | 71.1985 | 5 |
| persistence | 0 | 0 | not estimable | 1.04028 | 2.1521 | not estimable | 0 |
| training_mean | 0 | 2 | not estimable | 1.03703 | 1.03703 | not estimable | 0 |
| training_drift | 0 | 2 | not estimable | 1.04033 | 2.36066 | not estimable | 0 |

The dynamic parameter counts are M0=5, M1=4, M2=5, M3=5, M4=6, and M5=6. The conditional AICc additionally counts one common residual variance. It is a descriptive conditional pseudo-likelihood score, not an observation-process likelihood. Mean and drift baselines use two training-derived summaries; persistence uses none. AICc is not assigned to those baseline rules. Parameter units, inactive coordinates, fixed scales, near-bound values, and the original optimization budgets remain in the unchanged existing files.

## Text available for the paper

**Results suggestion.** The cycle diagnostics distinguish short-step accuracy from autonomous population variation. Across all six structures, both populations, and four held experiments, late free-forecast amplitude was negligible compared with the observed amplitude. The largest predicted-to-observed ratio was 1.4 x 10^-15. Conditional forecasts retained variation through observed-state resetting, but their mean late-amplitude ratios were 0.556–0.650 for prey and 0.751–0.840 for predators. All free-forecast periods and phases were therefore unavailable under the stated amplitude screen. These results support useful fitted short-step transitions, but not autonomous reconstruction of the observed cycles.

**Methods suggestion.** Cycle diagnostics were computed retrospectively from the frozen held-experiment predictions, without refitting. Amplitude was the 95th minus 5th sample percentile. The late window was the last half of the elapsed held target-time span. A harmonic scan fit an intercept, trend, sine, and cosine over periods between four median cadences and one quarter of the record duration. A period was assigned only with sufficient late amplitude, at least four prominent peaks, a harmonic variance fraction of at least 0.10, and an interior scan maximum. Phase was compared at the observed frequency only when both periods were eligible and agreed within 10%. Threshold sensitivity and explicit unavailable cases were retained. These diagnostic periods were not interpreted as limit-cycle proofs or significance tests.

**Figure caption suggestion.** Six-model prediction and cycle comparison from the same frozen fits. Symbols denote C1 (circle), C2 (square), C3 (triangle), and C4 (diamond); short lines show four-experiment means. Dashed lines in (a) and (b) show the persistence and training-mean baselines, respectively. Panels (c) and (d) show the late central-90% amplitude divided by the observed span. Filled markers are conditional predictions and open markers are free forecasts; the dashed amplitude reference is one. Purple marks models without added competition and teal marks models with competition. Near-zero free amplitudes describe the saved prediction windows.

## Files, execution, and verification

- Run `python run_cycle_metrics.py` from the project root. `--figures-only` regenerates the figures from the generated tables.
- Run `python -m unittest tests.test_cycle_metrics -v` for irregular-time period recovery, phase-lag sign, constant-record guards, and actual-day peak separation.
- `results/real_cycle_observed.csv`, `real_cycle_metrics.csv`, `real_cycle_summary.csv`, and `real_cycle_complexity.csv` contain the observed, forecast, aggregate, and complexity results.
- `real_cycle_threshold_sensitivity.csv` and `real_cycle_observed_threshold_sensitivity.csv` contain threshold checks; `real_cycle_cache_checks.csv` verifies all 72 cached scores.
- `real_growth_competition_comparisons.csv` and its summary preserve paired growth, competition, and predictive-interaction effects.
- `figures/paper_real_comparison.pdf` is the main four-panel prediction/amplitude figure. The other `paper_real*.pdf` and PNG counterparts provide complexity, factorial contrasts, full amplitude comparisons, and all-model C4 free time series.
- `logs/revision/EMPIRICAL_EXTENSION.json` records input hashes, code hash, protocol, actual counts, and versions. The original observations and attribution remain as documented by [Blasius et al.](https://doi.org/10.1038/s41586-019-1857-0) and the [CC BY data record](https://doi.org/10.6084/m9.figshare.10045976.v1).
