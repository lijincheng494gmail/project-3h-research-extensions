# Revised global classification for Q4

This supplement keeps the six-model comparison as the research objective. It adds proved global regions and exact remaining cases; no trajectory is used as a proof. M0/M4 use weak growth, M1/M3 logistic growth, and M2/M5 strong growth. The statements hold for both h=0 and h>0 unless a restriction is displayed.

## 1. Definitions and precise scope

Write Q++={(x,y):x>0,y>0}, s=beta*d/(e*m), lambda_K=e*m*K/beta-d, and lambda_A=e*m*A/beta-d. Let N+ count distinct positive equilibria, with multiplicity reported separately by the exact root classification. Set

    C(y)=(beta+y)(d+h*y)/(e*m),
    z=y/beta, kappa=h*beta/d,
    H(z)=(1+z)g(s(1+z)(1+kappa*z))-m*z.

Every positive root of H reconstructs a physical positive equilibrium, and every such equilibrium arises this way. The exact root classifier supplies N+; uniqueness never substitutes for a no-cycle argument below.

“Interior GAS” means a positive equilibrium is Lyapunov stable and attracts every initial state in Q++. Attraction to a boundary equilibrium is stated on its indicated domain. In particular, the strong origin can attract all strictly positive states without attracting predator-free states with x>A. A certified basin subset is not an entire basin or a global theorem.

For weak growth put

    c=r*alpha/K, p=(K-1/alpha)/2, M=max_[0,K] gW.

When alpha*K>1, p>0, gW(x)=M-c(x-p)^2, and M=r(1+alpha*K)^2/(4*alpha*K). Also 2p=K-1/alpha. For strong growth p=(K+A)/2, c=r/(A*K), M=r(K-A)^2/(4*A*K).

## 2. The original permanence and Lyapunov arguments are valid

The common bound S=e*x+y and its dissipative inequality give global existence and an eventual uniform population bound. The original weak/logistic permanence proof can be made explicit without a boundary theorem:

* In x<=delta_x choose g>=r/2 and e*m*x/beta<=d/2. Predators decline at least exponentially at rate d/2. After a uniform time T they fall below y_c with m*y_c/(beta+y_c)<=r/4. Prey then increase at rate at least r/4 until leaving the strip. A later excursion cannot fall below delta_x*exp(-m*T). Initial states below that bound first leave the strip and obey the same later-excursion bound.
* Once x has an eventual uniform lower bound eta_x, choose delta_y and delta_K such that predators grow for x>=K-delta_K,y<=delta_y, and prey have a positive uniform per-capita rate on [eta_x/2,K-delta_K] while y<=delta_y. The time to reach K-delta_K is uniformly bounded. During it predator decline is bounded below by -(d+h*delta_y), giving a uniform predator excursion bound.

Thus M0/M1/M3/M4 are uniformly permanent iff lambda_K>0; the necessity includes equality by the axial theorem below. For strong growth, x(0)<=A,y(0)>0 implies extinction, so global permanence is impossible.

For any positive equilibrium E*=(x*,y*), put c*=beta/[e(beta+y*)]. Direct differentiation gives exactly

    V=x-x*-x*log(x/x*)+c*[y-y*-y*log(y/y*)],
    Vdot=(x-x*)[g(x)-g(x*)]
         -c*[e*m*x*/((beta+y)(beta+y*))+h](y-y*)^2.

The coefficient cancels the mixed terms for this response. V is proper in the interior, so its decreasing sublevel sets stay away from both axes and infinity. The original logistic GAS conclusion, weak sufficient condition x*>=2p, and strong local basin certificate are therefore sound. No step requires replacing the response by a different functional response.

## 3. Logistic/weak predator exclusion, including equality

For logistic and weak growth, lambda_K<=0 implies (K,0) is GAS on {x>0,y>=0}. Use

    L_K=x-K-K*log(x/K)+y/e,
    L_K_dot=(x-K)g(x)+y[m*K/(beta+y)-d/e]-(h/e)y^2.

For these growth laws (x-K)g(x)<0 unless x=K. The predator term is strictly negative whenever y>0, including lambda_K=0. Proper positive-x level sets and LaSalle give the result. Therefore Q4 is complete for M1/M3: axial GAS if lambda_K<=0 and unique interior GAS if lambda_K>0.

## 4. New weak-Allee GAS region from a one-way prey barrier

**Theorem W1.** Suppose alpha*K>1, lambda_K>0, r<m<=M, and N+=1. Then the unique positive equilibrium is GAS in Q++.

**Proof.** For m<M let ell=p-sqrt((M-m)/c), u=p+sqrt((M-m)/c); here 0<ell<=u<K. At m=M set ell=u=p. On either vertical line g(x)=m,

    xdot=x*m*beta/(beta+y)>0.

Hence x>=ell and x>=u are positively invariant. In ell<=x<=u, g>=m and an eventual uniform bound y<=N makes xdot>=ell*m*beta/(beta+N)>0. A solution entering x>=ell reaches x>=u in finite time (the equality case has only one line).

On x>=u, g is strictly decreasing and positive until K. The prey and increasing predator nullclines have exactly one intersection there: g-q is positive at x=u and negative at x=K, interpreted only for x>=s on the predator nullcline. Its abscissa exceeds max(u,s). The Lyapunov function above has strictly negative derivative off this equilibrium on the invariant region x>=u, proving attraction of every state there.

If a trajectory never crossed ell, permanence would place its omega-limit set in a compact interior subset of x<=ell. Uniqueness means there is no equilibrium in that subset. The Poincare–Bendixson theorem would then force a periodic orbit. Such an orbit, lying wholly to the left of ell, encloses a positive equilibrium by the planar index theorem, a contradiction. The nonzero rightward vector field at x=ell excludes an invariant omega-limit set on that line. Thus every trajectory eventually enters the proven high-density basin. Its equilibrium is locally asymptotically stable because g'(x*)<0. This proves GAS.

If r>=m, all feasible equilibria lie on the descending limb beyond x=2p, and the original Lyapunov criterion already gives GAS. Thus the genuinely new part of W1 is r<m<=M with a unique root and x*<2p. W1 does not apply when extra left-hand equilibria are present.

## 5. New weak-Allee GAS region from an exact weighted Dulac certificate

**Theorem W2.** Suppose alpha*K>1, lambda_K>0, m>M, and there is q>=0 such that

    D_q(x)=beta*m*x*g'(x)+q*(e*m*x-beta*d)*(m-g(x))<=0

for every 0<=x<=K. Then the positive equilibrium is unique and GAS in Q++.

**Derivation.** Put phi(x)=m-g(x)>0 and use

    B(x,y)=(beta+y)*y^(q-1)/(x*phi(x)).

Its exact divergence is

    div(BF,BG)=y^(q-1)/(x*phi(x)) *
      [D_q(x)/phi(x)-(q+1)(d+h*beta)*y-(q+2)*h*y^2].

It is strictly negative in 0<x<K,y>0. At x=s the certificate requires g'(s)<=0, so s>=p; C(y)>s then lies on the strictly descending prey-growth limb, giving a unique equilibrium with g'(x*)<0. Periodic and homoclinic orbits are excluded by the strict Dulac divergence; uniform permanence makes the omega-limit sets compact in the interior. The unique locally stable equilibrium is consequently GAS. Initial states above K enter x<K: permanence gives an eventual positive predator lower bound, and then xdot is uniformly negative relative to x whenever x>=K.

**Exact way to check the certificate.** D_q is cubic in x. For a chosen rational q, its values at 0,K and the real critical points of D_q in (0,K) decide nonpositivity exactly. Alternatively, for p<=s<K define

    L=max(0, sup_[0,p] beta*x*g'(x)/[e*(s-x)*(m-g(x))]),
    U=inf_(s,K] -beta*x*g'(x)/[e*(x-s)*(m-g(x))].

At s=p remove the common x-p factor at that endpoint. The certificate exists iff L<=U. The extrema are algebraic and can be isolated exactly; this is a finite, checkable parameter condition, not a numerical phase-portrait label. Cases s<p cannot satisfy this certificate.

**Closed-form sufficient subregion.** Write a=m-M>0 and U0=K-p. Choose

    q=2*beta*c*p/[e*(m-M)].

Then D_q is the positive factor 2*beta*c*m/(m-M) times

    N(x)=(x-p)^2[p*c*(x-s)-(m-M)]-p*(m-M)*(s-p).

For p<=s<K, N<=0 on [0,s]. On [s,K], its derivative has at most one interior minimum, so N<=0 on the full interval iff N(K)<=0. Thus the explicit sufficient region is

    p<=s<K,
    m-M >= p*c*(K-p)^2*(K-s)/[(K-p)^2+p*(s-p)].

The simpler condition s>=p and m>=r(1+alpha*K)/2 implies it. Both conditions hold for all h>=0. Competition contributes additional negative terms to this divergence, although no claim is made that these sufficient regions are necessary global-stability thresholds.

Exact examples (r,K,alpha,beta,e)=(1,4,1,1,1): m=10,d=15,h=0 or 1 gives x* approximately 1.774 or 1.795, whereas the old sufficient bound is x*>=3. Here q=4/45. W1 also adds examples with m=3/2,d=3/4,h=0 or 1/10 and x* approximately 2.672 or 2.820<3. The CSV records exact isolating intervals and Sturm counts.

## 6. Complete strong-Allee exclusion and boundary-attraction statements

**Theorem S1: no interior equilibrium is ever GAS in Q++.** For every admissible strong-Allee parameter set, the open set 0<x<A,y>0 converges to the origin. Therefore no positive equilibrium, periodic orbit, or predator-free carrying state can attract all Q++. This fully resolves whether an interior strong-Allee GAS equilibrium is possible: it is not.

**Theorem S2: lambda_K<=0 gives three possible axial limits, not two.** Every strictly positive trajectory converges to exactly one of (0,0),(A,0),(K,0). Both the origin and (K,0) have nonempty open basins; the positive branch of the stable manifold W^s(A,0) separates them and consists of the initial states converging to (A,0).

**Proof of predator extinction.** If lambda_K<0, the bound limsup x<=K makes predator per-capita growth eventually strictly negative. At equality d=e*m*K/beta, an eventual y<=N and x<=K+epsilon give

    ydot<=y[e*m*epsilon/beta-c0*y],
    c0=e*m*K/[beta*(beta+N)]+h>0.

Logistic comparison and epsilon decreasing to zero imply y->0. To see that x has a limit, any compact x-interval avoiding 0,A,K eventually has the fixed sign of x*gS(x). Infinitely many crossings in both directions are impossible. Thus x converges and its limit must be one of the three scalar roots.

Since lambda_A<0 in this region, (A,0) is a hyperbolic saddle. Its stable eigenvector with predator coordinate 1 has prey coordinate

    -F_y(A,0)/[A*g'_S(A)-lambda_A]>0.

Thus W^s(A,0) really enters x>A,y>0. Omitting this set would make an “all trajectories go to origin or K” statement false. It is a one-dimensional separator, not an attracting equilibrium with an open basin.

At lambda_K=0, (K,0) remains asymptotically stable relative to the nonnegative quadrant. For all lambda_K<=0 an explicit positive basin subset is

    L_K < A-K-K*log(A/K).

This proper sublevel lies entirely in x>A, has decreasing L_K, and converges to (K,0). The origin has its usual low-prey basin. The saddle's two local unstable directions lead to those two basins, and because every other trajectory converges to one of the two attracting states, W^s(A,0) is their common boundary in Q++. This identifies the separator dynamically; no closed formula for its graph is claimed.

**Theorem S3: exact criterion for origin attraction of all strictly positive states.** The origin is GAS relative to Q++ union {(0,0)} iff

    lambda_K>0 and N+=0.

This statement never asserts GAS on the entire closed quadrant, where (A,0),(K,0) and the predator-free trajectories remain present.

**Necessity.** A positive equilibrium is a stationary counterexample. If lambda_K<=0, the open carrying-state basin from S2 is a counterexample.

**Sufficiency away from lambda_A=0.** If lambda_K>0 and N+=0, then s<=A: otherwise s in (A,K) gives H(0)=gS(s)>0 while H is negative at the y corresponding to x=K, forcing a positive root. At s<A, (A,0) is a source, the carrying state is a saddle whose stable manifold is the predator-free axis, and the origin is a sink. A periodic orbit would enclose a positive equilibrium and is impossible. A nontrivial omega-limit graph would require a closed heteroclinic circuit; the boundary equilibria have no such incoming/outgoing configuration. Bounded planar trajectories must therefore converge to the origin.

**The potentially degenerate boundary s=A is included.** Let j>=1 be the first index with H_j!=0 in H(z)=sum H_j*z^j. Such j exists because the polynomial is not identically zero. The center direction at (A,0) has

    x=A+[m/(beta*g'_S(A))]y+O(y^2),
    ydot=-e*m*H_j/[beta^(j+1)*g'_S(A)]*y^(j+1)
          +o(y^(j+1)).

To derive the sign rather than assuming a nonzero quadratic term, let x=P(y) be the local root of F(x,y)=0. Since F_x(A,0)=A*g'_S(A)>0,

    P(y)-C(y)=-H(y/beta)/g'_S(A)+o(y^j).

On a center manifold x=U(y), invariance gives U-P=O(y^(j+1)): F_x is nonzero and U'(y)*ydot is one order higher than the leading predator per-capita rate. Substitution into ydot=y*e*m*(U-C)/(beta+y) gives the displayed coefficient. This argument also covers H_1=0 and higher degeneracies.

If N+=0, H(z)<0 for every z>0 (its tail is negative and it has no positive zero), hence H_j<0. The center direction is repelling for y>0, so no interior trajectory converges to (A,0). The same planar argument now applies. More generally, H_j>0 gives an attracting center direction along a one-dimensional threshold set, whereas H_j<0 gives a repelling center direction. The familiar quadratic coefficient is recovered exactly:

    B_A=e*m^2/(beta^2*g'_S(A))-e*m*A/beta^2-h
       =-e*m*H_1/(beta^2*g'_S(A)).

## 7. Larger certified strong-Allee coexistence basins

If m<=M=max gS, let ell<=u be the roots gS(x)=m (ell=u=p at equality). Then A<ell<=u<K. For lambda_K>0, every initial state x(0)>=ell,y(0)>0 converges to the unique positive equilibrium on x>u. The proof is the same rightward-barrier and decreasing-growth Lyapunov argument as in W1. Other positive equilibria may exist to the left; this is a basin theorem, never Q++ GAS.

At any descending-limb equilibrium x*>p, let L=2p-x* (so A<L<x*) and

    V_barrier=L-x*-x*log(L/x*).

The original certificate V<V_barrier also remains valid, because this sublevel lies in x>L and Vdot is strictly negative off the equilibrium. For weak descending-limb equilibria the same certificate works whenever 0<L<x*; L<=0 recovers the original global criterion. These are sufficient recovery regions, not estimates of the exact separatrix unless separately established.

## 8. Exact proved regions and exact remaining sets for the 42-cell matrix

### M1/M3, Q4 — established

Full dichotomy: (K,0) GAS on x>0,y>=0 iff lambda_K<=0; unique positive equilibrium GAS in Q++ iff lambda_K>0.

### M0/M4, Q4 — partial global classification with expanded established regions

For lambda_K<=0 the axial theorem is complete. For lambda_K>0 define three exact sufficient conditions:

* C_L: alpha*K<=1, or the unique equilibrium satisfies x*>=K-1/alpha.
* C_B: alpha*K>1, r<m<=M and N+=1.
* C_D: alpha*K>1, m>M and the cubic certificate D_q<=0 on [0,K] holds for some q>=0.

Each yields unique interior GAS. The case r>=m is already covered by C_L. Conversely, N+>=2 rules out GAS of any individual positive equilibrium. A unique linearly unstable equilibrium (Delta<0 or T>0) also cannot be GAS. If the unique equilibrium is a hyperbolic repeller (Delta>0,T>0), permanence and Poincare–Bendixson additionally force at least one periodic orbit; no uniqueness of that orbit is asserted.

The exact remaining parameter set, before any separately certified nonlinear local-instability exclusion, is

    R_W={lambda_K>0, N+=1, Delta>=0, T<=0}
        minus (C_L union C_B union C_D).

It includes stable-equilibrium cases needing a global no-cycle/basin proof and nonhyperbolic boundaries needing nonlinear local analysis. Any member separately proved locally unstable (e.g. a subcritical weak focus) is removed from R_W and classified as no GAS. We do not assert that every member of R_W is globally stable or globally unstable. The need to exclude extra cycles is genuine; a root count alone does not settle it.

### M2/M5, Q4 — partial basin classification, complete GAS exclusions and axial/extinction regimes

Interior GAS is impossible for all parameters. The lambda_K<=0 three-axial-limit classification is established. The iff criterion lambda_K>0,N+=0 for the origin to attract every strictly positive initial state is established, including s=A and higher center degeneracies. Explicit carrying and coexistence basin subsets are established.

The exact remaining dynamical parameter set is

    R_S={lambda_K>0, N+>=1}.

Within R_S, no equilibrium attracts all Q++; the unresolved part is the complete coexistence/extinction basin geometry, occurrence and number of cycles or saddle connections, and attraction inside every coexistence basin. Descending-limb sublevels and the high-prey barrier region are already resolved subsets. At lambda_A<0 there is an interior stable threshold curve to (A,0); at lambda_A>0 no positive trajectory approaches (A,0); at lambda_A=0 the first nonzero H coefficient decides its center direction as above. These statements do not determine all basin boundaries in R_S.

## 9. Reproduction and verification scope

Run `.venv/bin/python run_global_classification.py`. It writes `logs/revision/GLOBAL_CLASSIFICATION.json` and `results/global_classification_examples.csv`. The run verifies seven exact symbolic derivative/factorization identities and eight rational parameter examples using exact polynomial root counts and isolating intervals. Four weak examples satisfy the new GAS results while failing the old x*>=K-1/alpha sufficient condition. Two strong examples certify the no-positive-equilibrium extinction region; two certify the non-global high-prey coexistence basin. Three additional actual center-manifold series checks cover H_1=0 with a nonzero cubic center flow and H_1=H_2=0 with a nonzero quartic center flow, including h=0 and h>0. For example (r,A,K,m,beta,e,d,h)=(1,3,7,8/7,1,1,24/7,24/7) gives H(z)=-(20z^3+15z^4+3z^5)/7 and ydot=(120/7)y^4+O(y^5). Thus the degenerate s=A no-root case is verified directly as well as covered by the proof. No ODE trajectory is used, no empirical fit is reused as a proof, and no general limit-cycle uniqueness is claimed.
