# Complete feasible equilibrium-count classification

## Conclusion and scope

The fixed-parameter equilibrium count is now established for all six model structures, including repeated roots and collisions with an axis. The result is a complete implicit analytical classification, with an exact rational algorithm for the recorded parameter values. It is not an expanded closed-form atlas of every discriminant surface.

The main improvement is that **all four Allee models have at most three physically feasible positive equilibria, counted with multiplicity**, even when predator competition makes the elimination polynomial degree five. Three distinct equilibria are attainable in M0, M2, M4, and M5. The old degree-five statement was a safe algebraic bound, but was not sharp for physical roots.

For Q2, the appropriate status is **established_exact_algorithmic_count**. No fixed-parameter root-count case is left unresolved. Complete global attractor classification remains a separate Q4 question.

## 1. A coordinate that makes feasibility automatic

The shared system is

\[
\dot x=x[g(x)-my/(\beta+y)],\qquad
\dot y=y[emx/(\beta+y)-d-hy].
\]

All \(r,K,m,\beta,e,d\) are positive and \(h\ge0\). Weak growth has \(\alpha>0\), and strong growth has \(0<A<K\). Define

\[
z=\frac y\beta,\qquad s=\frac{\beta d}{em}>0,\qquad
\kappa=\frac{h\beta}{d}\ge0.
\]

The positive predator nullcline is

\[
x=C(z)=s(1+z)(1+\kappa z),\qquad C'(z)>0.
\]

The equilibrium equation becomes

\[
H(z)=(1+z)g(C(z))-mz=0,\qquad z>0.
\tag{1}
\]

**Bijection.** Every positive equilibrium gives a positive root of (1). Conversely, every positive root defines \(x=C(z)>0,y=\beta z>0\) and satisfies both ODEs. At that root,

\[
g(x)=\frac{mz}{1+z}\in(0,m).
\]

This automatically implies \(x<K\) for logistic and weak growth, and \(A<x<K\) for strong growth. Thus no extra numerical physical filter can remove or add a positive \(z\) root. The monotone coordinate change also preserves local root multiplicity.

The only nonnegative axial equilibria remain \((0,0),(K,0)\), with \((A,0)\) added in strong models. A root at \(z=0\) is an axial collision and must be excluded from the positive equilibrium count.

## 2. Exact coefficients and the sharp three-root bound

For either Allee law write

\[
g(x)=a+bx-cx^2,\qquad c>0.
\]

The coefficients are

| Growth | \(a\) | \(b\) | \(c\) |
|---|---|---|---|
| Weak | \(r\) | \(r(\alpha-1/K)\) | \(r\alpha/K\) |
| Strong | \(-r\) | \(r(1/A+1/K)\) | \(r/(AK)\) |

Writing \(H(z)=\sum_{j=0}^5H_jz^j\) gives

\[
\begin{aligned}
H_0&=a+bs-cs^2=g(s),\\
H_1&=a+bs(2+\kappa)-cs^2(3+2\kappa)-m,\\
H_2&=bs(1+2\kappa)-cs^2(3+6\kappa+\kappa^2),\\
H_3&=bs\kappa-cs^2(1+6\kappa+3\kappa^2),\\
H_4&=-cs^2(2\kappa+3\kappa^2),\\
H_5&=-cs^2\kappa^2.
\end{aligned}
\tag{2}
\]

For \(\kappa>0\), \(H_4,H_5<0\). Moreover, \(H_3>0\) implies \(H_2>0\). Indeed, the two positivity thresholds for \(b/(cs)\) satisfy

\[
\frac{1+6\kappa+3\kappa^2}{\kappa}
-\frac{3+6\kappa+\kappa^2}{1+2\kappa}
=\frac{1+5\kappa+9\kappa^2+5\kappa^3}
{\kappa(1+2\kappa)}>0.
\tag{3}
\]

The coefficient sequence from \(H_2\) onward can therefore change sign from positive to negative at most once; it cannot have a negative-to-positive change. Adding \(H_0,H_1\) produces at most three sign changes. Descartes' rule gives at most three positive roots, counted with multiplicity. If \(H_0<0\), the bound improves to two.

For \(h=0\), \(H_4=H_5=0\) and \(H_3=-cs^2<0\), so the same bound follows directly from the cubic. Applying the same sign argument to

\[
H'(z)=H_1+2H_2z+3H_3z^2+4H_4z^3+5H_5z^4
\]

shows that it has at most two positive roots, counted with multiplicity. Consequently a positive repeated root of \(H\) can only be double or triple.

For logistic growth, take \(c=0,b=-r/K<0\). The actual polynomial degrees are two when \(h=0\) and three when \(h>0\). Its positive equilibrium is unique if \(s<K\), and absent if \(s\ge K\). This also follows directly because \(g(C(z))\) strictly decreases and \(mz/(1+z)\) strictly increases.

## 3. Necessary and sufficient critical-value sign classification

Let \(0<c_1<\cdots<c_k\), \(k\le2\), be the distinct positive roots of \(H'\). Define

\[
v_0=H(0),\qquad v_i=H(c_i),\qquad v_{k+1}=-\infty.
\]

On each interval between successive critical points, \(H\) is strictly monotone. There is one simple root in that open interval exactly when its two endpoint values have opposite signs. A zero critical value contributes one distinct repeated root. Therefore

\[
N_{\rm distinct}
=\sum_{i=0}^{k}\mathbf1_{\{v_iv_{i+1}<0\}}
+\sum_{i=1}^{k}\mathbf1_{\{v_i=0\}}.
\tag{4}
\]

In the last interval, the sign test means \(v_k>0\). A root at \(v_0=0\) is excluded. At a zero critical value, the multiplicity of the equilibrium root is one more than the multiplicity of that root of \(H'\).

Equation (4) is a complete necessary and sufficient parameter classification. It involves at most two critical values, rather than a numerical search for all equilibrium roots. When \(h=0\), the critical points are the positive values among

\[
c_\pm=\frac{-H_2\pm\sqrt{H_2^2-3H_3H_1}}{3H_3},
\]

when the discriminant is nonnegative. When \(h>0\), the critical polynomial is quartic, but has at most two positive roots; exact isolation and the signs \(H(c_i)\) give the same finite classification.

These are implicit algebraic sign regions. Expanding quartic radical expressions or a large discriminant case list adds no missing fixed-parameter information and is not claimed here.

### 3.1 Weak growth, and strong growth with \(A<s<K\)

For weak growth, \(s<K\) is necessary and sufficient for coexistence. Then \(H_0>0\). Strong growth has \(H_0>0\) exactly when \(A<s<K\). In either case:

- If there are two simple positive critical points \(c_1<c_2\), the first is a local minimum and the second a local maximum. Put \(u=H(c_1)\), \(v=H(c_2)\), with \(u<v\).
- There are **three distinct positive equilibria if and only if** \(u<0<v\).
- There are **two distinct positive equilibria if and only if** \(u=0\) or \(v=0\). One is double and the other simple.
- In all other cases there is exactly one distinct positive equilibrium.

The last case includes a triple root when a double critical point also has \(H=0\). It is one equilibrium with algebraic multiplicity three. If there are fewer than two distinct positive critical points, there is one distinct positive equilibrium.

For weak growth, useful simpler sufficient uniqueness conditions are \(\alpha K\le1\), or \(r\ge m\). The first makes \(g\) decreasing everywhere. In the second, any feasible point \(g<m\) lies on its descending limb when the weak curve initially increases.

### 3.2 Strong growth with \(s<A\)

Here \(H_0<0\), while \(H(z)\to-\infty\). Let

\[
M=\max\{H(0),H(c_1),\ldots,H(c_k)\}.
\]

Then \(M<0\) gives no positive equilibria; \(M=0\) gives one double positive equilibrium; and \(M>0\) gives two simple positive equilibria. No third physical root is possible in this region.

In particular, \(\lambda_K>0\) alone is not sufficient for strong-Allee coexistence. For example, \(r=.1,K=8,A=2,m=e=\beta=1,d=.1,h=0\) has \(s=.1<A\), positive predator invasion at \(K\), and no positive equilibrium. Its exact count is in the example file.

### 3.3 Strong boundary \(s=A\): exclude the axial root

At \(s=A\), \(H_0=0\). Set

\[
L=H_1=A g'_S(A)(1+\kappa)-m.
\]

The complete boundary rule is:

| Boundary condition | Positive equilibrium count |
|---|---|
| \(L>0\) | exactly one, simple |
| \(L<0\) | zero or two simple; one double at the positive maximum-zero condition |
| \(L=0,\ H_2>0\) | exactly one, simple |
| \(L=0,\ H_2\le0\) | none |

For \(L<0\), use the largest positive critical value of \(H\): positive gives two roots, zero gives one double root, negative or no positive critical point gives none. The zero value \(H(0)=0\) must not be used as an interior maximum.

When \(L=0\),

\[
H_2=A g'_S(A)(1+2\kappa)-cA^2(1+\kappa)^2.
\]

If \(H_2=0\), (3) gives \(H_3<0\), so \(z=0\) is a triple axial root and there are no positive roots. The exact solver removes that factor rather than counting three coexistence states.

The center-manifold coefficient at the axial state is related by

\[
B_A=\frac{em^2}{\beta^2g'_S(A)}
-\frac{emA}{\beta^2}-h
=-\frac{em}{\beta^2g'_S(A)}\,H_1.
\]

This relation checks compatibility with the separate Q4 boundary analysis; it is not used to replace the root-count proof.

### 3.4 No invasion at \(K\)

For every growth law, \(s\ge K\), equivalently \(\lambda_K\le0\), gives no positive equilibrium because \(C(z)>s\ge K\) for all \(z>0\), whereas a root requires \(g(C(z))>0\). At \(s=K\), the possible zero root belongs to \((K,0)\) and is excluded.

## 4. Exact algorithm and multiple-root certificates

The implementation first represents the stated decimal parameters as exact rational numbers and constructs (1) over \(\mathbb Q[z]\). It then:

1. Removes every \(z=0\) factor and records its multiplicity.
2. Uses square-free factorization. For each factor, forms its exact Sturm chain and evaluates sign variations at \(0^+\) and \(+\infty\).
3. Sums distinct-root counts across factors; their factor exponents give algebraic multiplicities.
4. Isolates every positive root in rational intervals and maps the intervals monotonically to \(x=C(z)\) and \(y=\beta z\).
5. Independently isolates the at most two positive critical points. Exact polynomial gcd identifies zero critical values. Otherwise rational interval arithmetic is refined until the sign of \(H(c_i)\) excludes zero.
6. Requires (4) to agree with the Sturm count.

No floating companion-matrix roots decide the count. Midpoint floating ODE residuals are additional diagnostics, not the certificate. The rational-input convention is explicit: the exact statements apply to the encoded decimal values, not to unknown physical parameter uncertainty. The analytical sign rules themselves hold for arbitrary admissible real parameters.

The code uses the documented exact polynomial, square-free, Sturm, and root-isolation operations in [SymPy 1.14](https://docs.sympy.org/latest/modules/polys/reference.html). Certificates store polynomial coefficients, factor multiplicities, Sturm signs/variations, critical-value sign enclosures, and positive-root isolating intervals.

## 5. Reachability of the sharp upper bound

For \(h=0\), write \(g=a+bx-cx^2\) and

\[
\widehat P=x(m-g)-\beta d/e.
\]

Set \(x_c=b/(3c)\), \(m_c=a+b^2/(3c)\), and \(\beta d/e=cx_c^3\). Then \(\widehat P=c(x-x_c)^3\). For a small rational \(\delta>0\), replace

\[
m=m_c-c\delta^2,\qquad
\beta d/e=cx_c^3-c\delta^2x_c.
\]

This gives exactly

\[
\widehat P=c(x-x_c)[(x-x_c)^2-\delta^2].
\]

Choosing all three roots in the physical interval produces three distinct positive equilibria. Strong growth requires \(A<x_c<K\), for example \(K>2A\); the concrete example below satisfies this.

All four examples in the next table have \(r=1/5,K=8,e=13/20,\beta=1\), with \(\alpha=4/5\) for weak growth and \(A=2\) for strong growth.

| Model | \(m\) | \(d\) | \(h\) | Three prey equilibrium coordinates |
|---|---|---|---|---|
| M0 | \(399/800\) | \(9009/64000\) | 0 | \(7/4,9/4,11/4\), exactly |
| M4 | \(399/800\) | \(9009/64000\) | \(1/10000\) | 1.808367, 2.122484, 2.819120 |
| M2 | \(41/192\) | \(5083/17280\) | 0 | \(17/6,10/3,23/6\), exactly |
| M5 | \(41/192\) | \(5083/17280\) | \(1/10000\) | 2.841945, 3.305702, 3.852352 |

The positive-h entries are certified by exact Sturm signs and rational isolating intervals, rather than asserted only by continuity. The same construction at \(\delta=0\) supplies positive triple roots in M0 and M2. Exact positive-h double roots and axial triple collisions are also tested.

## 6. Actual verification and comparison with the previous results

The actual run produced:

- **144/144** previous extended parameter/model sets with exactly matching equilibrium counts.
- Maximum absolute discrepancy from the previous numerical equilibrium coordinates: **\(9.74\times10^{-13}\)**.
- **29 exact rational examples**, covering zero, one, two, and three distinct equilibria; positive double/triple roots; positive-h folds; and axial double/triple collisions.
- **4 independent interaction-grid boundary points**.

The boundary audit confirms two equilibria at \(A/K=.34411764705882353\) for both \(h=0\) and \(h=.15\). At \(A/K=.3558823529411765\), there are zero equilibria for \(h=0\) but two for \(h=.15\). The interaction is undefined in the latter row because its no-competition comparison arm is absent; the mask does not mean that the positive-h arm lacks coexistence.

All four meaningful root-classification tests pass after correcting a test-only fraction-to-float conversion. The correction history is preserved.

Reproduce with .venv/bin/python run_root_classification.py and .venv/bin/python -m unittest tests.test_root_classification -v.

Files:

- src/root_classification.py
- run_root_classification.py
- results/root_classification_audit.csv
- results/root_classification_roots.csv
- results/root_classification_examples.csv
- results/root_classification_interaction_audit.csv
- results/root_classification_certificates.json
- logs/revision/ROOT_CLASSIFICATION.json
- logs/revision/root_classification_tests.txt

## 7. Six-model Q2 matrix text

| Model | Exact conclusion | Status |
|---|---|---|
| M0 | Axes \(0,K\). No coexistence if \(s\ge K\); otherwise 1 or 3 simple equilibria, 2 distinct at folds, or a triple degeneracy counted as one. Exact critical-value/Sturm rule is necessary and sufficient. | established_exact_algorithmic_count |
| M1 | Axes \(0,K\). Exactly one coexistence state iff \(s<K\), none otherwise. | established_exact_algorithmic_count |
| M2 | Axes \(0,A,K\). No coexistence if \(s\ge K\). If \(s<A\), 0/2 simple roots or 1 double root; if \(A<s<K\), the same 1/3/fold classification as M0; \(s=A\) follows the explicit boundary rule. | established_exact_algorithmic_count |
| M3 | Same existence/uniqueness as M1 for all \(h>0\). | established_exact_algorithmic_count |
| M4 | Same exact physical-count classification as M0 for all \(h>0\), despite a degree-five elimination polynomial. Three distinct roots are attained at strictly positive \(h\). | established_exact_algorithmic_count |
| M5 | Same exact physical-count and boundary classification as M2 for all \(h>0\). Three distinct roots are attained at strictly positive \(h\). | established_exact_algorithmic_count |

“Established” here refers to equilibrium existence, number, and uniqueness for fixed admissible parameters through exact sign conditions. It does not assert a complete global dynamical phase diagram or statistical identification from observed data.
