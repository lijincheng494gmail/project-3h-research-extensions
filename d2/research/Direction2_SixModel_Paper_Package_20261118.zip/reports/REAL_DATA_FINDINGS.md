# Observed-data findings

These results use independent held experiments C1–C4 under the same nominal external medium. Each primary fit uses all three non-test experiments. The full methods and source audit are in `REAL_DATA_METHODS.md`.

## Positive findings

All six structures improve mean one-step conditional prediction over persistence and the training mean, and each beats persistence in all four outer experiments. These predictions reset to the preceding observed state at every interval. The comparison supports short-step predictive usefulness of a fitted deterministic transition; it does not identify the true biological mechanism.

| model | macro_test_nrmse | macro_free_trajectory_nrmse | folds_better_than_persistence | mean_delta_AICc_within_fold |
|---|---|---|---|---|
| M0 | 0.885835 | 1.04204 | 4 | 39.2706 |
| M1 | 0.884862 | 1.03758 | 4 | 33.9134 |
| M2 | 0.89902 | 1.08019 | 4 | 104.048 |
| M3 | 0.882473 | 1.0582 | 4 | 0 |
| M4 | 0.885504 | 1.06213 | 4 | 7.63635 |
| M5 | 0.896572 | 1.09779 | 4 | 71.1985 |
| persistence | 1.04028 | 2.1521 | 0 | n/a |
| training_mean | 1.03703 | 1.03703 | 2 | n/a |
| training_drift | 1.04033 | 2.36066 | 1 | n/a |

## Unexpected or negative findings

The mean one-step differences among logistic and weak-Allee structures are small. The sign of the competition improvement varies among held experiments. Adding a structural mechanism does not provide a consistent held-experiment benefit. The training-mean baseline matches or beats the mean free-trajectory score of every six-model structure. Observed-state resetting accounts for an important part of the short-step performance.

The weak and strong Allee shape/threshold coordinates lie at or near their lower fitting bounds in every outer fit. This limits a biological interpretation of their fitted values. The bounds enforce the chosen structure; a numerical bound hit is not evidence that an Allee mechanism was independently detected.

Every fitted strong-Allee A is below both the training and held minimum observed prey density. The fitted A values range from about 0.00372 to 0.00467 in millions of cells/ml, versus observed minima 0.09–0.12. These observations do not directly sample a threshold crossing; see `real_parameter_identification.csv`.

Bound hits: 19 parameter/fold/model rows; see `real_benchmark_parameters.csv`.

## Scale-assumption sensitivity

Four prespecified changes in fixed e or beta were refitted on C1–C3 and scored on C4. These variants were not selected to replace the primary fit.

| model | min_test_nrmse | max_test_nrmse | all_fits_converged | max_sampled_DOP853_normalized_error | max_all_pair_halving_normalized_difference | DOP853_normalized_error_worst_halving |
|---|---|---|---|---|---|---|
| M0 | 0.822576 | 0.869377 | True | 1.87081e-10 | 3.83937e-08 | 4.07819e-08 |
| M1 | 0.823429 | 0.861168 | True | 5.74945e-11 | 3.99427e-10 | 4.25986e-10 |
| M2 | 0.841077 | 0.891664 | True | 4.83209e-09 | 2.20771e-05 | 2.32726e-05 |
| M3 | 0.819151 | 0.838913 | True | 3.22653e-11 | 2.40457e-10 | 2.5644e-10 |
| M4 | 0.819641 | 0.84596 | True | 5.12714e-11 | 1.71457e-08 | 1.8232e-08 |
| M5 | 0.839457 | 0.87663 | True | 4.65218e-10 | 2.69831e-06 | 2.84847e-06 |

## Profiles and numerical checks

| model | parameter | profile_points | min_value | max_value | min_relative_sse_change | max_relative_sse_change | all_nuisance_fits_converged |
|---|---|---|---|---|---|---|---|
| M0 | K | 5 | 0.490527 | 1.96211 | 0 | 0.130758 | True |
| M0 | r | 5 | 1.13239 | 4 | 0 | 0.0210513 | True |
| M1 | K | 5 | 0.568647 | 2.27459 | 0 | 0.123106 | True |
| M1 | r | 4 | 1.35232 | 4 | 0 | 0.0510807 | True |
| M2 | fA | 4 | 0.005 | 0.01 | 0 | 0.00115645 | True |
| M2 | r | 5 | 0.0213666 | 0.0854666 | 0 | 0.0234887 | True |
| M3 | h | 5 | 0.0506728 | 0.202691 | 0 | 0.00649487 | True |
| M3 | r | 5 | 1.17886 | 4 | 0 | 0.0494083 | True |
| M4 | h | 5 | 0.0499982 | 0.199993 | 0 | 0.00629596 | True |
| M4 | r | 5 | 0.948376 | 3.7935 | 0 | 0.0365554 | True |
| M5 | h | 5 | 0.0561046 | 0.224418 | 0 | 0.00825312 | True |
| M5 | r | 5 | 0.0152654 | 0.0610618 | 0 | 0.0219888 | True |

Profiles are finite-budget nuisance-reoptimized objective scans, not confidence intervals. A flat scan or ill-conditioned residual Jacobian limits parameter interpretation.

Final solver audit: {"state": "pass", "acceptance": 0.0001, "sampled_DOP853_audits": 296, "full_pair_halving_groups": 48, "pair_evaluations_per_step": 20664, "worst_DOP853_normalized_error": 1.6098435867773447e-05, "worst_all_pair_halving_normalized_difference": 1.527152927610284e-05, "main_step": 0.00625, "half_step": 0.003125}.

Primary and nested fits, numerical convergence, profiles, sensitivity, and bound-hit counts are recorded in `logs/REAL_FINAL_SUMMARY.json`. Only four experimental replicates are available. Serially dependent one-step pairs do not establish a four-fold prediction ranking as a population-level statistical conclusion.
