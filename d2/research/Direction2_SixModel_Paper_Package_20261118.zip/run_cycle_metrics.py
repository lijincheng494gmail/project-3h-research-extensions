"""Retrospective cycle diagnostics for frozen, experiment-held-out predictions.

No model is refitted. All models/baselines are evaluated on the same cached
held target times. Frequency/phase outputs are descriptive diagnostics, with
explicit amplitude/coherence guards; a finite-record harmonic is not a limit
cycle proof or a calibrated significance test.
"""
from __future__ import annotations
from pathlib import Path
import argparse, hashlib, json, platform, time
import numpy as np
import pandas as pd
from scipy.signal import find_peaks

ROOT=Path(__file__).resolve().parent
MODELS=['M0','M1','M2','M3','M4','M5']
BASELINES=['persistence','training_mean','training_drift']
DEFS={'M0':('Weak Allee',False),'M1':('Logistic',False),'M2':('Strong Allee',False),
      'M3':('Logistic',True),'M4':('Weak Allee',True),'M5':('Strong Allee',True)}
PROTOCOL={
 'analysis':'retrospective diagnostics of existing held-experiment prediction caches; no new fitting',
 'amplitude':'95th minus 5th sample percentile on the common target times',
 'late_window':'last half of elapsed target-time span, including its midpoint',
 'amplitude_floor_training_sd_fraction':.05,
 'peak_prominence_observed_A90_fraction':.25,
 'peak_min_separation_median_cadences':2.,
 'peak_period_min_peaks':4,
 'harmonic_period_min_median_cadences':4.,
 'harmonic_min_record_cycles':4.,
 'harmonic_grid_frequencies':2048,
 'harmonic_min_detrended_variance_fraction':.10,
 'phase_max_relative_period_difference':.10,
 'phase':'projection at observed selected frequency; positive lag = prediction later',
 'threshold_sensitivity_amplitude_floor_fractions':[.02,.05,.10],
 'threshold_sensitivity_harmonic_fractions':[.05,.10,.20],
 'forecast_modes':{'conditional':'reset from preceding observed state at every interval',
                   'free':'initialize only at first held observed state'},
 'no_interpolation':True,
 'independence':'four held experiments; serial samples and overlapping training folds are not independent replications'
}


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def amplitude(z):
 z=np.asarray(z,float)
 return float(np.quantile(z,.95)-np.quantile(z,.05))


def separated_peaks(t,z,prominence,min_separation):
 """Prominence filtering, then greedy separation in days rather than samples."""
 indices,props=find_peaks(z,prominence=prominence)
 keep=[]
 for j in np.argsort(-props['prominences'],kind='stable'):
  i=int(indices[j])
  if all(abs(t[i]-t[k])>=min_separation for k in keep):keep.append(i)
 return np.asarray(sorted(keep),int)


class HarmonicScan:
 """Least-squares harmonic improvement over a fitted intercept + linear trend.

 Columns sin(wt), cos(wt) are residualized against [1,t]. The explained
 residual sum of squares is a'sy+b'cy, giving a two-coefficient conditional
 R^2. No distributional null or p-value is assumed.
 """
 def __init__(self,t):
  self.t=np.asarray(t,float)-float(t[0]);self.duration=float(self.t[-1]);self.cadence=float(np.median(np.diff(self.t)))
  self.late=self.t>=self.duration/2
  self.base=np.column_stack([np.ones(len(t)),(self.t-self.t.mean())/max(self.duration,1.)])
  self.pinv=np.linalg.pinv(self.base)
  self.min_period=PROTOCOL['harmonic_period_min_median_cadences']*self.cadence
  self.max_period=self.duration/PROTOCOL['harmonic_min_record_cycles']
  self.valid=self.max_period>self.min_period and len(t)>=24
  if not self.valid:return
  self.freq=np.linspace(1/self.max_period,1/self.min_period,PROTOCOL['harmonic_grid_frequencies'])
  w=2*np.pi*self.t[:,None]*self.freq[None,:]
  self.s=np.sin(w);self.c=np.cos(w)
  self.s-=self.base@(self.pinv@self.s);self.c-=self.base@(self.pinv@self.c)
  self.ss=np.sum(self.s*self.s,axis=0);self.cc=np.sum(self.c*self.c,axis=0);self.sc=np.sum(self.s*self.c,axis=0)
  self.det=self.ss*self.cc-self.sc*self.sc
 def fit(self,z):
  if not self.valid:return dict(index=None,period=np.nan,r2=np.nan,phase=np.nan,boundary=False)
  residual=np.asarray(z)-self.base@(self.pinv@np.asarray(z));sse=float(residual@residual)
  if sse<=1e-24*max(1.,float(np.sum(np.asarray(z)**2))):
   return dict(index=None,period=np.nan,r2=0.,phase=np.nan,boundary=False)
  sy=self.s.T@residual;cy=self.c.T@residual
  a=(sy*self.cc-cy*self.sc)/self.det;b=(cy*self.ss-sy*self.sc)/self.det
  r2=np.clip((a*sy+b*cy)/sse,0.,1.)
  i=int(np.argmax(r2))
  return dict(index=i,period=float(1/self.freq[i]),r2=float(r2[i]),phase=float(np.arctan2(b[i],a[i])),boundary=i in [0,len(self.freq)-1])
 def at(self,z,i):
  if i is None:return np.nan,np.nan
  residual=np.asarray(z)-self.base@(self.pinv@np.asarray(z));sse=float(residual@residual)
  if sse<=1e-24*max(1.,float(np.sum(np.asarray(z)**2))):return 0.,np.nan
  sy=float(self.s[:,i]@residual);cy=float(self.c[:,i]@residual)
  a=(sy*self.cc[i]-cy*self.sc[i])/self.det[i];b=(cy*self.ss[i]-sy*self.sc[i])/self.det[i]
  return float(np.clip((a*sy+b*cy)/sse,0,1)),float(np.arctan2(b,a))


def summarize_series(t,z,scale,reference_amplitude,scan):
 z=np.asarray(z,float);A=amplitude(z);lateA=amplitude(z[scan.late]);floor=PROTOCOL['amplitude_floor_training_sd_fraction']*scale
 prominence=PROTOCOL['peak_prominence_observed_A90_fraction']*reference_amplitude
 peaks=separated_peaks(np.asarray(t),z,prominence,PROTOCOL['peak_min_separation_median_cadences']*scan.cadence)
 gaps=np.diff(np.asarray(t)[peaks]);fit=scan.fit(z)
 if not scan.valid:status='record_too_short_for_defined_frequency_band'
 elif lateA<floor:status='insufficient_late_amplitude'
 elif len(peaks)<PROTOCOL['peak_period_min_peaks']:status='fewer_than_four_prominent_peaks'
 elif fit['index'] is None:status='no_detrended_variation'
 elif fit['boundary']:status='spectral_maximum_on_search_boundary'
 elif fit['r2']<PROTOCOL['harmonic_min_detrended_variance_fraction']:status='weak_single_harmonic_projection'
 else:status='descriptive_period_estimable'
 period=fit['period'] if status=='descriptive_period_estimable' else np.nan
 return dict(amplitude_A90=A,late_amplitude_A90=lateA,temporal_sd=float(np.std(z)),late_temporal_sd=float(np.std(z[scan.late])),
  amplitude_floor=floor,late_amplitude_above_floor=bool(lateA>=floor),peak_prominence=prominence,prominent_peak_count=len(peaks),
  peak_times_days=json.dumps(np.asarray(t)[peaks].tolist()),
  median_interpeak_days=float(np.median(gaps)) if len(peaks)>=4 else np.nan,
  interpeak_IQR_days=float(np.quantile(gaps,.75)-np.quantile(gaps,.25)) if len(peaks)>=4 else np.nan,
  peak_interval_status='descriptive_interpeak_interval' if len(peaks)>=4 else 'fewer_than_four_prominent_peaks',
  dominant_period_candidate_days=fit['period'],harmonic_variance_fraction=fit['r2'],
  harmonic_peak_on_boundary=fit['boundary'],dominant_period_days=period,period_status=status,
  search_min_period_days=scan.min_period,search_max_period_days=scan.max_period,
  _fit=fit)


def phase_diagnostic(z,reference,diag,refdiag,scan):
 if not np.isfinite(refdiag['dominant_period_days']):return np.nan,np.nan,'observed_period_not_estimable',np.nan
 if not np.isfinite(diag['dominant_period_days']):return np.nan,np.nan,'predicted_period_not_estimable',np.nan
 relative=abs(diag['dominant_period_days']/refdiag['dominant_period_days']-1.)
 if relative>PROTOCOL['phase_max_relative_period_difference']:return np.nan,np.nan,'periods_differ_by_more_than_10_percent',np.nan
 r2,phi=scan.at(z,refdiag['_fit']['index']);_,refphi=scan.at(reference,refdiag['_fit']['index'])
 if r2<PROTOCOL['harmonic_min_detrended_variance_fraction']:return np.nan,np.nan,'weak_projection_at_observed_frequency',r2
 difference=float(np.arctan2(np.sin(phi-refphi),np.cos(phi-refphi)))
 lag=-difference*refdiag['dominant_period_days']/(2*np.pi)
 return lag,abs(lag),'descriptive_phase_comparable',r2


def row_public(row):return {k:v for k,v in row.items() if not k.startswith('_')}


def paired_table(scores,metrics):
 """Three comparison dimensions for the 3 x 2 design, after refitting each model."""
 comparisons=[
  ('competition','Logistic: M3 - M1',{'M3':1,'M1':-1}),
  ('competition','Weak: M4 - M0',{'M4':1,'M0':-1}),
  ('competition','Strong: M5 - M2',{'M5':1,'M2':-1}),
  ('Allee_no_h','Weak - Logistic: M0 - M1',{'M0':1,'M1':-1}),
  ('Allee_no_h','Strong - Logistic: M2 - M1',{'M2':1,'M1':-1}),
  ('Allee_no_h','Strong - Weak: M2 - M0',{'M2':1,'M0':-1}),
  ('Allee_with_h','Weak - Logistic: M4 - M3',{'M4':1,'M3':-1}),
  ('Allee_with_h','Strong - Logistic: M5 - M3',{'M5':1,'M3':-1}),
  ('Allee_with_h','Strong - Weak: M5 - M4',{'M5':1,'M4':-1}),
  ('interaction','Weak: (M4-M0)-(M3-M1)',{'M4':1,'M0':-1,'M3':-1,'M1':1}),
  ('interaction','Strong: (M5-M2)-(M3-M1)',{'M5':1,'M2':-1,'M3':-1,'M1':1})]
 rows=[]
 for held in ['C1','C2','C3','C4']:
  g=scores[scores.held==held].set_index('model')
  endpoints={('conditional','both','NRMSE'):g.test_nrmse.to_dict(),('free','both','NRMSE'):g.free_trajectory_nrmse.to_dict(),
             ('training','both','conditional_AICc'):g.conditional_AICc.to_dict()}
  for mode in ['conditional','free']:
   for population in ['prey','predator']:
    p=metrics[(metrics.held==held)&(metrics.forecast_mode==mode)&(metrics.population==population)].set_index('model')
    for endpoint in ['amplitude_A90_relative_absolute_error','late_amplitude_A90_relative_absolute_error',
                     'peak_count_absolute_error','dominant_period_relative_absolute_error','absolute_phase_lag_days']:
     endpoints[(mode,population,endpoint)]=p[endpoint].to_dict()
  for (mode,population,endpoint),values in endpoints.items():
   for kind,label,weights in comparisons:
    valid=all(np.isfinite(values.get(m,np.nan)) for m in weights)
    value=sum(w*values[m] for m,w in weights.items()) if valid else np.nan
    missing=';'.join(m for m in weights if not np.isfinite(values.get(m,np.nan)))
    rows.append(dict(held=held,comparison_class=kind,comparison=label,forecast_mode=mode,population=population,endpoint=endpoint,
                     value=value,estimable=valid,missing_model_metric=missing,formula=json.dumps(weights,sort_keys=True),
                     interpretation='predictive comparison after separate equal-budget refits; not a matched-parameter ecological interaction'))
 return pd.DataFrame(rows)


def plot_results(root,metrics,complexity,comparisons,predictions):
 import matplotlib
 matplotlib.use('Agg')
 import matplotlib.pyplot as plt
 from matplotlib.lines import Line2D
 plt.rcParams.update({'font.size':12,'axes.labelsize':12,'axes.titlesize':12,'xtick.labelsize':11,'ytick.labelsize':11,'pdf.fonttype':42})
 colors={m:('#2E756D' if DEFS[m][1] else '#1F1E33') for m in MODELS}
 markers=['o','s','^','D'];x=np.arange(6)
 def save(fig,name):
  fig.savefig(root/'figures'/f'{name}.png',dpi=220,bbox_inches='tight');fig.savefig(root/'figures'/f'{name}.pdf',bbox_inches='tight');plt.close(fig)
 # Single-column, full-width manuscript figure. Four marks are experiments, not error bars.
 fig,axes=plt.subplots(3,1,figsize=(7.6,9.4),constrained_layout=True)
 scores=pd.read_csv(root/'results/real_benchmark_scores.csv')
 for ax,col,title in [(axes[0],'test_nrmse','(a) One-step prediction with observed-state resetting'),
                      (axes[1],'free_trajectory_nrmse','(b) Free trajectories from the first held observation')]:
  for j,m in enumerate(MODELS):
   q=scores[scores.model==m]
   for k,held in enumerate(['C1','C2','C3','C4']):
    value=float(q[q.held==held][col].iloc[0]);ax.scatter(j+(k-1.5)*.055,value,color=colors[m],marker=markers[k],s=30,zorder=3)
   ax.hlines(q[col].mean(),j-.25,j+.25,color=colors[m],linewidth=3)
  for base,label,ls in [('persistence','Persistence','--'),('training_mean','Training mean',':')]:
   ax.axhline(scores[scores.model==base][col].mean(),color='#AAA2AC',linestyle=ls,linewidth=1.3,label=label)
  ax.set_xticks(x,MODELS);ax.set_ylabel('Normalized RMSE');ax.set_title(title,loc='left');ax.legend(fontsize=9,loc='center right',bbox_to_anchor=(1.,.65))
 ax=axes[2]
 for j,m in enumerate(MODELS):
  q=scores[scores.model.isin(MODELS)].copy();q['delta']=q.conditional_AICc-q.groupby('held').conditional_AICc.transform('min');v=q[q.model==m]
  for k,held in enumerate(['C1','C2','C3','C4']):ax.scatter(j+(k-1.5)*.055,v[v.held==held].delta.iloc[0],color=colors[m],marker=markers[k],s=30)
  ax.hlines(v.delta.mean(),j-.25,j+.25,color=colors[m],linewidth=3)
 ax.set_xticks(x,[f'{m}\nk={int(complexity[complexity.model==m].dynamic_parameters.iloc[0])}' for m in MODELS]);ax.set_ylabel('Conditional AICc difference');ax.set_title('(c) Training fit with a parameter penalty',loc='left')
 fig.suptitle('Six models on the same four held experiments',fontsize=14)
 fig.legend(handles=[Line2D([0],[0],marker=markers[k],color='none',markerfacecolor='#1F1E33',markeredgecolor='#1F1E33',label=h) for k,h in enumerate(['C1','C2','C3','C4'])],loc='lower center',ncol=4,bbox_to_anchor=(.5,-.05),fontsize=10)
 save(fig,'paper_real_prediction_complexity')
 # Main-paper composite: the score comparison and the cycle-amplitude result.
 fig,axes=plt.subplots(2,2,figsize=(7.9,7.2),constrained_layout=True)
 for ax,col,title,base,label in [(axes[0,0],'test_nrmse','(a) One-step prediction','persistence','Persistence mean'),
                                 (axes[0,1],'free_trajectory_nrmse','(b) Free-running prediction','training_mean','Training-mean baseline')]:
  for j,m in enumerate(MODELS):
   q=scores[scores.model==m]
   for k,held in enumerate(['C1','C2','C3','C4']):ax.scatter(j+(k-1.5)*.065,q[q.held==held][col].iloc[0],marker=markers[k],s=29,color=colors[m])
   ax.hlines(q[col].mean(),j-.27,j+.27,color=colors[m],linewidth=2.7)
  ax.axhline(scores[scores.model==base][col].mean(),color='#AAA2AC',linestyle='--',linewidth=1.2,label=label)
  ax.set_xticks(x,MODELS);ax.set_ylabel('Normalized RMSE');ax.set_title(title,loc='left',fontsize=12);ax.legend(fontsize=8,loc='center right',bbox_to_anchor=(1.,.57))
 for ax,pop,title in [(axes[1,0],'prey','(c) Late prey amplitude'),(axes[1,1],'predator','(d) Late predator amplitude')]:
  for j,m in enumerate(MODELS):
   for mode,offset in [('conditional',-.12),('free',.12)]:
    q=metrics[(metrics.model==m)&(metrics.population==pop)&(metrics.forecast_mode==mode)]
    for k,held in enumerate(['C1','C2','C3','C4']):
     value=q[q.held==held].late_amplitude_ratio.iloc[0]
     ax.scatter(j+offset+(k-1.5)*.03,value,marker=markers[k],s=26,facecolors=(colors[m] if mode=='conditional' else 'none'),edgecolors=colors[m],linewidth=.9)
    ax.hlines(q.late_amplitude_ratio.mean(),j+offset-.12,j+offset+.12,color=colors[m],linewidth=2.5)
  ax.axhline(1,color='#AAA2AC',linestyle='--',linewidth=1.1)
  ax.set_ylim(-.065,1.12);ax.set_xticks(x,MODELS);ax.set_ylabel('Amplitude / observed');ax.set_title(title,loc='left',fontsize=12)
 fig.legend(handles=[Line2D([0],[0],marker='o',color='none',markerfacecolor='#1F1E33',markeredgecolor='#1F1E33',label='One-step (filled)'),
                     Line2D([0],[0],marker='o',color='none',markerfacecolor='none',markeredgecolor='#1F1E33',label='Free (open)')],
            loc='lower center',ncol=2,bbox_to_anchor=(.5,-.07),fontsize=10)
 save(fig,'paper_real_comparison')

 # Pairwise contrasts: data points show all folds and thick ticks show their means.
 groups=[['Allee_no_h','Allee_with_h'],['competition'],['interaction']]
 titles=['Allee growth contrasts','Competition contrasts','Predictive interaction contrasts']
 fig,axes=plt.subplots(1,3,figsize=(12.6,5.0),constrained_layout=True)
 data=comparisons[(comparisons.endpoint=='NRMSE')&(comparisons.forecast_mode=='conditional')]
 selected_labels=[['Weak - Logistic: M0 - M1','Strong - Logistic: M2 - M1','Weak - Logistic: M4 - M3','Strong - Logistic: M5 - M3'],
                  ['Logistic: M3 - M1','Weak: M4 - M0','Strong: M5 - M2'],
                  ['Weak: (M4-M0)-(M3-M1)','Strong: (M5-M2)-(M3-M1)']]
 for ax,kinds,title,labels in zip(axes,groups,titles,selected_labels):
  q=data[data.comparison_class.isin(kinds)]
  for j,label in enumerate(labels):
   g=q[q.comparison==label]
   for k,held in enumerate(['C1','C2','C3','C4']):ax.scatter(g[g.held==held].value.iloc[0],j+(k-1.5)*.07,marker=markers[k],s=38,color='#1F1E33')
   ax.vlines(g.value.mean(),j-.27,j+.27,color='#2E756D',linewidth=3)
  ax.axvline(0,color='#ABA8BA',linewidth=1);ax.set_yticks(range(len(labels)),[z.replace(': ','\n') for z in labels],fontsize=10)
  ax.invert_yaxis();ax.set_title(title)
  explanation=('Negative favors the Allee alternative' if kinds[0]=='Allee_no_h' else ('Negative favors competition' if kinds[0]=='competition' else 'Negative: competition helps more under Allee'))
  ax.set_xlabel('Change in held one-step NRMSE\n'+explanation)
 fig.suptitle('Four held experiments; each model is independently refitted',fontsize=14)
 fig.legend(handles=[Line2D([0],[0],marker=markers[k],color='none',markerfacecolor='#1F1E33',markeredgecolor='#1F1E33',label=h) for k,h in enumerate(['C1','C2','C3','C4'])]+[Line2D([0],[0],color='#2E756D',linewidth=3,label='Four-experiment mean')],loc='lower center',ncol=5,bbox_to_anchor=(.5,-.07),fontsize=10)
 save(fig,'paper_real_factorial_comparison')
 # Amplitude comparison, including persistence to expose the effect of resetting.
 order=MODELS+['persistence','training_mean'];labels=MODELS+['P','Mean']
 fig,axes=plt.subplots(2,2,figsize=(9.5,7.1),constrained_layout=True)
 for row,pop in enumerate(['prey','predator']):
  for col,mode in enumerate(['conditional','free']):
   ax=axes[row,col]
   for j,m in enumerate(order):
    q=metrics[(metrics.model==m)&(metrics.population==pop)&(metrics.forecast_mode==mode)]
    color=colors.get(m,'#AAA2AC')
    for k,held in enumerate(['C1','C2','C3','C4']):ax.scatter(j+(k-1.5)*.055,q[q.held==held].late_amplitude_ratio.iloc[0],color=color,marker=markers[k],s=30)
    ax.hlines(q.late_amplitude_ratio.mean(),j-.24,j+.24,color=color,linewidth=2.8)
   ax.axhline(1,color='#AAA2AC',linestyle='--',linewidth=1);ax.set_xticks(range(len(order)),labels)
   ax.set_ylim(-.06,max(1.15,float(metrics[(metrics.population==pop)&(metrics.forecast_mode==mode)].late_amplitude_ratio.max())*1.08))
   ax.set_ylabel(f'{pop.capitalize()} amplitude / observed');ax.set_title('One-step resetting' if mode=='conditional' else 'Free trajectory')
 fig.suptitle('Late-window central-90% amplitude; P = persistence, Mean = training mean',fontsize=13)
 save(fig,'paper_real_cycle_amplitudes')
 # All six free forecasts on one prespecified experiment, not a selected best model.
 fig,axes=plt.subplots(2,1,figsize=(7.6,6.0),sharex=True,constrained_layout=True)
 palette={'M0':'#1F1E33','M1':'#6D6988','M2':'#ABA8BA','M3':'#2E756D','M4':'#5C9B91','M5':'#B47843'}
 for ax,pop,unit in [(axes[0],'x','Algae (10^6 cells/ml)'),(axes[1],'y','Rotifers (20 animals/ml)')]:
  obs=predictions[(predictions.held=='C4')&(predictions.model=='M0')]
  ax.scatter(obs.time_to,obs['observed_'+pop],s=11,color='#1F1E33',label='Observed',alpha=.7)
  for m in MODELS:
   g=predictions[(predictions.held=='C4')&(predictions.model==m)]
   ax.plot(g.time_to,g['free_predicted_'+pop],label=m,color=palette[m],linewidth=1.3)
  ax.set_ylabel(unit)
 axes[0].legend(ncol=4,fontsize=9);axes[-1].set_xlabel('Time (days)');fig.suptitle('C4: all six free forecasts after fitting C1-C3',fontsize=13)
 save(fig,'paper_real_all_models_C4')


def run(root=ROOT,figures_only=False):
 root=Path(root)
 for d in ['results','figures','reports/revision','logs/revision','configs']:(root/d).mkdir(parents=True,exist_ok=True)
 if figures_only:
  plot_results(root,pd.read_csv(root/'results/real_cycle_metrics.csv'),pd.read_csv(root/'results/real_cycle_complexity.csv'),
               pd.read_csv(root/'results/real_growth_competition_comparisons.csv'),pd.read_csv(root/'results/real_predictions.csv'));return
 start=time.time()
 inputs=['results/real_predictions.csv','results/real_benchmark_scores.csv','results/real_benchmark_parameters.csv','results/real_folds.csv',
         'logs/REAL_SOURCE_DOWNLOADS.json']+[f'data/real/C{i}.csv' for i in range(1,5)]
 hashes={f:sha(root/f) for f in inputs}
 (root/'configs/REAL_CYCLE_PROTOCOL.json').write_text(json.dumps(PROTOCOL,indent=2))
 predictions=pd.read_csv(root/'results/real_predictions.csv');scores=pd.read_csv(root/'results/real_benchmark_scores.csv')
 folds=pd.read_csv(root/'results/real_folds.csv').set_index('held')
 frames={f'C{i}':pd.read_csv(root/f'data/real/C{i}.csv') for i in range(1,5)}
 observed_rows=[];observed_threshold_rows=[];rows=[];threshold_rows=[];baseline_checks=[]
 for held in frames:
  canonical=predictions[(predictions.held==held)&(predictions.model=='M0')].sort_values('time_to')
  t=canonical.time_to.to_numpy();observed=canonical[['observed_x','observed_y']].to_numpy();scan=HarmonicScan(t)
  scale=folds.loc[held,['train_scale_x','train_scale_y']].to_numpy(float)
  raw=frames[held];initial=raw.iloc[0,1:3].to_numpy(float)
  for m in MODELS:
   g=predictions[(predictions.held==held)&(predictions.model==m)].sort_values('time_to')
   np.testing.assert_array_equal(g.time_to,t);np.testing.assert_allclose(g[['observed_x','observed_y']],observed,rtol=0,atol=0)
  pairs=[]
  for c,d in frames.items():
   if c==held:continue
   z=d.iloc[:,1:3].to_numpy();pairs.append((z[:-1],np.diff(d.time_days),z[1:]))
  X=np.concatenate([a[0] for a in pairs]);DT=np.concatenate([a[1] for a in pairs]);Y=np.concatenate([a[2] for a in pairs]);mean=Y.mean(0);drift=np.mean((Y-X)/DT[:,None],axis=0)
  previous=canonical[['conditioned_x','conditioned_y']].to_numpy();gaps=canonical.gap_days.to_numpy()
  forecasts={}
  for m in MODELS:
   g=predictions[(predictions.held==held)&(predictions.model==m)].sort_values('time_to')
   forecasts[(m,'conditional')]=g[['predicted_x','predicted_y']].to_numpy();forecasts[(m,'free')]=g[['free_predicted_x','free_predicted_y']].to_numpy()
  forecasts.update({('persistence','conditional'):previous,('persistence','free'):np.repeat(initial[None,:],len(t),axis=0),
   ('training_mean','conditional'):np.repeat(mean[None,:],len(t),axis=0),('training_mean','free'):np.repeat(mean[None,:],len(t),axis=0),
   ('training_drift','conditional'):np.maximum(previous+gaps[:,None]*drift,0),
   ('training_drift','free'):np.maximum(initial+(t-float(raw.time_days.iloc[0]))[:,None]*drift,0)})
  for (m,mode),pred in forecasts.items():
   nrmse=float(np.mean(np.sqrt(np.mean((pred-observed)**2,axis=0))/scale));expected=float(scores[(scores.held==held)&(scores.model==m)][('test_nrmse' if mode=='conditional' else 'free_trajectory_nrmse')].iloc[0])
   error=abs(nrmse-expected);assert error<1e-10
   baseline_checks.append(dict(held=held,model=m,forecast_mode=mode,recomputed_nrmse=nrmse,cached_nrmse=expected,absolute_difference=error))
  for j,population in enumerate(['prey','predator']):
   reference=observed[:,j];obsA=amplitude(reference);obsdiag=summarize_series(t,reference,scale[j],obsA,scan)
   observed_rows.append(dict(held=held,population=population,n_targets=len(t),duration_days=scan.duration,median_cadence_days=scan.cadence,
                             training_sd=scale[j],units='10^6 cells/ml' if j==0 else '20 animals/ml',**row_public(obsdiag)))
   for floor_fraction in PROTOCOL['threshold_sensitivity_amplitude_floor_fractions']:
    for r2_threshold in PROTOCOL['threshold_sensitivity_harmonic_fractions']:
     eligible=bool(scan.valid and obsdiag['late_amplitude_A90']>=floor_fraction*scale[j] and obsdiag['prominent_peak_count']>=4 and not obsdiag['_fit']['boundary'] and np.isfinite(obsdiag['harmonic_variance_fraction']) and obsdiag['harmonic_variance_fraction']>=r2_threshold)
     observed_threshold_rows.append(dict(held=held,population=population,amplitude_floor_training_sd_fraction=floor_fraction,
       harmonic_fraction_threshold=r2_threshold,descriptive_period_estimable=eligible))
   for (m,mode),pred in forecasts.items():
    z=pred[:,j];diag=summarize_series(t,z,scale[j],obsA,scan)
    phase,absphase,phasestatus,phase_r2=phase_diagnostic(z,reference,diag,obsdiag,scan)
    period_error=abs(diag['dominant_period_days']/obsdiag['dominant_period_days']-1.) if np.isfinite(diag['dominant_period_days']) and np.isfinite(obsdiag['dominant_period_days']) else np.nan
    rows.append(dict(held=held,model=m,forecast_mode=mode,population=population,n_targets=len(t),
     growth=DEFS[m][0] if m in DEFS else 'baseline',competition=DEFS[m][1] if m in DEFS else False,
     observed_amplitude_A90=obsA,observed_late_amplitude_A90=obsdiag['late_amplitude_A90'],
     amplitude_ratio=diag['amplitude_A90']/obsA,late_amplitude_ratio=diag['late_amplitude_A90']/obsdiag['late_amplitude_A90'],
     amplitude_A90_relative_absolute_error=abs(diag['amplitude_A90']/obsA-1.),
     late_amplitude_A90_relative_absolute_error=abs(diag['late_amplitude_A90']/obsdiag['late_amplitude_A90']-1.),
     observed_prominent_peak_count=obsdiag['prominent_peak_count'],peak_count_absolute_error=abs(diag['prominent_peak_count']-obsdiag['prominent_peak_count']),
     observed_dominant_period_days=obsdiag['dominant_period_days'],observed_period_status=obsdiag['period_status'],
     dominant_period_relative_absolute_error=period_error,phase_lag_days=phase,absolute_phase_lag_days=absphase,
     phase_status=phasestatus,harmonic_fraction_at_observed_frequency=phase_r2,**row_public(diag)))
    for floor_fraction in PROTOCOL['threshold_sensitivity_amplitude_floor_fractions']:
     for r2_threshold in PROTOCOL['threshold_sensitivity_harmonic_fractions']:
      eligible=bool(scan.valid and diag['late_amplitude_A90']>=floor_fraction*scale[j] and diag['prominent_peak_count']>=4 and not diag['_fit']['boundary'] and np.isfinite(diag['harmonic_variance_fraction']) and diag['harmonic_variance_fraction']>=r2_threshold)
      threshold_rows.append(dict(held=held,model=m,forecast_mode=mode,population=population,amplitude_floor_training_sd_fraction=floor_fraction,
                               harmonic_fraction_threshold=r2_threshold,late_amplitude_above_floor=diag['late_amplitude_A90']>=floor_fraction*scale[j],descriptive_period_estimable=eligible))
 observed_df=pd.DataFrame(observed_rows);metric_df=pd.DataFrame(rows);checks=pd.DataFrame(baseline_checks)
 observed_df.to_csv(root/'results/real_cycle_observed.csv',index=False)
 pd.DataFrame(observed_threshold_rows).to_csv(root/'results/real_cycle_observed_threshold_sensitivity.csv',index=False)
 metric_df.to_csv(root/'results/real_cycle_metrics.csv',index=False)
 pd.DataFrame(threshold_rows).to_csv(root/'results/real_cycle_threshold_sensitivity.csv',index=False);checks.to_csv(root/'results/real_cycle_cache_checks.csv',index=False)
 summary=metric_df.groupby(['model','forecast_mode','population'],sort=False).agg(held_experiments=('held','size'),mean_amplitude_ratio=('amplitude_ratio','mean'),
  mean_late_amplitude_ratio=('late_amplitude_ratio','mean'),max_late_amplitude_ratio=('late_amplitude_ratio','max'),
  mean_peak_count_absolute_error=('peak_count_absolute_error','mean'),predicted_periods_estimable=('dominant_period_days','count'),
  period_pairs_comparable=('dominant_period_relative_absolute_error','count'),mean_relative_period_error=('dominant_period_relative_absolute_error','mean'),
  phase_pairs_comparable=('absolute_phase_lag_days','count'),mean_absolute_phase_lag_days=('absolute_phase_lag_days','mean')).reset_index()
 summary.to_csv(root/'results/real_cycle_summary.csv',index=False)
 comparisons=paired_table(scores,metric_df);comparisons.to_csv(root/'results/real_growth_competition_comparisons.csv',index=False)
 comp_summary=comparisons.groupby(['comparison_class','comparison','forecast_mode','population','endpoint'],sort=False).agg(estimable_folds=('value','count'),
   mean_contrast=('value','mean'),minimum_contrast=('value','min'),maximum_contrast=('value','max'),negative_folds=('value',lambda x:int((x<0).sum()))).reset_index()
 comp_summary.to_csv(root/'results/real_growth_competition_comparison_summary.csv',index=False)
 scores=scores.copy();scores['delta_AICc']=scores.conditional_AICc-scores.groupby('held').conditional_AICc.transform('min')
 parameter_data=pd.read_csv(root/'results/real_benchmark_parameters.csv');complexity=[]
 for m in MODELS+BASELINES:
  g=scores[scores.model==m]
  complexity.append(dict(model=m,growth=DEFS[m][0] if m in DEFS else 'baseline',competition=DEFS[m][1] if m in DEFS else False,
   dynamic_parameters=int(g.k_dynamic.iloc[0]) if m in MODELS else 0,
   data_summary_parameters=0 if m in MODELS or m=='persistence' else 2,
   parameters_including_residual_variance=int(g.k_including_variance.iloc[0]) if m in MODELS else np.nan,
   mean_conditional_nrmse=g.test_nrmse.mean(),mean_free_nrmse=g.free_trajectory_nrmse.mean(),mean_training_nrmse=g.train_nrmse.mean(),
   mean_delta_conditional_AICc=g.delta_AICc.mean(),near_bound_parameter_rows=int(((parameter_data.model==m)&parameter_data.at_bound).sum()),
   AICc_interpretation='descriptive conditional Gaussian pseudo-likelihood' if m in MODELS else 'not defined for baseline rule'))
 complexity=pd.DataFrame(complexity);complexity.to_csv(root/'results/real_cycle_complexity.csv',index=False)
 plot_results(root,metric_df,complexity,comparisons,predictions)
 free=metric_df[(metric_df.model.isin(MODELS))&(metric_df.forecast_mode=='free')]
 conditional=metric_df[(metric_df.model.isin(MODELS))&(metric_df.forecast_mode=='conditional')]
 after={f:sha(root/f) for f in inputs};assert hashes==after
 status=dict(state='completed',new_model_fits=0,new_ODE_simulations=0,held_experiments=4,distinct_held_target_states=861,
  observed_population_records=len(observed_df),forecast_population_records=len(metric_df),pairwise_comparison_rows=len(comparisons),
  threshold_sensitivity_rows=len(threshold_rows),observed_threshold_sensitivity_rows=len(observed_threshold_rows),cache_score_checks=len(checks),max_cache_score_difference=float(checks.absolute_difference.max()),
  free_model_population_records=len(free),free_records_with_late_amplitude_above_floor=int(free.late_amplitude_above_floor.sum()),
  free_periods_estimable=int(free.dominant_period_days.notna().sum()),conditional_periods_estimable=int(conditional.dominant_period_days.notna().sum()),
  observed_periods_estimable=int(observed_df.dominant_period_days.notna().sum()),observed_period_status_counts=observed_df.period_status.value_counts().to_dict(),
  maximum_free_late_amplitude_ratio=float(free.late_amplitude_ratio.max()),
  protocol=PROTOCOL,input_sha256=hashes,inputs_unchanged=True,code_sha256=sha(Path(__file__)),
  python=platform.python_version(),numpy=np.__version__,pandas=pd.__version__,scipy=__import__('scipy').__version__,matplotlib=__import__('matplotlib').__version__,wall_seconds=time.time()-start,
  source_references=['https://doi.org/10.1038/s41586-019-1857-0','https://doi.org/10.6084/m9.figshare.10045976.v1',
                     'https://docs.scipy.org/doc/scipy/reference/generated/scipy.signal.find_peaks.html'])
 (root/'logs/revision/EMPIRICAL_EXTENSION.json').write_text(json.dumps(status,indent=2))
 write_report(root,status,summary,observed_df,comp_summary,complexity)
 print(json.dumps(status,indent=2))


def write_report(root,status,summary,observed,contrasts,complexity):
 def table(frame):
  def cell(v):
   if isinstance(v,(float,np.floating)):return 'not estimable' if np.isnan(v) else f'{v:.6g}'
   return str(v).replace('|','/')
  return '\n'.join(['| '+' | '.join(frame.columns)+' |','|'+'|'.join(['---']*len(frame.columns))+'|']+
                   ['| '+' | '.join(cell(v) for v in row)+' |' for row in frame.itertuples(index=False,name=None)])
 amp=[]
 for m in MODELS:
  def value(mode,pop):return float(summary[(summary.model==m)&(summary.forecast_mode==mode)&(summary.population==pop)].mean_late_amplitude_ratio.iloc[0])
  amp.append(dict(model=m,conditional_prey=value('conditional','prey'),conditional_predator=value('conditional','predator'),
                  free_prey=value('free','prey'),free_predator=value('free','predator')))
 amplitude_table=pd.DataFrame(amp)
 selected=contrasts[(contrasts.forecast_mode=='conditional')&(contrasts.population=='both')&(contrasts.endpoint=='NRMSE')]
 text=f'''# Empirical extension for the six-model paper

## Actual status and scope

This extension adds retrospective cycle diagnostics to the frozen C1–C4 held-experiment predictions. It performs **zero new model fits and zero new ODE simulations**. The 72 reconstructed model/baseline/forecast-mode NRMSE values agree with their cached scores within {status['max_cache_score_difference']:.3g}. Input hashes before and after the run agree. No original data, model equation, parameter fit, old report, or main manuscript was changed.

There are 861 distinct held target states, eight observed population records (four experiments, two populations), and 144 forecast population records (nine prediction rules, two modes, two populations, four experiments). The six mechanistic models account for 48 free-running population records. These counts are not independent experimental replications. Training folds overlap and successive observations are serially dependent.

The study has **two factors in a 3 x 2 design**, not three independent factors. Its three comparison dimensions are growth, competition, and their interaction. M0 remains the original weak-Allee model. The empirical contrasts compare separately refitted structures under the same fitting protocol; they are not parameter-matched causal effects of changing an ecological mechanism.

## Findings for H5

The earlier short-step improvement remains unchanged: M3 has mean held one-step NRMSE 0.882473, M1 0.884862, and persistence 1.040276. M3 gives the lowest descriptive conditional training AICc in all four folds. This identifies a useful fitted short-step transition, together with small differences among the six structures.

The added cycle metrics show a clear limitation. Every one of the 48 free-running model/population/experiment records has negligible late amplitude. The maximum late amplitude divided by its observed counterpart is {status['maximum_free_late_amplitude_ratio']:.3g}. No free trajectory receives an estimated sustained period or phase. This describes the saved finite prediction windows; it is not a proof about all attractors or parameter values of a model family.

The observed records retain repeated prominent peaks and substantial late amplitude. Conditional model predictions retain some of this variation because they restart from the preceding observed state, but their amplitude is attenuated. The following values are equal-weight means over the four held experiments. Amplitude means the central 90% sample span in the final half of elapsed target time, divided by the corresponding observed span.

{table(amplitude_table)}

Persistence has mean conditional late-amplitude ratios about 0.998 for prey and 1.000 for predators because it shifts the observed sequence by one interval. Its preservation of amplitude does not make it the better one-step RMSE predictor. Conversely, the mechanistic models' smaller RMSE does not show that they reproduce autonomous population cycles. Amplitude and forecasting error describe different properties.

H5 is supported as a statement that structure affects these fitted prediction scores. The evidence does not show a consistent predictive advantage from adding weak/strong Allee growth or direct predator competition. It also does not establish a biological Allee threshold, a measured conversion efficiency, or successful autonomous reconstruction of the experimental cycles. The previously recorded bound hits and fixed e/beta assumptions remain relevant.

## Paired growth, competition, and predictive interaction

Negative score differences favor the first named alternative. The interaction is a difference of differences relative to the logistic competition effect. The following table reports mean one-step NRMSE contrasts and the full four-experiment range; it contains no independence-based standard errors or p-values.

{table(selected[['comparison_class','comparison','estimable_folds','mean_contrast','minimum_contrast','maximum_contrast','negative_folds']])}

For logistic and weak growth, competition worsens one-step prediction in C1 and C2 and improves it in C3 and C4. For strong growth, it worsens C1 and improves C2–C4. The weak-growth predictive interaction is positive in all four experiments, meaning that competition is slightly less favorable for prediction under weak growth than under logistic growth after refitting. Its mean is about +0.00206 NRMSE. The strong-growth interaction averages about -0.000059 and changes sign. These are predictive contrasts after separate parameter estimation, not evidence of ecological synergy or a new matched-parameter mechanism.

`results/real_growth_competition_comparisons.csv` retains every fold, forecast mode, population, endpoint, formula, and unavailable component. It includes all three pairwise growth contrasts in both competition arms, all three competition pairs, and two independent interaction contrasts relative to logistic growth. Their difference gives the redundant strong-versus-weak competition interaction. A missing period/phase component produces a missing contrast rather than a zero effect.

## Periods, peaks, and unavailable quantities

{table(observed[['held','population','prominent_peak_count','median_interpeak_days','dominant_period_days','harmonic_variance_fraction','period_status']])}

All eight observed population records have at least 17 selected peaks. However, only three pass the stated single-harmonic coherence screen at its primary 0.10 threshold. The five other records are not declared noncyclic: their repeated peaks are irregular or spread across frequencies, so this simple rule does not assign one coherent period. Candidate scan maxima remain in the CSV. The observed eligibility count changes from eight at a 0.05 harmonic threshold to three at 0.10 and zero at 0.20. This sensitivity is recorded explicitly; the absence of sustained free-forecast amplitude does not depend on that choice.

Period and phase errors are reported only when both the observed and predicted records meet the eligibility rules. Phase also requires compatible periods and sufficient projection onto the observed frequency. The phase is a whole-record harmonic projection, not a time-varying biological delay. Sub-cadence values are fitted diagnostic values and do not establish sub-cadence measurement accuracy. Counts of comparable pairs accompany every mean; the available phase cases are too few and not identical across all models to justify a general phase ranking.

## Reproducible definitions

1. **Common samples and units.** Each diagnostic uses the same target times and target observations as the existing held prediction score. Initial observations used to initialize free trajectories are excluded from scoring. Time is days; prey units are millions of cells/ml; predator units are 20 animals/ml. No data are interpolated or smoothed.
2. **Amplitude.** A90 = Q0.95(z) - Q0.05(z), using ordinary sample quantiles. The late window is t >= t_min + (t_max-t_min)/2. Ratios use the observed span in the same experiment, species, and window. Absolute relative amplitude error is abs(ratio-1). The amplitude itself is reported without thresholding.
3. **Peaks.** Local maxima are found with prominence at least 0.25 times the full-record observed A90. Candidate peaks are processed in descending prominence; retained peaks must be separated by at least two median observation cadences in actual days. Median interpeak interval and its IQR are reported only with at least four retained peaks. These are descriptive event spacings, not proven cycle periods. The source peak operation is documented in the [SciPy reference](https://docs.scipy.org/doc/scipy/reference/generated/scipy.signal.find_peaks.html); the actual-time separation rule is implemented here.
4. **Harmonic scan.** At each of 2048 equally spaced frequencies, least squares fits an intercept, a linear trend, sin(2 pi f t), and cos(2 pi f t). Frequencies run from 4/T to 1/(4 median_delta_t), so searched periods range from four median cadences to one quarter of the record duration. T is the elapsed target-time span. The scan score is the fraction of trend-residual sum of squares explained by the two harmonic terms.
5. **Period eligibility.** The late A90 must reach 0.05 times the training-only residual scale used in the original score, at least four prominent peaks must be present, the maximum harmonic score must be at least 0.10, and the maximizing frequency must not lie on the search boundary. Otherwise the period is missing with a specific reason. The raw candidate period and harmonic score remain available. These thresholds are diagnostic rules, not a calibrated significance test.
6. **Phase.** At the observed selected frequency, the phase of b sin(wt)+c cos(wt) is atan2(c,b). The signed prediction lag is minus the wrapped predicted-minus-observed phase difference divided by w; positive values mean a later prediction. Both periods must be eligible, their relative difference must be at most 10%, and the predicted projection at the observed frequency must explain at least 10% of its detrended variance. Other cases remain missing.
7. **Sensitivity.** Eligibility is recomputed for amplitude floors 0.02, 0.05, and 0.10 times the training scale and harmonic fractions 0.05, 0.10, and 0.20. Forecast and observed sensitivity files retain all combinations. No free mechanistic record becomes amplitude-eligible even at the lowest floor. The rules were added after the original fits, so these are retrospective diagnostics rather than a newly untouched validation dataset.

## Model complexity

{table(complexity[['model','dynamic_parameters','data_summary_parameters','parameters_including_residual_variance','mean_conditional_nrmse','mean_free_nrmse','mean_delta_conditional_AICc','near_bound_parameter_rows']])}

The dynamic parameter counts are M0=5, M1=4, M2=5, M3=5, M4=6, and M5=6. The conditional AICc additionally counts one common residual variance. It is a descriptive conditional pseudo-likelihood score, not an observation-process likelihood. Mean and drift baselines use two training-derived summaries; persistence uses none. AICc is not assigned to those baseline rules. Parameter units, inactive coordinates, fixed scales, near-bound values, and the original optimization budgets remain in the unchanged existing files.

## Text available for the paper

**Results suggestion.** The cycle diagnostics distinguish short-step accuracy from autonomous population variation. Across all six structures, both populations, and four held experiments, late free-forecast amplitude was negligible compared with the observed amplitude. The largest predicted-to-observed ratio was 1.4 x 10^-15. Conditional forecasts retained variation through observed-state resetting, but their mean late-amplitude ratios were 0.556–0.650 for prey and 0.751–0.840 for predators. All free-forecast periods and phases were therefore unavailable under the stated amplitude screen. These results support useful fitted short-step transitions, but not autonomous reconstruction of the observed cycles.

**Methods suggestion.** Cycle diagnostics were computed retrospectively from the frozen held-experiment predictions, without refitting. Amplitude was the 95th minus 5th sample percentile. The late window was the last half of the elapsed held target-time span. A harmonic scan fit an intercept, trend, sine, and cosine over periods between four median cadences and one quarter of the record duration. A period was assigned only with sufficient late amplitude, at least four prominent peaks, a harmonic variance fraction of at least 0.10, and an interior scan maximum. Phase was compared at the observed frequency only when both periods were eligible and agreed within 10%. Threshold sensitivity and explicit unavailable cases were retained. These diagnostic periods were not interpreted as limit-cycle proofs or significance tests.

**Figure caption suggestion.** Six-model prediction and cycle comparison from the same frozen fits. Symbols denote C1 (circle), C2 (square), C3 (triangle), and C4 (diamond); short lines show four-experiment means. Dashed lines in (a) and (b) show the persistence and training-mean baselines, respectively. Panels (c) and (d) show the late central-90% amplitude divided by the observed span. Filled markers are conditional predictions and open markers are free forecasts; the dashed amplitude reference is one. Purple marks models without added competition and teal marks models with competition. Near-zero free amplitudes describe the saved prediction windows.

## Files, execution, and verification

- Run `python run_cycle_metrics.py` from the project root. `--figures-only` regenerates the figures from the generated tables.
- Run `python -m unittest tests.test_cycle_metrics -v` for irregular-time period recovery, phase-lag sign, constant-record guards, and actual-day peak separation.
- `results/real_cycle_observed.csv`, `real_cycle_metrics.csv`, `real_cycle_summary.csv`, and `real_cycle_complexity.csv` contain the observed, forecast, aggregate, and complexity results.
- `real_cycle_threshold_sensitivity.csv` and `real_cycle_observed_threshold_sensitivity.csv` contain threshold checks; `real_cycle_cache_checks.csv` verifies all 72 cached scores.
- `real_growth_competition_comparisons.csv` and its summary preserve paired growth, competition, and predictive-interaction effects.
- `figures/paper_real_comparison.pdf` is the main four-panel prediction/amplitude figure. The other `paper_real*.pdf` and PNG counterparts provide complexity, factorial contrasts, full amplitude comparisons, and all-model C4 free time series.
- `logs/revision/EMPIRICAL_EXTENSION.json` records input hashes, code hash, protocol, actual counts, and versions. The original observations and attribution remain as documented by [Blasius et al.](https://doi.org/10.1038/s41586-019-1857-0) and the [CC BY data record](https://doi.org/10.6084/m9.figshare.10045976.v1).
'''
 (root/'reports/revision/EMPIRICAL_EXTENSION.md').write_text(text,encoding='utf-8')


if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('--figures-only',action='store_true');v=a.parse_args();run(figures_only=v.figures_only)
