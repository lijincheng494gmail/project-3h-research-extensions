"""Matched six-model displays and equilibrium factorial maps for the paper.

Uses the frozen synthetic experiment results. New maps describe locally stable
largest-prey equilibrium branches, separately from initial-state trajectory effects.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.integrate import solve_ivp
from src.analytic import positive_equilibria, growth_derivatives, jacobian_exact

ROOT = Path(__file__).resolve().parent
COLORS = {'logistic': '#37758C', 'weak': '#A05E28', 'strong': '#775C91'}
MODELS = ['M0', 'M1', 'M2', 'M3', 'M4', 'M5']
GROWTH = dict(zip(MODELS, ['weak', 'logistic', 'strong', 'logistic', 'weak', 'strong']))
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 11,
                     'pdf.fonttype': 42,
                     'axes.spines.top': False, 'axes.spines.right': False,
                     'savefig.bbox': 'tight', 'figure.constrained_layout.use': True})


def save(fig, stem):
    fig.savefig(ROOT/'figures'/f'{stem}.png', dpi=220)
    fig.savefig(ROOT/'figures'/f'{stem}.pdf')
    plt.close(fig)


def rhs(z, p):
    x, y = z
    g = growth_derivatives(x, p)[0]
    pred = p['m']*x*y/(p['beta']+y)
    return np.array([x*g-pred, p['e']*pred-p['d']*y-p['h']*y*y])


def trajectory(p, z, t):
    def fun(_, logz):
        zz = np.exp(np.clip(logz, -740, 100))
        return rhs(zz, p)/np.maximum(zz, 1e-300)
    sol = solve_ivp(fun, [t[0], t[-1]], np.log(z), t_eval=t,
                    method='DOP853', rtol=1e-10, atol=1e-12, max_step=.35)
    if not sol.success:
        raise RuntimeError(sol.message)
    return np.exp(np.clip(sol.y.T, -740, 100))


def stable_largest(p):
    roots = positive_equilibria(p)
    stable = [z for z in roots if np.max(np.linalg.eigvals(jacobian_exact(p, z)).real) < -1e-8]
    return stable[-1] if stable else None


def phase_and_time():
    pars = pd.read_csv(ROOT/'results/extended_parameters.csv')
    pars = pars[(pars.scenario == 10) & (pars.scaling == 'same_r')].set_index('model')
    fig, axes = plt.subplots(3, 2, figsize=(7.6, 8.5))
    timefig, tax = plt.subplots(3, 2, figsize=(7.6, 8.5))
    traj_rows = []
    inits = [(6.4, .8), (.8, .8), (3.6, 2.)]
    t = np.linspace(0, 100, 501)
    max_resid = 0.
    for model, ax, ta in zip(MODELS, axes.flat, tax.flat):
        p = pars.loc[model].to_dict()
        xx, yy = np.meshgrid(np.linspace(.15, 8.3, 24), np.linspace(.07, 5.7, 23))
        uv = np.array([rhs(z, p) for z in zip(xx.flat, yy.flat)]).reshape(xx.shape+(2,))
        speed = np.sqrt((uv[..., 0]/8.)**2+(uv[..., 1]/5.7)**2)
        ax.quiver(xx, yy, uv[..., 0]/np.maximum(speed, 1e-12),
                  uv[..., 1]/np.maximum(speed, 1e-12), color='#c6c8cb',
                  angles='xy', scale_units='xy', scale=38, width=.0025)
        for j, z0 in enumerate(inits):
            zz = trajectory(p, z0, t)
            ax.plot(*zz.T, lw=1.4, color=['#193C57', '#B36828', '#8B6C97'][j],
                    label=f'({z0[0]:g}, {z0[1]:g})')
            ax.scatter(*z0, s=16, color=['#193C57', '#B36828', '#8B6C97'][j])
            if j == 0:
                ta.plot(t, zz[:, 0], color='#193C57', label='Prey x')
                ta.plot(t, zz[:, 1], color='#B36828', label='Predator y')
            for tt, (x, y) in zip(t, zz):
                traj_rows.append({'model': model, 'initial': j, 'time': tt, 'x': x, 'y': y,
                                  'x0': z0[0], 'y0': z0[1], 'scenario': 10})
        for z in positive_equilibria(p):
            stable = np.max(np.linalg.eigvals(jacobian_exact(p, z)).real) < 0
            ax.scatter(*z, s=52, marker='o' if stable else 'X',
                       facecolors='#318768' if stable else 'white', edgecolors='#318768', zorder=7)
            max_resid = max(max_resid, np.linalg.norm(rhs(z, p)))
        if GROWTH[model] == 'strong':
            ax.axvline(p['A'], color='#775C91', ls=':', lw=1)
        title = f"{model}: {GROWTH[model]}, h={p['h']:g}"
        ax.set(title=title, xlabel='Prey x', ylabel='Predator y', xlim=(0, 8.5), ylim=(0, 5.8))
        ta.set(title=title, xlabel='Time', ylabel='Population density', xlim=(0, 100))
        ta.grid(alpha=.15)
    axes.flat[0].legend(fontsize=10, title='Initial (x, y)', frameon=False)
    tax.flat[0].legend(fontsize=10, frameon=False)
    save(fig, 'paper_six_phase_portraits')
    save(timefig, 'paper_six_time_series')
    pd.DataFrame(traj_rows).to_csv(ROOT/'results/paper_phase_trajectories.csv', index=False)
    return max_resid


def equilibrium_diagram():
    df = pd.read_csv(ROOT/'results/extended_continuation.csv')
    df = df[(df.sweep_parameter == 'K') & (df.base_scenario == 10)]
    fig, axes = plt.subplots(3, 2, figsize=(7.6, 8.5))
    for model, ax in zip(MODELS, axes.flat):
        d = df[(df.model == model) & df.x_eq.notna()]
        for stable, marker, label in [(True, '.', 'Stable'), (False, 'x', 'Unstable / saddle')]:
            q = d[(d.max_eigen_real < -1e-8) == stable]
            ax.scatter(q.sweep_value, q.x_eq, s=11 if stable else 16,
                       color=COLORS[GROWTH[model]], marker=marker, label=label)
        kvals = np.linspace(1, 32, 125)
        if GROWTH[model] == 'strong':
            kvals = kvals[kvals > 2]
        invasion_K = 1.2*.25/(.65*.3)
        ax.plot(kvals[kvals <= invasion_K], kvals[kvals <= invasion_K], color='#888888', lw=1.4)
        ax.plot(kvals[kvals >= invasion_K], kvals[kvals >= invasion_K], color='#888888', lw=1.2, ls='--')
        if GROWTH[model] == 'strong':
            ax.plot(kvals, np.zeros_like(kvals), color='#555555', lw=1)
            ax.plot(kvals[kvals > 2], np.full(np.sum(kvals > 2), 2.), color='#999999', ls=':', lw=1)
        ax.axvline(invasion_K, color='#9f9f9f', ls=':', lw=.8)
        if GROWTH[model] == 'weak':
            ax.axvspan(1, 1/.225, color='#eeeeee', zorder=-2)
        ax.set(title=f'{model}: {GROWTH[model]}', xlabel='Carrying capacity K', ylabel='Equilibrium prey x',
               xlim=(2 if GROWTH[model] == 'strong' else 1, 32), ylim=(-.3, 33))
        ax.grid(alpha=.15)
    axes.flat[0].legend(fontsize=10, frameon=False)
    save(fig, 'paper_six_equilibrium_diagrams')


def factorial_tables():
    df = pd.read_csv(ROOT/'results/extended_contrasts.csv')
    sampled = df[df.regime == 'starter_distribution']
    groups = ['scaling', 'contrast_type', 'from_model', 'to_model']
    allrows = sampled.groupby(groups).agg(n_pairs=('delta_y_tail_mean', 'size'),
        mean_delta_prey=('delta_x_tail_mean', 'mean'), mean_delta_predator=('delta_y_tail_mean', 'mean'),
        min_delta_predator=('delta_y_tail_mean', 'min'), max_delta_predator=('delta_y_tail_mean', 'max'),
        n_positive=('delta_y_tail_mean', lambda x: int((x > 1e-8).sum())),
        n_negative=('delta_y_tail_mean', lambda x: int((x < -1e-8).sum()))).reset_index()
    allrows['summary_population'] = '8 sampled scenarios x 3 initial states; finite design'
    allrows.to_csv(ROOT/'results/paper_paired_comparisons.csv', index=False)
    df.groupby(['regime']+groups+['from_outcome', 'to_outcome']).agg(
        n_pairs=('delta_y_tail_mean', 'size'), mean_delta_predator=('delta_y_tail_mean', 'mean'),
        mean_delta_prey=('delta_x_tail_mean', 'mean')).reset_index().to_csv(
        ROOT/'results/paper_comparisons_by_regime_outcome.csv', index=False)
    return len(allrows)


def interaction_maps():
    base = dict(r=.7, K=8., m=.3, beta=1.2, e=.65, d=.25, h=0., alpha=.225, A=2.)
    hs = np.linspace(0, .15, 41)
    alphaKs = np.linspace(1.2, 6.4, 35)
    A_Ks = np.linspace(.05, .45, 35)
    rows = []
    max_residual = 0.
    for scaling in ['same_r', 'matched_reference_growth']:
        logistic = dict(base, allee='logistic')
        l0 = stable_largest(logistic)
        for growth, shapes in [('weak', alphaKs), ('strong', A_Ks)]:
            for shape in shapes:
                p0 = dict(base, allee=growth)
                if growth == 'weak':
                    p0['alpha'] = shape/base['K']
                    if scaling != 'same_r':
                        p0['r'] = base['r']/(1+.6*shape)
                else:
                    p0['A'] = shape*base['K']
                    if scaling != 'same_r':
                        p0['r'] = base['r']/(.6/shape-1)
                z0 = stable_largest(p0)
                for h in hs:
                    lh = stable_largest(dict(logistic, h=h))
                    p = dict(p0, h=h)
                    zh = stable_largest(p)
                    valid = all(z is not None for z in [l0, lh, z0, zh])
                    interaction = ((zh[1]-z0[1])-(lh[1]-l0[1])) if valid else np.nan
                    if valid:
                        max_residual = max(max_residual, np.linalg.norm(rhs(zh, p)))
                    rows.append(dict(scaling=scaling, growth=growth, shape_parameter=shape,
                        shape_name='alpha_K' if growth == 'weak' else 'A_over_K', h=h,
                        interaction_predator=interaction, valid_largest_stable_equilibria=valid,
                        x_h=zh[0] if valid else np.nan, y_h=zh[1] if valid else np.nan,
                        x_0=z0[0] if z0 is not None else np.nan, y_0=z0[1] if z0 is not None else np.nan,
                        r=p['r'], K=p['K'], alpha=p['alpha'], A=p['A'],
                        m=p['m'], beta=p['beta'], e=p['e'], d=p['d'],
                        basis='largest-prey locally stable equilibrium; not a basin comparison'))
    df = pd.DataFrame(rows)
    df.to_csv(ROOT/'results/paper_interaction_grid.csv', index=False)
    fig, axes = plt.subplots(2, 2, figsize=(7.6, 6.8))
    cap = np.nanmax(np.abs(df.interaction_predator))
    for ax, (scaling, growth) in zip(axes.flat, [(s, g) for s in ['same_r', 'matched_reference_growth'] for g in ['weak', 'strong']]):
        d = df[(df.scaling == scaling) & (df.growth == growth)]
        pivot = d.pivot(index='shape_parameter', columns='h', values='interaction_predator')
        xx, yy = np.meshgrid(pivot.columns.values, pivot.index.values)
        cmap = plt.get_cmap('RdBu_r').copy()
        cmap.set_bad('#d8d8d8')
        im = ax.pcolormesh(xx, yy, pivot.values, cmap=cmap, vmin=-cap, vmax=cap, shading='auto')
        lo, hi = np.nanmin(pivot.values[:, 1:]), np.nanmax(pivot.values[:, 1:])
        if lo < 0 < hi:
            ax.contour(xx, yy, pivot.values, levels=[0], colors='black', linewidths=.8)
        ax.set(title=f"{growth.capitalize()}; {'same r' if scaling == 'same_r' else 'matched growth'}",
            xlabel='Predator competition h', ylabel='αK' if growth == 'weak' else 'A / K')
    fig.colorbar(im, ax=list(axes.flat), label='Difference of predator competition effects')
    save(fig, 'paper_interaction_regions')
    nonzero = df[df.h > 0].copy()
    nonzero['positive'] = nonzero.interaction_predator > 1e-8
    nonzero['negative'] = nonzero.interaction_predator < -1e-8
    nonzero.groupby(['scaling', 'growth']).agg(n=('h', 'size'),
        valid=('valid_largest_stable_equilibria', 'sum'), n_positive=('positive', 'sum'),
        n_negative=('negative', 'sum'), minimum=('interaction_predator', 'min'),
        maximum=('interaction_predator', 'max')).reset_index().to_csv(
            ROOT/'results/paper_interaction_region_summary.csv', index=False)
    return {'rows': len(df), 'all_valid': bool(df.valid_largest_stable_equilibria.all()),
            'max_equilibrium_rhs_residual': max_residual,
            'grid_is_exact_parameter_partition': False}


def main():
    status = {'phase_max_equilibrium_residual': phase_and_time(),
              'paired_table_rows': factorial_tables(), 'interaction_grid': interaction_maps(),
              'trajectory_solver': 'DOP853 log-state; rtol1e-10 atol1e-12 max_step.35',
              'time_series_initial_state': [6.4, .8],
              'phase_initial_states': [[6.4, .8], [.8, .8], [3.6, 2.]],
              'synthetic_units': 'nondimensional',
              'source': 'frozen extension scenario 10 and full frozen contrasts'}
    equilibrium_diagram()
    assert status['phase_max_equilibrium_residual'] < 1e-8
    assert status['interaction_grid']['max_equilibrium_rhs_residual'] < 1e-7
    (ROOT/'logs/revision/PAPER_NUMERICS.json').write_text(json.dumps(status, indent=2))
    print(json.dumps(status, indent=2))


if __name__ == '__main__':
    main()
