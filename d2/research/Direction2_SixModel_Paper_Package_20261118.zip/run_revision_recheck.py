"""Reproduce prior deterministic results and validate unchanged empirical fits."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parent


def main():
    stages=[('baseline',['run_experiment.py','--mode','full']),
            ('analytical',['run_analytical_checks.py']),('extended',['run_extensions.py']),
            ('direct_solver',['run_direct_solver_audit.py']),
            ('real_fitted_transition_audit',['run_real_audit.py']),
            ('real_sensitivity_audit',['run_real_sensitivity_audit.py'])]
    frozen=['results/real_benchmark_scores.csv','results/real_benchmark_parameters.csv','results/real_predictions.csv']
    hashes={name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in frozen}
    records=[]
    for name,args in stages:
        start=time.monotonic()
        with (ROOT/f'logs/revision/recheck_{name}_stdout.txt').open('w') as out,\
             (ROOT/f'logs/revision/recheck_{name}_stderr.txt').open('w') as err:
            result=subprocess.run([sys.executable]+args,cwd=ROOT,stdout=out,stderr=err)
        records.append({'stage':name,'returncode':result.returncode,'seconds':time.monotonic()-start})
        print(json.dumps(records[-1]),flush=True)
        if result.returncode:
            raise RuntimeError('Scientific recheck failed: '+name)
    unchanged=all(hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest for name,digest in hashes.items())
    status={'state':'pass' if unchanged else 'failed','stages':records,
            'empirical_fit_caches_reused_without_refitting':True,'empirical_fit_inputs_unchanged':unchanged,
            'empirical_fit_sha256':hashes,'paid_resources_used':False}
    (ROOT/'logs/revision/PRIOR_RESULTS_RECHECK.json').write_text(json.dumps(status,indent=2))
    assert unchanged


if __name__=='__main__':main()
