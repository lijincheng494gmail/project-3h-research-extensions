"""Build final bilingual reports and coverage tables from actual result files."""
from pathlib import Path
import json
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parent
R=ROOT/'results'; D=ROOT/'reports'
MODELS=['M0','M1','M2','M3','M4','M5']

def table(headers,rows):
    return '\n'.join(['| '+' | '.join(headers)+' |','| '+' | '.join(['---']*len(headers))+' |']+
                     ['| '+' | '.join(str(v) for v in row)+' |' for row in rows])

def main():
    F=pd.read_csv(R/'extended_factorial.csv');C=pd.read_csv(R/'extended_contrasts.csv')
    S=pd.read_csv(R/'extended_shock_recovery.csv'); B=pd.read_csv(R/'extended_basin_boundaries.csv')
    W=pd.read_csv(R/'analytical_bifurcation_witnesses.csv'); AE=pd.read_csv(R/'analytical_equilibria.csv')
    E=pd.read_csv(R/'extended_equilibria.csv'); A=pd.read_csv(R/'extended_solver_audit.csv')
    RS=pd.read_csv(R/'real_benchmark_scores.csv'); RA=pd.read_csv(R/'real_solver_audit.csv')
    P=pd.read_csv(R/'real_benchmark_parameters.csv'); V=pd.read_csv(R/'real_folds.csv')
    IC=pd.read_csv(R/'extended_independent_root_audit.csv')
    macro=RS.groupby('model')[['test_nrmse','free_trajectory_nrmse']].mean()
    dynamic=RS[RS.model.isin(MODELS)].copy()
    dynamic['delta_AICc']=dynamic.conditional_AICc-dynamic.groupby('held').conditional_AICc.transform('min')
    dAIC=dynamic.groupby('model').delta_AICc.mean()
    starter=C[C.regime=='starter_distribution']
    def effect(scaling,typ,a,b):
        q=starter[(starter.scaling==scaling)&(starter.contrast_type==typ)&(starter.from_model==a)&(starter.to_model==b)]
        return q.delta_y_tail_mean.mean()
    contrast_rows=[]
    for typ,a,b in [('competition','M1','M3'),('competition','M0','M4'),('competition','M2','M5'),
                    ('growth_h0','M1','M0'),('growth_h0','M1','M2'),('growth_h0','M0','M2'),
                    ('interaction_weak_vs_logistic','M1->M3','M0->M4'),
                    ('interaction_strong_vs_logistic','M1->M3','M2->M5')]:
        contrast_rows.append([a+' to '+b,typ.replace('interaction_','interaction: '),
            f"{effect('same_r',typ,a,b):+.6f}",f"{effect('reference_growth_matched',typ,a,b):+.6f}"])
    ct=table(['Contrast','Type','Same r','Matched g(0.6K)'],contrast_rows)
    st=table(['Model','Recovered / 8','Longest recovery','Prey removals causing extinction'],[
        [m,int(S[S.model==m].recovered.sum()),f"{S[S.model==m].recovery_time_2pct.max():.1f}",
         ', '.join(f'{100*x:.0f}%' for x in S[(S.model==m)&(~S.recovered)&(S.perturbed_population=='prey')].reduction_fraction) or 'None in tested levels'] for m in MODELS])
    bt=table(['Model','A','Boundary prey density','Retained equilibrium fraction'],[
        [q.model,f'{q.A:g}',f'{q.lower_prey_density:.6f} to {q.upper_prey_density:.6f}',
         f'{q.lower_retained_fraction:.6f} to {q.upper_retained_fraction:.6f}'] for q in B.itertuples()])
    realrows=[]
    for m in MODELS+['persistence','training_mean','training_drift']:
        realrows.append([m,f'{macro.loc[m,"test_nrmse"]:.6f}',f'{macro.loc[m,"free_trajectory_nrmse"]:.6f}',
                         f'{dAIC.loc[m]:.2f}' if m in MODELS else 'N/A'])
    rt=table(['Model / baseline','Held one-step NRMSE','Held free NRMSE','Mean training delta AICc'],realrows)
    hw=W[W.event=='Hopf']
    ht=table(['Model','h','First Lyapunov coefficient','Local Hopf type'],[
        [q.model,f'{q.h:.6f}',f'{q.l1:+.8f}',q.hopf_type] for q in hw.itertuples()])
    br=S.groupby('model')[['x_eq','y_eq']].first()
    eqtable=table(['Model','Stable reference prey x*','Predator y*'],[
        [m,f'{br.loc[m,"x_eq"]:.6f}',f'{br.loc[m,"y_eq"]:.6f}'] for m in MODELS])
    winners=RS.loc[RS.groupby('held').test_nrmse.idxmin()]
    wintext='; '.join(f'{q.held}: {q.model}' for q in winners.itertuples())
    nbound=int(P.at_bound.sum())
    main_err=RA.max_normalized_error_main_step.max()
    path_err=A.max_scaled_path_error_T400.max()
    relgain=100*(macro.loc['M1','test_nrmse']-macro.loc['M3','test_nrmse'])/macro.loc['M1','test_nrmse']
    rec_n=int(S.recovered.sum())
    profiles=pd.read_csv(R/'real_parameter_profiles.csv') if (R/'real_parameter_profiles.csv').exists() else pd.DataFrame()
    sens=pd.read_csv(R/'real_assumption_sensitivity.csv') if (R/'real_assumption_sensitivity.csv').exists() else pd.DataFrame()
    identification=pd.read_csv(R/'real_parameter_identification.csv')
    strong_id=identification[identification.growth_kind=='strong']
    threshold_range=f'{strong_id.fitted_A.min():.5f} to {strong_id.fitted_A.max():.5f}'
    low_observed=min(strong_id.min_train_observed_prey.min(),strong_id.min_test_observed_prey.min())
    en=f'''# Allee growth and predator competition in six matched models

Project 3H, Direction 2. Executed 18 November 2026. All synthetic quantities use dimensionless population and time units. Real observations use days and the state scales defined below.

## Executive summary

The six-model study produced explicit mathematical results, {len(F)} extended trajectories, {len(C)} conditional contrasts, {len(S)} shock experiments, and four held-experiment observation benchmarks. M0 remains the teacher's exact equation. Weak and strong Allee models admit ordinary saddle-node, Hopf, and Bogdanov-Takens bifurcations in feasible positive parameter regimes. The logistic models exclude all three interior bifurcations. Predator competition changes recovery basins, but its population effect depends on the growth law and regime.

The apparent weak-Allee benefit reverses when reference growth is matched. In observed algae-rotifer data, M3 has the lowest mean one-step error, but its improvement over logistic M1 is only {relgain:.3f}%. No mechanistic model improves the mean free-trajectory score over the training-mean baseline. These data do not establish an Allee mechanism. Unrestricted global phase classification and a field-calibrated vertebrate application remain open; the verification matrix records these gaps.

## Background

The teacher's brief studies prey growth with a weak Allee effect and a predator-dependent foraging response. Its research programme follows [Haque (2011)](https://doi.org/10.1016/j.mbs.2011.07.003) and [Cantrell and Cosner (2001)](https://www.math.miami.edu/~rsc/docs/2001dynamics.pdf). Here all mathematical claims are derived for the actual displayed equations, rather than imported from a different denominator. The cancelled stochastic extension is excluded.

## Research question and hypotheses

With the predation law fixed, how do prey Allee growth and direct predator competition separately and jointly change coexistence, stability, and recovery? H1 concerns growth structure and equilibria. H2 concerns competition. H3 concerns interaction effects. H4 concerns shock basins and recovery. H5 asks whether these structural changes improve held-experiment prediction. The exact evidence and interpretation for each hypothesis appear in RESULTS_BY_HYPOTHESIS.md.

## Model definitions

All six models use `x' = x g(x) - mxy/(beta+y)` and `y' = emxy/(beta+y) - dy - hy^2`. All biological parameters are positive, except effective h=0 in the three models without added competition. Strong growth requires `0 < A < K`.

{table(['Model','Prey per-capita growth g(x)','Added predator competition'],[
['M0','r(1-x/K)(1+alpha x)','None: teacher original'],['M1','r(1-x/K)','None'],
['M2','r(1-x/K)(x/A-1)','None'],['M3','r(1-x/K)','h > 0'],
['M4','r(1-x/K)(1+alpha x)','h > 0'],['M5','r(1-x/K)(x/A-1)','h > 0']])}

For weak growth, positive low-density density dependence requires `alpha K > 1`. Every synthetic parameter row and sweep records alpha K; a weak-form curve with alpha K at most one is not described as having an increasing low-density per-capita rate. Strong r sets a negative per-capita rate at zero and therefore has a different interpretation from logistic r.

The correct Beddington-DeAngelis denominator mapping is `a=0, b=1, c=beta`, not c=0. The teacher's prose mentions competition, but its displayed original equation omits it. Both discrepancies are documented in SOURCE_AND_SCOPE_AUDIT.md.

## Design

The supplied full baseline was rerun: 18 sampled parameter scenarios, four initial states, and six models give 432 trajectories at T=70. This is retained as starter evidence. The extension uses eight sampled scenarios plus four constructed regimes, three matched initial states, six models, and two growth calibrations, giving {len(F)} trajectories at T=400. Initial states are `(0.8K,0.8)`, `(0.1K,0.8)`, and `(0.45K,2)`. A fixed seed of 2026 reproduces the sampled cases. Constructed regimes explore a bifurcation neighbourhood, a stable shock reference, and failed predator invasion; they are not a random ecological sample.

The first arm fixes r across growth laws. The second sets each growth law's per-capita rate at x=0.6K to `r_base(1-0.6)`. This matches one reference rate, not the entire growth curve. Competition comparisons retain the same growth law, calibration, parameters, and initial state. Growth comparisons retain the same predation law. The interaction is a difference of paired competition effects. Full parameters are in extended_parameters.csv; raw effects and outcome-stratified means are in extended_contrasts.csv and extended_contrast_summary.csv.

Shock tests start from the largest-prey stable coexistence equilibrium under `r=.7, K=8, alpha=.225, A=2, m=.3, beta=1.2, e=.65, d=.25`, with h=0 or .05. Each population is reduced separately by 5%, 25%, 60%, or 85%. Parameters remain fixed. Recovery requires both states to remain within 2% of the reference equilibrium for at least 50 time units, through the remaining observation horizon T=600. Basin bisection fixes predator density at its equilibrium value.

{eqtable}

For the real-data benchmark, the source is the laboratory study of [Blasius et al. (2020)](https://doi.org/10.1038/s41586-019-1857-0), with the [authors' public CSVs](https://github.com/berndblasius/WaveletAnalysis/tree/master/data/chemostat_experiments). The verified positive complete records number 358, 188, 180, and 139 for C1-C4. The prey unit is 10^6 cells/ml; the predator state is rotifers/ml divided by 20. Their medium has the same nominal nitrogen concentration. Thus this is transfer to a held experiment, not demonstrated transfer across external nutrient conditions. The two-state classroom model does not explicitly represent dilution, nutrients, or rotifer life stages.

Each outer fold reserves one entire experiment. A separate inner check fits two of the remaining experiments and validates on the third. Settings are fixed; validation and test errors do not tune the model. Final outer fits use all three non-test experiments, identical observation pairs, training-only scales, and equal two-start optimizer budgets. Each model fits four to six dynamic parameters; e=.65 and beta=1.2 are assumed scale parameters. One-step forecasts condition on the previous observed state. Free forecasts use only the first state and then integrate without resetting to later observations. Conditional training AICc is descriptive because residuals are serially dependent. See REAL_DATA_METHODS.md for bounds, profiles, and assumption sensitivities.

## Findings: positive results

### Mathematical structure

Positivity and ultimate boundedness hold for all six models. For logistic and weak growth, `emK/beta - d > 0` is the permanence condition; when this quantity is nonpositive the predator-free state (K,0) attracts all positive initial states. For strong growth, (0,0), (A,0), and (K,0) all require separate analysis. Every initial state with `0 < x0 <= A` and `y0 > 0` tends to (0,0), so strong models cannot be permanent for all positive initial states.

A scalar polynomial gives all feasible interior equilibrium candidates: degree at most three when h=0 and at most five when h>0. Each candidate is filtered for `0 < g(x) < m`, positive predator density, and the original ODE residual. Independent prey- and predator-coordinate reductions agree on all {len(IC)} tested parameter/model sets. At an interior equilibrium the Jacobian is explicit. Logistic growth makes its trace strictly negative and determinant strictly positive; its coexistence equilibrium is unique and globally attracting when predator invasion is positive.

An explicit relative-entropy Lyapunov function gives sufficient global stability for weak growth when `x* >= K - 1/alpha`. For strong growth it gives a certified local basin when the equilibrium lies on the descending growth limb. These are sufficient domains, not an unrestricted global classification. Proofs, exceptional cases, and the seven-question status for each model are in ANALYTICAL_RESULTS.md and MODEL_QUESTION_MATRIX.csv.

### Matched effects and interaction

The following means use only the eight sampled starter-distribution scenarios and their three initial states: 24 matched runs per displayed contrast and calibration. They are finite-design summaries of predator tail means, not estimates of a natural population average. Positive values mean a larger predator tail mean in the target model. The interaction row compares the indicated competition effects.

{ct}

The raw competition contrasts cover M1/M3, M0/M4, and M2/M5. Growth contrasts cover all three pairings within each h arm. Outcome labels accompany every effect, so an extinction-to-coexistence change can be distinguished from a shift between two coexistence states.

![Matched synthetic factorial](../figures/extended_factorial.png)

### Recovery basins

{rec_n} of {len(S)} shocks recover within the defined horizon. All eight shocks recover in M0, M1, M3, and M4. M2 loses coexistence after 60% and 85% prey removal. M5 recovers after 60% removal but fails after 85%. Every tested predator-only reduction recovers.

{st}

The strong-model prey-shock boundary lies above the single-population threshold A=2. Existing predators continue to consume prey after a shock. With predator density fixed at its own equilibrium, bisection gives:

{bt}

Both endpoints retain opposite outcomes when the horizon increases from 800 to 1600. These are numerical brackets along a specified shock ray, not a proof of a unique global separatrix. The Lyapunov sublevel calculation independently certifies a subset of successful recoveries. Files: extended_shock_recovery.csv, extended_basin_boundaries.csv, and extended_shock_lyapunov_certificates.csv.

![Shock recovery](../figures/extended_shock_recovery.png)

### Enrichment and bifurcations

Logistic M1/M3 exclude interior saddle-node, Hopf, and BT bifurcations for all admissible positive parameters. Weak M0/M4 and strong M2/M5 each have feasible ordinary saddle-node, Hopf, and BT examples, including strictly positive h in M4/M5. Twelve parameter-specific constructions satisfy exact symbolic equilibrium and critical-invariant identities. Their nondegeneracy and unfolding checks pass. They establish feasibility, not a complete partition of parameter space.

{ht}

Each row uses its own parameter regime; changes in Hopf type across these rows are not a paired causal effect of adding h. First Lyapunov coefficient signs are symbolically certified, and two coefficient formulas agree numerically. The normalization is stated in the analytical report. Local cycle existence follows from the Hopf theorem at these nondegenerate points; long finite-time oscillations alone are not used as its proof. Global cycle uniqueness and global homoclinic curves are not established.

At the constructed weak M0 Hopf point, increasing K through 8 changes the trace from negative to positive with positive determinant. A strong M2 example also loses stability with enrichment. The reference K sweeps and targeted neighbourhoods use fixed alpha or A, rather than silently rescaling their effects with K. Files: extended_continuation.csv, analytical_bifurcation_witnesses.csv, analytical_bifurcation_checks.csv, and logs/ANALYTICAL_EXACT_CERTIFICATES.json.

![Enrichment near a Hopf point](../figures/extended_enrichment_hopf.png)

## Findings: unexpected and negative results

The weak-growth comparison depends strongly on calibration. At the same r, M0 exceeds M1 in mean predator tail density by {effect('same_r','growth_h0','M1','M0'):+.6f}. After matching reference growth the difference is {effect('reference_growth_matched','growth_h0','M1','M0'):+.6f}. An apparent structural advantage therefore includes a change in growth magnitude. The weak-versus-logistic competition interaction also reverses sign. Neither contrast supports an unconditional benefit of Allee growth.

Competition does not have one universal effect on predator equilibrium density. On a regular stable branch, `dx*/dh = -J12*y*^2/det(J) > 0`, while `dy*/dh = J11*y*^2/det(J)`. The second sign follows the local slope of prey per-capita growth. In strong models, competition can also change which basin contains the initial state. These mechanisms explain why paired predator effects can have either sign.

The observed-data results are:

{rt}

Scores average four held experiments equally; lower is better. Training delta AICc is measured relative to the best mechanistic model within each fold and is not a held-out score. The one-step winner varies by experiment: {wintext}. Added competition improves average conditional fitting and gives the lowest mean held one-step error in M3, but its improvement over M1 is {relgain:.3f}%. Four experiments provide no strong evidence of a general ranking.

The training-mean baseline has free-trajectory NRMSE {macro.loc['training_mean','free_trajectory_nrmse']:.6f}, while the best mechanistic mean is {macro.loc[MODELS,'free_trajectory_nrmse'].min():.6f}. Resetting the state at each observed time therefore makes the task substantially easier than forecasting a whole trajectory. {nbound} fitted dynamic parameter entries are near their declared bounds. Allee-shape or threshold parameters repeatedly reach their lower bounds. Fitted strong thresholds A range from {threshold_range} million cells/ml, below both training and held observed minima (the smallest observed prey state is {low_observed:.2f}). The data therefore never directly sample a fitted threshold crossing. See real_parameter_identification.csv. The C4 training profiles ({len(profiles)} rows) and prespecified e/beta sensitivities ({len(sens)} fits) expose dependence on assumptions; they are not confidence intervals or evidence that thresholds have been biologically identified.

![Held-experiment benchmark](../figures/real_benchmark.png)

## Verification and interpretation

The original package manifest passes all 34 input hash checks. The baseline and extensions were actually executed. Forty-eight tighter synthetic integrations use T=800 rather than 400; the largest scaled discrepancy over the common T=400 path is {path_err:.3g}, with no endpoint outcome-label changes in those audited runs. The final real-data integrator is checked against tight DOP853 solves and step halving; the largest sampled normalized error is {main_err:.3g}. Rejected coarser precision rounds remain in logs. Final test and audit counts appear in logs/FINAL_VERIFICATION.json.

The structural mathematics establishes what these equations can do. The synthetic comparisons establish conditional effects within the listed scenarios. The observed benchmark establishes predictive errors under specified fitting and observation assumptions. These are distinct forms of evidence. The model omits known chemostat processes, and no fitted parameter is presented as a measured ecological constant. [Tanner (1975)](https://doi.org/10.2307/1936296) does not by itself supply a complete parameter mapping for Eq. (1.1); a field-calibrated muskrat/mink, moose/wolf, or hare/lynx claim is not made.

The completed coverage includes exact model definitions, all six seven-question entries, matched main and interaction contrasts, parameter/initial-state separation, whole-experiment prediction, baseline forecasts, and complexity-aware scoring. Of the 42 analytical question entries, 34 are done and eight are partial: full multiplicity-region and global/basin classification in the four Allee models. Global uniqueness of cycles and a fully calibrated vertebrate application also remain partial. See VERIFICATION_MATRIX.csv for each criterion and its evidence.

## Next feasible experiments

1. Measure prey growth across low densities without predators, then fit its scale and shape separately. Include densities around a proposed threshold.
2. Perturb predator density at matched prey density to separate interference through beta from direct loss through h. Record recovery trajectories with nutrient and dilution measurements.
3. Test a nutrient- and stage-aware model on additional entire chemostat experiments. Choose the model and fitting settings before opening new test trajectories.
4. Extend the analytic sufficient conditions and use validated continuation if a complete two-parameter global diagram or homoclinic structure is required.

## Reproduction and references

Run `bash run_complete.sh` from the extracted project directory. It creates an isolated environment when needed, reruns the scientific calculations and tests, rebuilds the reports, verifies artifacts, and produces the results ZIP. Exact dependency versions are saved in logs/environment.lock.txt. The source data transformations and original-file hashes are in data/provenance/original/ and real_source_verification.csv. AI use and author-review needs are documented separately in AI_USE_AND_AUTHOR_REVIEW.md.

Primary references: the supplied Project 3H brief; [Haque (2011)](https://doi.org/10.1016/j.mbs.2011.07.003); [Cantrell and Cosner (2001)](https://www.math.miami.edu/~rsc/docs/2001dynamics.pdf); [Tanner (1975)](https://doi.org/10.2307/1936296); [Blasius et al. (2020)](https://doi.org/10.1038/s41586-019-1857-0); [Kuznetsov's Hopf lecture notes](https://webspace.science.uu.nl/~kouzn101/cm/L2.pdf); and [the BT theorem and nondegeneracy conditions](https://www.scholarpedia.org/article/Bogdanov-Takens_bifurcation). Literature-access limits are stated in SOURCE_AND_SCOPE_AUDIT.md.
'''
    (D/'FINAL_REPORT_EN.md').write_text(en)
    zh=f'''# 六模型研究执行报告：Allee 增长与捕食者竞争

执行日期：2026年11月18日。模型编号和老师原方程保持不变；已取消的随机噪声任务未纳入研究。

## 先看结论

这次实际完成了数学推导、{len(F)}条扩展长时轨道、{len(C)}个配对效应及交互比较、{len(S)}个冲击实验，以及C1–C4四组真实实验的留组预测。结果不是把原包里的试跑图重新打包。

最值得保留的发现有三点。第一，弱Allee模型在相同r下看起来更有利，但把参考密度的增长率配平后，捕食者尾段均值的差异由{effect('same_r','growth_h0','M1','M0'):+.6f}变为{effect('reference_growth_matched','growth_h0','M1','M0'):+.6f}。增长幅度会影响所谓的结构优势。第二，强Allee模型的恢复边界不等于单种群阈值A；在本次参考情景中，以各模型自身共存平衡为基准、把捕食者初值固定在各自平衡密度时，竞争模型的猎物崩溃边界更低。第三，真实数据中增加Allee结构没有显示稳定的预测优势，复杂模型也没有在整段自由外推中超过训练均值基线。

一般参数下的完整全局相图、所有周期轨道的唯一性，以及老师提到的野外脊椎动物参数校准仍有缺口。报告逐项标为partial，没有写成全部数学问题已解决。

## 研究背景、问题与假说

老师原题研究弱Allee猎物增长和foraging-arena捕食。方向二固定捕食函数，只改变猎物增长类型和是否加入捕食者直接竞争。H1比较共存、灭绝和平衡；H2比较竞争效应；H3检查两种机制是否存在交互；H4检查冲击恢复和吸引域；H5检查真实观测的预测表现。H1–H5逐项证据见RESULTS_BY_HYPOTHESIS.md。

## 六个模型与尺度

共同方程为 `x' = x g(x) - mxy/(beta+y)`，`y' = emxy/(beta+y) - dy - hy^2`。

{table(['模型','猎物增长','捕食者竞争'],[['M0','弱Allee：r(1-x/K)(1+alpha x)','h=0，老师原模型'],['M1','Logistic：r(1-x/K)','h=0'],['M2','强Allee：r(1-x/K)(x/A-1)','h=0'],['M3','Logistic','h>0'],['M4','弱Allee','h>0'],['M5','强Allee','h>0']])}

老师正文提到竞争，但原方程没有 `-hy^2`，所以不能向M0偷偷加这一项。原题全局稳定性提示里的分母映射也需修正：`a=0,b=1,c=beta` 才是本题的 `beta+y`。弱Allee形式还必须检查 `alpha K>1`，才能说低密度人均增长率随密度增加。

合成实验的x、y、t均为无量纲；这些参数不是野外估计。真实实验用天、百万藻细胞/ml，以及轮虫个体数/ml除以20。真实拟合中固定的e、beta是尺度假设，不是直接测出的转换率或干扰参数。

## 实验设计

原包full基准已重跑：18组参数×4初值×6模型=432条T=70轨道。新增设计包含8组抽样情景和4组构造情景、3初值、6模型、两种增长尺度，共{len(F)}条T=400轨道。两种尺度分别是“固定r”和“在x=0.6K处配平人均增长率”。后一种只配平一个参考点，不会把不同增长曲线变成同一个模型。

冲击实验另用六模型均存在稳定共存的参考参数：`r=.7,K=8,alpha=.225,A=2,m=.3,beta=1.2,e=.65,d=.25`，竞争模型 `h=.05`。每个模型从自己的稳定共存平衡出发，分别移除5%、25%、60%、85%的猎物或捕食者，参数保持不变。恢复定义为两种群均回到平衡的2%以内，并至少保持50个时间单位至观察终点。未恢复不自动等于数学上的永久灭绝；本次失败项另核查了灭绝端点。

真实数据来自[Blasius等的实验](https://doi.org/10.1038/s41586-019-1857-0)，与[作者公开原始CSV](https://github.com/berndblasius/WaveletAnalysis/tree/master/data/chemostat_experiments)逐值核对。C1–C4保留358、188、180、139个正值完整观测。四组实验的外部培养基名义条件相同，不能称为跨营养条件验证。

外层每次整组留出一个实验，另设独立的内层整组验证记录。设置预先固定，不用验证或测试分数调参；外层最终模型用另外三组全部相邻观测对拟合。六模型具有相同数据、训练尺度和两起点优化预算。“条件一步预测”每次用上一观测重新给初值；“自由外推”只用留出实验的第一个状态，后续不重置。两者不能混为一谈。

## 已得到的正面发现

### 数学结果

六模型均保持正性并最终有界。Logistic和弱Allee模型的永久共存条件为 `emK/beta-d>0`；不满足时，正初值趋向捕食者消失的 `(K,0)`。强Allee模型必须额外分析 `(A,0)`；所有 `0<x0<=A,y0>0` 都趋向 `(0,0)`，因此不能对整个正象限宣称永久共存。

内部平衡可以化为单变量多项式：h=0时至多三次，h>0时至多五次，再检查非负可行性和原方程残差。本次两种独立消元方式在{len(IC)}组参数/模型组合上全部一致。Logistic的内部平衡唯一，存在时全局吸引，且不能发生内部Hopf、鞍结或BT分岔。

显式Lyapunov函数给出了弱Allee全局稳定的充分条件 `x*>=K-1/alpha`，以及强Allee下降支附近的可证明吸引域。充分条件以外的情形没有被写成已经证明。全部公式、证明和六模型×七问题的42格矩阵见ANALYTICAL_RESULTS.md、MODEL_QUESTION_MATRIX.csv。

### 配对主效应与交互

下表只汇总8组抽样情景×3初值=24个配对，不混入特意构造的分岔情景。数值是捕食者尾段均值差，不是实测效应或总体统计推断。

{ct}

全部三对竞争比较、每个竞争水平内的三对增长比较，以及三种差中之差均保留原始行和按情景/终态分层汇总。

### 冲击恢复

{rec_n}/{len(S)}次冲击按定义恢复。M0/M1/M3/M4的8次均恢复；M2在猎物移除60%、85%后灭绝；M5在60%移除后可恢复，但85%后仍失败。所有捕食者单独受冲击的实验均恢复。

{st}

固定捕食者在各自平衡密度时，强Allee猎物冲击边界为：

{bt}

这些边界均高于A=2，因为冲击后仍存在的捕食者继续消耗猎物。二分法在T=800定位，两个端点在T=1600仍分别灭绝/恢复。这是指定冲击射线上的数值夹逼，不能代替整个吸引域边界的唯一性证明。Lyapunov子水平集另提供了一部分成功恢复的解析保证。

### 富营养化与分岔

M0/M4/M2/M5分别构造了可行的Hopf、普通鞍结和BT点，共12个例子；竞争模型例子的h严格大于零。符号计算精确核查平衡、临界迹/行列式、非退化和展开秩。四个Hopf例子的第一Lyapunov系数为：

{ht}

各行参数不同，因此不能把Hopf类型的差异直接归因于竞争。M0和M2还给出了K增加导致稳定性丢失的例子。局部周期轨道的存在由非退化Hopf定理支持；长时间波动本身没有被当成全局周期唯一性的证明。完整向量、推导和符号证书均已保存。

## 意外结果和负面发现

固定r与配平增长率会给出方向相反的弱Allee比较，因此不能宣称弱Allee无条件有利。竞争对稳定平衡中捕食者数量的影响也不固定：解析导数的符号取决于猎物人均增长曲线的局部斜率；在强Allee模型中，竞争还可能把同一初值从灭绝盆移入共存盆。

真实数据结果如下，数值越低越好；AICc仅表示训练条件残差的描述性复杂度分数。

{rt}

各留出实验的一步最优模型为 {wintext}。M3的平均一步误差最低，但比M1只低{relgain:.3f}%。四组实验不足以支持稳定的普遍排名。自由外推中，训练均值基线为{macro.loc['training_mean','free_trajectory_nrmse']:.6f}，最佳机制模型均值为{macro.loc[MODELS,'free_trajectory_nrmse'].min():.6f}；机制模型没有超过这个简单基线。

共有{nbound}个拟合动态参数条目接近指定边界，Allee强度/阈值多次到达下界。拟合强Allee阈值A仅为{threshold_range}百万细胞/ml，低于对应训练和留出数据的最小猎物观测值；所有保留观测的猎物最小值为{low_observed:.2f}，因此数据没有直接观测到拟合阈值两侧的跨越。详见real_parameter_identification.csv。C4训练参数剖面有{len(profiles)}行，固定e/beta敏感性有{len(sens)}次拟合。它们显示参数解释依赖假设，不能据此声称识别出了真实的生物Allee阈值；剖面也不是校准过的置信区间。

## 核验、解释与缺口

原包34项文件哈希全部通过。48组更严格合成积分把时域延至800，在共同T=400轨道上的最大尺度误差为{path_err:.3g}，这些抽查的终态标签均未变化。真实数据最终求解器对照高精度DOP853并减半步长，抽查最大标准化误差为{main_err:.3g}。被精度核查淘汰的粗步长轮次保留在logs，最终测试/产物核验见FINAL_VERIFICATION.json。

数学结果说明这些方程能够产生什么行为；合成实验说明给定情景中的条件效应；真实数据预测说明在指定拟合假设下的误差。三者不能互相冒充。两状态模型没有显式表示培养系统的营养、稀释和轮虫阶段结构。Tanner文献中的内禀增长率也不能直接当成本模型的死亡率d，不能据此虚构一套野外参数。

本次交付覆盖研究计划的明确模型、42格分析状态、主效应/交互、冲击恢复、根扫描、整组留出、基线和复杂度分数。42格数学分析中34格done、8格partial；后者对应四个Allee模型的一般多重根参数区域和完整全局/盆地分类。全局周期唯一性、完整同宿曲线和野外动物校准也仍有缺口；具体证据在VERIFICATION_MATRIX.csv中逐项列出。

## 下一步可实施实验

1. 无捕食者条件下测量低密度猎物增长，先分清增长幅度与Allee形状，覆盖候选阈值两侧。
2. 在匹配猎物密度下扰动捕食者密度，区分beta干扰与h直接竞争，并记录营养和稀释条件。
3. 增加完整独立培养实验，在打开测试轨道前固定模型和拟合设置，再比较含营养/阶段结构的模型。
4. 如需完整两参数全局相图，进一步做有验证的延拓和同宿分支计算。

## 阅读与复现

先看本报告，再看RESULTS_BY_HYPOTHESIS.md和VERIFICATION_MATRIX.csv；数学细节见ANALYTICAL_RESULTS.md，方法见SYNTHETIC_METHODS.md和REAL_DATA_METHODS.md。执行 `bash run_complete.sh` 可复现计算、报告、核验与ZIP。英文PDF按原题12pt和不超过25页要求生成；代码/AI说明另存。10分钟汇报提纲见PRESENTATION_10MIN.md，实际口头汇报仍由作者完成。

参考来源：老师原始PDF；[Haque 2011](https://doi.org/10.1016/j.mbs.2011.07.003)；[Cantrell–Cosner 2001](https://www.math.miami.edu/~rsc/docs/2001dynamics.pdf)；[Tanner 1975](https://doi.org/10.2307/1936296)；[Blasius等2020](https://doi.org/10.1038/s41586-019-1857-0)；[Hopf理论讲义](https://webspace.science.uu.nl/~kouzn101/cm/L2.pdf)；[BT非退化条件](https://www.scholarpedia.org/article/Bogdanov-Takens_bifurcation)。文献获取范围和模型原题问题见SOURCE_AND_SCOPE_AUDIT.md。
'''
    (D/'FINAL_REPORT_ZH.md').write_text(zh)
    hypotheses=[
        ('H1','Allee growth changes coexistence, thresholds, and equilibria','Supported conditionally by proofs and synthetic scenarios',
         'ANALYTICAL_RESULTS.md;results/analytical_equilibria.csv;results/extended_factorial.csv;figures/extended_factorial.png',
         'Analytic + synthetic, all six; matched parameter/initial-state design',
         f'Strong growth has axial (A,0) and guaranteed extinction for x0<=A. Sampled weak-vs-logistic tail effect reverses from {effect("same_r","growth_h0","M1","M0"):+.6f} to {effect("reference_growth_matched","growth_h0","M1","M0"):+.6f} after reference calibration.',
         'Not a measured ecological advantage; one reference rate does not match full growth curves.'),
        ('H2','Predator competition changes equilibria and stability','Supported conditionally',
         'results/extended_contrasts.csv;results/analytical_equilibria.csv;results/analytical_bifurcation_witnesses.csv',
         'Analytic + synthetic; M1/M3, M0/M4, M2/M5 with matched other inputs',
         'Stable-branch prey density increases with h; predator-density response follows sign(g prime). Positive-h models have directly certified feasible bifurcations.',
         'Witness regimes are not paired causal tests of Hopf type; branch effects and basin switches differ.'),
        ('H3','Allee and competition effects are not additive','Supported in the sampled design',
         'results/extended_contrasts.csv;results/extended_contrast_summary.csv;figures/extended_factorial.png',
         'Synthetic; difference in paired competition effects; eight sampled regimes x three initial states',
         f'Weak/logistic interaction mean is {effect("same_r","interaction_weak_vs_logistic","M1->M3","M0->M4"):+.6f} at same r and {effect("reference_growth_matched","interaction_weak_vs_logistic","M1->M3","M0->M4"):+.6f} after calibration.',
         'Finite-design descriptive interactions, not a significance test or population estimand.'),
        ('H4','Recovery and basins vary by model','Supported for specified shock protocol',
         'results/extended_shock_recovery.csv;results/extended_basin_boundaries.csv;results/extended_shock_lyapunov_certificates.csv;figures/extended_shock_recovery.png',
         'Synthetic; stable reference; separate prey/predator shocks at fixed parameters',
         f'{rec_n}/48 shocks recover. M2 fails prey removals60/85%, M5 only85%. At fixed y_eq the M2 and M5 boundary brackets are recorded above A=2.',
         'Brackets are along one shock ray, not unique global separatrices; recovery is finite-horizon unless certified.'),
        ('H5','Added structures improve observed ecological prediction','Limited competition gain; no consistent Allee or free-forecast benefit',
         'results/real_benchmark_scores.csv;results/real_nested_validation.csv;results/real_assumption_sensitivity.csv;results/real_parameter_profiles.csv;figures/real_benchmark.png',
         'Observed C1-C4; four whole-experiment test folds, inner held validation, fixed settings',
         f'M3 mean conditional NRMSE {macro.loc["M3","test_nrmse"]:.6f} vs M1 {macro.loc["M1","test_nrmse"]:.6f}; best mechanistic free mean {macro.loc[MODELS,"free_trajectory_nrmse"].min():.6f} vs training mean {macro.loc["training_mean","free_trajectory_nrmse"]:.6f}.',
         'Only four same-medium experiments; many shape bounds active; fixed e/beta; serial residuals; no independent mechanism validation.')]
    hdf=pd.DataFrame(hypotheses,columns=['hypothesis','question','finding','evidence','source_and_split','exact_result','limits'])
    hdf.to_csv(R/'hypothesis_evidence.csv',index=False)
    (D/'RESULTS_BY_HYPOTHESIS.md').write_text('# Results by hypothesis / 按假说列出的证据\n\n'+
        '\n\n'.join(f'## {h}\n\nQuestion: {q}\n\nFinding: {f}\n\nSource and split: {s}\n\nResult: {v}\n\nEvidence: '+e+'\n\nInterpretation limits: '+l for h,q,f,e,s,v,l in hypotheses))
    matrix=[]
    for m in MODELS:
        kind={'M0':'weak','M1':'logistic','M2':'strong','M3':'logistic','M4':'weak','M5':'strong'}[m]
        mf=F[F.model==m]; me=AE[(AE.model==m)&(AE.kind=='positive')];ms=S[S.model==m]
        deg={'M0':3,'M1':2,'M2':3,'M3':3,'M4':5,'M5':5}[m]
        descriptions=[
          ('Q1 positivity, boundedness, permanence','proved; permanence conditional' if kind!='strong' else 'proved; global permanence disproved',
           'Positivity and absorbing bound; lambda_K>0 permanence iff for logistic/weak; x0<=A extinction prevents strong permanence',
           'results/extended_factorial.csv;results/analytical_equilibria.csv',f'{len(mf)} actual long-horizon runs; outcomes {mf.outcome.value_counts().to_dict()}'),
          ('Q2 equilibria and feasibility','unique feasible coexistence criterion proved' if kind=='logistic' else 'exact scalar reduction; general multiplicity-region classification partial',
           f'Axes (0,0),(K,0)'+(',(A,0)' if kind=='strong' else '')+f'; interior degree bound<={deg}, physical filter 0<g<m',
           'results/analytical_equilibria.csv;results/extended_equilibria.csv;results/extended_independent_root_audit.csv',f'{len(me)} positive roots across18 baseline scenarios; root residual maximum {me.rhs_norm.max() if len(me) else 0:.3g}'),
          ('Q3 local stability','proved via exact Jacobian',
           'Exact trace/determinant conditions; axial eigenvalues; logistic interior always stable',
           'results/analytical_equilibria.csv;results/extended_continuation.csv',f'{int((me.max_eig_real<0).sum())}/{len(me)} baseline-scenario positive equilibria strictly stable'),
          ('Q4 global stability and basins','proved global coexistence/axial regimes' if kind=='logistic' else 'sufficient domains proved; unrestricted classification partial',
           'Logistic: GAS interior when lambda_K>0, axial otherwise' if kind=='logistic' else 'Weak: Lyapunov GAS if x*>=K-1/alpha; axial GAS if lambda_K<=0' if kind=='weak' else 'Origin attracts x0<=A; descending-limb coexistence has a certified Lyapunov sublevel',
           'results/extended_shock_recovery.csv;results/extended_shock_lyapunov_certificates.csv;results/extended_basin_boundaries.csv',f'{int(ms.recovered.sum())}/8 specified shocks recover; max observed recovery {ms.recovery_time_2pct.max():.1f}'),
          ('Q5 enrichment','stable-branch sensitivity proved; parameter-specific numerical checks',
           'Both equilibrium states increase with K on a stable branch at fixed alpha/A; stability may change for Allee growth; logistic excludes Hopf',
           'results/extended_continuation.csv;results/extended_continuation_parameters.csv;results/analytical_bifurcation_witnesses.csv;figures/extended_enrichment_hopf.png',
           'All feasible roots evaluated over K grid; local critical examples supplied for Allee models' if kind!='logistic' else 'K sweep stable whenever coexistence exists; general negative-trace proof'),
          ('Q6 local bifurcations','interior SN/Hopf/BT excluded' if kind=='logistic' else 'SN/Hopf/BT feasible with nondegenerate certified witnesses',
           'TC at lambda_K=0 is always forward and nondegenerate: quadratic coefficient B<0 and derivative of lambda_K with respect to d is -1',
           'results/analytical_bifurcation_witnesses.csv;results/analytical_bifurcation_checks.csv;logs/ANALYTICAL_EXACT_CERTIFICATES.json',
           'No feasible interior critical point by sign proof' if kind=='logistic' else f'{len(W[W.model==m])} certified examples; Hopf l1={W[(W.model==m)&(W.event=="Hopf")].l1.iloc[0]:+.8f}'),
          ('Q7 ecological interpretation','conditional interpretation tied to explicit evidence',
           'Growth law, interference through beta, and direct competition through h have distinct effects; measured predictions do not identify mechanisms',
           'results/extended_contrasts.csv;results/real_benchmark_scores.csv',f'Mean held conditional NRMSE {macro.loc[m,"test_nrmse"]:.6f}; free {macro.loc[m,"free_trajectory_nrmse"]:.6f}')]
        for question,status,analytic,evidence,numeric in descriptions:
            matrix.append(dict(model=m,question=question,analytic_status=status,analytic_result=analytic,numerical_result=numeric,
                               evidence=evidence,proof='reports/ANALYTICAL_RESULTS.md',units='synthetic nondimensional; real benchmark days/scaled states',
                               limitation='Claims apply to stated conditions; unrestricted phase/cycle classification and field calibration remain open.'))
    M=pd.DataFrame(matrix)
    authoritative=pd.read_csv(D/'SEVEN_QUESTION_EVIDENCE.csv')
    statuscol=next(k for k in authoritative.columns if k in ['status','completion_status'])
    # This matrix supplements rather than replaces the proof author's 34 done / 8 partial audit.
    M['status']=['partial' if row.model in ['M0','M2','M4','M5'] and row.question.startswith(('Q2','Q4')) else 'done' for row in M.itertuples()]
    assert M.status.value_counts().to_dict()==authoritative[statuscol].value_counts().to_dict()
    M.to_csv(D/'MODEL_QUESTION_MATRIX.csv',index=False)
    (D/'MODEL_QUESTION_MATRIX.md').write_text('# Six models x seven questions\n\n'+
        table(['Model','Question','Analytical status','Numerical result'],M[['model','question','analytic_status','numerical_result']].values.tolist())+
        '\n\nExact evidence and proof links are in MODEL_QUESTION_MATRIX.csv. Q4 conditional results are not full-parameter global classification.\n')
    criteria=[
      ('A exact six-model definition','done','src/experiments.py;tests/test_models.py','M0 teacher equation preserved; no h in M0.'),
      ('A strong growth scaling and alphaK','done','results/extended_parameters.csv;reports/SYNTHETIC_METHODS.md','Same-r and reference-rate arms; alphaK saved.'),
      ('B six models x seven analyses coverage','done','reports/MODEL_QUESTION_MATRIX.csv;reports/SEVEN_QUESTION_EVIDENCE.csv;reports/ANALYTICAL_RESULTS.md','All42 entries carry analytical status and actual numerical evidence;34done8partial, not42solved.'),
      ('B positivity and boundedness','done','reports/ANALYTICAL_RESULTS.md;tests/test_scientific_identities.py','Proofs for all six.'),
      ('B permanence and axial A','done','reports/ANALYTICAL_RESULTS.md;results/analytical_equilibria.csv','Conditional permanence; strong global permanence excluded; A axis explicit.'),
      ('B interior feasibility and local stability','done','src/analytic.py;results/extended_independent_root_audit.csv','Complete scalar reduction, physical filters, exact Jacobian; not interval-certified roots.'),
      ('B general Allee multiplicity-region classification','partial','reports/ANALYTICAL_RESULTS.md;reports/SEVEN_QUESTION_EVIDENCE.csv','Exact feasible scalar conditions and degree bounds supplied; full parameter-region partitions for weak/strong h=0/h>0 remain open.'),
      ('B unrestricted global phase classification','partial','reports/ANALYTICAL_RESULTS.md;results/extended_shock_lyapunov_certificates.csv','Logistic complete; weak/strong sufficient Lyapunov domains and numerical basins; remaining regions unclassified.'),
      ('B global cycle uniqueness and homoclinic curves','partial','reports/ANALYTICAL_RESULTS.md;results/extended_bifurcation_crosschecks.csv','Local Hopf cycles established; no general global uniqueness or validated homoclinic continuation.'),
      ('C three competition pairs','done','results/extended_contrasts.csv','M1/M3, M0/M4, M2/M5 matched.'),
      ('C three growth pairs and interaction','done','results/extended_contrasts.csv;results/extended_contrast_summary.csv','All growth pairs at each h, three differences in differences; outcome/regime strata.'),
      ('D separate initial-state shocks','done','results/extended_shock_recovery.csv','48 runs at fixed parameter reference; four levels x two populations x six models.'),
      ('D strong basin boundary','done','results/extended_basin_boundaries.csv;results/extended_basin_history_M2.csv;results/extended_basin_history_M5.csv','Specified fixed-predator shock ray; T800 bisection checked atT1600.'),
      ('E K h A alpha sweeps and orbits','done','results/extended_continuation.csv;results/extended_continuation_parameters.csv;results/extended_continuation_orbits.csv','Polynomial root grids, nearest-neighbour display labels, local stability and finite orbit diagnostics.'),
      ('E bifurcation feasibility and nondegeneracy','done','results/analytical_bifurcation_witnesses.csv;logs/ANALYTICAL_EXACT_CERTIFICATES.json','12 exact local witnesses; logistic exclusion; TC criterion and degeneracies explicit.'),
      ('F original observed-data provenance','done','results/real_source_verification.csv;data/provenance/original/','Raw source, units, transformations, hashes and release metadata checked.'),
      ('F fair whole-experiment benchmark','done','results/real_folds.csv;results/real_nested_validation.csv;results/real_fit_attempts.csv','Four outer tests and24 inner validation fits; fixed settings; matched training pairs/scales/budgets.'),
      ('F baselines complexity profiles robustness','done','results/real_benchmark_scores.csv;results/real_parameter_profiles.csv;results/real_assumption_sensitivity.csv','One-step and free scores, three baselines, descriptive conditional AICc, training profiles, e/beta sensitivity.'),
      ('Original brief viii vertebrate field parameters','partial','reports/SOURCE_AND_SCOPE_AUDIT.md','No verified full Eq1.1 parameter/measurement mapping from Tanner; synthetic cases and chemostat data are labelled separately.'),
      ('Original brief vii stochastic dynamics','excluded','RESEARCH_PLAN.md;reports/SOURCE_AND_SCOPE_AUDIT.md','Cancelled by teacher; no stochastic dynamics added.'),
      ('Solver and horizon verification','done','results/extended_solver_audit.csv;results/real_solver_audit.csv;logs/FINAL_VERIFICATION.json','Tighter/doubled-horizon synthetic checks and refined real integrator checks; rejected rounds retained.'),
      ('Reproducible bilingual reports and ZIP','done','reports/FINAL_REPORT_EN.md;reports/FINAL_REPORT_ZH.md;run_complete.sh;package_results.py','Reports/matrices/raw results/figures/logs/source and SHA256 included; final packaging independently checked.'),
      ('Original report length and oral preparation','done','reports/FINAL_REPORT_EN.pdf;reports/PRESENTATION_10MIN.md;reports/AI_USE_AND_AUTHOR_REVIEW.md','PDF12pt <=25 pages; ten-minute outline. Actual oral assessment remains human delivery.')]
    Q=pd.DataFrame(criteria,columns=['criterion','status','evidence','scope_or_gap']);Q.to_csv(D/'VERIFICATION_MATRIX.csv',index=False)
    (D/'AI_USE_AND_AUTHOR_REVIEW.md').write_text('''# Code and AI-use documentation\n\nThe user authorized autonomous execution of the supplied Direction2 research plan. Codex inspected and retained the original ZIP, verified its manifest, reran the baseline, derived analytical results, wrote and executed extensions and observation benchmarks, and generated this report. Parallel agents separated mathematics, synthetic computation, and observed-data fitting. The primary agent reviewed their equations, evidence, code, and claims, and added independent balance/Jacobian/Lyapunov checks and artifact audits.\n\nThe submitted original archive is identified by SHA256 `8b5203014d34a444a8454295513cf31db8f0a00ebd79d04ca8bdd3738b30db1b`. No experimental values, field parameter calibrations, or inaccessible literature theorems were invented. All new scenario parameters are explicitly synthetic. Coarse real-solver rounds and an inadmissible early test fixture failure were retained with their corrections.\n\nThis package is a research execution record and draft coursework report. It has not been submitted to a journal, assessment portal, or public repository. The human author should understand and independently review the mathematical arguments and biological interpretation, check the course's AI disclosure format against its student handbook, and take responsibility for any eventual submission. Full global phase and cycle classification and vertebrate calibration are explicitly partial. Oral delivery is not automated.\n\nSource code is in src/ and root run_*.py. Numerical inputs, protocols, exact versions, stdout/stderr, and file hashes are included. The English PDF is the concise main report; detailed proofs, CSVs, and source documentation are separate supporting material.\n''')
    (D/'PRESENTATION_10MIN.md').write_text(f'''# Ten-minute presentation outline / 10分钟汇报提纲\n\nThis is preparation material; the author delivers and adapts the presentation. Use the English main report and the named figures.\n\n| Time | Topic | Evidence and main statement |\n| --- | --- | --- |\n| 0:00-1:00 | Question and exact model | Fix predation, compare3growth laws x2competition states; M0 is unchanged. |\n| 1:00-2:00 | Fair design | Same-r and matched-reference-growth arms; same data partitions and fitting budget. |\n| 2:00-3:30 | What can be proved | Positivity/bounds; invasion threshold; logistic GAS and no interior Hopf/SN/BT; strong A-axis and extinction basin. |\n| 3:30-5:00 | Main effects and interaction | extended_factorial.png; weak-vs-logistic mean predator effect reverses after growth calibration. |\n| 5:00-6:15 | Shock recovery | extended_shock_recovery.png; {rec_n}/48recoveries, strong basin boundaries aboveA and lowered byh in reference. |\n| 6:15-7:15 | Enrichment and bifurcation | extended_enrichment_hopf.png;12certified local bifurcation witnesses, including positiveh; no universal type comparison. |\n| 7:15-8:45 | Observed predictions | real_benchmark.png; M3conditionalNRMSE{macro.loc['M3','test_nrmse']:.4f}; full-trajectory forecasts do not beat training mean. |\n| 8:45-10:00 | Interpretation and next experiment | Distinguish equation properties, synthetic conditional effects, and observed predictions. Measure low-density growth and predator-density responses. |\n\n## Likely questions\n\n1. Why is h absent from M0? Because the displayed teacher equation omits it; only extension arms add it.\n2. Why is alphaK checked? A positive low-density slope requires alphaK>1, not merely alpha>0.\n3. Why can competition increase predator density? Indirect prey release and an increasing growth limb can reverse the stable-branch response; basin switching is another mechanism.\n4. Does a varying tail prove a cycle? No. Local cycles at the named Hopf points follow nondegeneracy and l1; global uniqueness remains open.\n5. Why is the strong recovery boundary aboveA? Predators continue to remove prey after the shock. The reported bracket fixes their initial density at equilibrium.\n6. Why not claim Allee identification from observed fits? Shape/threshold bounds, fixed scale assumptions, omitted chemostat processes, and only4held experiments limit interpretation.\n7. Are Tanner predator growth rates d? No; a measured intrinsic growth rate is not the classroom predator death parameter.\n''')
    summary=dict(extended_trajectories=len(F),conditional_contrasts=len(C),shock_runs=len(S),recoveries=rec_n,
        independent_root_sets=len(IC),bifurcation_witnesses=len(W),model_question_cells=len(M),
        verification_status_counts=Q.status.value_counts().to_dict(),real_macro_scores=macro.to_dict('index'),
        real_bound_entries=nbound,real_profile_rows=len(profiles),real_sensitivity_fits=len(sens),
        synthetic_max_scaled_path_error=float(path_err),real_max_sampled_normalized_error=float(main_err))
    (ROOT/'logs/REPORT_NUMBERS.json').write_text(json.dumps(summary,indent=2))
    print(json.dumps(summary,indent=2))

if __name__=='__main__':main()
