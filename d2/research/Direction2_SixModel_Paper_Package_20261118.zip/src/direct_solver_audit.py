"""Independent direct-state Radau checks of the synthetic log-state DOP853 solver."""
from pathlib import Path
import json
import time
import numpy as np
import pandas as pd
from scipy.integrate import solve_ivp
from .experiments import MODEL_DEFS,make,rhs
from .analytic import jacobian_exact
from .extended_experiments import case_parameters,positive_roots,root_record,simulate


def run(root):
    root=Path(root);started=time.time();rows=[]
    base=case_parameters()[10]
    for model in MODEL_DEFS:
        p=make(base,model)
        stable=[z for z in positive_roots(p) if root_record(p,z)['stability']=='stable']
        eq=max(stable,key=lambda z:z[0])
        starts=[('stable_equilibrium_perturbed',eq*np.array([.75,.9])),
                ('low_prey_common_initial',np.array([.1*p['K'],.8]))]
        for initial,z0 in starts:
            ts,logz,logn=simulate(p,z0,T=80,step=.5,rtol=1e-10,atol=1e-12,max_step=.35)
            direct=solve_ivp(lambda t,z:rhs(z,p),(0,80),z0,method='Radau',
                jac=lambda t,z:jacobian_exact(p,z),t_eval=ts,
                rtol=1e-10,atol=1e-12,max_step=.35)
            if not direct.success or len(direct.t)!=len(ts):
                raise RuntimeError(model+' direct Radau failed: '+direct.message)
            z=direct.y.T
            scale=np.maximum(np.max(logz,axis=0),.1)
            err=np.max(np.abs(z-logz)/scale)
            minimum=np.min(z)
            positivity=bool(minimum>=-1e-11)
            agreement=bool(err<2e-7)
            rows.append({'model':model,'initial_case':initial,'x0':z0[0],'y0':z0[1],
                'T':80.,'sample_step':.5,'rtol':1e-10,'atol':1e-12,'max_step':.35,
                'reference_method':'DOP853_log_state','audit_method':'Radau_direct_state',
                'max_scaled_path_error':err,'direct_min_population':minimum,
                'direct_negative_excursion':max(0.,-minimum),
                'positivity_absolute_tolerance':1e-11,
                'positivity_within_tolerance':positivity,'path_agreement_threshold':2e-7,
                'path_agreement':agreement,'pass':positivity and agreement,
                'direct_x_final':z[-1,0],'direct_y_final':z[-1,1],
                'log_x_final':logz[-1,0],'log_y_final':logz[-1,1],
                'direct_nfev':direct.nfev,'log_nfev':logn,
                'data_kind':'synthetic_dimensionless',
                'strong_subthreshold_case':bool(p['allee']=='strong' and z0[0]<p['A'])})
    df=pd.DataFrame(rows);df.to_csv(root/'results/direct_solver_audit.csv',index=False)
    status={'status':'passed' if df['pass'].all() else 'failed',
            'cases':len(df),'passed':int(df['pass'].sum()),
            'max_scaled_path_error':float(df.max_scaled_path_error.max()),
            'largest_direct_negative_excursion':float(df.direct_negative_excursion.max()),
            'strong_subthreshold_cases':int(df.strong_subthreshold_case.sum()),
            'elapsed_seconds':time.time()-started,
            'interpretation':'Direct-state signed roundoff below atol is recorded, not relabelled as a biological negative population.',
            'parameters':'results/extended_parameters.csv:scenario10,scaling same_r',
            'independent_features':'Different state coordinates and solver families; exact Jacobian supplied only to Radau.'}
    (root/'logs/DIRECT_SOLVER_AUDIT.json').write_text(json.dumps(status,indent=2))
    print(json.dumps(status,indent=2))
    if status['status']!='passed':raise RuntimeError('Independent direct solver audit failed')
    return status
