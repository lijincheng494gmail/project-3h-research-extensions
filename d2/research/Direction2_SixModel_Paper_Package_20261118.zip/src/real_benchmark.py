"""Reproducible held-experiment benchmark for the fixed six-model design.
Conditional predictions start from the preceding observed state. Free forecasts
use only the held experiment's first observed state. No test fitting or tuning.
"""
from __future__ import annotations
from pathlib import Path
import argparse, hashlib, json, platform, time
import numpy as np
import pandas as pd
from scipy.optimize import least_squares
from scipy.integrate import solve_ivp
from .experiments import MODEL_DEFS, make, rhs, getpairs
from .core import integrate

STATE_COLS=['prey_million_cells_per_ml','predator_20_animals_per_ml']
DEFAULT={'r':.55,'K':1.2,'m':.85,'d':.5,'u':.6,'fA':.2,'h':.12}
BOUNDS={'r':(.01,4.),'K':(.12,8.),'m':(.03,10.),'d':(.01,4.),
        'u':(.001,5.),'fA':(.005,.7),'h':(.00001,3.)}
PROTOCOL={'seed':20261118,'starts':2,'max_nfev':100,'step':.00625,'solver_normalized_acceptance':.0001,
 'fixed_e':.65,'fixed_beta':1.2,'residual':'untransformed populations / training target SD',
 'bounds':BOUNDS,'outer_folds':['C1','C2','C3','C4'],
 'hyperparameters':'fixed before held-data scoring; no validation-selected hyperparameters',
 'sensitivity_folds':['C4'],'sensitivity_fixed_pairs':[[.325,1.2],[1.3,1.2],[.65,.6],[.65,2.4]],
 'profile_fold':'C4','profile_grid_multipliers':[.5,.75,1.,1.5,2.],
 'profile_max_nfev':60,'profile_kind':'reoptimized nuisance parameters; objective profile, not a confidence interval'}


def names_for(model):
    kind,competition=MODEL_DEFS[model]
    return ['r','K','m','d']+(['u'] if kind=='weak' else [])+(['fA'] if kind=='strong' else [])+(['h'] if competition else [])


def decode(theta,model,e=.65,beta=1.2):
    names=names_for(model);q={**DEFAULT,**dict(zip(names,np.exp(theta)))}
    return make(dict(r=q['r'],K=q['K'],m=q['m'],d=q['d'],alpha=(1+q['u'])/q['K'],
                     A=q['fA']*q['K'],h=q['h'],e=e,beta=beta),model)


def batch_next(xy,dt,p,step=.00625):
    """Vector RK4 in log coordinates; every retained gap uses its actual duration.

    No interpolation: a skipped missing observation gives a longer ODE interval.
    The finite log guard is only for invalid optimization trials; solver audit
    compares final fits with unguarded positive-state DOP853 integration.
    """
    xy=np.asarray(xy,float);dt=np.asarray(dt,float)
    if xy.ndim!=2 or xy.shape[1]!=2 or len(xy)!=len(dt) or np.any(xy<=0) or np.any(dt<=0):
        raise ValueError('positive states and durations required')
    n=np.maximum(1,np.ceil(dt/step).astype(int));h=dt/n
    u=np.log(xy)
    def f(v):
        x=np.exp(np.clip(v[:,0],-690,30));y=np.exp(np.clip(v[:,1],-690,30))
        g=p['r']*(1-x/p['K'])
        if p['allee']=='weak':g=g*(1+p['alpha']*x)
        elif p['allee']=='strong':g=g*(x/p['A']-1)
        return np.column_stack([g-p['m']*y/(p['beta']+y),p['e']*p['m']*x/(p['beta']+y)-p['d']-p['h']*y])
    with np.errstate(over='ignore',invalid='ignore'):
        for i in range(int(n.max())):
            active=np.flatnonzero(i<n);v=u[active];s=h[active,None]
            k1=f(v);k2=f(v+k1*s/2);k3=f(v+k2*s/2);k4=f(v+k3*s)
            u[active]=v+s*(k1+2*k2+2*k3+k4)/6
            if np.any(~np.isfinite(u)) or np.any(u>30):
                return np.full_like(xy,1e8)
    return np.exp(np.clip(u,-690,30))


def make_train(frames,held):
    train=[c for c in frames if c!=held]
    pairs=[getpairs(frames[c]) for c in train]
    X=np.concatenate([v[0] for v in pairs]);DT=np.concatenate([v[1] for v in pairs]);Y=np.concatenate([v[2] for v in pairs])
    scale=np.maximum(np.std(Y,axis=0,ddof=0),.1)
    return train,X,DT,Y,scale


def metrics(Y,pred,scale):
    err=pred-Y;rm=np.sqrt(np.mean(err*err,axis=0));norm=rm/scale
    return dict(nrmse=float(np.mean(norm)),rmse_prey=float(rm[0]),rmse_predator=float(rm[1]),
                normalized_rmse_prey=float(norm[0]),normalized_rmse_predator=float(norm[1]),
                standardized_sse=float(np.sum((err/scale)**2)))


def fit_one(model,X,DT,Y,scale,starts=2,max_nfev=100,e=.65,beta=1.2,step=.00625,seed=20261118,initial=None,fixed=None):
    names=names_for(model);lb=np.log([BOUNDS[n][0] for n in names]);ub=np.log([BOUNDS[n][1] for n in names])
    x0=np.log([DEFAULT[n] for n in names]) if initial is None else np.asarray(initial).copy()
    x0=np.clip(x0,lb+1e-8,ub-1e-8)
    fixed={} if fixed is None else fixed
    free=np.asarray([i for i,n in enumerate(names) if n not in fixed],int)
    for n,v in fixed.items():x0[names.index(n)]=np.log(v)
    rng=np.random.default_rng(seed)
    trials=[x0]+[np.clip(x0+rng.uniform(-.7,.7,len(x0)),lb+1e-6,ub-1e-6) for _ in range(starts-1)]
    attempts=[];best=None;calls=0
    def unpack(v):
        t=x0.copy();t[free]=v;return t
    def fun(v):
        nonlocal calls
        calls+=1
        pred=batch_next(X,DT,decode(unpack(v),model,e,beta),step)
        r=((pred-Y)/scale).ravel()
        return np.nan_to_num(np.clip(r,-1e7,1e7),nan=1e7,posinf=1e7,neginf=-1e7)
    for s,t in enumerate(trials):
        t0=time.monotonic();before=calls
        fit=least_squares(fun,t[free],bounds=(lb[free],ub[free]),max_nfev=max_nfev,
                          xtol=1e-7,ftol=1e-7,gtol=1e-6)
        theta=unpack(fit.x);score=float(np.dot(fit.fun,fit.fun))
        attempts.append(dict(start=s,success=bool(fit.success),status=int(fit.status),nfev=int(fit.nfev),
                             residual_calls=calls-before,sse=score,optimality=float(fit.optimality),
                             message=fit.message,wall_seconds=time.monotonic()-t0))
        if best is None or score<best['sse']:
            best=dict(theta=theta,p=decode(theta,model,e,beta),sse=score,success=bool(fit.success),
                      status=int(fit.status),optimality=float(fit.optimality),selected_start=s,
                      active_bounds=int(np.count_nonzero(fit.active_mask)),jac=fit.jac)
    best['attempts']=attempts
    return best


def solve_next_dop853(xy,dt,p):
    u0=np.log(xy)
    def f(_,u):
        z=np.exp(np.clip(u,-690,100));x,y=z
        return np.asarray([p['r']*(1-x/p['K'])*(1+p['alpha']*x if p['allee']=='weak' else (x/p['A']-1 if p['allee']=='strong' else 1))-p['m']*y/(p['beta']+y),
                           p['e']*p['m']*x/(p['beta']+y)-p['d']-p['h']*y])
    sol=solve_ivp(f,(0,float(dt)),u0,method='DOP853',rtol=1e-11,atol=1e-13,max_step=.05)
    if not sol.success:raise RuntimeError(sol.message)
    return np.exp(sol.y[:,-1])


def run(root,main=True,sensitivity=True,profile=True):
    root=Path(root);start=time.time()
    for d in ['results','reports','logs','figures','configs']:(root/d).mkdir(exist_ok=True)
    (root/'configs/REAL_BENCHMARK_PROTOCOL.json').write_text(json.dumps(PROTOCOL,indent=2))
    frames={f'C{i}':pd.read_csv(root/f'data/real/C{i}.csv') for i in range(1,5)}
    scores=[];parameters=[];attempts=[];predictions=[];audit=[];folds=[];cache={};profile_rows=[]
    for held,df in frames.items():
        train,X,DT,Y,scale=make_train(frames,held)
        folds.append(dict(held=held,train=';'.join(train),train_pairs=len(X),test_pairs=len(df)-1,
                          train_scale_x=scale[0],train_scale_y=scale[1],train_max_gap_days=DT.max(),
                          train_pairs_over_1_5_days=int(np.count_nonzero(DT>1.5)),test_max_gap_days=np.diff(df.time_days).max(),
                          train_pair_sha256=hashlib.sha256(np.column_stack([X,DT,Y]).tobytes()).hexdigest()))
        XX,T,YY=getpairs(df);times=df.time_days.to_numpy();zz=df[STATE_COLS].to_numpy()
        if main:
            for model in MODEL_DEFS:
                print('FIT',held,model,flush=True)
                fit=fit_one(model,X,DT,Y,scale,starts=PROTOCOL['starts'],max_nfev=PROTOCOL['max_nfev'])
                cache[(held,model)]=fit
                pred=batch_next(XX,T,fit['p']);train_pred=batch_next(X,DT,fit['p'])
                mm=metrics(YY,pred,scale);tm=metrics(Y,train_pred,scale)
                try:
                    free=integrate(rhs,fit['p'],times,zz[0],rtol=1e-10,atol=1e-12)[1:]
                    fm=metrics(YY,free,scale);free_ok=True
                except Exception as exc:
                    free=np.full_like(YY,np.nan);fm={'nrmse':np.nan};free_ok=False
                k=len(names_for(model));N=Y.size;kall=k+1
                aic=N*np.log(max(tm['standardized_sse']/N,1e-300))+2*kall
                aicc=aic+2*kall*(kall+1)/(N-kall-1)
                svals=np.linalg.svd(fit['jac'],compute_uv=False)
                row=dict(held=held,model=model,data_kind='observed_algae_rotifer',forecast='one_step_conditional',
                         train_pairs=len(X),test_pairs=len(XX),k_dynamic=k,k_including_variance=kall,
                         train_nrmse=tm['nrmse'],test_nrmse=mm['nrmse'],test_rmse_prey=mm['rmse_prey'],test_rmse_predator=mm['rmse_predator'],
                         test_normalized_rmse_prey=mm['normalized_rmse_prey'],test_normalized_rmse_predator=mm['normalized_rmse_predator'],
                         train_standardized_sse=tm['standardized_sse'],conditional_AIC=aic,conditional_AICc=aicc,
                         free_trajectory_nrmse=fm['nrmse'],free_solver_success=free_ok,fit_success=fit['success'],
                         fit_status=fit['status'],selected_start=fit['selected_start'],active_bounds=fit['active_bounds'],
                         jacobian_condition_number=float(svals[0]/max(svals[-1],1e-300)),fixed_e=.65,fixed_beta=1.2)
                scores.append(row)
                for a in fit['attempts']:attempts.append(dict(held=held,model=model,**a))
                for n,v in zip(names_for(model),np.exp(fit['theta'])):
                    parameters.append(dict(held=held,model=model,parameter=n,role='fitted',value=float(v),lower=BOUNDS[n][0],upper=BOUNDS[n][1],
                                           at_bound=bool(np.isclose(v,BOUNDS[n][0],rtol=.002) or np.isclose(v,BOUNDS[n][1],rtol=.002))))
                parameters.extend([dict(held=held,model=model,parameter=n,role=('fixed_scale_assumption' if n in ['e','beta'] else ('derived_active' if ((n=='alpha' and MODEL_DEFS[model][0]=='weak') or (n=='A' and MODEL_DEFS[model][0]=='strong')) else 'inactive_not_used')),value=fit['p'][n],lower=np.nan,upper=np.nan,at_bound=False) for n in ['alpha','A','e','beta']])
                for i in range(len(XX)):
                    predictions.append(dict(held=held,model=model,time_from=float(times[i]),time_to=float(times[i+1]),gap_days=float(T[i]),
                      observed_x=YY[i,0],observed_y=YY[i,1],conditioned_x=XX[i,0],conditioned_y=XX[i,1],
                      predicted_x=pred[i,0],predicted_y=pred[i,1],free_predicted_x=free[i,0],free_predicted_y=free[i,1]))
                # Deterministic audit samples include longest gap, lowest x, lowest y, and evenly spread intervals.
                indices=np.unique(np.r_[np.linspace(0,len(XX)-1,8).astype(int),np.argmax(T),np.argmin(XX[:,0]),np.argmin(XX[:,1])])
                half=batch_next(XX[indices],T[indices],fit['p'],.003125)
                for j,i in enumerate(indices):
                    ref=solve_next_dop853(XX[i],T[i],fit['p'])
                    audit.append(dict(held=held,model=model,pair_index=int(i),gap_days=T[i],main_step=.00625,half_step=.003125,
                       max_abs_error_main_step=float(np.max(np.abs(pred[i]-ref))),
                       max_normalized_error_main_step=float(np.max(np.abs(pred[i]-ref)/scale)),
                       max_abs_error_half_step=float(np.max(np.abs(half[j]-ref))),
                       max_normalized_error_half_step=float(np.max(np.abs(half[j]-ref)/scale))))
                pd.DataFrame(scores).to_csv(root/'results/real_benchmark_scores.csv',index=False)
                (root/'logs/REAL_FIT_CACHE.json').write_text(json.dumps({f'{h}/{m}':{'theta':f['theta'].tolist(),'p':f['p'],'sse':f['sse']} for (h,m),f in cache.items()},indent=2))
            # Test observations enter scoring only; all baseline constants use training observations.
            targetmean=Y.mean(0);drift=np.mean((Y-X)/DT[:,None],axis=0)
            for name,pred,free in [('persistence',XX,np.repeat(zz[:1],len(XX),axis=0)),
                                 ('training_mean',np.repeat(targetmean[None,:],len(XX),axis=0),np.repeat(targetmean[None,:],len(XX),axis=0)),
                                 ('training_drift',np.maximum(XX+T[:,None]*drift,0),np.maximum(zz[0]+(times[1:]-times[0])[:,None]*drift,0))]:
                mm=metrics(YY,pred,scale);fm=metrics(YY,free,scale)
                scores.append(dict(held=held,model=name,data_kind='observed_algae_rotifer',forecast='baseline',train_pairs=len(X),test_pairs=len(XX),
                                   test_nrmse=mm['nrmse'],test_rmse_prey=mm['rmse_prey'],test_rmse_predator=mm['rmse_predator'],
                                   test_normalized_rmse_prey=mm['normalized_rmse_prey'],test_normalized_rmse_predator=mm['normalized_rmse_predator'],free_trajectory_nrmse=fm['nrmse']))
            for fname,rows in [('real_benchmark_scores.csv',scores),('real_benchmark_parameters.csv',parameters),('real_fit_attempts.csv',attempts),
                               ('real_predictions.csv',predictions),('real_solver_audit.csv',audit),('real_folds.csv',folds)]:
                pd.DataFrame(rows).to_csv(root/'results'/fname,index=False)
    if not main:
        saved=json.loads((root/'logs/REAL_FIT_CACHE.json').read_text())
        cache={(key.split('/')[0],key.split('/')[1]):dict(theta=np.asarray(v['theta']),p=v['p'],sse=v['sse']) for key,v in saved.items()}
    held='C4';train,X,DT,Y,scale=make_train(frames,held);XX,T,YY=getpairs(frames[held])
    sensitivity_rows=[]
    if sensitivity:
        for e,beta in PROTOCOL['sensitivity_fixed_pairs']:
            for model in MODEL_DEFS:
                print('SENSITIVITY',e,beta,model,flush=True)
                fit=fit_one(model,X,DT,Y,scale,starts=2,max_nfev=100,e=e,beta=beta,initial=cache[(held,model)]['theta'])
                pred=batch_next(XX,T,fit['p']);mm=metrics(YY,pred,scale)
                audit_ids=np.unique([int(np.argmax(T)),int(np.argmin(XX[:,0])),int(np.argmin(XX[:,1]))])
                audit_error=max(float(np.max(np.abs(pred[i]-solve_next_dop853(XX[i],T[i],fit['p']))/scale)) for i in audit_ids)
                sensitivity_rows.append(dict(held=held,model=model,fixed_e=e,fixed_beta=beta,test_nrmse=mm['nrmse'],
                                              training_sse=fit['sse'],fit_success=fit['success'],max_sampled_DOP853_normalized_error=audit_error,
                                              parameter_json=json.dumps({n:float(v) for n,v in zip(names_for(model),np.exp(fit['theta']))}),
                                              status='prespecified_assumption_sensitivity_not_test_tuning'))
                pd.DataFrame(sensitivity_rows).to_csv(root/'results/real_assumption_sensitivity.csv',index=False)
    if profile:
        for model in MODEL_DEFS:
            best=cache[(held,model)]
            profiled=['r']+(['h'] if MODEL_DEFS[model][1] else (['fA'] if MODEL_DEFS[model][0]=='strong' else ['K']))
            for parameter in profiled:
                center=float(np.exp(best['theta'][names_for(model).index(parameter)]))
                vals=np.unique(np.clip(center*np.asarray(PROTOCOL['profile_grid_multipliers']),BOUNDS[parameter][0],BOUNDS[parameter][1]))
                for v in vals:
                    print('PROFILE',model,parameter,v,flush=True)
                    if np.isclose(v,center):sse=best['sse'];success=True
                    else:
                        fit=fit_one(model,X,DT,Y,scale,starts=1,max_nfev=60,initial=best['theta'],fixed={parameter:float(v)})
                        sse=fit['sse'];success=fit['success']
                    profile_rows.append(dict(held=held,model=model,parameter=parameter,value=float(v),reference_value=center,
                                              profile_sse=sse,reference_sse=best['sse'],relative_sse_change=sse/best['sse']-1,
                                              nuisance_fit_success=success,refit_performed=bool(not np.isclose(v,center)),interpretation='objective profile; no calibrated CI'))
                    pd.DataFrame(profile_rows).to_csv(root/'results/real_parameter_profiles.csv',index=False)
    if (root/'results/real_benchmark_scores.csv').exists():
        plot_results(root)
    (root/'logs/REAL_RUN_STATUS.json').write_text(json.dumps(dict(state='completed',main_ran=main,sensitivity_ran=sensitivity,
      profiles_ran=profile,wall_seconds=time.time()-start,protocol=PROTOCOL,python=platform.python_version(),
      caveats=['Only four held experiments; same medium.','Serial correlation makes conditional AICc descriptive.',
               'Parameter bounds and fixed e/beta are modeling assumptions, not measured truths.']),indent=2))
    print('REAL BENCHMARK DONE',time.time()-start,flush=True)


def plot_results(root):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    scores=pd.read_csv(root/'results/real_benchmark_scores.csv')
    order=list(MODEL_DEFS)+['persistence','training_mean','training_drift']
    colors=['#1F1E33','#4F4A70','#77718E','#2E756D','#5C9B91','#88B5AD','#B2A8B9','#C6BAC9','#DDD2DE']
    fig,axes=plt.subplots(1,2,figsize=(13,4.7))
    for ax,col,title in [(axes[0],'test_nrmse','Held experiment: one-step conditional'),(axes[1],'free_trajectory_nrmse','Held experiment: forecast from first state')]:
        for j,m in enumerate(order):
            vals=scores[scores.model==m][col].to_numpy()
            ax.bar(j,np.mean(vals),color=colors[j],width=.75)
            ax.scatter(j+np.linspace(-.16,.16,len(vals)),vals,s=17,color='#1F1E33',edgecolor='white',linewidth=.3,zorder=4)
        ax.set_xticks(range(len(order)),order,rotation=40,ha='right',fontsize=8)
        ax.set_ylabel('Normalized RMSE (training scales)');ax.set_title(title,fontsize=11)
    fig.suptitle('Real algae / rotifer observations; bars = four-fold mean, dots = held experiments',fontsize=11)
    fig.tight_layout();fig.savefig(root/'figures/real_benchmark.png',dpi=190);plt.close(fig)
    preds=pd.read_csv(root/'results/real_predictions.csv');part=preds[(preds.held=='C4')&(preds.model=='M1')]
    fig,axes=plt.subplots(2,1,figsize=(10,6),sharex=True)
    for ax,state,unit in [(axes[0],'x','Algae (10^6 cells/ml)'),(axes[1],'y','Rotifers (20 animals/ml)')]:
        ax.plot(part.time_to,part['observed_'+state],'.',color='#1F1E33',label='Observed',markersize=3)
        ax.plot(part.time_to,part['predicted_'+state],color='#2E756D',label='One step; prior observed state',linewidth=.9)
        ax.plot(part.time_to,part['free_predicted_'+state],color='#C38445',label='Only first observed state',linewidth=1)
        ax.set_ylabel(unit);ax.legend(fontsize=8,ncol=3)
    axes[0].set_title('C4, prespecified M1 illustration; parameters fitted on C1-C3')
    axes[-1].set_xlabel('Time (days)');fig.tight_layout();fig.savefig(root/'figures/real_C4_forecasts.png',dpi=190);plt.close(fig)


if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]);a.add_argument('--only',choices=['all','main','extras'],default='all');v=a.parse_args()
    run(v.root,main=v.only!='extras',sensitivity=v.only!='main',profile=v.only!='main')
