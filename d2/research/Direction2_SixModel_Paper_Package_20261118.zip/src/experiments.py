"""Direction 2: M0=teacher original, 3 Allee classes x 2 predator competition states."""
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.optimize import least_squares
from .core import integrate,eq_table,end_label,dumpcsv,rmse,write_status,save_report
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

MODEL_DEFS={
 'M0':('weak',False), 'M1':('logistic',False), 'M2':('strong',False),
 'M3':('logistic',True), 'M4':('weak',True), 'M5':('strong',True)
}

def prey_per_capita(x,p,kind):
    g=p['r']*(1-x/p['K'])
    if kind=='weak':return g*(1+p['alpha']*x)
    if kind=='strong':return g*(x/p['A']-1)
    return g

def rhs(z,p):
    x,y=z
    den=p['beta']+y
    food=p['m']*x*y/den
    return np.asarray([x*prey_per_capita(x,p,p['allee'])-food,
                    p['e']*food-p['d']*y-p['h']*y*y])

def make(base,model):
    p=dict(base);name,competition=MODEL_DEFS[model]
    p['allee']=name
    if not competition:p['h']=0.
    if name=='logistic':p['alpha']=0.
    if name=='strong':p['alpha']=0.
    return p

def sample_cases(n,seed=2026):
    g=np.random.default_rng(seed)
    out=[]
    for i in range(n):
        K=float(g.uniform(5.,11.))
        out.append(dict(scenario=i,r=float(g.uniform(.5,.95)),K=K,
            alpha=float(g.uniform(1.2,2.6)/K),A=float(g.uniform(.17,.35)*K),
            beta=float(g.uniform(.8,2)),m=float(g.uniform(.3,.65)),e=.65,
            d=float(g.uniform(.17,.35)),h=float(g.uniform(.015,.095))))
    return out

def batch_next(xy,dt,p):
    xy=np.asarray(xy);dt=np.asarray(dt)
    n=np.maximum(1,np.ceil(dt/.1).astype(int));h=dt/n
    u=np.log(np.maximum(xy,1e-11))
    def f(uv):
        x=np.exp(np.clip(uv[:,0],-40,20));y=np.exp(np.clip(uv[:,1],-40,20))
        den=p['beta']+y
        return np.column_stack([prey_per_capita(x,p,p['allee'])-p['m']*y/den,
          p['e']*p['m']*x/den-p['d']-p['h']*y])
    for i in range(int(np.max(n))):
        step=np.where(i<n,h,0.)[:,None]
        k1=f(u);k2=f(u+k1*step/2);k3=f(u+k2*step/2);k4=f(u+k3*step)
        u+=(k1+2*k2+2*k3+k4)*step/6
    return np.exp(np.clip(u,-40,20))

def getpairs(df):
    z=df[['prey_million_cells_per_ml','predator_20_animals_per_ml']].to_numpy()
    return z[:-1],np.diff(df.time_days.to_numpy()),z[1:]

def fit_real(root,full):
    frames={f'C{i}':pd.read_csv(root/f'data/real/C{i}.csv') for i in range(1,5)}
    rows=[]; folds=list(frames) if full else ['C4']
    for held in folds:
        pairs=[getpairs(df) for c,df in frames.items() if c!=held]
        X=np.concatenate([z[0] for z in pairs]); DT=np.concatenate([z[1] for z in pairs]); Y=np.concatenate([z[2] for z in pairs])
        # Fixed training-only subsample for starter optimization budget; all held-out observations are scored.
        sub=np.unique(np.linspace(0,len(X)-1,min(180,len(X))).astype(int))
        X=X[sub]; DT=DT[sub]; Y=Y[sub]
        XX,T,Yval=getpairs(frames[held]);scale=np.maximum(np.std(Y,axis=0),.1)
        for model in MODEL_DEFS:
            kind,competition=MODEL_DEFS[model]
            names=['r','K','m','d']+(['u'] if kind=='weak' else [])+(['fA'] if kind=='strong' else [])+(['h'] if competition else [])
            default={'r':.55,'K':1.2,'m':.85,'d':.5,'u':.6,'fA':.25,'h':.12}
            limits={'r':(.02,2.5),'K':(.12,6.),'m':(.03,7.),'d':(.02,3.),
                    'u':(.05,3.),'fA':(.10,.48),'h':(.005,1.5)}
            lb=np.log([limits[k][0] for k in names]);ub=np.log([limits[k][1] for k in names]);x0=np.log([default[k] for k in names]);
            def decode(logtheta):
                dd={**default,**dict(zip(names,np.exp(logtheta)))}
                param={'r':dd['r'],'K':dd['K'],'m':dd['m'],'beta':1.2,'e':.65,
                       'd':dd['d'],'alpha':(1+dd['u'])/dd['K'],'A':dd['fA']*dd['K'],'h':dd['h']}
                return make(param,model)
            def fun(xx):
                try:yp=batch_next(X,DT,decode(xx));v=((yp-Y)/scale).ravel()
                except Exception:return np.ones(Y.size)*1e5
                return np.where(np.isfinite(v),np.clip(v,-1e5,1e5),1e5)
            seeds=[x0]
            fits=[least_squares(fun,seed,bounds=(lb,ub),max_nfev=18) for seed in seeds]
            best=min(fits,key=lambda f:np.sum(f.fun**2))
            pv=decode(best.x);pred=batch_next(XX,T,pv)
            rows.append({'held_experiment':held,'model':model,'test_next_step_nrmse':rmse(Yval,pred,scale),
              'fit_success':bool(best.success),'model_parameters':repr({k:round(v,5) for k,v in pv.items() if isinstance(v,(int,float,np.floating))}),
              'real_observation_count':len(Yval),'data_kind':'observed_algae_rotifer'})
        rows.append({'held_experiment':held,'model':'last_observation',
                     'test_next_step_nrmse':rmse(Yval,XX,scale),'fit_success':True,
                     'model_parameters':'none','real_observation_count':len(Yval),'data_kind':'observed_algae_rotifer'})
    return rows

def run(root,mode):
    root=Path(root);full=mode=='full'
    cases=sample_cases(18 if full else 5)
    traj_rows=[];eqrows=[];differences=[];traces=[]
    times=np.linspace(0,70,301 if full else 201)
    for base in cases:
        timescale=base['K']
        initial=[(.75*timescale,.8),(.11*timescale,.8),(.85*timescale,2.3),(.3*timescale,.3)] if full else [(.75*timescale,.8),(.11*timescale,.8)]
        for idx,z0 in enumerate(initial):
            by_model={}
            for model in MODEL_DEFS:
                p=make(base,model)
                z=integrate(rhs,p,times,z0)
                tail=z[int(.75*len(z)):]
                row={'scenario':base['scenario'],'initial':idx,'model':model,
                     'x_final':z[-1,0],'y_final':z[-1,1],'y_mean_tail':np.mean(tail[:,1]),
                     'x_span_tail':np.ptp(tail[:,0]),'y_span_tail':np.ptp(tail[:,1]),
                     'label':end_label(z,times)}
                traj_rows.append(row);by_model[model]=row
                if base['scenario']==0 and idx==0:
                    for j in range(0,len(times),max(1,len(times)//80)):
                        traces.append({'model':model,'time':times[j],'x':z[j,0],'y':z[j,1]})
            for no,yes in [('M1','M3'),('M0','M4'),('M2','M5')]:
                differences.append({'scenario':base['scenario'],'initial':idx,'without':no,'with':yes,
                     'change_y_mean_tail':by_model[yes]['y_mean_tail']-by_model[no]['y_mean_tail']})
            differences.append({'scenario':base['scenario'],'initial':idx,'without':'M1_to_M3','with':'M2_to_M5',
                 'change_y_mean_tail':(by_model['M5']['y_mean_tail']-by_model['M2']['y_mean_tail'])-
                                       (by_model['M3']['y_mean_tail']-by_model['M1']['y_mean_tail'])})
        for model in MODEL_DEFS:
            p=make(base,model)
            eqrows +=[{'scenario':base['scenario'],**row} for row in eq_table(rhs,model,p,base['K']*1.2,6.)]
    df=dumpcsv(root,'six_model_finite_horizon.csv',traj_rows)
    dumpcsv(root,'six_model_numerical_equilibrium_candidates.csv',eqrows)
    dumpcsv(root,'six_model_mechanism_contrasts.csv',differences)
    dumpcsv(root,'synthetic_parameter_scenarios.csv',cases)
    T=dumpcsv(root,'six_model_example_trajectories.csv',traces)
    R=dumpcsv(root,'six_model_real_data_prediction.csv',fit_real(root,full))
    fig,ax=plt.subplots(figsize=(8,4.5))
    for model,part in T.groupby('model'):
        ax.plot(part.time,part.y,label=model)
    ax.set(xlabel='Dimensionless time',ylabel='Predator y',title='Six-model matched initial-state comparison (synthetic)')
    ax.legend(ncol=3,fontsize=8);fig.tight_layout();fig.savefig(root/'figures/six_model_trajectories.png',dpi=180);plt.close(fig)
    fig,ax=plt.subplots(figsize=(8.8,4.2))
    r=R[R.held_experiment==('C4' if not full else 'C1')]
    ax.bar(r.model,r.test_next_step_nrmse,color=['#1F1E33']*6+['#ABA8BA'])
    ax.set(ylabel='Test normalized RMSE',title='REAL algae/rotifer observations: six-model next-step pilot')
    fig.tight_layout();fig.savefig(root/'figures/six_model_real_data.png',dpi=180);plt.close(fig)
    save_report(root,'方向二：六模型 3×2 设计 / Six-model factorial comparison',
      '在固定 Foraging-arena 捕食函数的条件下，无/弱/强 Allee 和有/无捕食者种内竞争如何改变共存、恢复与稳定？',
      'M0=老师原模型(weak, no h); M1=Logistic/no h; M2=strong/no h; M3=Logistic/h; M4=weak/h; M5=strong/h。共同参数、初值配对；数值候选平衡点、固定时域轨道与三对种内竞争差值。C1–C4 实测藻类/轮虫时间序列作为同条件下一步预测对照。',
      f'本轮生成 {len(df)} 条配对轨道、{len(eqrows)} 条数值内部平衡候选、{len(differences)} 条配对机制差值、{len(R)} 条真实数据预测评分。各模型相同输入的变化可在 CSV 中逐行核对。',
      'Codex 全量：六模型七项数学分析与解析证明；强 Allee 的边界阈值及盆地；大冲击恢复与分岔；嵌套模型比较；所有真实 C1–C4 留出并进行误差/复杂度分析。',
      '人工设置的模型情景不是实测；根仅为数值候选；末段有波动不等于已经证明周期轨道。')
    write_status(root,mode,{'paired_trajectories':len(df),'numeric_equilibria':len(eqrows),
      'mechanism_contrasts':len(differences),'real_scores':len(R)},
      'M0 exactly follows Eq. 1.1; M4/M3/M5 add -h y^2. Fixed e/beta in empirical pilot; cannot infer measured conversion rates from it.')
