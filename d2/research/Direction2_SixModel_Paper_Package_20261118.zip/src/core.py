"""Shared deterministic integration, equilibrium checks, I/O utilities.
Never interpret a finite-horizon label as an analytic proof of a limit cycle or global stability.
"""
from __future__ import annotations
from pathlib import Path
from typing import Callable
import json
import numpy as np
import pandas as pd
from scipy.integrate import solve_ivp
from scipy.optimize import root

COLORS={'primary':'#1F1E33','secondary':'#6D6988','muted':'#ABA8BA'}

def outdirs(root):
    for item in ['results','figures','reports','logs','data/synthetic']:
        (Path(root)/item).mkdir(parents=True,exist_ok=True)

def integrate(rhs:Callable, p:dict, t, z0, rtol=1e-8, atol=1e-10):
    """Positive-state RK integration in log coordinates. Both populations must start > 0."""
    t=np.asarray(t,dtype=float)
    z0=np.asarray(z0,dtype=float)
    if z0.shape!=(2,) or min(z0)<=0:raise ValueError('positive two-state initial conditions required')
    if len(t)<2 or np.any(np.diff(t)<=0): raise ValueError('strictly increasing sample times required')
    def f(_,logz):
        z=np.exp(np.clip(logz,-690,200))
        deriv=rhs(z,p)
        return np.asarray(deriv,dtype=float)/np.maximum(z,1e-270)
    sol=solve_ivp(f,(float(t[0]),float(t[-1])),np.log(z0),method='DOP853',t_eval=t,
                  rtol=rtol,atol=atol,max_step=0.35)
    if not sol.success or len(sol.t)!=len(t) or np.any(~np.isfinite(sol.y)):
        raise RuntimeError('ODE solve failed: '+sol.message)
    zz=np.exp(np.clip(sol.y.T,-690,200))
    if np.any(~np.isfinite(zz)) or np.max(zz)>1e25:
        raise RuntimeError('Unphysical overflow state: inspect parameter regime')
    return zz

def jacobian(rhs,p,z):
    z=np.asarray(z,dtype=float)
    J=np.empty((2,2))
    for j in range(2):
        h=max(1e-6,1e-5*abs(z[j]))
        l=z.copy();r=z.copy();l[j]-=h;r[j]+=h
        J[:,j]=(rhs(r,p)-rhs(l,p))/(2*h)
    return J

def equilibria(rhs,p, xmax, ymax, ngrid=7):
    """Numeric candidate roots via multistart; mathematical root completeness requires proof."""
    sols=[]
    candidates=np.geomspace(max(xmax*.015,1e-3),max(xmax,0.02),ngrid)
    ys=np.geomspace(max(ymax*.01,1e-3),max(ymax,.02),ngrid)
    for x in candidates:
        for y in ys:
            def fn(uv):
                z=np.exp(np.clip(uv,-25,15))
                return rhs(z,p)
            try:
                r=root(fn,np.log([x,y]),method='hybr', options={'maxfev':350})
                z=np.exp(np.clip(r.x,-25,15))
                scale=max(1.,xmax,ymax)
                if (r.success and min(z)>1e-5 and max(z)<1e4*scale
                    and np.linalg.norm(rhs(z,p))<2e-6*scale
                    and not any(np.linalg.norm(z-zprev) < 1e-3*(1+np.linalg.norm(zprev)) for zprev in sols)):
                    sols.append(z)
            except (FloatingPointError, ValueError, OverflowError): pass
    return sorted(sols, key=lambda z:z[0])

def eq_table(rhs, model, p, xmax, ymax):
    rows=[]
    for i,z in enumerate(equilibria(rhs,p,xmax,ymax)):
        j=jacobian(rhs,p,z); eig=np.linalg.eigvals(j)
        if np.all(eig.real< -1e-6): label='locally_asymptotically_stable'
        elif np.any(eig.real> 1e-6):label='unstable'
        else:label='inconclusive_near_critical'
        rows.append({'model':model,'root_id':i,'x':z[0],'y':z[1],
                     'trace':np.trace(j),'determinant':np.linalg.det(j),
                     'eig1_real':float(eig[0].real),'eig2_real':float(eig[1].real),
                     'local_classification':label,'status':'numerical_candidate'})
    return rows

def end_label(a, times):
    """Descriptive finite-time label only."""
    tail=a[int(len(a)*.75):]; mean=np.mean(tail,axis=0);span=np.ptp(tail,axis=0)
    if mean[0]<1e-5:return 'prey_near_zero_at_horizon'
    if mean[1]<1e-5:return 'predator_near_zero_at_horizon'
    if np.max(span/(.05+mean))<.02:return 'near_constant_last_quarter'
    return 'changing_at_horizon_not_classified'

def dumpcsv(root,name,rows,columns=None):
    dest=Path(root)/'results'/name
    if rows:
        df=pd.DataFrame.from_records(rows)
    else:df=pd.DataFrame(columns=columns or [])
    df.to_csv(dest,index=False,encoding='utf-8')
    return df

def rmse(obs,pred,scale=None):
    obs=np.asarray(obs,dtype=float);pred=np.asarray(pred,dtype=float)
    if scale is None:scale=np.maximum(np.std(obs,axis=0),.1)
    return float(np.mean(np.sqrt(np.mean(((obs-pred)/scale)**2,axis=0))))

def write_status(root,stage,counts,notes):
    (Path(root)/'logs'/'RUN_STATUS.json').write_text(json.dumps({'stage':stage,'counts':counts,
    'notes':notes,'analysis_level':'numerical_pilot_not_analytic_proof'},ensure_ascii=False,indent=2),encoding='utf-8')

def save_report(root,title,question,procedure,observations,next_experiments,scope):
    content='\n'.join([f'# {title}','', '## 研究问题 / Research question',question,'',
      '## 研究设计 / Research design',procedure,'',
      '## 本轮数值观察 / Numerical observations',observations,'',
      '## 下一步 / Next experiments',next_experiments,'',
      '## 数据和结论范围 / Evidence status',scope,''])
    (Path(root)/'reports'/'PILOT_REPORT_ZH.md').write_text(content,encoding='utf-8')
    return content
