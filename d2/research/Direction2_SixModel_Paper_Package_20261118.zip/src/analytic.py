"""Exact algebraic reductions for the six deterministic model structures.

Polynomial roots are numerical evaluations of a complete scalar reduction,
not interval-certified algebraic numbers. All feasibility filters are explicit.
"""
from __future__ import annotations
import numpy as np
from numpy.polynomial import Polynomial


def growth_coefficients(p):
    """Ascending coefficients of g(x), where x'=x[g(x)-my/(beta+y)]."""
    r, K = p['r'], p['K']
    kind = p['allee']
    if kind == 'logistic':
        return np.asarray([r, -r/K, 0.])
    if kind == 'weak':
        a = p['alpha']
        return np.asarray([r, r*(a-1/K), -r*a/K])
    if kind == 'strong':
        A = p['A']
        return np.asarray([-r, r*(1/A+1/K), -r/(A*K)])
    raise ValueError(kind)


def growth_derivatives(x, p):
    a, b, c = growth_coefficients(p)
    return a+b*x+c*x*x, b+2*c*x, 2*c


def positive_equilibria(p, imag_tol=1e-7, residual_tol=1e-7):
    """Return every feasible positive root of the x-polynomial reduction.

    For h=0 use e*x*(m-g)-beta*d=0 (degree <=3).
    For h>0 use e*x*(m-g)^2-beta*d*(m-g)-h*beta^2*g=0
    (degree <=5). Feasibility: x>0 and 0<g<m; y=beta*g/(m-g).
    Return type: list[np.ndarray([x,y])], sorted by x.
    """
    g = Polynomial(growth_coefficients(p))
    x = Polynomial([0., 1.])
    s = p['m']-g
    if p['h'] == 0:
        poly = p['e']*x*s-p['beta']*p['d']
    else:
        poly = p['e']*x*s*s-p['beta']*p['d']*s-p['h']*p['beta']**2*g
    out = []
    for root in poly.roots():
        if abs(root.imag) > imag_tol*(1+abs(root.real)):
            continue
        xx = float(root.real)
        gg = float(g(xx))
        if xx <= 0 or xx >= p['K'] or not (0 < gg < p['m']):
            continue
        yy = p['beta']*gg/(p['m']-gg)
        rr = p['e']*p['m']*xx/(p['beta']+yy)-p['d']-p['h']*yy
        if abs(rr) > residual_tol*(1+p['d']+p['h']*yy):
            continue
        z = np.asarray([xx, yy])
        if not any(np.linalg.norm(z-other)<1e-6*(1+np.linalg.norm(z)) for other in out):
            out.append(z)
    return sorted(out, key=lambda z: z[0])


def jacobian_exact(p, z):
    """Exact Jacobian at ANY nonnegative state, not only an equilibrium."""
    x, y = z
    g, gp, _ = growth_derivatives(x, p)
    den = p['beta']+y
    return np.asarray([
        [g+x*gp-p['m']*y/den, -p['m']*x*p['beta']/den**2],
        [p['e']*p['m']*y/den,
         p['e']*p['m']*x*p['beta']/den**2-p['d']-2*p['h']*y]])


def equilibrium_summary(p):
    """Rows: root_id,x,y,trace,determinant,eig1_real,eig2_real,stable,status."""
    rows=[]
    for i, z in enumerate(positive_equilibria(p)):
        J=jacobian_exact(p,z)
        eig=np.linalg.eigvals(J)
        rows.append(dict(root_id=i, x=z[0], y=z[1], trace=float(np.trace(J)),
            determinant=float(np.linalg.det(J)), eig1_real=float(eig[0].real),
            eig2_real=float(eig[1].real), stable=bool(max(eig.real)<-1e-8),
            status='complete_polynomial_reduction_numerical_roots'))
    return rows
