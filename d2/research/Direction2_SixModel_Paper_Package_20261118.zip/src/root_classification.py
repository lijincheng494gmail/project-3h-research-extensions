"""Certified equilibrium counts for the six foraging-arena models.

Parameters are interpreted as exact rational values of their supplied decimal
strings. No floating companion-matrix roots are used to determine root counts.
The positive predator coordinate z=y/beta enforces physical feasibility.
"""
from __future__ import annotations
import math
import sympy as sp

Z=sp.Symbol('z')
PARAMETER_KEYS=('r','K','alpha','A','m','beta','e','d','h')


def rational(value):
    if isinstance(value,sp.Rational):
        return value
    if isinstance(value,float) and not math.isfinite(value):
        raise ValueError('finite parameter required')
    return sp.Rational(str(value))


def rational_parameters(parameters):
    p={k:rational(parameters.get(k,0)) for k in PARAMETER_KEYS}
    p['allee']=parameters['allee']
    for k in ('r','K','m','beta','e','d'):
        if p[k]<=0:
            raise ValueError(f'{k} must be positive')
    if p['h']<0:
        raise ValueError('h must be nonnegative')
    if p['allee']=='weak' and p['alpha']<=0:
        raise ValueError('alpha must be positive in weak model')
    if p['allee']=='strong' and not 0<p['A']<p['K']:
        raise ValueError('strong growth requires 0<A<K')
    if p['allee'] not in ('logistic','weak','strong'):
        raise ValueError('unknown growth law')
    return p


def predator_polynomial(parameters):
    """Return exact H(z), parameters, s and kappa.

    x=s(1+z)(1+kappa*z), s=beta*d/(e*m), kappa=h*beta/d.
    H=(1+z)g(x)-m*z. Every positive root is a physical equilibrium.
    """
    p=rational_parameters(parameters)
    s=p['beta']*p['d']/(p['e']*p['m'])
    kappa=p['h']*p['beta']/p['d']
    x=s*(1+Z)*(1+kappa*Z)
    g=p['r']*(1-x/p['K'])
    if p['allee']=='weak':
        g*=1+p['alpha']*x
    elif p['allee']=='strong':
        g*=x/p['A']-1
    return sp.Poly((1+Z)*g-p['m']*Z,Z,domain=sp.QQ),p,s,kappa


def strip_zero_root(poly):
    """Remove every root at z=0; these are axial collisions, not coexistence."""
    multiplicity=0
    while poly.degree()>0 and poly.eval(0)==0:
        poly=poly.exquo(sp.Poly(Z,Z,domain=sp.QQ))
        multiplicity+=1
    return poly,multiplicity


def sign_changes(signs):
    signs=[int(v) for v in signs if v]
    return sum(a!=b for a,b in zip(signs,signs[1:]))


def positive_sturm_certificate(poly):
    """Exact distinct and multiplicity counts on (0,infinity)."""
    stripped,zero_multiplicity=strip_zero_root(poly)
    if stripped.degree()<=0:
        return dict(distinct_positive=0,positive_with_multiplicity=0,
            zero_root_multiplicity=zero_multiplicity,factors=[])
    factors=[]
    distinct=total=0
    for factor,multiplicity in stripped.sqf_list()[1]:
        seq=factor.sturm()
        signs0=[int(sp.sign(q.eval(0))) for q in seq]
        signsinf=[int(sp.sign(q.LC())) for q in seq]
        v0=sign_changes(signs0);vinf=sign_changes(signsinf)
        n=v0-vinf
        factors.append(dict(polynomial_coefficients_descending=[str(c) for c in factor.all_coeffs()],
            multiplicity=int(multiplicity),sturm_signs_at_0=signs0,
            sturm_signs_at_positive_infinity=signsinf,variation_at_0=v0,
            variation_at_positive_infinity=vinf,positive_roots=n))
        distinct+=n;total+=n*multiplicity
    return dict(distinct_positive=int(distinct),positive_with_multiplicity=int(total),
        zero_root_multiplicity=zero_multiplicity,factors=factors)


def polynomial_interval(poly,a,b):
    """Rational Horner enclosure; sufficient to certify a nonzero sign."""
    lo=hi=sp.Rational(0)
    for coefficient in poly.all_coeffs():
        products=[lo*a,lo*b,hi*a,hi*b]
        lo=min(products)+coefficient
        hi=max(products)+coefficient
    return lo,hi


def critical_values(poly,eps=sp.Rational(1,10**12)):
    """Isolate every positive critical point and certify sign H(c).

    A common root of H and H' is detected by exact polynomial gcd. Otherwise
    rational interval arithmetic is refined until its sign excludes zero.
    """
    derivative=poly.diff()
    stripped,_=strip_zero_root(derivative)
    if stripped.degree()<=0:
        return []
    sqfree=stripped.sqf_part()
    common,_=strip_zero_root(sp.gcd(poly,derivative))
    out=[]
    for (a,b),multiplicity in stripped.intervals(inf=0,eps=eps):
        if b<=0:
            continue
        if a==b:
            sign=int(sp.sign(poly.eval(a)))
            hlo=hhi=poly.eval(a)
        elif common.degree()>0 and common.count_roots(a,b)>0:
            sign=0;hlo=hhi=sp.Rational(0)
        else:
            for _ in range(1024):
                hlo,hhi=polynomial_interval(poly,a,b)
                if hlo>0:
                    sign=1;break
                if hhi<0:
                    sign=-1;break
                a,b=sqfree.refine_root(a,b,eps=(b-a)/4)
            else:
                raise ArithmeticError('critical-value sign did not isolate')
        out.append(dict(z_lower=str(a),z_upper=str(b),
            derivative_root_multiplicity=int(multiplicity),
            H_sign=sign,H_lower=str(hlo),H_upper=str(hhi)))
    return out


def classify(parameters,eps=sp.Rational(1,10**12),with_intervals=True):
    poly,p,s,kappa=predator_polynomial(parameters)
    sturm=positive_sturm_certificate(poly)
    crit=critical_values(poly,eps=eps)
    initial_sign=int(sp.sign(poly.eval(0)))
    signs=[initial_sign]+[q['H_sign'] for q in crit]+[-1]
    monotone_interval_roots=sum(a*b<0 for a,b in zip(signs,signs[1:]))
    critical_roots=sum(q['H_sign']==0 for q in crit)
    monotone_count=int(monotone_interval_roots+critical_roots)
    if monotone_count!=sturm['distinct_positive']:
        raise AssertionError('Sturm and critical-value classifications disagree')
    if s>=p['K'] and sturm['distinct_positive']:
        raise AssertionError('physical root above carrying capacity')
    if sturm['positive_with_multiplicity']>3:
        raise AssertionError('three-root physical bound violated')
    if sum(c['derivative_root_multiplicity'] for c in crit)>2:
        raise AssertionError('two-critical-point bound violated')
    if p['allee']=='logistic' and sturm['distinct_positive']!=int(bool(s<p['K'])):
        raise AssertionError('logistic uniqueness criterion violated')
    if p['allee']=='strong':
        region='s_below_A' if s<p['A'] else 's_equal_A' if s==p['A'] else 'A_below_s_below_K' if s<p['K'] else 's_at_or_above_K'
    else:
        region='s_below_K' if s<p['K'] else 's_at_or_above_K'
    roots=[]
    if with_intervals:
        stripped,_=strip_zero_root(poly)
        if stripped.degree()>0:
            for (a,b),multiplicity in stripped.intervals(inf=0,eps=eps):
                if b<=0:
                    continue
                lower_x=s*(1+a)*(1+kappa*a)
                upper_x=s*(1+b)*(1+kappa*b)
                roots.append(dict(z_lower=str(a),z_upper=str(b),
                    multiplicity=int(multiplicity),x_lower=str(lower_x),
                    x_upper=str(upper_x),y_lower=str(p['beta']*a),
                    y_upper=str(p['beta']*b)))
        if len(roots)!=sturm['distinct_positive'] or sum(q['multiplicity'] for q in roots)!=sturm['positive_with_multiplicity']:
            raise AssertionError('isolating intervals and Sturm counts disagree')
    return dict(parameters={k:(str(v) if k!='allee' else v) for k,v in p.items()},
        s=str(s),kappa=str(kappa),parameter_region=region,
        polynomial_degree=int(poly.degree()),
        H_coefficients_ascending=[str(poly.nth(i)) for i in range(poly.degree()+1)],
        H0_sign=initial_sign,**sturm,positive_critical_points=crit,
        monotonicity_classification_count=monotone_count,roots=roots,
        classification_status='exact rational Sturm + exact critical-value sign classification')
