"""Synthetic factorial, recovery, continuation and independent numerical audits.

These experiments use dimensionless, explicitly constructed parameters. They do
not fit or simulate field measurements. All model IDs and equations are imported
from the supplied six-model implementation.
"""
from __future__ import annotations
from pathlib import Path
import json
import time
import warnings
import numpy as np
import pandas as pd
from numpy.polynomial import Polynomial as P
from scipy.integrate import solve_ivp
from scipy.optimize import root
from scipy.signal import find_peaks
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from .experiments import MODEL_DEFS, make, rhs, prey_per_capita, sample_cases


def growth_coefficients(p):
    r, K = p['r'], p['K']
    if p['allee'] == 'logistic': return np.array([r, -r/K, 0.])
    if p['allee'] == 'weak':
        a = p['alpha']; return np.array([r, r*(a-1/K), -r*a/K])
    A = p['A']; return np.array([-r, r*(1/A+1/K), -r/(A*K)])


def jacobian(p, z):
    x, y = z; b = p['beta']; den = b+y
    g0,g1,g2 = growth_coefficients(p)
    g = g0+g1*x+g2*x*x; gp = g1+2*g2*x
    return np.array([[g+x*gp-p['m']*y/den, -p['m']*x*b/den**2],
                     [p['e']*p['m']*y/den,
                      p['e']*p['m']*x*b/den**2-p['d']-2*p['h']*y]])


def positive_roots(p):
    """Complete polynomial candidate enumeration in predator y, then ODE filtering.

    X(y)=(beta+y)(d+h*y)/(e*m).  Multiplying the prey nullcline
    g(X(y))=m*y/(beta+y) gives a polynomial of degree at most five.
    Degree bounds are not claims that all those roots are feasible or distinct.
    """
    Y = P([0.,1.]); den = P([p['beta'],1.])
    X = den*P([p['d'],p['h']])/(p['e']*p['m'])
    a0,a1,a2 = growth_coefficients(p)
    poly = den*(P([a0])+a1*X+a2*X*X)-p['m']*Y
    ans=[]
    for yy in poly.roots():
        if abs(yy.imag)>2e-6*(1+abs(yy.real)) or yy.real<=1e-8: continue
        y=float(yy.real); x=float(X(y)); z=np.array([x,y])
        if not (0<x<p['K']*(1+1e-8)): continue
        if np.linalg.norm(rhs(z,p),np.inf)>1e-6*(1+np.max(z)): continue
        if any(np.linalg.norm(z-old)<1e-5*(1+np.linalg.norm(old)) for old in ans): continue
        ans.append(z)
    return sorted(ans,key=lambda z:z[0])


def root_record(p,z):
    J=jacobian(p,z); eig=np.linalg.eigvals(J); re=float(np.max(eig.real))
    det=float(np.linalg.det(J)); tr=float(np.trace(J))
    status=('stable' if re < -1e-7 else 'saddle' if det < -1e-8
            else 'unstable' if re > 1e-7 else 'near_critical')
    return {'x_eq':float(z[0]),'y_eq':float(z[1]),'trace':tr,
            'determinant':det,'max_eigen_real':re,'stability':status,
            'rhs_residual':float(np.linalg.norm(rhs(z,p),np.inf))}


def simulate(p,z0,T=400,step=1.,rtol=1e-8,atol=1e-10,max_step=1.5):
    """Positive log-state DOP853 integration; no density floor in the dynamics."""
    z0=np.asarray(z0,dtype=float)
    if np.min(z0)<=0: raise ValueError('strictly positive initial states required')
    ts=np.linspace(0,T,int(round(T/step))+1)
    def f(t,u):
        if np.any(u>100): raise RuntimeError('overflow in synthetic solve')
        z=np.exp(np.maximum(u,-740.))
        x,y=z
        return np.array([prey_per_capita(x,p,p['allee'])-p['m']*y/(p['beta']+y),
                         p['e']*p['m']*x/(p['beta']+y)-p['d']-p['h']*y])
    s=solve_ivp(f,(0,T),np.log(z0),method='DOP853',t_eval=ts,
                rtol=rtol,atol=atol,max_step=max_step)
    if not s.success or len(s.t)!=len(ts): raise RuntimeError(s.message)
    z=np.exp(np.maximum(s.y.T,-740.))
    return ts,z,int(s.nfev)


def diagnostics(p,ts,z):
    tail=z[ts>=.75*ts[-1]]; mean=tail.mean(axis=0); span=np.ptp(tail,axis=0)
    roots=positive_roots(p)
    dist=[np.max(np.abs(z[-1]-q)/np.maximum(q,1e-4)) for q in roots]
    nearest=int(np.argmin(dist)) if dist else None
    if z[-1,0]/p['K']<1e-8 and z[-1,1]<1e-7: label='extinction_at_horizon'
    elif z[-1,1]<1e-7 and abs(z[-1,0]/p['K']-1)<.01: label='prey_only_at_horizon'
    elif dist and min(dist)<.01 and max(span/np.maximum(mean,.05))<.01:
        label='coexistence_near_equilibrium'
    else: label='changing_or_oscillatory_at_horizon'
    idx,_=find_peaks(tail[:,0],prominence=max(1e-8,.01*np.mean(tail[:,0])))
    periods=np.diff(ts[ts>=.75*ts[-1]][idx])
    return {'outcome':label,'x_final':z[-1,0],'y_final':z[-1,1],
            'x_tail_mean':mean[0],'y_tail_mean':mean[1],
            'x_tail_span':span[0],'y_tail_span':span[1],
            'nearest_eq_relative_error':min(dist) if dist else np.nan,
            'tail_prey_peaks':len(idx),
            'tail_peak_period_mean':np.mean(periods) if len(periods) else np.nan,
            'tail_peak_period_cv':np.std(periods)/np.mean(periods) if len(periods)>1 else np.nan}


def case_parameters():
    cases=sample_cases(8)
    for q in cases: q['regime']='starter_distribution'
    for kind,x,alpha,A in [('weak',1.,.8,2.),('strong',3.,.2,2.)]:
        q=dict(r=.2,K=8.,alpha=alpha,A=A,m=.8,e=.65,h=.035,d=.25,beta=1.2)
        p=make(q,'M0' if kind=='weak' else 'M2')
        g=prey_per_capita(x,p,kind); a=growth_coefficients(p); gp=a[1]+2*a[2]*x
        q['beta']=q['e']*g*(q['m']-g)/(q['m']*gp)
        q['d']=x*q['m']*gp/g
        q['scenario']=len(cases);q['regime']=kind+'_hopf_reference'
        cases.append(q)
    q=dict(r=.7,K=8.,alpha=.225,A=2.,m=.3,e=.65,h=.05,d=.25,beta=1.2,
           scenario=len(cases),regime='stable_shock_reference')
    cases.append(q)
    q=dict(r=.6,K=2.,alpha=.9,A=.5,m=.3,e=.65,h=.05,d=.6,beta=1.2,
           scenario=len(cases),regime='predator_noninvasion_reference')
    cases.append(q)
    return cases


def model_parameters(base,model,scaling):
    p=make(base,model)
    if scaling=='reference_growth_matched':
        # Same g(.6K)=r_base*(1-.6), above all supplied thresholds.
        x=.6*p['K']; kind=p['allee']
        factor=(1+p['alpha']*x if kind=='weak' else x/p['A']-1 if kind=='strong' else 1.)
        if factor<=0: raise ValueError('reference must exceed strong threshold')
        p['r']=base['r']/factor
    return p


def write_csv(root,name,rows):
    pd.DataFrame(rows).to_csv(root/'results'/('extended_'+name+'.csv'),index=False)


def factorial(root):
    rows=[]; params=[]; contrasts=[]; eqs=[]; audit=[]
    initials=[(.8,.8),(.10,.8),(.45,2.)]
    trace_rows=[]
    for base in case_parameters():
        for scaling in ['same_r','reference_growth_matched']:
            for model in MODEL_DEFS:
                p=model_parameters(base,model,scaling)
                ident=dict(scenario=base['scenario'],regime=base['regime'],
                           scaling=scaling,model=model)
                params.append({**ident,**p,'alpha_K':p['alpha']*p['K'],
                               'g_reference':prey_per_capita(.6*p['K'],p,p['allee']),
                               'data_kind':'synthetic_dimensionless'})
                for i,q in enumerate(positive_roots(p)):
                    eqs.append({**ident,'root_id':i,**root_record(p,q)})
            for initial,(fx,y0) in enumerate(initials):
                by_model={}
                for model in MODEL_DEFS:
                    p=model_parameters(base,model,scaling);z0=[fx*p['K'],y0]
                    ts,z,nfev=simulate(p,z0)
                    ident=dict(scenario=base['scenario'],regime=base['regime'],
                               scaling=scaling,initial=initial,model=model)
                    rec={**ident,'x0':z0[0],'y0':z0[1],'T':ts[-1],
                         **diagnostics(p,ts,z),'solver_nfev':nfev}
                    rows.append(rec);by_model[model]=rec
                    if base['scenario'] in [8,9,10] and initial==0 and scaling=='same_r':
                        trace_rows.extend({**ident,'time':t,'x':a,'y':b}
                                          for t,(a,b) in zip(ts[::2],z[::2]))
                    # Every model and both normalizations crosschecked in four
                    # predeclared regimes, including reference bifurcations.
                    if base['scenario'] in [0,8,9,10] and initial==0:
                        t2,z2,n2=simulate(p,z0,T=800,step=1,rtol=1e-10,atol=1e-12,max_step=.35)
                        same=z2[:len(ts)]
                        scale=np.maximum(np.max(z,axis=0),.1)
                        err=np.max(np.abs(same-z)/scale)
                        d2=diagnostics(p,t2,z2)
                        audit.append({**ident,'T_primary':400,'T_crosscheck':800,
                          'primary_rtol':1e-8,'crosscheck_rtol':1e-10,
                          'primary_max_step':1.5,'crosscheck_max_step':.35,
                          'max_scaled_path_error_T400':err,
                          'outcome_T400':rec['outcome'],'outcome_T800':d2['outcome'],
                          'x_tail_mean_T400':rec['x_tail_mean'],'x_tail_mean_T800':d2['x_tail_mean'],
                          'y_tail_mean_T400':rec['y_tail_mean'],'y_tail_mean_T800':d2['y_tail_mean'],
                          'crosscheck_solver_nfev':n2})
                pairs=[('competition','M1','M3'),('competition','M0','M4'),('competition','M2','M5'),
                       ('growth_h0','M1','M0'),('growth_h0','M1','M2'),('growth_h0','M0','M2'),
                       ('growth_hplus','M3','M4'),('growth_hplus','M3','M5'),('growth_hplus','M4','M5')]
                for typ,a,b in pairs:
                    contrasts.append({'scenario':base['scenario'],'regime':base['regime'],
                       'scaling':scaling,'initial':initial,'contrast_type':typ,'from_model':a,'to_model':b,
                       'from_outcome':by_model[a]['outcome'],'to_outcome':by_model[b]['outcome'],
                       'delta_x_tail_mean':by_model[b]['x_tail_mean']-by_model[a]['x_tail_mean'],
                       'delta_y_tail_mean':by_model[b]['y_tail_mean']-by_model[a]['y_tail_mean']})
                for name,a,b,c,d in [('weak_vs_logistic','M0','M4','M1','M3'),
                                     ('strong_vs_logistic','M2','M5','M1','M3'),
                                     ('strong_vs_weak','M2','M5','M0','M4')]:
                    contrasts.append({'scenario':base['scenario'],'regime':base['regime'],
                       'scaling':scaling,'initial':initial,'contrast_type':'interaction_'+name,
                       'from_model':c+'->'+d,'to_model':a+'->'+b,
                       'from_outcome':by_model[c]['outcome']+';'+by_model[d]['outcome'],
                       'to_outcome':by_model[a]['outcome']+';'+by_model[b]['outcome'],
                       'delta_x_tail_mean':(by_model[b]['x_tail_mean']-by_model[a]['x_tail_mean'])-(by_model[d]['x_tail_mean']-by_model[c]['x_tail_mean']),
                       'delta_y_tail_mean':(by_model[b]['y_tail_mean']-by_model[a]['y_tail_mean'])-(by_model[d]['y_tail_mean']-by_model[c]['y_tail_mean'])})
        print('factorial scenario',base['scenario'],'completed',flush=True)
    for n,r in [('parameters',params),('factorial',rows),('equilibria',eqs),
                ('contrasts',contrasts),('solver_audit',audit),('selected_trajectories',trace_rows)]:
        write_csv(root,n,r)
    df=pd.DataFrame(contrasts)
    group=['scaling','regime','contrast_type','from_model','to_model','from_outcome','to_outcome']
    summ=df.groupby(group).agg(n=('delta_y_tail_mean','size'),
        mean_delta_x=('delta_x_tail_mean','mean'),mean_delta_y=('delta_y_tail_mean','mean'),
        min_delta_y=('delta_y_tail_mean','min'),max_delta_y=('delta_y_tail_mean','max')).reset_index()
    summ.to_csv(root/'results/extended_contrast_summary.csv',index=False)
    return len(rows),len(contrasts)


def recovery(root):
    base=case_parameters()[10]
    rows=[];traces=[];boundaries=[]
    for model in MODEL_DEFS:
        p=make(base,model)
        stable=[q for q in positive_roots(p) if root_record(p,q)['stability']=='stable']
        if not stable:
            rows.append({'model':model,'status':'no_stable_coexistence_at_reference'})
            continue
        eq=max(stable,key=lambda q:q[0])
        for axis in [0,1]:
            for reduction in [.05,.25,.60,.85]:
                z0=eq.copy(); z0[axis]*=1-reduction
                ts,z,nf=simulate(p,z0,T=600,step=.5)
                error=np.max(np.abs(z-eq)/eq,axis=1)
                # first entry after which all remaining samples stay within 2%,
                # with at least 50 time units of confirmed residence.
                suffix=np.maximum.accumulate(error[::-1])[::-1]
                valid=np.flatnonzero((suffix<=.02)&(ts<=550))
                recov=float(ts[valid[0]]) if len(valid) else np.nan
                diag=diagnostics(p,ts,z)
                rec={'model':model,'perturbed_population':'prey' if axis==0 else 'predator',
                     'reduction_fraction':reduction,'retained_fraction':1-reduction,
                     'x_eq':eq[0],'y_eq':eq[1],'x0':z0[0],'y0':z0[1],
                     'A':p['A'] if p['allee']=='strong' else np.nan,
                     'recovery_time_2pct':recov,'recovery_residence_required':50.,
                     'T':600.,'recovered':bool(len(valid)),**diag}
                rows.append(rec)
                if axis==0 and reduction in [.60,.85]:
                    traces.extend({'model':model,'reduction_fraction':reduction,'time':t,
                                   'x_over_equilibrium':q[0]/eq[0],
                                   'y_over_equilibrium':q[1]/eq[1]}
                                  for t,q in zip(ts[::4],z[::4]))
        if p['allee']=='strong':
            def endpoint(frac,T):
                ts,z,_=simulate(p,[frac*eq[0],eq[1]],T=T,step=2.)
                return diagnostics(p,ts,z)['outcome'],z[-1]
            lo,hi=.001,1.;iterations=20;history=[];status='bracketed'
            for i in range(iterations):
                mid=(lo+hi)/2;label,last=endpoint(mid,800)
                history.append({'model':model,'iteration':i,'fraction':mid,
                                'T':800,'outcome':label,'x_final':last[0],'y_final':last[1]})
                if label=='extinction_at_horizon':lo=mid
                elif label=='coexistence_near_equilibrium':hi=mid
                else:status='unresolved_midpoint';break
            lowlabel,lowlast=endpoint(lo,1600);hilabel,hilast=endpoint(hi,1600)
            boundaries.append({'model':model,'boundary_type':'fixed_predator_y_eq_prey_shock',
                'reference_x_eq':eq[0],'reference_y_eq':eq[1],'A':p['A'],
                'lower_retained_fraction':lo,'upper_retained_fraction':hi,
                'lower_prey_density':lo*eq[0],'upper_prey_density':hi*eq[0],
                'bracket_width_fraction':hi-lo,'lower_outcome_T1600':lowlabel,
                'upper_outcome_T1600':hilabel,'iterations':len(history),'status':status,
                'valid_T1600_bracket':lowlabel=='extinction_at_horizon' and hilabel=='coexistence_near_equilibrium'})
            write_csv(root,'basin_history_'+model,history)
    write_csv(root,'shock_recovery',rows);write_csv(root,'shock_trajectories',traces)
    write_csv(root,'basin_boundaries',boundaries)
    return len(rows)


def continuation(root):
    base=case_parameters()[10];bifbase=case_parameters()[8]
    scans=[];orbits=[];params=[]
    for model in MODEL_DEFS:
        kind,comp=MODEL_DEFS[model]
        definitions=[('K',np.linspace(1.,32.,125),base)]
        if comp:definitions.append(('h',np.linspace(0.,.4,81),base))
        if kind=='weak':definitions.append(('alpha',np.linspace(.03,2.,101),bifbase))
        if kind=='strong':definitions.append(('A',np.linspace(.4,6.8,101),base))
        # beta scans straddle constructed feasible Hopf points.
        if kind in ['weak','strong']:
            q=case_parameters()[8 if kind=='weak' else 9]
            definitions.append(('beta',q['beta']*np.linspace(.4,2.,101),q))
            definitions.append(('K',np.linspace(4.,16.,121),q))
        for param,values,b in definitions:
            previous=[];next_branch=0
            for i,value in enumerate(values):
                q=dict(b);q[param]=float(value);p=make(q,model)
                # K sweep keeps the physical A fixed; skip infeasible strong A>=K.
                if kind=='strong' and p['A']>=p['K']:continue
                rr=positive_roots(p);available=list(previous);current=[]
                ident={'model':model,'sweep_parameter':param,'sweep_value':value,'grid_index':i,
                       'base_scenario':b['scenario'],'positive_root_count':len(rr)}
                params.append({**ident,**p,'alpha_K':p['alpha']*p['K']})
                for z in rr:
                    if available:
                        j=int(np.argmin([abs(z[0]-w[1][0]) for w in available]));branch,old=available.pop(j)
                    else:branch=next_branch;next_branch+=1
                    current.append((branch,z))
                    scans.append({**ident,'branch_id':branch,**root_record(p,z)})
                previous=current
                if not rr:scans.append({**ident,'branch_id':-1,'stability':'no_positive_equilibrium'})
                # Orbit checks on a sparse prescribed grid, all six structures.
                if i%20==0 or i==len(values)-1:
                    ts,z,_=simulate(p,[.8*p['K'],.8],T=500,step=1.)
                    orbits.append({**ident,'x0':.8*p['K'],'y0':.8,'T':500,**diagnostics(p,ts,z)})
            print('continuation',model,param,'completed',flush=True)
    write_csv(root,'continuation',scans);write_csv(root,'continuation_parameters',params)
    write_csv(root,'continuation_orbits',orbits)
    return len(scans),len(orbits)


def constructed_events(root):
    from run_analytical_checks import hopf_lyapunov,invariant_derivatives
    rows=[];cross=[]
    for kind,model,x in [('weak','M0',1.),('strong','M2',3.)]:
        base=dict(r=.2,K=8.,alpha=.8,A=2.,m=.8,e=.65,h=0.,d=.25,beta=1.2)
        p=make(base,model);coeff=growth_coefficients(p)
        g=prey_per_capita(x,p,kind);gp=coeff[1]+2*coeff[2]*x;gpp=2*coeff[2]
        for event in ['Hopf_linear_conditions','saddle_node','BT_linear_conditions']:
            q=dict(p)
            if event=='Hopf_linear_conditions':
                q['beta']=q['e']*g*(q['m']-g)/(q['m']*gp)
                q['d']=x*q['m']*gp/g
            else:
                q['m']=g+x*gp
                q['beta']=1. if event=='saddle_node' else q['e']*x*g/q['m']
                q['d']=q['e']*x*(q['m']-g)/q['beta']
            y=q['beta']*g/(q['m']-g);eq=np.array([x,y])
            rec={**q,'model':model,'event':event,'x':x,'y':y,
                 'growth':g,'growth_derivative':gp,'growth_second_derivative':gpp,
                 'scalar_fold_second_derivative':-2*gp-x*gpp,
                 'scalar_fold_d_derivative':-q['beta']/q['e'],**root_record(q,eq)}
            rec.update(invariant_derivatives(q,x))
            if event=='Hopf_linear_conditions':
                eps=1e-4*q['beta'];vals=[]
                for delta in [-eps,eps]:
                    pp=dict(q);pp['beta']+=delta
                    near=min(positive_roots(pp),key=lambda z:np.linalg.norm(z-eq))
                    vals.append(np.trace(jacobian(pp,near)))
                rec['trace_derivative_beta']=(vals[1]-vals[0])/(2*eps)
                rec.update(hopf_lyapunov(q,eq))
                rec['status']='nondegenerate_Hopf_checked_l1_and_transversality'
                rec['event']='Hopf'
                # Long, two-sided orbits track stable state / recurring oscillation;
                # this does not establish uniqueness of a periodic orbit.
                for factor in [.9,.99,1.01,1.1]:
                    pp=dict(q);pp['beta']*=factor
                    z0=eq*np.array([1.05,.95]);ts,z,_=simulate(pp,z0,T=2000,step=.5)
                    cross.append({'model':model,'event':'Hopf_beta_crossing',
                       'beta_factor':factor,'beta':pp['beta'],'T':2000,
                       **diagnostics(pp,ts,z)})
            elif event=='saddle_node':
                rec['status']='nondegenerate_scalar_fold_with_nonzero_other_eigenvalue'
                counts=[]
                for factor in [.999,1.001]:
                    pp=dict(q);pp['d']*=factor;rr=positive_roots(pp)
                    cross.append({'model':model,'event':'fold_d_crossing','d_factor':factor,
                                  'd':pp['d'],'positive_root_count':len(rr)})
            else:
                rec['status']='nondegenerate_BT_checked_normal_form_and_unfolding_rank'
                rec['event']='Bogdanov_Takens'
            rows.append(rec)
    write_csv(root,'constructed_bifurcations',rows);write_csv(root,'bifurcation_crosschecks',cross)
    return len(rows)


def independent_audit(root):
    try:
        from .analytic import positive_equilibria,jacobian_exact
    except ImportError:
        return {'status':'analytic_module_unavailable_at_run'}
    params=pd.read_csv(root/'results/extended_parameters.csv')
    rows=[]
    for _,rec in params.iterrows():
        p={k:rec[k] for k in ['r','K','alpha','A','m','beta','e','d','h','allee']}
        a=positive_roots(p);b=positive_equilibria(p)
        err=max([min(np.linalg.norm(z-w) for w in b) for z in a],default=0.) if b else (0. if not a else np.inf)
        jerr=max([np.max(np.abs(jacobian(p,z)-jacobian_exact(p,z))) for z in a],default=0.)
        rows.append({'scenario':rec['scenario'],'scaling':rec['scaling'],'model':rec['model'],
                     'y_polynomial_roots':len(a),'x_polynomial_roots':len(b),
                     'max_nearest_root_error':err,'max_jacobian_error':jerr,
                     'agreement':len(a)==len(b) and err<1e-5 and jerr<1e-7})
    write_csv(root,'independent_root_audit',rows)
    shocks=pd.read_csv(root/'results/extended_shock_recovery.csv')
    certs=[];base=case_parameters()[10]
    for _,rec in shocks.iterrows():
        p=make(base,rec['model']);xs,ys=rec['x_eq'],rec['y_eq']
        x0,y0=rec['x0'],rec['y0'];weight=p['beta']/(p['e']*(p['beta']+ys))
        value=x0-xs-xs*np.log(x0/xs)+weight*(y0-ys-ys*np.log(y0/ys))
        threshold=np.nan;barrier=np.nan
        if p['allee']=='logistic':sufficient=True;domain='global_positive_quadrant'
        elif p['allee']=='weak':
            sufficient=xs>=p['K']-1/p['alpha'];domain='global_when_xstar_ge_K_minus_1overalpha'
        else:
            threshold=p['K']+p['A']-xs
            barrier=threshold-xs-xs*np.log(threshold/xs)
            sufficient=xs>(p['K']+p['A'])/2 and value<barrier
            domain='invariant_V_sublevel_above_L'
        certs.append({'model':rec['model'],'perturbed_population':rec['perturbed_population'],
            'reduction_fraction':rec['reduction_fraction'],'x_eq':xs,'y_eq':ys,
            'V_initial':value,'V_weight_predator':weight,'strong_L':threshold,
            'strong_V_barrier':barrier,'sufficient_guaranteed_return':bool(sufficient),
            'certificate_domain':domain,'observed_recovery':rec['recovered'],
            'certificate_contradicted':bool(sufficient and not rec['recovered'])})
    write_csv(root,'shock_lyapunov_certificates',certs)
    return {'status':'done','all_agree':all(r['agreement'] for r in rows),'n':len(rows)}


def figures(root):
    plt.rcParams.update({'axes.spines.top':False,'axes.spines.right':False,'font.size':9})
    colors={'M0':'#1F1E33','M1':'#79758F','M2':'#B95E54','M3':'#4B8F8C','M4':'#6D68A5','M5':'#C99B45'}
    df=pd.read_csv(root/'results/extended_factorial.csv')
    fig,axs=plt.subplots(1,2,figsize=(11,4),sharey=True)
    for ax,scaling in zip(axs,['same_r','reference_growth_matched']):
        part=df[df.scaling==scaling]
        for i,model in enumerate(MODEL_DEFS):
            v=part.loc[part.model==model,'y_tail_mean'];ax.scatter(np.full(len(v),i)+np.linspace(-.16,.16,len(v)),v,s=12,c=colors[model],alpha=.65)
            ax.scatter([i],[v.median()],marker='_',s=350,c='black')
        ax.set(xticks=np.arange(6),xticklabels=list(MODEL_DEFS),ylabel='Predator tail mean (T = 400)',
               title='Same intrinsic r' if scaling=='same_r' else 'Matched g(0.6 K)')
    fig.suptitle('Synthetic matched factorial: each dot is one scenario and initial state')
    fig.tight_layout();fig.savefig(root/'figures/extended_factorial.png',dpi=180);plt.close(fig)
    rr=pd.read_csv(root/'results/extended_shock_recovery.csv')
    fig,axs=plt.subplots(1,2,figsize=(11,4))
    for ax,pop in zip(axs,['prey','predator']):
        part=rr[rr.perturbed_population==pop]
        for model,g in part.groupby('model',sort=False):
            ax.plot(100*g.reduction_fraction,g.recovery_time_2pct,marker='o',label=model,color=colors[model])
            failed=g[~g.recovered];ax.scatter(100*failed.reduction_fraction,np.full(len(failed),30.),marker='x',color=colors[model],s=65)
        ax.axhline(27,color='#999999',lw=.6,ls=':')
        ax.set(xlabel='Population removed (%)',ylabel='Recovery time to 2% of equilibrium',title=pop.capitalize()+' shock',ylim=(-1,32))
        ax.set_yticks([0,5,10,15,20,25,30],['0','5','10','15','20','25','No return'])
        for red,failed in part[~part.recovered].groupby('reduction_fraction'):
            ax.annotate('/'.join(failed.model),xy=(100*red,30),xytext=(0,-17),
                        textcoords='offset points',ha='center',fontsize=8)
    axs[1].legend(ncol=2);fig.tight_layout();fig.savefig(root/'figures/extended_shock_recovery.png',dpi=180);plt.close(fig)
    df=pd.read_csv(root/'results/extended_continuation.csv')
    fig,axs=plt.subplots(2,3,figsize=(12,7))
    for ax,model in zip(axs.flat,MODEL_DEFS):
        part=df[(df.model==model)&(df.sweep_parameter=='K')&(df.base_scenario==10)]
        for status,g in part.groupby('stability'):
            if status=='no_positive_equilibrium':continue
            ax.scatter(g.sweep_value,g.x_eq,s=10,c=colors[model],marker='o' if status=='stable' else 'x',alpha=.8,label=status)
        ax.set(title=model,xlabel='K (A and alpha fixed)',ylabel='Positive equilibrium prey x')
        if len(part):ax.legend(fontsize=7)
    fig.suptitle('Enrichment continuation: all feasible polynomial roots, not only one branch')
    fig.tight_layout();fig.savefig(root/'figures/extended_enrichment.png',dpi=180);plt.close(fig)
    fig,axs=plt.subplots(1,2,figsize=(11,4))
    for ax,models,scenario in zip(axs,[['M0','M4'],['M2','M5']],[8,9]):
        part=df[(df.model.isin(models))&(df.sweep_parameter=='K')&(df.base_scenario==scenario)]
        for model,g in part.groupby('model'):
            for status,gg in g.groupby('stability'):
                if status=='no_positive_equilibrium':continue
                ax.scatter(gg.sweep_value,gg.trace,s=12,color=colors[model],
                    marker='o' if status=='stable' else 'x',label=model+' '+status.replace('_',' '))
        ax.axhline(0,color='#777777',lw=.8)
        ax.set(xlabel='K (alpha or A fixed)',ylabel='Jacobian trace at equilibrium',
               title='Weak Allee reference' if scenario==8 else 'Strong Allee reference')
        ax.set_ylim(-.05,.05)
        ax.legend(fontsize=7,ncol=2)
    fig.suptitle('Targeted enrichment scans around exact no-competition Hopf witnesses')
    fig.tight_layout();fig.savefig(root/'figures/extended_enrichment_hopf.png',dpi=180);plt.close(fig)


def run(root,stages=None):
    root=Path(root);start=time.time();counts={}
    selected=stages or ['factorial','recovery','continuation','events','audit','figures']
    if 'factorial' in selected:counts['factorial']=factorial(root)
    if 'recovery' in selected:counts['shock_rows']=recovery(root)
    if 'continuation' in selected:counts['continuation']=continuation(root)
    if 'events' in selected:counts['event_rows']=constructed_events(root)
    if 'audit' in selected:counts['independent_audit']=independent_audit(root)
    if 'figures' in selected:figures(root)
    status={'stage':'synthetic_extensions_completed','counts':counts,'elapsed_seconds':time.time()-start,
            'seed':2026,'data_kind':'synthetic_dimensionless','equations':'canonical M0-M5 unchanged',
            'primary_solver':{'method':'DOP853_log_state','rtol':1e-8,'atol':1e-10,'max_step':1.5},
            'factorial_T':400,'solver_audit_T':800,'shock_T':600,'basin_T':800,'basin_check_T':1600,
            'normalization_reference_x_K':.6,'fitted_parameters':False,
            'notes':'No stochastic dynamics; oscillatory trajectories are numerical evidence, not uniqueness proofs.'}
    (root/'logs/EXTENDED_RUN_STATUS.json').write_text(json.dumps(status,indent=2),encoding='utf-8')
    print(json.dumps(status,indent=2),flush=True)
    return status
