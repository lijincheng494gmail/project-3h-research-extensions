#!/usr/bin/env bash
# Python evidence calculations and LaTeX manuscript reproduction.
set -euo pipefail
cd "$(dirname "$0")"
TASK_MODE="${1:-paper}"
mkdir -p logs/revision
if [ ! -x .venv/bin/python ]; then
  "${PYTHON:-python3}" -m venv .venv
fi
STUDY_PYTHON=.venv/bin/python
if ! "$STUDY_PYTHON" -c 'import numpy,scipy,pandas,matplotlib,sympy,reportlab,pypdf' >/dev/null 2>&1; then
  "$STUDY_PYTHON" -m pip install -r logs/environment.lock.txt
fi
case "$TASK_MODE" in
  paper)
    "$STUDY_PYTHON" run_root_classification.py > logs/revision/root_classification_stdout.txt 2> logs/revision/root_classification_stderr.txt
    "$STUDY_PYTHON" run_global_classification.py > logs/revision/global_classification_stdout.txt 2> logs/revision/global_classification_stderr.txt
    "$STUDY_PYTHON" run_cycle_metrics.py > logs/revision/cycle_stdout.txt 2> logs/revision/cycle_stderr.txt
    "$STUDY_PYTHON" run_paper_numerics.py > logs/revision/paper_numerics_stdout.txt 2> logs/revision/paper_numerics_stderr.txt
    "$STUDY_PYTHON" build_paper_tables.py
    "$STUDY_PYTHON" render_paper.py
    "$STUDY_PYTHON" verify_paper.py
    "$STUDY_PYTHON" package_paper.py
    ;;
  verify)
    "$STUDY_PYTHON" verify_results.py > logs/revision/legacy_evidence_audit_stdout.txt
    "$STUDY_PYTHON" verify_paper.py
    ;;
  reproduce)
    bash run_complete.sh
    ;;
  quick|full|tests)
    PYTHON="$STUDY_PYTHON" bash run_baseline.sh "$TASK_MODE"
    ;;
  package)
    "$STUDY_PYTHON" verify_paper.py
    "$STUDY_PYTHON" package_paper.py
    ;;
  *)
    echo 'Usage: bash run.sh [paper|verify|reproduce|quick|full|tests|package]'
    exit 2
    ;;
esac
